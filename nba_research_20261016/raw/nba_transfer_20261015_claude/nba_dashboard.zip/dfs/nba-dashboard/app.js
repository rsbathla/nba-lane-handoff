/* ============================================
   NBA Matchup Lab — Application Logic
   ============================================ */

const PLAY_TYPE_ORDER = [
  "C&S", "Pull Up", "<10ft", "Transition", "Spot Up",
  "PnR BH", "ISO", "PnR RM", "Post Up", "Handoff"
];

let DATA = null;
let playerKeys = [];
let playersByTeam = {};
let expandedDefenseTeam = null;
let radarChart = null;

/* ── Sort State ── */
var sortState = {
  matchup: { col: null, dir: null },
  playerDetail: { col: null, dir: null },
  defenseDetail: { col: null, dir: null }
};

/* ── Edge Score Weights ── */
var edgeWeights = {
  pt: 1.2,
  sz: 1.0,
  pos: 0.8,
  env: 1.0,
  t20: 0.5
};
var EDGE_DEFAULTS = { pt: 1.2, sz: 1.0, pos: 0.8, env: 1.0, t20: 0.5 };

function calcEdgeScore(p) {
  return (
    (p.pt_adv_score || 0) * edgeWeights.pt +
    (p.sz_adv_score || 0) * edgeWeights.sz +
    (p.pos_adv_score || 0) * edgeWeights.pos +
    (p.env_score || 0) * edgeWeights.env +
    (p.top20_score || 0) * edgeWeights.t20
  );
}

function calcValue(p) {
  var proj = p.fc_proj || p.dk_fp_avg || 0;
  if (!p.salary || p.salary === 0 || proj === 0) return null;
  return (proj / p.salary) * 1000;
}

function getEdgeScoreHtml(score) {
  var cls, label;
  if (score >= 6) { cls = 'edge-elite'; label = '\u2B50'; }
  else if (score >= 3) { cls = 'edge-good'; label = ''; }
  else if (score >= 1) { cls = 'edge-ok'; label = ''; }
  else if (score <= -2) { cls = 'edge-bad'; label = ''; }
  else { cls = 'edge-neutral'; label = ''; }
  var prefix = score > 0 ? '+' : '';
  return '<span class="edge-score ' + cls + '">' + label + (label ? ' ' : '') + prefix + score.toFixed(1) + '</span>';
}

function getValueHtml(val) {
  if (val === null || val === undefined) return '<span class="val-badge val-avg">\u2014</span>';
  var cls;
  if (val >= 5.5) cls = 'val-great';
  else if (val >= 4.5) cls = 'val-good';
  else if (val >= 3.5) cls = 'val-avg';
  else cls = 'val-bad';
  return '<span class="val-badge ' + cls + '">' + val.toFixed(1) + 'x</span>';
}

var scatterChart = null;

/* ── Helpers ── */
function pct(val) {
  if (val === 0 || val === null || val === undefined) return "0.0%";
  return (val * 100).toFixed(1) + "%";
}

function fmtNum(val, decimals) {
  if (decimals === undefined) decimals = 1;
  if (val === 0 || val === null || val === undefined) return "0.0";
  return val.toFixed(decimals);
}

function getRankClass(rank) {
  if (rank >= 21) return "rank-good";
  if (rank >= 11) return "rank-neutral";
  return "rank-bad";
}

function getRating(rank) {
  if (rank >= 26) return { text: "Elite", cls: "rating-elite" };
  if (rank >= 21) return { text: "Good", cls: "rating-good" };
  if (rank >= 11) return { text: "Neutral", cls: "rating-neutral" };
  return { text: "Tough", cls: "rating-tough" };
}

function getWeaknessBadgeClass(count) {
  if (count >= 4) return "high";
  if (count >= 2) return "medium";
  return "low";
}

function escapeHtml(str) {
  var div = document.createElement("div");
  div.appendChild(document.createTextNode(str));
  return div.innerHTML;
}

/* Percentile badge: 100 = worst defense. Color: green for high pctile (exploitable), red for low */
function pctileBadge(val) {
  if (val == null) return '';
  var cls = 'pctile-mid';
  if (val >= 75) cls = 'pctile-high';
  else if (val >= 50) cls = 'pctile-mid-high';
  else if (val >= 25) cls = 'pctile-mid-low';
  else cls = 'pctile-low';
  var suffix = 'th';
  if (val % 100 !== 11 && val % 10 === 1) suffix = 'st';
  else if (val % 100 !== 12 && val % 10 === 2) suffix = 'nd';
  else if (val % 100 !== 13 && val % 10 === 3) suffix = 'rd';
  return '<span class="pctile-badge ' + cls + '">' + val + suffix + '</span>';
}

function defStatBlock(label, value, pctile, fmt) {
  var valStr = fmt === 'pct' ? (value != null ? (value * 100).toFixed(1) + '%' : '—') : (value != null ? fmtNum(value) : '—');
  return '<div class="def-stat-block"><span class="def-stat-value">' + valStr + '</span>' + pctileBadge(pctile) + '<span class="def-stat-label">' + label + '</span></div>';
}

/* ── Position Vulnerability Helper ── */
var POS_ORDER = ['PG', 'SG', 'SF', 'PF', 'C'];
var expandedPosVuln = {}; /* track which team+pos is expanded: key = 'TEAM_POS' */
function posVulnTier(pctVal) {
  return pctVal >= 55 ? 'hot' : (pctVal >= 48 ? 'warm' : (pctVal < 42 ? 'cold' : ''));
}
function buildPosVulnPlayerTable(team, pos) {
  var players = DATA.pos_vuln_players && DATA.pos_vuln_players[team] && DATA.pos_vuln_players[team][pos];
  if (!players || players.length === 0) return '<div class="pv-no-data">No L7 data</div>';
  var html = '<div class="pv-player-table">';
  html += '<table><thead><tr>';
  html += '<th>Player</th><th>Team</th><th>Date</th><th>Min</th><th>Avg Min</th><th>DK FP</th><th>FP/Min</th><th>Avg FP/Min</th><th>Diff</th><th>Top Play Types</th>';
  html += '</tr></thead><tbody>';
  players.forEach(function(p) {
    var diffCls = p.diff > 0 ? 'positive' : (p.diff < 0 ? 'negative' : '');
    var diffPrefix = p.diff > 0 ? '+' : '';
    var ptHtml = '';
    if (p.top2_pt && p.top2_pt.length > 0) {
      ptHtml = p.top2_pt.map(function(t) {
        return '<span class="pv-pt-chip">' + escapeHtml(t.name) + ' <span class="pv-pt-fga">' + t.fga + '</span></span>';
      }).join(' ');
    } else {
      ptHtml = '\u2014';
    }
    html += '<tr class="' + (p.outperformed ? 'pv-over' : 'pv-under') + '">';
    html += '<td class="pv-name">' + escapeHtml(p.name) + '</td>';
    html += '<td>' + escapeHtml(p.team) + '</td>';
    html += '<td>' + p.date + '</td>';
    html += '<td>' + p.min + '</td>';
    html += '<td>' + (p.avg_min != null ? p.avg_min : '\u2014') + '</td>';
    html += '<td>' + p.dk_fp + '</td>';
    html += '<td>' + p.fp_per_min.toFixed(2) + '</td>';
    html += '<td>' + p.avg_fp_per_min.toFixed(2) + '</td>';
    html += '<td class="pv-diff ' + diffCls + '">' + diffPrefix + p.diff.toFixed(3) + '</td>';
    html += '<td>' + ptHtml + '</td>';
    html += '</tr>';
  });
  html += '</tbody></table></div>';
  return html;
}
function buildPosVuln(team, highlightPos, compact) {
  var vuln = DATA.defense_pos_vulnerability && DATA.defense_pos_vulnerability[team];
  if (!vuln) return '';
  var cls = compact ? ' pos-vuln-compact' : '';
  var html = '<div class="pos-vuln' + cls + '">';
  html += '<div class="pos-vuln-title">Pos FP/Min Outperformance vs ' + escapeHtml(team) + ' DEF <span class="pos-vuln-hint">(click position to expand)</span></div>';
  html += '<div class="pos-vuln-grid">';
  POS_ORDER.forEach(function(pos) {
    var d = vuln[pos];
    if (!d) return;
    var pctVal = d.outperform_pct;
    var tierCls = posVulnTier(pctVal);
    var activeCls = (highlightPos && pos === highlightPos) ? ' active' : '';
    var eKey = team + '_' + pos;
    var isExpanded = expandedPosVuln[eKey];
    html += '<div class="pos-vuln-item ' + tierCls + activeCls + '" data-pv-team="' + team + '" data-pv-pos="' + pos + '" style="cursor:pointer">';
    html += '<div class="pos-vuln-pos">' + pos + ' <span class="pv-expand-icon">' + (isExpanded ? '\u25B2' : '\u25BC') + '</span></div>';
    /* Season line */
    html += '<div class="pos-vuln-pct">' + pctVal.toFixed(1) + '%</div>';
    html += '<div class="pos-vuln-label">Season</div>';
    html += '<div class="pos-vuln-sub">' + d.outperformed + '/' + d.total_games + ' gms</div>';
    html += pctileBadge(d.pctile);
    /* L7 line */
    if (d.l7_outperform_pct != null) {
      var l7Tier = posVulnTier(d.l7_outperform_pct);
      html += '<div class="pos-vuln-l7"><span class="pos-vuln-l7-val ' + l7Tier + '">' + d.l7_outperform_pct.toFixed(1) + '%</span> L7';
      html += ' <span class="pos-vuln-l7-gms">(' + d.l7_outperformed + '/' + d.l7_total_games + ')</span>';
      html += '</div>';
      if (d.l7_pctile != null) html += pctileBadge(d.l7_pctile);
    }
    html += '</div>';
  });
  html += '</div>';
  /* Expanded player tables */
  POS_ORDER.forEach(function(pos) {
    var eKey = team + '_' + pos;
    if (expandedPosVuln[eKey]) {
      html += '<div class="pv-expanded" data-pv-team="' + team + '" data-pv-pos="' + pos + '">';
      html += '<div class="pv-expanded-header">' + pos + ' vs ' + escapeHtml(team) + ' DEF \u2014 L7 Games</div>';
      html += buildPosVulnPlayerTable(team, pos);
      html += '</div>';
    }
  });
  html += '</div>';
  return html;
}
/* Delegated click handler for pos vuln tiles */
document.addEventListener('click', function(e) {
  var tile = e.target.closest('[data-pv-team][data-pv-pos]:not(.pv-expanded)');
  if (!tile) return;
  var team = tile.getAttribute('data-pv-team');
  var pos = tile.getAttribute('data-pv-pos');
  var eKey = team + '_' + pos;
  expandedPosVuln[eKey] = !expandedPosVuln[eKey];
  /* Re-render the current view */
  var activeTab = document.querySelector('.tab-btn.active');
  if (activeTab) {
    var tabId = activeTab.getAttribute('data-tab');
    if (tabId === 'matchup') renderMatchup();
    else if (tabId === 'defense') renderDefenseGrid();
    else if (tabId === 'daily') renderDailyContent();
    else if (tabId === 'posvuln') renderPosVulnTab();
  }
});

/* Unified matchup stat cell: value + optional percentile + label */
function muStat(value, pctile, label) {
  var html = '<div class="mu-stat">';
  html += '<div class="mu-stat-val">' + value + '</div>';
  html += '<div class="mu-stat-pctile">' + (pctile != null ? pctileBadge(pctile) : '<span class="pctile-placeholder"></span>') + '</div>';
  html += '<div class="mu-stat-label">' + label + '</div>';
  html += '</div>';
  return html;
}

/* ── Sort Utilities ── */
function toggleSort(stateKey, colIndex) {
  var s = sortState[stateKey];
  if (s.col === colIndex) {
    if (s.dir === "asc") { s.dir = "desc"; }
    else if (s.dir === "desc") { s.col = null; s.dir = null; }
    else { s.dir = "asc"; }
  } else {
    s.col = colIndex;
    s.dir = "asc";
  }
}

function sortHeaderClass(stateKey, colIndex) {
  var s = sortState[stateKey];
  if (s.col === colIndex) {
    return s.dir === "asc" ? "sortable sort-asc" : "sortable sort-desc";
  }
  return "sortable";
}

function sortRows(rows, stateKey) {
  var s = sortState[stateKey];
  if (s.col === null || s.dir === null) return rows;
  var col = s.col;
  var dir = s.dir === "asc" ? 1 : -1;
  return rows.slice().sort(function(a, b) {
    var va = a[col];
    var vb = b[col];
    if (typeof va === "string" && typeof vb === "string") {
      return dir * va.localeCompare(vb);
    }
    va = (va === null || va === undefined) ? -Infinity : va;
    vb = (vb === null || vb === undefined) ? -Infinity : vb;
    return dir * (va - vb);
  });
}

/* ── Data Loading ── */
async function loadData() {
  var resp = await fetch("./data.json");
  DATA = await resp.json();

  playerKeys = Object.keys(DATA.players).sort(function(a, b) {
    var pa = DATA.players[a];
    var pb = DATA.players[b];
    if (pa.team !== pb.team) return pa.team.localeCompare(pb.team);
    return pa.name.localeCompare(pb.name);
  });

  playersByTeam = {};
  playerKeys.forEach(function(key) {
    var p = DATA.players[key];
    if (!playersByTeam[p.team]) playersByTeam[p.team] = [];
    playersByTeam[p.team].push(key);
  });

  initUI();
}

/* ── Initialize UI ── */
function initUI() {
  initTabs();
  initMatchupFinder();
  initPlayerProfiles();
  initDefenseProfiles();
  initDailyMatchup();
}

/* ── Tab Navigation ── */
function initTabs() {
  var buttons = document.querySelectorAll(".tab-btn");
  buttons.forEach(function(btn) {
    btn.addEventListener("click", function() {
      var tabId = btn.getAttribute("data-tab");
      switchTab(tabId);
    });
  });
}

function switchTab(tabId) {
  document.querySelectorAll(".tab-btn").forEach(function(b) {
    b.classList.remove("active");
    b.setAttribute("aria-selected", "false");
  });
  document.querySelectorAll(".tab-panel").forEach(function(p) {
    p.classList.remove("active");
  });

  var tabBtn = document.querySelector("[data-tab=\"" + tabId + "\"]");
  var panel = document.getElementById("panel-" + tabId);
  if (tabBtn) {
    tabBtn.classList.add("active");
    tabBtn.setAttribute("aria-selected", "true");
  }
  if (panel) panel.classList.add("active");
}

/* ==========================================
   TAB 1: MATCHUP FINDER
   ========================================== */
var selectedPlayerKey = null;
var selectedOpponent = null;
var dropdownHighlightIndex = -1;
var filteredDropdownItems = [];

function initMatchupFinder() {
  populateOpponentSelect();
  initPlayerSearchDropdown();

  document.getElementById("opponent-select").addEventListener("change", function(e) {
    selectedOpponent = e.target.value || null;
    renderMatchup();
  });
}

function populateOpponentSelect() {
  var select = document.getElementById("opponent-select");
  DATA.teams.forEach(function(team) {
    var opt = document.createElement("option");
    opt.value = team;
    opt.textContent = team;
    select.appendChild(opt);
  });
}

function initPlayerSearchDropdown() {
  var input = document.getElementById("player-search");
  var list = document.getElementById("player-list");

  input.addEventListener("focus", function() {
    renderDropdownList("");
    list.classList.add("open");
    input.setAttribute("aria-expanded", "true");
  });

  input.addEventListener("input", function() {
    var query = input.value.trim().toLowerCase();
    renderDropdownList(query);
    list.classList.add("open");
    input.setAttribute("aria-expanded", "true");
    dropdownHighlightIndex = -1;
  });

  input.addEventListener("keydown", function(e) {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      dropdownHighlightIndex = Math.min(dropdownHighlightIndex + 1, filteredDropdownItems.length - 1);
      updateDropdownHighlight();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      dropdownHighlightIndex = Math.max(dropdownHighlightIndex - 1, 0);
      updateDropdownHighlight();
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (dropdownHighlightIndex >= 0 && filteredDropdownItems[dropdownHighlightIndex]) {
        selectPlayer(filteredDropdownItems[dropdownHighlightIndex]);
        list.classList.remove("open");
        input.setAttribute("aria-expanded", "false");
      }
    } else if (e.key === "Escape") {
      list.classList.remove("open");
      input.setAttribute("aria-expanded", "false");
      input.blur();
    }
  });

  document.addEventListener("click", function(e) {
    if (!e.target.closest("#player-dropdown")) {
      list.classList.remove("open");
      input.setAttribute("aria-expanded", "false");
    }
  });
}

function renderDropdownList(query) {
  var list = document.getElementById("player-list");
  list.innerHTML = "";
  filteredDropdownItems = [];
  dropdownHighlightIndex = -1;

  var teams = DATA.teams;
  teams.forEach(function(team) {
    var teamPlayers = playersByTeam[team] || [];
    var filtered = teamPlayers.filter(function(key) {
      if (!query) return true;
      var p = DATA.players[key];
      return p.name.toLowerCase().indexOf(query) !== -1 || p.team.toLowerCase().indexOf(query) !== -1;
    });

    if (filtered.length === 0) return;

    var header = document.createElement("div");
    header.className = "dropdown-team-header";
    header.textContent = team;
    list.appendChild(header);

    filtered.forEach(function(key) {
      var p = DATA.players[key];
      var item = document.createElement("div");
      item.className = "dropdown-item";
      item.setAttribute("role", "option");
      item.setAttribute("data-key", key);
      item.innerHTML = escapeHtml(p.name) + " <span class=\"team-tag\">(" + escapeHtml(p.team) + ")</span>";
      item.addEventListener("click", function() {
        selectPlayer(key);
        document.getElementById("player-list").classList.remove("open");
        document.getElementById("player-search").setAttribute("aria-expanded", "false");
      });
      list.appendChild(item);
      filteredDropdownItems.push(key);
    });
  });
}

function updateDropdownHighlight() {
  var items = document.querySelectorAll("#player-list .dropdown-item");
  items.forEach(function(item, i) {
    item.classList.toggle("highlighted", i === dropdownHighlightIndex);
    if (i === dropdownHighlightIndex) {
      item.scrollIntoView({ block: "nearest" });
    }
  });
}

function selectPlayer(key) {
  selectedPlayerKey = key;
  var p = DATA.players[key];
  var input = document.getElementById("player-search");
  input.value = p.name + " (" + p.team + ")";
  renderMatchup();
}

function renderMatchup() {
  var container = document.getElementById("matchup-result");

  if (!selectedPlayerKey || !selectedOpponent) {
    container.innerHTML = "<div class=\"empty-state\">" +
      "<div class=\"empty-state-icon\"><svg width=\"48\" height=\"48\" viewBox=\"0 0 48 48\" fill=\"none\" aria-hidden=\"true\"><circle cx=\"24\" cy=\"24\" r=\"20\" stroke=\"#6b7280\" stroke-width=\"2\" stroke-dasharray=\"4 4\"/><path d=\"M18 24h12M24 18v12\" stroke=\"#6b7280\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg></div>" +
      "<div class=\"empty-state-title\">Select a Player &amp; Opponent</div>" +
      "<div class=\"empty-state-text\">Choose a player and opposing team to analyze the matchup</div></div>";
    return;
  }

  var player = DATA.players[selectedPlayerKey];
  var defense = DATA.defenses[selectedOpponent];
  if (!player || !defense) return;

  var html = "<div class=\"matchup-card\">";

  /* ── Unified Matchup Header ── */
  html += "<div class=\"mu-header\">";

  /* Row 1: Names */
  html += "<div class=\"mu-names\">";
  html += "<div class=\"mu-name-left\">";
  html += "<div class=\"mu-name\">" + escapeHtml(player.name) + "</div>";
  html += "<div class=\"mu-meta\">" + escapeHtml(player.team) + (player.position ? " &middot; " + escapeHtml(player.position) : "") + " &middot; Age " + player.age + " &middot; " + player.games + " GP" + (player.avg_min != null ? " &middot; " + fmtNum(player.avg_min) + " MIN" : "") + "</div>";
  html += "</div>";
  html += "<div class=\"mu-vs\">VS</div>";
  html += "<div class=\"mu-name-right\">";
  html += "<div class=\"mu-name\">" + escapeHtml(defense.team) + " DEF</div>";
  html += "<div class=\"mu-meta\">" + defense.weakness_count + " weaknesses</div>";
  html += "</div>";
  html += "</div>";

  /* Row 2: Stats grid — player left, defense right, aligned */
  html += "<div class=\"mu-stats-grid\">";

  /* Player stats */
  html += "<div class=\"mu-side mu-side-player\">";
  html += "<div class=\"mu-side-label\">PLAYER</div>";
  html += "<div class=\"mu-stat-row\">";
  html += muStat(fmtNum(player.overall_fga), null, 'FGA');
  html += muStat(pct(player.overall_fg_pct), null, 'FG%');
  html += muStat(player.usage_rate != null ? fmtNum(player.usage_rate) + '%' : '—', null, 'USG%');
  html += muStat(player.dk_fp != null ? fmtNum(player.dk_fp) : '—', null, 'DK FP');
  html += muStat(player.fd_fp != null ? fmtNum(player.fd_fp) : '—', null, 'FD FP');
  html += "</div></div>";

  /* Defense stats */
  html += "<div class=\"mu-side mu-side-defense\">";
  html += "<div class=\"mu-side-label\">DEFENSE</div>";
  html += "<div class=\"mu-stat-row\">";
  html += muStat(pct(defense.overall_fg_allowed), defense.fg_pct_allowed_pctile, 'FG% Allowed');
  html += muStat(fmtNum(defense.overall_fga_allowed), defense.fga_allowed_pctile, 'FGA Allowed');
  html += muStat(defense.def_eff != null ? fmtNum(defense.def_eff) : '—', defense.def_eff_pctile, 'Def Eff');
  html += muStat(defense.pace != null ? fmtNum(defense.pace) : '—', defense.pace_pctile, 'Pace');
  html += muStat(defense.fgm_allowed != null ? fmtNum(defense.fgm_allowed) : '—', defense.fgm_allowed_pctile, 'FGM Allowed');
  html += "</div></div>";

  html += "</div>"; /* mu-stats-grid */

  /* Position Vulnerability — highlight player's position */
  html += buildPosVuln(selectedOpponent, player.position || null, false);

  html += "</div>"; /* mu-header */

  /* Table */
  var matchupHeaders = ["Play Type", "Player FGA", "Player FG%", "Freq", "Def Rank", "Def L7 FG%", "Def L7 FGA", "Rating"];
  html += "<div class=\"matchup-table-wrap\">";
  html += "<table class=\"matchup-table\">";
  html += "<thead><tr>";
  matchupHeaders.forEach(function(h, i) {
    html += "<th class=\"" + sortHeaderClass("matchup", i) + "\" data-sort-key=\"matchup\" data-sort-col=\"" + i + "\">" + h + "</th>";
  });
  html += "</tr></thead><tbody>";

  var exploitable = [];
  var avoidable = [];

  /* Build row data for sorting */
  var matchupRows = [];
  PLAY_TYPE_ORDER.forEach(function(pt) {
    var pp = player.play_types[pt] || { fga: 0, fg_pct: 0, freq: 0 };
    var dp = defense.play_types[pt] || { final_rank: 15, l7_fg_pct: 0, l7_fga: 0 };
    var rank = dp.final_rank;
    var rating = getRating(rank);
    /* sortValues: [playType, fga, fg_pct, freq, rank, l7_fg_pct, l7_fga, ratingSort] */
    matchupRows.push([pt, pp.fga, pp.fg_pct, pp.freq, rank, dp.l7_fg_pct, dp.l7_fga, rank]);

    if (pp.fga >= 1.5 && rank >= 21) {
      exploitable.push(pt + " (Rank " + rank + ", " + fmtNum(pp.fga) + " FGA)");
    }
    if (pp.fga >= 1.5 && rank <= 10) {
      avoidable.push(pt + " (Rank " + rank + ", " + fmtNum(pp.fga) + " FGA)");
    }
  });

  var sortedMatchupRows = sortRows(matchupRows, "matchup");
  sortedMatchupRows.forEach(function(row) {
    var pt = row[0];
    var fga = row[1];
    var fg_pct = row[2];
    var freq = row[3];
    var rank = row[4];
    var l7_fg_pct = row[5];
    var l7_fga = row[6];
    var rating = getRating(rank);
    var isExploitable = fga >= 2.0 && rank >= 21;

    var trClass = isExploitable ? " class=\"exploitable\"" : "";
    html += "<tr" + trClass + ">";
    html += "<td>" + escapeHtml(pt) + "</td>";
    html += "<td>" + fmtNum(fga) + "</td>";
    html += "<td>" + pct(fg_pct) + "</td>";
    html += "<td>" + pct(freq) + "</td>";
    html += "<td><span class=\"rank-badge " + getRankClass(rank) + "\">" + rank + "</span></td>";
    html += "<td>" + pct(l7_fg_pct) + "</td>";
    html += "<td>" + fmtNum(l7_fga) + "</td>";
    html += "<td><span class=\"rating-badge " + rating.cls + "\">" + rating.text + "</span></td>";
    html += "</tr>";
  });

  html += "</tbody></table></div>";

  /* Takeaways */
  html += "<div class=\"takeaways\">";
  html += "<div class=\"takeaways-title\">Key Takeaways</div>";

  if (exploitable.length > 0) {
    html += "<div class=\"takeaway-group\">";
    html += "<div class=\"takeaway-label exploit\">&#9650; Exploitable</div>";
    html += "<div class=\"takeaway-items\">";
    exploitable.forEach(function(item) {
      html += "<span class=\"takeaway-chip exploit\">" + escapeHtml(item) + "</span>";
    });
    html += "</div></div>";
  }

  if (avoidable.length > 0) {
    html += "<div class=\"takeaway-group\">";
    html += "<div class=\"takeaway-label avoid\">&#9660; Avoid</div>";
    html += "<div class=\"takeaway-items\">";
    avoidable.forEach(function(item) {
      html += "<span class=\"takeaway-chip avoid\">" + escapeHtml(item) + "</span>";
    });
    html += "</div></div>";
  }

  if (exploitable.length === 0 && avoidable.length === 0) {
    html += "<div style=\"font-size:var(--text-sm);color:var(--text-muted)\">No strong exploitable or avoidable matchups detected for this player's volume play types.</div>";
  }

  html += "</div></div>";
  container.innerHTML = html;
}

/* ==========================================
   TAB 2: PLAYER PROFILES
   ========================================== */
var selectedProfileKey = null;

function initPlayerProfiles() {
  renderPlayerList("");
  document.getElementById("profiles-search").addEventListener("input", function(e) {
    renderPlayerList(e.target.value.trim().toLowerCase());
  });
}

function renderPlayerList(query) {
  var container = document.getElementById("profiles-list");
  container.innerHTML = "";

  DATA.teams.forEach(function(team) {
    var teamPlayers = playersByTeam[team] || [];
    var filtered = teamPlayers.filter(function(key) {
      if (!query) return true;
      var p = DATA.players[key];
      return p.name.toLowerCase().indexOf(query) !== -1 || p.team.toLowerCase().indexOf(query) !== -1;
    });

    if (filtered.length === 0) return;

    var header = document.createElement("div");
    header.className = "player-list-team-header";
    header.textContent = team + " (" + filtered.length + ")";
    container.appendChild(header);

    filtered.forEach(function(key) {
      var p = DATA.players[key];
      var item = document.createElement("div");
      item.className = "player-list-item";
      if (key === selectedProfileKey) item.classList.add("selected");
      item.textContent = p.name;
      item.setAttribute("data-key", key);
      item.addEventListener("click", function() {
        selectProfile(key);
      });
      container.appendChild(item);
    });
  });
}

function selectProfile(key) {
  selectedProfileKey = key;

  /* Update selection visual */
  document.querySelectorAll(".player-list-item").forEach(function(item) {
    item.classList.toggle("selected", item.getAttribute("data-key") === key);
  });

  renderPlayerDetail(key);
}

function renderPlayerDetail(key) {
  var container = document.getElementById("player-detail");
  var player = DATA.players[key];
  if (!player) return;

  /* Sort play types by FGA descending for bar chart */
  var sortedPT = PLAY_TYPE_ORDER.slice().sort(function(a, b) {
    var fa = (player.play_types[a] || {}).fga || 0;
    var fb = (player.play_types[b] || {}).fga || 0;
    return fb - fa;
  });

  var maxFGA = sortedPT.reduce(function(max, pt) {
    var val = (player.play_types[pt] || {}).fga || 0;
    return Math.max(max, val);
  }, 0.1);

  var top3 = sortedPT.slice(0, 3).map(function(pt) { return pt; });

  var html = "";
  html += "<div class=\"player-detail-header\">";
  html += "<div class=\"player-detail-name\">" + escapeHtml(player.name) + "</div>";
  html += "<div class=\"player-detail-meta\">";
  html += "<span>" + escapeHtml(player.team) + "</span>";
  if (player.position) html += "<span>" + escapeHtml(player.position) + "</span>";
  html += "<span>Age " + player.age + "</span>";
  html += "<span>" + player.games + " GP</span>";
  html += (player.avg_min != null ? "<span>" + fmtNum(player.avg_min) + " MIN</span>" : "");
  html += "<span>" + fmtNum(player.overall_fga) + " FGA</span>";
  html += "<span>" + pct(player.overall_fg_pct) + " FG%</span>";
  if (player.usage_rate != null) html += "<span>" + fmtNum(player.usage_rate) + "% USG</span>";
  if (player.dk_fp != null) html += "<span>" + fmtNum(player.dk_fp) + " DK</span>";
  if (player.fd_fp != null) html += "<span>" + fmtNum(player.fd_fp) + " FD</span>";
  html += "</div></div>";

  /* Bar chart */
  html += "<div class=\"bar-chart\">";
  sortedPT.forEach(function(pt) {
    var pp = player.play_types[pt] || { fga: 0 };
    var widthPct = maxFGA > 0 ? (pp.fga / maxFGA * 100) : 0;
    var isTop3 = top3.indexOf(pt) !== -1 && pp.fga > 0;
    html += "<div class=\"bar-row\">";
    html += "<div class=\"bar-label\">" + escapeHtml(pt) + "</div>";
    html += "<div class=\"bar-track\"><div class=\"bar-fill" + (isTop3 ? " top-3" : "") + "\" style=\"width:" + widthPct.toFixed(1) + "%\"></div></div>";
    html += "<div class=\"bar-value\">" + fmtNum(pp.fga) + "</div>";
    html += "</div>";
  });
  html += "</div>";

  /* Data table */
  var pdHeaders = ["Play Type", "FGA", "FG%", "Freq"];
  html += "<table class=\"data-table\">";
  html += "<thead><tr>";
  pdHeaders.forEach(function(h, i) {
    html += "<th class=\"" + sortHeaderClass("playerDetail", i) + "\" data-sort-key=\"playerDetail\" data-sort-col=\"" + i + "\">" + h + "</th>";
  });
  html += "</tr></thead><tbody>";

  var pdRows = [];
  PLAY_TYPE_ORDER.forEach(function(pt) {
    var pp = player.play_types[pt] || { fga: 0, fg_pct: 0, freq: 0 };
    pdRows.push([pt, pp.fga, pp.fg_pct, pp.freq]);
  });
  var sortedPDRows = sortRows(pdRows, "playerDetail");
  sortedPDRows.forEach(function(row) {
    html += "<tr><td>" + escapeHtml(row[0]) + "</td><td>" + fmtNum(row[1]) + "</td><td>" + pct(row[2]) + "</td><td>" + pct(row[3]) + "</td></tr>";
  });
  html += "</tbody></table>";

  container.innerHTML = html;
}

/* ==========================================
   TAB 3: DEFENSE PROFILES
   ========================================== */
function initDefenseProfiles() {
  renderDefenseGrid();
}

function renderDefenseGrid() {
  var container = document.getElementById("defense-grid");
  container.innerHTML = "";

  /* Sort by weakness_count desc */
  var sortedTeams = DATA.teams.slice().sort(function(a, b) {
    return (DATA.defenses[b].weakness_count || 0) - (DATA.defenses[a].weakness_count || 0);
  });

  sortedTeams.forEach(function(team) {
    var defense = DATA.defenses[team];
    var card = document.createElement("div");
    card.className = "defense-card";
    card.setAttribute("data-team", team);

    if (team === expandedDefenseTeam) {
      card.classList.add("expanded");
    }

    var html = "";
    html += "<div class=\"defense-card-header\">";
    html += "<span class=\"defense-team-name\">" + escapeHtml(team) + "</span>";
    html += "<span class=\"weakness-badge " + getWeaknessBadgeClass(defense.weakness_count) + "\">" + defense.weakness_count + " weak</span>";
    html += "</div>";

    /* Overall stats */
    html += "<div class=\"def-enhanced-stats compact\">";
    html += defStatBlock('FG% Allowed', defense.overall_fg_allowed, defense.fg_pct_allowed_pctile, 'pct');
    html += defStatBlock('FGA Allowed', defense.overall_fga_allowed, defense.fga_allowed_pctile);
    html += defStatBlock('Def Eff', defense.def_eff, defense.def_eff_pctile);
    html += defStatBlock('Pace', defense.pace, defense.pace_pctile);
    html += defStatBlock('FGM', defense.fgm_allowed, defense.fgm_allowed_pctile);
    html += "</div>";

    html += "<div class=\"defense-card-body\">";

    if (defense.weaknesses && defense.weaknesses.length > 0) {
      html += "<div class=\"defense-card-section\">";
      html += "<div class=\"defense-card-section-title weak\">Weaknesses</div>";
      html += "<div class=\"defense-chip-list\">";
      defense.weaknesses.forEach(function(w) {
        html += "<span class=\"defense-chip weak\">" + escapeHtml(w.type) + " <span class=\"chip-rank\">#" + w.rank + "</span></span>";
      });
      html += "</div></div>";
    }

    if (defense.strengths && defense.strengths.length > 0) {
      html += "<div class=\"defense-card-section\">";
      html += "<div class=\"defense-card-section-title strong\">Strengths</div>";
      html += "<div class=\"defense-chip-list\">";
      defense.strengths.forEach(function(s) {
        html += "<span class=\"defense-chip strong\">" + escapeHtml(s.type) + " <span class=\"chip-rank\">#" + s.rank + "</span></span>";
      });
      html += "</div></div>";
    }

    html += "</div>";

    /* Position Vulnerability */
    html += buildPosVuln(team, null, true);

    /* Expanded detail */
    if (team === expandedDefenseTeam) {
      html += buildDefenseDetail(defense);
    }

    card.innerHTML = html;

    card.addEventListener("click", function() {
      if (expandedDefenseTeam === team) {
        expandedDefenseTeam = null;
      } else {
        expandedDefenseTeam = team;
      }
      renderDefenseGrid();
    });

    container.appendChild(card);
  });

  /* Render radar chart if expanded */
  if (expandedDefenseTeam) {
    var canvasEl = document.getElementById("radar-canvas-" + expandedDefenseTeam);
    if (canvasEl) {
      renderRadarChart(canvasEl, DATA.defenses[expandedDefenseTeam]);
    }
  }
}

function buildDefenseDetail(defense) {
  var html = "<div class=\"defense-detail\">";

  /* Table */
  var ddHeaders = ["Play Type", "Rank", "L7 FG%", "L7 FGA", "Ssn FG%", "Ssn FGA"];
  html += "<div><table class=\"defense-detail-table\">";
  html += "<thead><tr>";
  ddHeaders.forEach(function(h, i) {
    html += "<th class=\"" + sortHeaderClass("defenseDetail", i) + "\" data-sort-key=\"defenseDetail\" data-sort-col=\"" + i + "\">" + h + "</th>";
  });
  html += "</tr></thead><tbody>";

  var ddRows = [];
  PLAY_TYPE_ORDER.forEach(function(pt) {
    var dp = defense.play_types[pt] || {};
    var rank = dp.final_rank || 15;
    ddRows.push([pt, rank, dp.l7_fg_pct || 0, dp.l7_fga || 0, dp.season_fg_pct || 0, dp.season_fga || 0]);
  });
  var sortedDDRows = sortRows(ddRows, "defenseDetail");
  sortedDDRows.forEach(function(row) {
    var rank = row[1];
    html += "<tr>";
    html += "<td>" + escapeHtml(row[0]) + "</td>";
    html += "<td><span class=\"rank-badge " + getRankClass(rank) + "\">" + rank + "</span></td>";
    html += "<td>" + pct(row[2]) + "</td>";
    html += "<td>" + fmtNum(row[3]) + "</td>";
    html += "<td>" + pct(row[4]) + "</td>";
    html += "<td>" + fmtNum(row[5]) + "</td>";
    html += "</tr>";
  });

  html += "</tbody></table></div>";

  /* Radar chart */
  html += "<div class=\"radar-container\"><canvas id=\"radar-canvas-" + escapeHtml(defense.team) + "\" width=\"280\" height=\"280\"></canvas></div>";

  html += "</div>";
  return html;
}

function renderRadarChart(canvas, defense) {
  var labels = PLAY_TYPE_ORDER.map(function(pt) { return pt; });
  var dataValues = PLAY_TYPE_ORDER.map(function(pt) {
    var dp = defense.play_types[pt] || {};
    return dp.final_rank || 15;
  });

  if (radarChart) {
    radarChart.destroy();
    radarChart = null;
  }

  radarChart = new Chart(canvas, {
    type: "radar",
    data: {
      labels: labels,
      datasets: [{
        label: "Defensive Rank",
        data: dataValues,
        backgroundColor: "rgba(59, 130, 246, 0.15)",
        borderColor: "#3b82f6",
        borderWidth: 2,
        pointBackgroundColor: dataValues.map(function(v) {
          if (v >= 21) return "#10b981";
          if (v >= 11) return "#f59e0b";
          return "#ef4444";
        }),
        pointBorderColor: "transparent",
        pointRadius: 5,
        pointHoverRadius: 7
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      scales: {
        r: {
          min: 0,
          max: 30,
          ticks: {
            stepSize: 10,
            color: "#6b7280",
            backdropColor: "transparent",
            font: { size: 10 }
          },
          grid: {
            color: "rgba(255,255,255,0.06)"
          },
          angleLines: {
            color: "rgba(255,255,255,0.06)"
          },
          pointLabels: {
            color: "#9ca3af",
            font: {
              size: 11,
              family: "'Inter', sans-serif"
            }
          }
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#1a2332",
          titleColor: "#e5e7eb",
          bodyColor: "#9ca3af",
          borderColor: "#1f2937",
          borderWidth: 1,
          padding: 10,
          titleFont: { family: "'Inter', sans-serif", size: 12 },
          bodyFont: { family: "'Inter', sans-serif", size: 11 },
          callbacks: {
            label: function(ctx) {
              var rank = ctx.raw;
              var label = rank >= 21 ? "Weakness" : (rank >= 11 ? "Average" : "Strength");
              return "Rank " + rank + " (" + label + ")";
            }
          }
        }
      }
    }
  });
}

/* ── Sort Click Handler (event delegation) ── */
document.addEventListener("click", function(e) {
  var th = e.target.closest("th.sortable");
  if (!th) return;
  var key = th.getAttribute("data-sort-key");
  var col = parseInt(th.getAttribute("data-sort-col"), 10);
  if (!key || isNaN(col)) return;

  toggleSort(key, col);

  /* Re-render the appropriate table */
  if (key === "matchup") {
    renderMatchup();
  } else if (key === "playerDetail" && selectedProfileKey) {
    renderPlayerDetail(selectedProfileKey);
  } else if (key === "defenseDetail" && expandedDefenseTeam) {
    renderDefenseGrid();
  } else if (key === "dailyAll") {
    renderDailyAllPlayers();
  } else if (key.indexOf("dg_") === 0) {
    renderDailyByGame();
  }
});



/* ==========================================
   TAB 4: DAILY MATCHUP (Upload-Driven)
   ========================================== */
var dailyView = 'games';
var dailyPlayers = [];   /* parsed from CSV + enriched */
var dailyGames = [];     /* unique game matchups */

sortState.dailyAll = { col: null, dir: null };
var dailyGameSortStates = {};

/* ── Team Abbreviation Map ── */
var TEAM_ABBR_MAP = {
  'ATL': 'ATL', 'BOS': 'BOS', 'BKN': 'BKN', 'CHA': 'CHA', 'CHI': 'CHI',
  'CLE': 'CLE', 'DAL': 'DAL', 'DEN': 'DEN', 'DET': 'DET', 'GSW': 'GSW',
  'GS': 'GSW', 'HOU': 'HOU', 'IND': 'IND', 'LAC': 'LAC', 'LAL': 'LAL',
  'MEM': 'MEM', 'MIA': 'MIA', 'MIL': 'MIL', 'MIN': 'MIN', 'NOP': 'NOP',
  'NO': 'NOP', 'NYK': 'NYK', 'NY': 'NYK', 'OKC': 'OKC', 'ORL': 'ORL',
  'PHI': 'PHI', 'PHX': 'PHX', 'POR': 'POR', 'SAC': 'SAC', 'SAS': 'SAS',
  'SA': 'SAS', 'TOR': 'TOR', 'UTA': 'UTA', 'WAS': 'WAS'
};

function normTeam(raw) {
  if (!raw) return '';
  var t = raw.replace(/^@\s*/i, '').replace(/^vs\s*/i, '').trim().toUpperCase();
  return TEAM_ABBR_MAP[t] || t;
}

/* ── CSV Parsing ── */
function parseCSVLine(line) {
  var result = [];
  var current = '';
  var inQuotes = false;
  for (var i = 0; i < line.length; i++) {
    var ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (i + 1 < line.length && line[i + 1] === '"') {
          current += '"'; i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        result.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
  }
  result.push(current.trim());
  return result;
}

function parseDKCSV(text) {
  var lines = text.split(/\r?\n/).filter(function(l) { return l.trim().length > 0; });
  if (lines.length < 3) return [];

  /* Header row is line index 1 (row 0 is group headers) */
  var headers = parseCSVLine(lines[1]);
  var nameIdx = headers.indexOf('Player');
  var posIdx = headers.indexOf('Pos');
  var salaryIdx = headers.indexOf('Salary');
  var teamIdx = headers.indexOf('Team');
  var oppIdx = headers.indexOf('Opp');
  var totalIdx = headers.indexOf('Total');
  var fcProjIdx = -1;

  /* Find FC Proj column — it's labeled 'FC Proj' in the headers */
  for (var h = 0; h < headers.length; h++) {
    if (headers[h] === 'FC Proj') { fcProjIdx = h; break; }
  }
  /* Fallback: season average 'FPs' column */
  var fpsIdx = headers.indexOf('FPs');

  /* Find projected minutes column */
  var minsIdx = -1;
  for (var h2 = 0; h2 < headers.length; h2++) {
    if (headers[h2] === 'Proj Mins') { minsIdx = h2; break; }
  }
  /* Fallback: season average 'Min' column */
  var avgMinIdx = headers.indexOf('Min');

  var players = [];
  for (var i = 2; i < lines.length; i++) {
    var cols = parseCSVLine(lines[i]);
    if (cols.length < 5) continue;
    var name = cols[nameIdx] || '';
    if (!name) continue;

    var projMins = minsIdx >= 0 ? parseFloat(cols[minsIdx]) || 0 : 0;
    /* If Proj Mins looks like a placeholder (< 10), fall back to season avg Min */
    if (projMins < 10 && avgMinIdx >= 0) {
      projMins = parseFloat(cols[avgMinIdx]) || 0;
    }
    if (projMins < 15) continue; /* Filter < 15 min projection */

    var team = normTeam(cols[teamIdx]);
    var oppRaw = cols[oppIdx] || '';
    var isAway = oppRaw.indexOf('@') === -1; /* if Opp has no @, player's team col has no @ either — DK puts @ on the away column */
    var opp = normTeam(oppRaw);

    players.push({
      name: name,
      pos: cols[posIdx] || '',
      salary: parseInt(cols[salaryIdx]) || 0,
      team: team,
      opponent: opp,
      total: parseFloat(cols[totalIdx]) || 0,
      fc_proj: (function() { var v = fcProjIdx >= 0 ? parseFloat(cols[fcProjIdx]) || 0 : 0; if (v < 10 && fpsIdx >= 0) v = parseFloat(cols[fpsIdx]) || 0; return v; })(),
      proj_mins: projMins
    });
  }
  return players;
}

/* ── Enrich Players ── */
function enrichDailyPlayers(rawPlayers) {
  var splits = DATA.player_splits || {};
  var playersDB = DATA.players || {};
  var defenses = DATA.defenses || {};
  var teamEnv = DATA.team_environment || {};
  var medians = (DATA.daily_matchup || {}).environment_medians || { pace: 94.8, def_eff: 118.9 };
  var playerShotZones = DATA.player_shot_zones || {};
  var defShotZones = DATA.defense_shot_zones || {};

  return rawPlayers.map(function(p) {
    /* Find split data — try name match */
    var split = splits[p.name] || null;

    /* Find player DB entry — try Name|TEAM */
    var playerKey = p.name + '|' + p.team;
    var playerDB = playersDB[playerKey] || null;

    /* If no exact match on name in splits, try fuzzy */
    if (!split) {
      var nameNorm = p.name.replace(/\./g, '').replace(/'/g, "'").toLowerCase();
      for (var sk in splits) {
        var skNorm = sk.replace(/\./g, '').replace(/'/g, "'").toLowerCase();
        if (skNorm === nameNorm || (splits[sk].team === p.team && skNorm.indexOf(nameNorm.split(' ').pop()) !== -1)) {
          split = splits[sk];
          break;
        }
      }
    }

    /* If no exact match on playerDB, try name fuzzy */
    if (!playerDB) {
      for (var pk in playersDB) {
        if (pk.indexOf(p.name) === 0 || pk.split('|')[0] === p.name) {
          playerDB = playersDB[pk];
          break;
        }
      }
    }

    var oppDef = defenses[p.opponent] || null;
    var oppEnv = teamEnv[p.opponent] || null;
    var playerTeamEnv = teamEnv[p.team] || null;

    /* Expected game pace */
    var expectedPace = 0;
    if (playerTeamEnv && oppEnv) {
      expectedPace = (playerTeamEnv.avg_pace + oppEnv.avg_pace) / 2;
    }

    /* Environment scoring */
    var envScore = 0;
    var envNotes = [];

    if (split && oppEnv) {
      /* Pace preference */
      var isFast = expectedPace > medians.pace;
      if (split.pace_pref === 'fast' && isFast) { envScore += 1; envNotes.push('Thrives in fast pace'); }
      else if (split.pace_pref === 'fast' && !isFast) { envScore -= 1; envNotes.push('Prefers faster pace'); }
      else if (split.pace_pref === 'slow' && !isFast) { envScore += 1; envNotes.push('Thrives in slow pace'); }
      else if (split.pace_pref === 'slow' && isFast) { envScore -= 1; envNotes.push('Prefers slower pace'); }

      /* Defensive weakness exploitation */
      var oppDefEff = oppEnv.avg_def_eff || medians.def_eff;
      var isWeakDef = oppDefEff > medians.def_eff;
      if (split.def_boost === 'yes' && isWeakDef) { envScore += 2; envNotes.push('Exploits weak defense'); }
      else if (split.def_boost === 'yes' && !isWeakDef) { envScore -= 1; envNotes.push('Struggles vs elite D'); }
      else if (split.def_boost === 'no' && !isWeakDef) { envScore += 1; }

      /* Bonus for aligned pace + defense */
      if (envScore >= 2) envNotes.push('Top environment');
    }

    /* Yahoo position lookup for pos vulnerability */
    var yahooPositions = DATA.player_positions || {};
    var yahooPos = yahooPositions[p.name] || p.pos.split('/')[0]; /* fallback to first DK pos */
    /* Normalize multi-pos to single */
    if (yahooPos.indexOf('/') !== -1) yahooPos = yahooPos.split('/')[0];

    /* Position vulnerability vs opponent defense */
    var posVuln = DATA.defense_pos_vulnerability || {};
    var oppPosVuln = posVuln[p.opponent] && posVuln[p.opponent][yahooPos];
    var posAdvL7 = oppPosVuln ? oppPosVuln.l7_outperform_pct : null;
    var posAdvL7Pctile = oppPosVuln ? oppPosVuln.l7_pctile : null;
    var posAdvSzn = oppPosVuln ? oppPosVuln.outperform_pct : null;
    var posAdvSznPctile = oppPosVuln ? oppPosVuln.pctile : null;

    /* Shot zone data */
    var szPlayer = playerShotZones[p.name] || null;
    var szOppDef = defShotZones[p.opponent] || null;

    /* Volume multiplier: higher share = bigger impact */
    function volMult(sharePct) {
      if (sharePct >= 60) return 2;
      if (sharePct >= 40) return 1.5;
      return 1;
    }

    /* ── Shot Zone Advantage Score ── */
    var szAdvScore = 0;
    var szAdvNotes = [];
    if (szPlayer && szOppDef) {
      var zoneChecks = [
        { name: 'PITP', share: szPlayer.avg_pitp_share || 0, defRank: szOppDef.pitp_def_rank || 15 },
        { name: 'Mid', share: szPlayer.avg_mid_share || 0, defRank: szOppDef.mid_def_rank || 15 },
        { name: '3PT', share: szPlayer.avg_3pt_share || 0, defRank: szOppDef['3pt_def_rank'] || 15 }
      ];
      zoneChecks.forEach(function(z) {
        if (z.share >= 20) {
          var mult = volMult(z.share);
          var multLabel = mult > 1 ? ' (x' + mult + ')' : '';
          if (z.defRank >= 26) { szAdvScore += Math.round(2 * mult); szAdvNotes.push(z.name + ' ' + z.share.toFixed(0) + '% vs Rk' + Math.round(z.defRank) + multLabel + ' \u26A1'); }
          else if (z.defRank >= 21) { szAdvScore += Math.round(1 * mult); szAdvNotes.push(z.name + ' ' + z.share.toFixed(0) + '% vs Rk' + Math.round(z.defRank) + multLabel); }
          else if (z.defRank <= 5) { szAdvScore -= Math.round(1 * mult); szAdvNotes.push(z.name + ' ' + z.share.toFixed(0) + '% vs Rk' + Math.round(z.defRank) + multLabel + ' (tough)'); }
        }
      });
    }

    /* ── Play Type Advantage Score ── */
    var ptAdvScore = 0;
    var ptAdvNotes = [];
    if (playerDB && playerDB.play_types && oppDef && oppDef.play_types) {
      PLAY_TYPE_ORDER.forEach(function(pt) {
        var ppt = playerDB.play_types[pt];
        var dpt = oppDef.play_types[pt];
        if (ppt && ppt.fga > 0 && ppt.freq >= 0.20 && dpt) {
          var defRank = dpt.final_rank || 15;
          var freqPct = ppt.freq * 100;
          var mult = volMult(freqPct);
          var multLabel = mult > 1 ? ' (x' + mult + ')' : '';
          if (defRank >= 26) { ptAdvScore += Math.round(2 * mult); ptAdvNotes.push(pt + ' ' + freqPct.toFixed(0) + '% vs Rk' + defRank + multLabel + ' \u26A1'); }
          else if (defRank >= 21) { ptAdvScore += Math.round(1 * mult); ptAdvNotes.push(pt + ' ' + freqPct.toFixed(0) + '% vs Rk' + defRank + multLabel); }
          else if (defRank <= 5) { ptAdvScore -= Math.round(1 * mult); ptAdvNotes.push(pt + ' ' + freqPct.toFixed(0) + '% vs Rk' + defRank + multLabel + ' (tough)'); }
        }
      });
    }

    /* ── Position vs DEF Score ── */
    var posAdvScore = 0;
    var posAdvNotes = [];
    if (oppPosVuln) {
      /* Use L7 pctile as primary */
      var l7p = oppPosVuln.l7_pctile;
      var sznp = oppPosVuln.pctile;
      if (l7p !== null && l7p !== undefined) {
        if (l7p >= 75) { posAdvScore += 2; posAdvNotes.push(yahooPos + ' L7 ' + ordSuffix(l7p) + ' pctile'); }
        else if (l7p >= 55) { posAdvScore += 1; posAdvNotes.push(yahooPos + ' L7 ' + ordSuffix(l7p) + ' pctile'); }
        else if (l7p < 25) { posAdvScore -= 2; posAdvNotes.push(yahooPos + ' L7 ' + ordSuffix(l7p) + ' pctile (tough)'); }
        else if (l7p < 45) { posAdvScore -= 1; posAdvNotes.push(yahooPos + ' L7 ' + ordSuffix(l7p) + ' pctile'); }
      }
      /* Bonus if season confirms */
      if (sznp !== null && sznp !== undefined) {
        if (sznp >= 65 && posAdvScore > 0) { posAdvScore += 1; posAdvNotes.push('Season ' + ordSuffix(sznp) + ' confirms'); }
        else if (sznp < 35 && posAdvScore < 0) { posAdvScore -= 1; posAdvNotes.push('Season ' + ordSuffix(sznp) + ' confirms'); }
      }
    }

    /* Shot zone similarity with top-20% — how well does opponent defense
       allow shots in the zones where this player's best games happen? */
    var szMatch = 0; /* 0-6 scale */
    var szNotes = [];
    if (szPlayer && szOppDef && szPlayer.top20_pitp_share !== undefined) {
      /* Find the player's dominant shot zone in top-20% games */
      var zones = [
        { name: 'PITP', share: szPlayer.top20_pitp_share || 0, defRank: szOppDef.pitp_def_rank || 15 },
        { name: 'Mid', share: szPlayer.top20_mid_share || 0, defRank: szOppDef.mid_def_rank || 15 },
        { name: '3PT', share: szPlayer.top20_3pt_share || 0, defRank: szOppDef['3pt_def_rank'] || 15 }
      ];
      zones.sort(function(a, b) { return b.share - a.share; });

      /* Primary zone (highest share in top-20% games) */
      var primary = zones[0];
      var secondary = zones[1];

      /* Score: if opponent is weak (rank >= 21) in player's top-20% primary zone */
      if (primary.defRank >= 25) { szMatch += 3; szNotes.push(primary.name + ' zone: opp Rk' + Math.round(primary.defRank) + ' (exploit)'); }
      else if (primary.defRank >= 20) { szMatch += 2; szNotes.push(primary.name + ' zone: opp Rk' + Math.round(primary.defRank) + ' (favorable)'); }
      else if (primary.defRank <= 8) { szMatch -= 1; szNotes.push(primary.name + ' zone: opp Rk' + Math.round(primary.defRank) + ' (tough)'); }

      /* Secondary zone */
      if (secondary.share > 25) {
        if (secondary.defRank >= 25) { szMatch += 2; szNotes.push(secondary.name + ' zone: opp Rk' + Math.round(secondary.defRank) + ' (exploit)'); }
        else if (secondary.defRank >= 20) { szMatch += 1; szNotes.push(secondary.name + ' zone: opp Rk' + Math.round(secondary.defRank) + ' (favorable)'); }
        else if (secondary.defRank <= 8) { szMatch -= 1; szNotes.push(secondary.name + ' zone: opp Rk' + Math.round(secondary.defRank) + ' (tough)'); }
      }
    }

    /* Top-20% match scoring — now includes pace + defense + shot zones */
    var top20Score = 0;
    var top20Match = '';
    if (split && split.top20_threshold && oppEnv) {
      var paceMatch = 0;
      var defMatch = 0;

      /* Pace alignment with top-20% games */
      if (isFast && split.top20_fast_pct > 50) paceMatch = 2;
      else if (!isFast && split.top20_slow_pct > 50) paceMatch = 2;
      else if (isFast && split.top20_fast_pct > 30) paceMatch = 1;
      else if (!isFast && split.top20_slow_pct > 30) paceMatch = 1;

      /* Defense alignment with top-20% games */
      var oppDefEff2 = oppEnv.avg_def_eff || medians.def_eff;
      var oppIsWeak = oppDefEff2 > medians.def_eff;
      if (oppIsWeak && split.top20_weak_pct > 50) defMatch = 2;
      else if (!oppIsWeak && split.top20_elite_pct > 50) defMatch = 2;
      else if (oppIsWeak && split.top20_weak_pct > 30) defMatch = 1;
      else if (!oppIsWeak && split.top20_elite_pct > 30) defMatch = 1;

      /* Combined score: pace(0-2) + defense(0-2) + shot_zones(-2 to 5) */
      top20Score = paceMatch + defMatch + Math.max(-2, Math.min(szMatch, 5));
      if (top20Score >= 5) top20Match = 'hot';
      else if (top20Score >= 3) top20Match = 'warm';
      else if (top20Score >= 1) top20Match = 'mild';
      else top20Match = 'cold';
    }

    /* Build play-type data cross-referenced with opponent defense */
    var playTypes = [];
    if (playerDB && playerDB.play_types && oppDef) {
      PLAY_TYPE_ORDER.forEach(function(pt) {
        var ppt = playerDB.play_types[pt];
        var dpt = (oppDef.play_types || {})[pt];
        if (ppt && ppt.fga > 0) {
          playTypes.push({
            name: pt,
            fga: ppt.fga,
            fg_pct: ppt.fg_pct,
            freq: ppt.freq,
            def_rank: dpt ? dpt.final_rank : null,
            def_fg_pct: dpt ? dpt.l7_fg_pct : null
          });
        }
      });
    }

    return {
      name: p.name,
      team: p.team,
      opponent: p.opponent,
      pos: p.pos,
      salary: p.salary,
      total: p.total,
      fc_proj: p.fc_proj,
      proj_mins: p.proj_mins,
      /* env stats */
      avg_dkfp: split ? split.avg_dkfp : null,
      pace_pref: split ? split.pace_pref : '',
      fast_dkfp: split ? split.fast_dkfp : null,
      slow_dkfp: split ? split.slow_dkfp : null,
      weak_def_dkfp: split ? split.weak_def_dkfp : null,
      elite_def_dkfp: split ? split.elite_def_dkfp : null,
      def_boost: split ? split.def_boost : '',
      games: split ? split.games : 0,
      avg_min: (split && split.avg_min != null) ? split.avg_min : (playerDB && playerDB.avg_min != null ? playerDB.avg_min : null),
      usage_rate: (split && split.usage_rate != null) ? split.usage_rate : (playerDB && playerDB.usage_rate != null ? playerDB.usage_rate : null),
      dk_fp_avg: (split && split.dk_fp != null) ? split.dk_fp : (playerDB && playerDB.dk_fp != null ? playerDB.dk_fp : null),
      fd_fp_avg: (split && split.fd_fp != null) ? split.fd_fp : (playerDB && playerDB.fd_fp != null ? playerDB.fd_fp : null),
      expected_pace: expectedPace,
      env_score: envScore,
      env_notes: envNotes,
      opp_pace_tier: oppEnv ? oppEnv.pace_tier : '',
      opp_def_tier: oppEnv ? oppEnv.def_tier : '',
      /* top-20% */
      top20_match: top20Match,
      top20_score: top20Score,
      top20_threshold: split ? split.top20_threshold : null,
      top20_avg_dkfp: split ? split.top20_avg_dkfp : null,
      top20_dom_pace: split ? split.top20_dom_pace : '',
      top20_dom_def: split ? split.top20_dom_def : '',
      top20_fast_pct: split ? split.top20_fast_pct : 0,
      top20_slow_pct: split ? split.top20_slow_pct : 0,
      top20_weak_pct: split ? split.top20_weak_pct : 0,
      top20_elite_pct: split ? split.top20_elite_pct : 0,
      /* shot / play types */
      playTypes: playTypes,
      avg_fga: split ? split.avg_fga : null,
      avg_fg_pct: split ? split.avg_fg_pct : null,
      avg_tpa: split ? split.avg_tpa : null,
      avg_tp_pct: split ? split.avg_tp_pct : null,
      avg_fta: split ? split.avg_fta : null,
      avg_pts: split ? split.avg_pts : null,
      avg_reb: split ? split.avg_reb : null,
      avg_ast: split ? split.avg_ast : null,
      /* shot zone data */
      sz_player: szPlayer,
      sz_opp_def: szOppDef,
      sz_notes: szNotes,
      sz_match: szMatch,
      /* advantage scores */
      yahoo_pos: yahooPos,
      pt_adv_score: ptAdvScore,
      pt_adv_notes: ptAdvNotes,
      sz_adv_score: szAdvScore,
      sz_adv_notes: szAdvNotes,
      pos_adv_score: posAdvScore,
      pos_adv_notes: posAdvNotes
    };
  });
}

/* ── Init Upload ── */
function initDailyMatchup() {
  var dropzone = document.getElementById('upload-dropzone');
  var fileInput = document.getElementById('csv-file');
  var reuploadBtn = document.getElementById('daily-reupload');

  if (!dropzone || !fileInput) return;

  /* Drag & drop */
  dropzone.addEventListener('dragover', function(e) {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });
  dropzone.addEventListener('dragleave', function() {
    dropzone.classList.remove('dragover');
  });
  dropzone.addEventListener('drop', function(e) {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files.length) handleCSVFile(e.dataTransfer.files[0]);
  });

  /* Click to browse */
  fileInput.addEventListener('change', function() {
    if (fileInput.files.length) handleCSVFile(fileInput.files[0]);
  });

  /* Re-upload */
  if (reuploadBtn) {
    reuploadBtn.addEventListener('click', function() {
      document.getElementById('daily-upload-area').style.display = '';
      document.getElementById('daily-controls').style.display = 'none';
      document.getElementById('daily-content').innerHTML = '';
      document.getElementById('daily-scatter').style.display = 'none';
      document.getElementById('upload-status').textContent = '';
      fileInput.value = '';
      dailyPlayers = [];
      dailyGames = [];
      if (scatterChart) { scatterChart.destroy(); scatterChart = null; }
      renderPosVulnTab();
    });
  }

  /* Toggle buttons */
  document.querySelectorAll('.daily-toggle-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.daily-toggle-btn').forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      dailyView = btn.getAttribute('data-view');
      renderDailyContent();
    });
  });

  /* Edge weight sliders */
  var sliderIds = ['ew-pt', 'ew-sz', 'ew-pos', 'ew-env', 'ew-t20'];
  var weightKeys = ['pt', 'sz', 'pos', 'env', 't20'];
  sliderIds.forEach(function(id, i) {
    var slider = document.getElementById(id);
    var valEl = document.getElementById(id + '-val');
    if (slider) {
      slider.addEventListener('input', function() {
        var v = parseFloat(slider.value);
        edgeWeights[weightKeys[i]] = v;
        if (valEl) valEl.textContent = v.toFixed(1);
        renderDailyContent();
      });
    }
  });

  /* Reset weights */
  var resetBtn = document.getElementById('ew-reset');
  if (resetBtn) {
    resetBtn.addEventListener('click', function() {
      sliderIds.forEach(function(id, i) {
        edgeWeights[weightKeys[i]] = EDGE_DEFAULTS[weightKeys[i]];
        var slider = document.getElementById(id);
        var valEl = document.getElementById(id + '-val');
        if (slider) slider.value = EDGE_DEFAULTS[weightKeys[i]];
        if (valEl) valEl.textContent = EDGE_DEFAULTS[weightKeys[i]].toFixed(1);
      });
      renderDailyContent();
    });
  }
}

function handleCSVFile(file) {
  if (!file.name.endsWith('.csv')) {
    document.getElementById('upload-status').textContent = 'Please upload a .csv file';
    document.getElementById('upload-status').style.color = 'var(--error)';
    return;
  }

  var reader = new FileReader();
  reader.onload = function(e) {
    var raw = parseDKCSV(e.target.result);
    if (raw.length === 0) {
      document.getElementById('upload-status').textContent = 'No players found. Check CSV format.';
      document.getElementById('upload-status').style.color = 'var(--error)';
      return;
    }

    dailyPlayers = enrichDailyPlayers(raw);

    /* Extract unique games */
    var gameMap = {};
    dailyPlayers.forEach(function(p) {
      var key = [p.team, p.opponent].sort().join('_');
      if (!gameMap[key]) {
        gameMap[key] = { away: p.team, home: p.opponent, total: p.total };
      }
    });
    dailyGames = Object.values(gameMap);

    /* Set date from filename if possible */
    var dateMatch = file.name.match(/(\d{4}-\d{2}-\d{2})/);
    var dateEl = document.getElementById('daily-date');
    if (dateEl) dateEl.textContent = dateMatch ? dateMatch[1] : new Date().toISOString().slice(0, 10);

    /* Show results */
    var statusEl = document.getElementById('upload-status');
    statusEl.textContent = dailyPlayers.length + ' players loaded from ' + dailyGames.length + ' games';
    statusEl.style.color = 'var(--success)';

    document.getElementById('daily-upload-area').style.display = 'none';
    document.getElementById('daily-controls').style.display = '';

    renderDailyContent();
    renderPosVulnTab();
  };
  reader.readAsText(file);
}

/* ── Render ── */
function renderDailyContent() {
  var scatterEl = document.getElementById('daily-scatter');
  var contentEl = document.getElementById('daily-content');
  if (dailyView === 'scatter') {
    contentEl.style.display = 'none';
    scatterEl.style.display = '';
    renderScatterPlot();
  } else {
    scatterEl.style.display = 'none';
    contentEl.style.display = '';
    if (scatterChart) { scatterChart.destroy(); scatterChart = null; }
    if (dailyView === 'games') {
      renderDailyByGame();
    } else {
      renderDailyAllPlayers();
    }
  }
}

/* ── Scatter Plot: Edge Score vs Salary ── */
function renderScatterPlot() {
  var container = document.getElementById('daily-scatter');
  if (!dailyPlayers.length) { container.innerHTML = ''; return; }

  /* Position colors */
  var POS_COLORS = {
    'PG': '#3b82f6', 'SG': '#8b5cf6', 'SF': '#10b981',
    'PF': '#f59e0b', 'C': '#ef4444'
  };

  /* Build data points */
  var points = dailyPlayers.map(function(p) {
    var edge = calcEdgeScore(p);
    var val = calcValue(p);
    var pos = (p.pos || '').split('/')[0];
    return {
      x: p.salary,
      y: edge,
      name: p.name,
      team: p.team,
      pos: pos,
      proj: p.fc_proj,
      value: val,
      color: POS_COLORS[pos] || '#94a3b8'
    };
  }).filter(function(d) { return d.x > 0; });

  /* Group by position for datasets */
  var posList = ['PG', 'SG', 'SF', 'PF', 'C'];
  var datasets = posList.map(function(pos) {
    return {
      label: pos,
      data: points.filter(function(d) { return d.pos === pos; }),
      backgroundColor: (POS_COLORS[pos] || '#94a3b8') + 'cc',
      borderColor: POS_COLORS[pos] || '#94a3b8',
      borderWidth: 1.5,
      pointRadius: function(ctx) {
        var d = ctx.dataset.data[ctx.dataIndex];
        if (!d) return 4;
        return d.y >= 6 ? 8 : (d.y >= 3 ? 6 : 4);
      },
      pointHoverRadius: 10
    };
  });

  var html = '<div class="scatter-header">';
  html += '<div><div class="scatter-title">Edge Score vs Salary</div>';
  html += '<div class="scatter-subtitle">Higher + further left = best value. Hover for details.</div></div>';
  html += '</div>';
  html += '<div class="scatter-canvas-wrap"><canvas id="scatter-canvas" height="420"></canvas></div>';
  html += '<div class="scatter-legend">';
  posList.forEach(function(pos) {
    html += '<span class="scatter-legend-item"><span class="scatter-legend-dot" style="background:' + POS_COLORS[pos] + '"></span>' + pos + '</span>';
  });
  html += '</div>';
  container.innerHTML = html;

  var canvas = document.getElementById('scatter-canvas');
  if (!canvas) return;

  if (scatterChart) { scatterChart.destroy(); scatterChart = null; }

  scatterChart = new Chart(canvas, {
    type: 'scatter',
    data: { datasets: datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: { padding: { top: 10, right: 20, bottom: 10, left: 10 } },
      scales: {
        x: {
          title: { display: true, text: 'Salary ($)', color: '#9ca3af', font: { size: 12, family: "'Inter', sans-serif" } },
          ticks: { color: '#6b7280', callback: function(v) { return '$' + (v/1000).toFixed(0) + 'K'; }, font: { size: 10 } },
          grid: { color: 'rgba(255,255,255,0.04)' }
        },
        y: {
          title: { display: true, text: 'Edge Score', color: '#9ca3af', font: { size: 12, family: "'Inter', sans-serif" } },
          ticks: { color: '#6b7280', font: { size: 10 } },
          grid: { color: 'rgba(255,255,255,0.04)' }
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1a2332',
          titleColor: '#e5e7eb',
          bodyColor: '#9ca3af',
          borderColor: '#1f2937',
          borderWidth: 1,
          padding: 12,
          titleFont: { family: "'Inter', sans-serif", size: 13, weight: 'bold' },
          bodyFont: { family: "'Inter', sans-serif", size: 11 },
          callbacks: {
            title: function(items) {
              var d = items[0].raw;
              return d.name + ' (' + d.team + ')';
            },
            label: function(ctx) {
              var d = ctx.raw;
              return [
                'Edge: ' + (d.y >= 0 ? '+' : '') + d.y.toFixed(1),
                'Salary: $' + d.x.toLocaleString(),
                'Proj: ' + (d.proj || 0).toFixed(1),
                'Value: ' + (d.value != null ? d.value.toFixed(1) + 'x' : '—')
              ];
            }
          }
        }
      }
    },
    plugins: [{
      /* Label top-edge players directly on the chart */
      id: 'scatterLabels',
      afterDraw: function(chart) {
        var ctx = chart.ctx;
        ctx.save();
        ctx.font = '10px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#e5e7eb';

        var allPoints = [];
        chart.data.datasets.forEach(function(ds) {
          ds.data.forEach(function(d) {
            allPoints.push(d);
          });
        });

        /* Sort and label top N by edge score */
        allPoints.sort(function(a, b) { return b.y - a.y; });
        var labeled = allPoints.slice(0, 8);
        labeled.forEach(function(d) {
          var meta = null;
          chart.data.datasets.forEach(function(ds, dsIdx) {
            ds.data.forEach(function(pt, ptIdx) {
              if (pt === d) {
                var el = chart.getDatasetMeta(dsIdx).data[ptIdx];
                if (el) meta = el;
              }
            });
          });
          if (meta) {
            var lastName = d.name.split(' ').pop();
            ctx.fillText(lastName, meta.x, meta.y - 12);
          }
        });
        ctx.restore();
      }
    }]
  });
}

/* ── Badges & Helpers ── */
function getEnvBadge(tier) {
  if (!tier) return '';
  var cls = tier.toLowerCase();
  return '<span class="env-badge ' + cls + '">' + escapeHtml(tier) + '</span>';
}

function getEnvScoreHtml(score) {
  var cls = score > 0 ? 'positive' : (score < 0 ? 'negative' : 'neutral');
  var prefix = score > 0 ? '+' : '';
  return '<span class="env-score ' + cls + '">' + prefix + score + '</span>';
}

function getPacePrefBadge(pref) {
  if (!pref || pref === 'neutral') return '<span class="env-badge average">Neutral</span>';
  return '<span class="env-badge ' + pref + '">' + pref.charAt(0).toUpperCase() + pref.slice(1) + '</span>';
}

function getDefBoostBadge(boost) {
  if (!boost || boost === 'neutral') return '<span class="env-badge average">Neutral</span>';
  if (boost === 'yes') return '<span class="env-badge weak">Boosts</span>';
  return '<span class="env-badge elite">Struggles</span>';
}

function fmtDollars(val) {
  if (!val) return '$0';
  return '$' + val.toLocaleString();
}

function getTop20Badge(match, score) {
  if (!match || match === 'cold') return '<span class="top20-badge cold">Low</span>';
  if (match === 'hot') return '<span class="top20-badge hot">\u2B50 Hot</span>';
  if (match === 'warm') return '<span class="top20-badge warm">Warm</span>';
  return '<span class="top20-badge mild">Mild</span>';
}

function ordSuffix(n) {
  if (n === null || n === undefined) return '';
  var s = ['th','st','nd','rd'], v = n % 100;
  return n + (s[(v-20)%10]||s[v]||s[0]);
}

/* ── Advantage Score Badge (used for PT Adv, SZ Adv, Pos Adv) ── */
function getAdvScoreHtml(score, notes) {
  if (score === 0 && (!notes || notes.length === 0)) return '<span class="adv-score adv-zero">0</span>';
  var cls = score >= 3 ? 'adv-hot' : (score >= 1 ? 'adv-pos' : (score <= -2 ? 'adv-neg' : (score < 0 ? 'adv-cool' : 'adv-zero')));
  var tooltip = notes && notes.length > 0 ? notes.join(' \u2022 ') : '';
  return '<span class="adv-score ' + cls + '" title="' + escapeHtml(tooltip) + '">' + (score > 0 ? '+' : '') + score + '</span>';
}

function buildEnvNotes(notes) {
  if (!notes || notes.length === 0) return '<span style="color:var(--text-faint);font-size:11px">\u2014</span>';
  var html = '<div class="env-notes">';
  notes.forEach(function(note) {
    var cls = '';
    if (note.indexOf('Thrives') !== -1 || note.indexOf('Exploits') !== -1 || note.indexOf('Top') !== -1) cls = 'good';
    else if (note.indexOf('Struggles') !== -1 || note.indexOf('Prefers') !== -1) cls = 'bad';
    html += '<span class="env-note-chip ' + cls + '">' + escapeHtml(note) + '</span>';
  });
  html += '</div>';
  return html;
}

/* ── Play-Type Mini Table ── */
function buildPlayTypeMini(playTypes) {
  if (!playTypes || playTypes.length === 0) return '<span style="color:var(--text-faint);font-size:11px">\u2014</span>';

  var html = '<div class="pt-mini">';
  /* Header row */
  html += '<div class="pt-mini-header">Type</div>';
  html += '<div class="pt-mini-header">FGA</div>';
  html += '<div class="pt-mini-header">FG%</div>';
  html += '<div class="pt-mini-header">Freq</div>';
  html += '<div class="pt-mini-header">Def Rk</div>';

  /* Data rows — show top play types (those with > 0 fga) */
  var shown = playTypes.slice(0, 6); /* max 6 rows */
  shown.forEach(function(pt) {
    var rankCls = '';
    if (pt.def_rank !== null) {
      if (pt.def_rank >= 26) rankCls = 'exploit';
      else if (pt.def_rank <= 10) rankCls = 'tough';
    }
    html += '<div class="pt-mini-name">' + escapeHtml(pt.name) + '</div>';
    html += '<div class="pt-mini-cell">' + fmtNum(pt.fga) + '</div>';
    html += '<div class="pt-mini-cell">' + pct(pt.fg_pct) + '</div>';
    html += '<div class="pt-mini-cell">' + pct(pt.freq) + '</div>';
    html += '<div class="pt-mini-cell ' + rankCls + '">' + (pt.def_rank !== null ? '#' + pt.def_rank : '\u2014') + '</div>';
  });
  html += '</div>';
  return html;
}

/* ── Shot Zone Mini Table ── */
function buildShotZoneMini(szPlayer, szOppDef, szNotes) {
  if (!szPlayer || !szOppDef) return '<span style="color:var(--text-faint);font-size:11px">\u2014</span>';

  var zones = [
    { name: 'PITP', avgFga: szPlayer.avg_pitp_fga, avgShare: szPlayer.avg_pitp_share,
      t20Fga: szPlayer.top20_pitp_fga, t20Share: szPlayer.top20_pitp_share,
      defRank: szOppDef.pitp_def_rank, defPct: szOppDef.pitp_fg_pct_allowed },
    { name: 'Mid', avgFga: szPlayer.avg_mid_fga, avgShare: szPlayer.avg_mid_share,
      t20Fga: szPlayer.top20_mid_fga, t20Share: szPlayer.top20_mid_share,
      defRank: szOppDef.mid_def_rank, defPct: szOppDef.mid_fg_pct_allowed },
    { name: '3PT', avgFga: szPlayer.avg_3pt_fga, avgShare: szPlayer.avg_3pt_share,
      t20Fga: szPlayer.top20_3pt_fga, t20Share: szPlayer.top20_3pt_share,
      defRank: szOppDef['3pt_def_rank'], defPct: szOppDef['3pt_fg_pct_allowed'] }
  ];

  var html = '<div class="sz-mini">';
  /* Header */
  html += '<div class="sz-mini-header">Zone</div>';
  html += '<div class="sz-mini-header">Avg</div>';
  html += '<div class="sz-mini-header">Top20%</div>';
  html += '<div class="sz-mini-header">Opp Rk</div>';

  zones.forEach(function(z) {
    var rankCls = '';
    if (z.defRank >= 25) rankCls = 'exploit';
    else if (z.defRank <= 8) rankCls = 'tough';

    /* Highlight if top-20% share is meaningfully higher than avg (player shifts here in best games) */
    var shareDiff = (z.t20Share || 0) - (z.avgShare || 0);
    var nameCls = shareDiff > 3 ? ' sz-up' : (shareDiff < -3 ? ' sz-down' : '');

    html += '<div class="sz-mini-name' + nameCls + '">' + z.name + '</div>';
    html += '<div class="sz-mini-cell">' + (z.avgShare != null ? z.avgShare.toFixed(0) + '%' : '\u2014') + '</div>';
    html += '<div class="sz-mini-cell' + (shareDiff > 3 ? ' exploit' : '') + '">' + (z.t20Share != null ? z.t20Share.toFixed(0) + '%' : '\u2014') + '</div>';
    html += '<div class="sz-mini-cell ' + rankCls + '">' + (z.defRank != null ? '#' + Math.round(z.defRank) : '\u2014') + '</div>';
  });

  html += '</div>';

  /* Add shot zone notes if any */
  if (szNotes && szNotes.length > 0) {
    html += '<div class="sz-notes">';
    szNotes.forEach(function(note) {
      var cls = '';
      if (note.indexOf('exploit') !== -1) cls = 'good';
      else if (note.indexOf('tough') !== -1) cls = 'bad';
      else if (note.indexOf('favorable') !== -1) cls = 'good';
      html += '<span class="env-note-chip ' + cls + '">' + escapeHtml(note) + '</span>';
    });
    html += '</div>';
  }

  return html;
}

/* ── Render By Game ── */
function renderDailyByGame() {
  var container = document.getElementById('daily-content');
  if (!dailyPlayers.length) { container.innerHTML = ''; return; }

  var teamEnv = DATA.team_environment || {};
  var html = '';

  dailyGames.forEach(function(game) {
    var away = game.away;
    var home = game.home;
    var awayEnv = teamEnv[away] || {};
    var homeEnv = teamEnv[home] || {};

    var gameKey = away + '_' + home;
    if (!dailyGameSortStates[gameKey]) {
      dailyGameSortStates[gameKey] = { col: null, dir: null };
    }
    sortState['dg_' + gameKey] = dailyGameSortStates[gameKey];

    var expectedPace = ((awayEnv.avg_pace || 0) + (homeEnv.avg_pace || 0)) / 2;

    html += '<div class="daily-game-card">';

    /* Banner */
    html += '<div class="daily-game-banner">';
    html += '<div class="daily-team-info away">';
    html += '<div class="daily-team-abbr">' + escapeHtml(away) + '</div>';
    html += '<div class="daily-team-meta">';
    html += getEnvBadge(awayEnv.pace_tier);
    html += getEnvBadge(awayEnv.def_tier);
    html += '<span>Pace ' + (awayEnv.avg_pace || 0).toFixed(1) + '</span>';
    html += '</div></div>';

    html += '<div class="daily-game-center">';
    html += '<div class="daily-game-vs">@</div>';
    if (game.total) html += '<div class="daily-game-total">O/U ' + game.total.toFixed(1) + '</div>';
    html += '<div class="daily-game-total">Exp Pace ' + expectedPace.toFixed(1) + '</div>';
    html += '</div>';

    html += '<div class="daily-team-info home">';
    html += '<div class="daily-team-abbr">' + escapeHtml(home) + '</div>';
    html += '<div class="daily-team-meta">';
    html += '<span>Pace ' + (homeEnv.avg_pace || 0).toFixed(1) + '</span>';
    html += getEnvBadge(homeEnv.pace_tier);
    html += getEnvBadge(homeEnv.def_tier);
    html += '</div></div>';
    html += '</div>';

    /* Position Vulnerability for both teams in this game */
    html += '<div style="display:flex;gap:16px;flex-wrap:wrap;padding:0 16px 8px">';
    html += '<div style="flex:1;min-width:240px">' + buildPosVuln(home, null, true) + '</div>';
    html += '<div style="flex:1;min-width:240px">' + buildPosVuln(away, null, true) + '</div>';
    html += '</div>';

    /* Players in this game */
    var gamePlayers = dailyPlayers.filter(function(p) {
      return (p.team === away || p.team === home) && (p.opponent === away || p.opponent === home);
    }).sort(function(a, b) {
      return calcEdgeScore(b) - calcEdgeScore(a) || (b.fc_proj || 0) - (a.fc_proj || 0);
    });

    var DAILY_HEADERS = ['Player', 'Team', 'Pos', 'Salary', 'FC Proj', 'Edge', 'Value', 'Min', 'USG%', 'DK FP', 'FD FP', 'PT Adv', 'SZ Adv', 'Pos Adv', 'Env', 'Top20', 'Pace Pref', 'Opp Pace', 'Opp Def', 'Avg DKFP', 'Fast', 'Slow', 'Weak D', 'Elite D', 'Pts', 'Reb', 'Ast', 'Shot Zones', 'Play Types', 'Notes'];

    html += '<div class="daily-table-wrap"><table class="daily-table">';
    html += '<thead><tr>';
    DAILY_HEADERS.forEach(function(h, i) {
      if (i >= 27) { /* Shot Zones, Play Types, Notes not sortable */
        html += '<th>' + h + '</th>';
      } else {
        html += '<th class="' + sortHeaderClass('dg_' + gameKey, i) + '" data-sort-key="dg_' + gameKey + '" data-sort-col="' + i + '">' + h + '</th>';
      }
    });
    html += '</tr></thead><tbody>';

    var rowData = gamePlayers.map(function(p) {
      return [
        p.name,              /* 0 */
        p.team,              /* 1 */
        p.pos,               /* 2 */
        p.salary,            /* 3 */
        p.fc_proj,           /* 4 */
        calcEdgeScore(p),    /* 5 — Edge Score */
        calcValue(p),        /* 6 — Value */
        p.avg_min,           /* 7 */
        p.usage_rate,        /* 8 */
        p.dk_fp_avg,         /* 9 */
        p.fd_fp_avg,         /* 10 */
        p.pt_adv_score,      /* 11 — PT Adv */
        p.sz_adv_score,      /* 12 — SZ Adv */
        p.pos_adv_score,     /* 13 — Pos Adv */
        p.env_score,         /* 14 */
        p.top20_score,       /* 15 */
        p.pace_pref,         /* 16 */
        p.opp_pace_tier,     /* 17 */
        p.opp_def_tier,      /* 18 */
        p.avg_dkfp,          /* 19 */
        p.fast_dkfp,         /* 20 */
        p.slow_dkfp,         /* 21 */
        p.weak_def_dkfp,     /* 22 */
        p.elite_def_dkfp,    /* 23 */
        p.avg_pts,           /* 24 */
        p.avg_reb,           /* 25 */
        p.avg_ast,           /* 26 */
        p,                   /* 27 — full player obj for shot zones */
        p.playTypes,         /* 28 — not sortable */
        p.env_notes,         /* 29 — not sortable */
        p.top20_match,       /* 30 — hidden, used for badge render */
        p.pt_adv_notes,      /* 31 — hidden, for tooltip */
        p.sz_adv_notes,      /* 32 — hidden, for tooltip */
        p.pos_adv_notes      /* 33 — hidden, for tooltip */
      ];
    });

    var sorted = sortRows(rowData, 'dg_' + gameKey);
    sorted.forEach(function(r) {
      var envScore = r[14];
      var edgeScore = r[5];
      var trCls = edgeScore >= 6 ? ' class="env-positive"' : (edgeScore <= -2 ? ' class="env-negative"' : '');
      html += '<tr' + trCls + '>';
      html += '<td>' + escapeHtml(r[0]) + '</td>';
      html += '<td>' + escapeHtml(r[1]) + '</td>';
      html += '<td>' + escapeHtml(r[2]) + '</td>';
      html += '<td>' + fmtDollars(r[3]) + '</td>';
      html += '<td>' + fmtNum(r[4]) + '</td>';
      html += '<td>' + getEdgeScoreHtml(r[5]) + '</td>';
      html += '<td>' + getValueHtml(r[6]) + '</td>';
      html += '<td>' + (r[7] !== null && r[7] !== undefined ? fmtNum(r[7]) : '\u2014') + '</td>';
      html += '<td>' + (r[8] !== null && r[8] !== undefined ? fmtNum(r[8]) + '%' : '\u2014') + '</td>';
      html += '<td>' + (r[9] !== null && r[9] !== undefined ? fmtNum(r[9]) : '\u2014') + '</td>';
      html += '<td>' + (r[10] !== null && r[10] !== undefined ? fmtNum(r[10]) : '\u2014') + '</td>';
      html += '<td>' + getAdvScoreHtml(r[11], r[31]) + '</td>';
      html += '<td>' + getAdvScoreHtml(r[12], r[32]) + '</td>';
      html += '<td>' + getAdvScoreHtml(r[13], r[33]) + '</td>';
      html += '<td>' + getEnvScoreHtml(r[14]) + '</td>';
      html += '<td>' + getTop20Badge(r[30], r[15]) + '</td>';
      html += '<td>' + getPacePrefBadge(r[16]) + '</td>';
      html += '<td>' + getEnvBadge(r[17]) + '</td>';
      html += '<td>' + getEnvBadge(r[18]) + '</td>';
      html += '<td>' + (r[19] !== null && r[19] !== undefined ? fmtNum(r[19]) : '\u2014') + '</td>';
      html += '<td>' + (r[20] !== null && r[20] !== undefined ? fmtNum(r[20]) : '\u2014') + '</td>';
      html += '<td>' + (r[21] !== null && r[21] !== undefined ? fmtNum(r[21]) : '\u2014') + '</td>';
      html += '<td>' + (r[22] !== null && r[22] !== undefined ? fmtNum(r[22]) : '\u2014') + '</td>';
      html += '<td>' + (r[23] !== null && r[23] !== undefined ? fmtNum(r[23]) : '\u2014') + '</td>';
      html += '<td>' + (r[24] !== null && r[24] !== undefined ? fmtNum(r[24]) : '\u2014') + '</td>';
      html += '<td>' + (r[25] !== null && r[25] !== undefined ? fmtNum(r[25]) : '\u2014') + '</td>';
      html += '<td>' + (r[26] !== null && r[26] !== undefined ? fmtNum(r[26]) : '\u2014') + '</td>';
      html += '<td>' + buildShotZoneMini(r[27].sz_player, r[27].sz_opp_def, r[27].sz_notes) + '</td>';
      html += '<td>' + buildPlayTypeMini(r[28]) + '</td>';
      html += '<td>' + buildEnvNotes(r[29]) + '</td>';
      html += '</tr>';
    });

    html += '</tbody></table></div></div>';
  });

  container.innerHTML = html;
}

/* ── Render All Players ── */
function renderDailyAllPlayers() {
  var container = document.getElementById('daily-content');
  if (!dailyPlayers.length) { container.innerHTML = ''; return; }

  var ALL_HEADERS = ['Player', 'Team', 'Opp', 'Pos', 'Salary', 'FC Proj', 'Edge', 'Value', 'Min', 'USG%', 'DK FP', 'FD FP', 'PT Adv', 'SZ Adv', 'Pos Adv', 'Env', 'Top20', 'Pace Pref', 'Opp Pace', 'Opp Def', 'Avg DKFP', 'Fast', 'Slow', 'Weak D', 'Elite D', 'Pts', 'Reb', 'Ast', 'Shot Zones', 'Play Types', 'Notes'];

  var html = '<div class="daily-table-wrap"><table class="daily-table">';
  html += '<thead><tr>';
  ALL_HEADERS.forEach(function(h, i) {
    if (i >= 28) { /* Shot Zones, Play Types, Notes not sortable */
      html += '<th>' + h + '</th>';
    } else {
      html += '<th class="' + sortHeaderClass('dailyAll', i) + '" data-sort-key="dailyAll" data-sort-col="' + i + '">' + h + '</th>';
    }
  });
  html += '</tr></thead><tbody>';

  var rowData = dailyPlayers.map(function(p) {
    return [
      p.name,              /* 0 */
      p.team,              /* 1 */
      p.opponent,          /* 2 */
      p.pos,               /* 3 */
      p.salary,            /* 4 */
      p.fc_proj,           /* 5 */
      calcEdgeScore(p),    /* 6 — Edge Score */
      calcValue(p),        /* 7 — Value */
      p.avg_min,           /* 8 */
      p.usage_rate,        /* 9 */
      p.dk_fp_avg,         /* 10 */
      p.fd_fp_avg,         /* 11 */
      p.pt_adv_score,      /* 12 — PT Adv */
      p.sz_adv_score,      /* 13 — SZ Adv */
      p.pos_adv_score,     /* 14 — Pos Adv */
      p.env_score,         /* 15 */
      p.top20_score,       /* 16 */
      p.pace_pref,         /* 17 */
      p.opp_pace_tier,     /* 18 */
      p.opp_def_tier,      /* 19 */
      p.avg_dkfp,          /* 20 */
      p.fast_dkfp,         /* 21 */
      p.slow_dkfp,         /* 22 */
      p.weak_def_dkfp,     /* 23 */
      p.elite_def_dkfp,    /* 24 */
      p.avg_pts,           /* 25 */
      p.avg_reb,           /* 26 */
      p.avg_ast,           /* 27 */
      p,                   /* 28 — full player obj */
      p.playTypes,         /* 29 — not sortable */
      p.env_notes,         /* 30 — not sortable */
      p.top20_match,       /* 31 — hidden */
      p.pt_adv_notes,      /* 32 — hidden, for tooltip */
      p.sz_adv_notes,      /* 33 — hidden, for tooltip */
      p.pos_adv_notes      /* 34 — hidden, for tooltip */
    ];
  });

  var sorted = sortRows(rowData, 'dailyAll');
  sorted.forEach(function(r) {
    var edgeScore = r[6];
    var trCls = edgeScore >= 6 ? ' class="env-positive"' : (edgeScore <= -2 ? ' class="env-negative"' : '');
    html += '<tr' + trCls + '>';
    html += '<td>' + escapeHtml(r[0]) + '</td>';
    html += '<td>' + escapeHtml(r[1]) + '</td>';
    html += '<td>' + escapeHtml(r[2]) + '</td>';
    html += '<td>' + escapeHtml(r[3]) + '</td>';
    html += '<td>' + fmtDollars(r[4]) + '</td>';
    html += '<td>' + fmtNum(r[5]) + '</td>';
    html += '<td>' + getEdgeScoreHtml(r[6]) + '</td>';
    html += '<td>' + getValueHtml(r[7]) + '</td>';
    html += '<td>' + (r[8] !== null && r[8] !== undefined ? fmtNum(r[8]) : '\u2014') + '</td>';
    html += '<td>' + (r[9] !== null && r[9] !== undefined ? fmtNum(r[9]) + '%' : '\u2014') + '</td>';
    html += '<td>' + (r[10] !== null && r[10] !== undefined ? fmtNum(r[10]) : '\u2014') + '</td>';
    html += '<td>' + (r[11] !== null && r[11] !== undefined ? fmtNum(r[11]) : '\u2014') + '</td>';
    html += '<td>' + getAdvScoreHtml(r[12], r[32]) + '</td>';
    html += '<td>' + getAdvScoreHtml(r[13], r[33]) + '</td>';
    html += '<td>' + getAdvScoreHtml(r[14], r[34]) + '</td>';
    html += '<td>' + getEnvScoreHtml(r[15]) + '</td>';
    html += '<td>' + getTop20Badge(r[31], r[16]) + '</td>';
    html += '<td>' + getPacePrefBadge(r[17]) + '</td>';
    html += '<td>' + getEnvBadge(r[18]) + '</td>';
    html += '<td>' + getEnvBadge(r[19]) + '</td>';
    html += '<td>' + (r[20] !== null && r[20] !== undefined ? fmtNum(r[20]) : '\u2014') + '</td>';
    html += '<td>' + (r[21] !== null && r[21] !== undefined ? fmtNum(r[21]) : '\u2014') + '</td>';
    html += '<td>' + (r[22] !== null && r[22] !== undefined ? fmtNum(r[22]) : '\u2014') + '</td>';
    html += '<td>' + (r[23] !== null && r[23] !== undefined ? fmtNum(r[23]) : '\u2014') + '</td>';
    html += '<td>' + (r[24] !== null && r[24] !== undefined ? fmtNum(r[24]) : '\u2014') + '</td>';
    html += '<td>' + (r[25] !== null && r[25] !== undefined ? fmtNum(r[25]) : '\u2014') + '</td>';
    html += '<td>' + (r[26] !== null && r[26] !== undefined ? fmtNum(r[26]) : '\u2014') + '</td>';
    html += '<td>' + (r[27] !== null && r[27] !== undefined ? fmtNum(r[27]) : '\u2014') + '</td>';
    html += '<td>' + buildShotZoneMini(r[28].sz_player, r[28].sz_opp_def, r[28].sz_notes) + '</td>';
    html += '<td>' + buildPlayTypeMini(r[29]) + '</td>';
    html += '<td>' + buildEnvNotes(r[30]) + '</td>';
    html += '</tr>';
  });

  html += '</tbody></table></div>';
  container.innerHTML = html;
}

/* ── TAB 5: POS VS DEF ── */
function renderPosVulnTab() {
  var container = document.getElementById('pv-tab-content');
  if (!container) return;

  /* Need daily data loaded */
  if (!dailyPlayers || dailyPlayers.length === 0) {
    container.innerHTML = '<div class="empty-state">' +
      '<div class="empty-state-icon"><svg width="48" height="48" viewBox="0 0 48 48" fill="none" aria-hidden="true">' +
      '<circle cx="24" cy="24" r="20" stroke="#6b7280" stroke-width="2" stroke-dasharray="4 4"/>' +
      '<path d="M18 24h12M24 18v12" stroke="#6b7280" stroke-width="2" stroke-linecap="round"/></svg></div>' +
      '<div class="empty-state-title">No CSV Loaded</div>' +
      '<div class="empty-state-text">Upload a DraftKings CSV in the Daily Matchup tab to populate today\'s teams</div>' +
      '</div>';
    return;
  }

  /* Collect unique teams from daily slate (both teams and opponents) */
  var teamSet = {};
  dailyPlayers.forEach(function(p) {
    teamSet[p.team] = true;
    teamSet[p.opponent] = true;
  });
  var teams = Object.keys(teamSet).sort();

  var html = '<div class="pv-tab-grid">';
  teams.forEach(function(team) {
    html += '<div class="pv-tab-card">';
    html += buildPosVuln(team, null, false);
    html += '</div>';
  });
  html += '</div>';
  container.innerHTML = html;
}

/* ── Boot ── */
loadData();

/* ── Auto-load test CSV ── */
function autoLoadTestCSV() {
  fetch('./test_dk.csv')
    .then(function(r) { return r.blob(); })
    .then(function(blob) {
      var file = new File([blob], 'test_dk.csv', {type: 'text/csv'});
      handleCSVFile(file);
    })
    .catch(function(e) { console.warn('Auto-load failed:', e); });
}
// Expose for manual triggering
window.__autoLoadCSV = autoLoadTestCSV;
