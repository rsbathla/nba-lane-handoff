/* ==========================================
   TAB 4: DAILY MATCHUP (Upload-Driven)
   ========================================== */
var dailyView = 'games';
var dailyPlayers = [];   /* parsed from CSV + enriched */
var dailyGames = [];     /* unique game matchups */

sortState.dailyAll = { col: null, dir: null };
var dailyGameSortStates = {};

/* ── Team Abbreviation Map ── */
var TEAM_ABBR_MAP = {
  'ATL': 'ATL', 'BOS': 'BOS', 'BKN': 'BKN', 'CHA': 'CHA', 'CHI': 'CHI',
  'CLE': 'CLE', 'DAL': 'DAL', 'DEN': 'DEN', 'DET': 'DET', 'GSW': 'GSW',
  'GS': 'GSW', 'HOU': 'HOU', 'IND': 'IND', 'LAC': 'LAC', 'LAL': 'LAL',
  'MEM': 'MEM', 'MIA': 'MIA', 'MIL': 'MIL', 'MIN': 'MIN', 'NOP': 'NOP',
  'NO': 'NOP', 'NYK': 'NYK', 'NY': 'NYK', 'OKC': 'OKC', 'ORL': 'ORL',
  'PHI': 'PHI', 'PHX': 'PHX', 'POR': 'POR', 'SAC': 'SAC', 'SAS': 'SAS',
  'SA': 'SAS', 'TOR': 'TOR', 'UTA': 'UTA', 'WAS': 'WAS'
};

function normTeam(raw) {
  if (!raw) return '';
  var t = raw.replace(/^@\s*/i, '').replace(/^vs\s*/i, '').trim().toUpperCase();
  return TEAM_ABBR_MAP[t] || t;
}

/* ── CSV Parsing ── */
function parseCSVLine(line) {
  var result = [];
  var current = '';
  var inQuotes = false;
  for (var i = 0; i < line.length; i++) {
    var ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (i + 1 < line.length && line[i + 1] === '"') {
          current += '"'; i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        result.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
  }
  result.push(current.trim());
  return result;
}

function parseDKCSV(text) {
  var lines = text.split(/\r?\n/).filter(function(l) { return l.trim().length > 0; });
  if (lines.length < 3) return [];

  /* Header row is line index 1 (row 0 is group headers) */
  var headers = parseCSVLine(lines[1]);
  var nameIdx = headers.indexOf('Player');
  var posIdx = headers.indexOf('Pos');
  var salaryIdx = headers.indexOf('Salary');
  var teamIdx = headers.indexOf('Team');
  var oppIdx = headers.indexOf('Opp');
  var totalIdx = headers.indexOf('Total');
  var fcProjIdx = -1;

  /* Find FC Proj column — it's labeled 'FC Proj' in the headers */
  for (var h = 0; h < headers.length; h++) {
    if (headers[h] === 'FC Proj') { fcProjIdx = h; break; }
  }

  /* Find projected minutes column */
  var minsIdx = -1;
  for (var h2 = 0; h2 < headers.length; h2++) {
    if (headers[h2] === 'Proj Mins') { minsIdx = h2; break; }
  }

  var players = [];
  for (var i = 2; i < lines.length; i++) {
    var cols = parseCSVLine(lines[i]);
    if (cols.length < 5) continue;
    var name = cols[nameIdx] || '';
    if (!name) continue;

    var projMins = minsIdx >= 0 ? parseFloat(cols[minsIdx]) || 0 : 99;
    if (projMins < 15) continue; /* Filter < 15 min projection */

    var team = normTeam(cols[teamIdx]);
    var oppRaw = cols[oppIdx] || '';
    var isAway = oppRaw.indexOf('@') === -1; /* if Opp has no @, player's team col has no @ either — DK puts @ on the away column */
    var opp = normTeam(oppRaw);

    players.push({
      name: name,
      pos: cols[posIdx] || '',
      salary: parseInt(cols[salaryIdx]) || 0,
      team: team,
      opponent: opp,
      total: parseFloat(cols[totalIdx]) || 0,
      fc_proj: fcProjIdx >= 0 ? parseFloat(cols[fcProjIdx]) || 0 : 0,
      proj_mins: projMins
    });
  }
  return players;
}

/* ── Enrich Players ── */
function enrichDailyPlayers(rawPlayers) {
  var splits = DATA.player_splits || {};
  var playersDB = DATA.players || {};
  var defenses = DATA.defenses || {};
  var teamEnv = DATA.team_environment || {};
  var medians = (DATA.daily_matchup || {}).environment_medians || { pace: 94.8, def_eff: 118.9 };
  var playerShotZones = DATA.player_shot_zones || {};
  var defShotZones = DATA.defense_shot_zones || {};

  return rawPlayers.map(function(p) {
    /* Find split data — try name match */
    var split = splits[p.name] || null;

    /* Find player DB entry — try Name|TEAM */
    var playerKey = p.name + '|' + p.team;
    var playerDB = playersDB[playerKey] || null;

    /* If no exact match on name in splits, try fuzzy */
    if (!split) {
      var nameNorm = p.name.replace(/\./g, '').replace(/'/g, "'").toLowerCase();
      for (var sk in splits) {
        var skNorm = sk.replace(/\./g, '').replace(/'/g, "'").toLowerCase();
        if (skNorm === nameNorm || (splits[sk].team === p.team && skNorm.indexOf(nameNorm.split(' ').pop()) !== -1)) {
          split = splits[sk];
          break;
        }
      }
    }

    /* If no exact match on playerDB, try name fuzzy */
    if (!playerDB) {
      for (var pk in playersDB) {
        if (pk.indexOf(p.name) === 0 || pk.split('|')[0] === p.name) {
          playerDB = playersDB[pk];
          break;
        }
      }
    }

    var oppDef = defenses[p.opponent] || null;
    var oppEnv = teamEnv[p.opponent] || null;
    var playerTeamEnv = teamEnv[p.team] || null;

    /* Expected game pace */
    var expectedPace = 0;
    if (playerTeamEnv && oppEnv) {
      expectedPace = (playerTeamEnv.avg_pace + oppEnv.avg_pace) / 2;
    }

    /* Environment scoring */
    var envScore = 0;
    var envNotes = [];

    if (split && oppEnv) {
      /* Pace preference */
      var isFast = expectedPace > medians.pace;
      if (split.pace_pref === 'fast' && isFast) { envScore += 1; envNotes.push('Thrives in fast pace'); }
      else if (split.pace_pref === 'fast' && !isFast) { envScore -= 1; envNotes.push('Prefers faster pace'); }
      else if (split.pace_pref === 'slow' && !isFast) { envScore += 1; envNotes.push('Thrives in slow pace'); }
      else if (split.pace_pref === 'slow' && isFast) { envScore -= 1; envNotes.push('Prefers slower pace'); }

      /* Defensive weakness exploitation */
      var oppDefEff = oppEnv.avg_def_eff || medians.def_eff;
      var isWeakDef = oppDefEff > medians.def_eff;
      if (split.def_boost === 'yes' && isWeakDef) { envScore += 2; envNotes.push('Exploits weak defense'); }
      else if (split.def_boost === 'yes' && !isWeakDef) { envScore -= 1; envNotes.push('Struggles vs elite D'); }
      else if (split.def_boost === 'no' && !isWeakDef) { envScore += 1; }

      /* Bonus for aligned pace + defense */
      if (envScore >= 2) envNotes.push('Top environment');
    }

    /* Shot zone data */
    var szPlayer = playerShotZones[p.name] || null;
    var szOppDef = defShotZones[p.opponent] || null;

    /* Shot zone similarity with top-20% — how well does opponent defense
       allow shots in the zones where this player's best games happen? */
    var szMatch = 0; /* 0-6 scale */
    var szNotes = [];
    if (szPlayer && szOppDef && szPlayer.top20_pitp_share !== undefined) {
      /* Find the player's dominant shot zone in top-20% games */
      var zones = [
        { name: 'PITP', share: szPlayer.top20_pitp_share || 0, defRank: szOppDef.pitp_def_rank || 15 },
        { name: 'Mid', share: szPlayer.top20_mid_share || 0, defRank: szOppDef.mid_def_rank || 15 },
        { name: '3PT', share: szPlayer.top20_3pt_share || 0, defRank: szOppDef['3pt_def_rank'] || 15 }
      ];
      zones.sort(function(a, b) { return b.share - a.share; });

      /* Primary zone (highest share in top-20% games) */
      var primary = zones[0];
      var secondary = zones[1];

      /* Score: if opponent is weak (rank >= 21) in player's top-20% primary zone */
      if (primary.defRank >= 25) { szMatch += 3; szNotes.push(primary.name + ' zone: opp Rk' + Math.round(primary.defRank) + ' (exploit)'); }
      else if (primary.defRank >= 20) { szMatch += 2; szNotes.push(primary.name + ' zone: opp Rk' + Math.round(primary.defRank) + ' (favorable)'); }
      else if (primary.defRank <= 8) { szMatch -= 1; szNotes.push(primary.name + ' zone: opp Rk' + Math.round(primary.defRank) + ' (tough)'); }

      /* Secondary zone */
      if (secondary.share > 25) {
        if (secondary.defRank >= 25) { szMatch += 2; szNotes.push(secondary.name + ' zone: opp Rk' + Math.round(secondary.defRank) + ' (exploit)'); }
        else if (secondary.defRank >= 20) { szMatch += 1; szNotes.push(secondary.name + ' zone: opp Rk' + Math.round(secondary.defRank) + ' (favorable)'); }
        else if (secondary.defRank <= 8) { szMatch -= 1; szNotes.push(secondary.name + ' zone: opp Rk' + Math.round(secondary.defRank) + ' (tough)'); }
      }
    }

    /* Top-20% match scoring — now includes pace + defense + shot zones */
    var top20Score = 0;
    var top20Match = '';
    if (split && split.top20_threshold && oppEnv) {
      var paceMatch = 0;
      var defMatch = 0;

      /* Pace alignment with top-20% games */
      if (isFast && split.top20_fast_pct > 50) paceMatch = 2;
      else if (!isFast && split.top20_slow_pct > 50) paceMatch = 2;
      else if (isFast && split.top20_fast_pct > 30) paceMatch = 1;
      else if (!isFast && split.top20_slow_pct > 30) paceMatch = 1;

      /* Defense alignment with top-20% games */
      var oppDefEff2 = oppEnv.avg_def_eff || medians.def_eff;
      var oppIsWeak = oppDefEff2 > medians.def_eff;
      if (oppIsWeak && split.top20_weak_pct > 50) defMatch = 2;
      else if (!oppIsWeak && split.top20_elite_pct > 50) defMatch = 2;
      else if (oppIsWeak && split.top20_weak_pct > 30) defMatch = 1;
      else if (!oppIsWeak && split.top20_elite_pct > 30) defMatch = 1;

      /* Combined score: pace(0-2) + defense(0-2) + shot_zones(-2 to 5) */
      top20Score = paceMatch + defMatch + Math.max(-2, Math.min(szMatch, 5));
      if (top20Score >= 5) top20Match = 'hot';
      else if (top20Score >= 3) top20Match = 'warm';
      else if (top20Score >= 1) top20Match = 'mild';
      else top20Match = 'cold';
    }

    /* Build play-type data cross-referenced with opponent defense */
    var playTypes = [];
    if (playerDB && playerDB.play_types && oppDef) {
      PLAY_TYPE_ORDER.forEach(function(pt) {
        var ppt = playerDB.play_types[pt];
        var dpt = (oppDef.play_types || {})[pt];
        if (ppt && ppt.fga > 0) {
          playTypes.push({
            name: pt,
            fga: ppt.fga,
            fg_pct: ppt.fg_pct,
            freq: ppt.freq,
            def_rank: dpt ? dpt.final_rank : null,
            def_fg_pct: dpt ? dpt.l7_fg_pct : null
          });
        }
      });
    }

    return {
      name: p.name,
      team: p.team,
      opponent: p.opponent,
      pos: p.pos,
      salary: p.salary,
      total: p.total,
      fc_proj: p.fc_proj,
      proj_mins: p.proj_mins,
      /* env stats */
      avg_dkfp: split ? split.avg_dkfp : null,
      pace_pref: split ? split.pace_pref : '',
      fast_dkfp: split ? split.fast_dkfp : null,
      slow_dkfp: split ? split.slow_dkfp : null,
      weak_def_dkfp: split ? split.weak_def_dkfp : null,
      elite_def_dkfp: split ? split.elite_def_dkfp : null,
      def_boost: split ? split.def_boost : '',
      games: split ? split.games : 0,
      expected_pace: expectedPace,
      env_score: envScore,
      env_notes: envNotes,
      opp_pace_tier: oppEnv ? oppEnv.pace_tier : '',
      opp_def_tier: oppEnv ? oppEnv.def_tier : '',
      /* top-20% */
      top20_match: top20Match,
      top20_score: top20Score,
      top20_threshold: split ? split.top20_threshold : null,
      top20_avg_dkfp: split ? split.top20_avg_dkfp : null,
      top20_dom_pace: split ? split.top20_dom_pace : '',
      top20_dom_def: split ? split.top20_dom_def : '',
      top20_fast_pct: split ? split.top20_fast_pct : 0,
      top20_slow_pct: split ? split.top20_slow_pct : 0,
      top20_weak_pct: split ? split.top20_weak_pct : 0,
      top20_elite_pct: split ? split.top20_elite_pct : 0,
      /* shot / play types */
      playTypes: playTypes,
      avg_fga: split ? split.avg_fga : null,
      avg_fg_pct: split ? split.avg_fg_pct : null,
      avg_tpa: split ? split.avg_tpa : null,
      avg_tp_pct: split ? split.avg_tp_pct : null,
      avg_fta: split ? split.avg_fta : null,
      avg_pts: split ? split.avg_pts : null,
      avg_reb: split ? split.avg_reb : null,
      avg_ast: split ? split.avg_ast : null,
      /* shot zone data */
      sz_player: szPlayer,
      sz_opp_def: szOppDef,
      sz_notes: szNotes,
      sz_match: szMatch
    };
  });
}

/* ── Init Upload ── */
function initDailyMatchup() {
  var dropzone = document.getElementById('upload-dropzone');
  var fileInput = document.getElementById('csv-file');
  var reuploadBtn = document.getElementById('daily-reupload');

  if (!dropzone || !fileInput) return;

  /* Drag & drop */
  dropzone.addEventListener('dragover', function(e) {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });
  dropzone.addEventListener('dragleave', function() {
    dropzone.classList.remove('dragover');
  });
  dropzone.addEventListener('drop', function(e) {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files.length) handleCSVFile(e.dataTransfer.files[0]);
  });

  /* Click to browse */
  fileInput.addEventListener('change', function() {
    if (fileInput.files.length) handleCSVFile(fileInput.files[0]);
  });

  /* Re-upload */
  if (reuploadBtn) {
    reuploadBtn.addEventListener('click', function() {
      document.getElementById('daily-upload-area').style.display = '';
      document.getElementById('daily-controls').style.display = 'none';
      document.getElementById('daily-content').innerHTML = '';
      document.getElementById('upload-status').textContent = '';
      fileInput.value = '';
      dailyPlayers = [];
      dailyGames = [];
    });
  }

  /* Toggle buttons */
  document.querySelectorAll('.daily-toggle-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.daily-toggle-btn').forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      dailyView = btn.getAttribute('data-view');
      renderDailyContent();
    });
  });
}

function handleCSVFile(file) {
  if (!file.name.endsWith('.csv')) {
    document.getElementById('upload-status').textContent = 'Please upload a .csv file';
    document.getElementById('upload-status').style.color = 'var(--error)';
    return;
  }

  var reader = new FileReader();
  reader.onload = function(e) {
    var raw = parseDKCSV(e.target.result);
    if (raw.length === 0) {
      document.getElementById('upload-status').textContent = 'No players found. Check CSV format.';
      document.getElementById('upload-status').style.color = 'var(--error)';
      return;
    }

    dailyPlayers = enrichDailyPlayers(raw);

    /* Extract unique games */
    var gameMap = {};
    dailyPlayers.forEach(function(p) {
      var key = [p.team, p.opponent].sort().join('_');
      if (!gameMap[key]) {
        gameMap[key] = { away: p.team, home: p.opponent, total: p.total };
      }
    });
    dailyGames = Object.values(gameMap);

    /* Set date from filename if possible */
    var dateMatch = file.name.match(/(\d{4}-\d{2}-\d{2})/);
    var dateEl = document.getElementById('daily-date');
    if (dateEl) dateEl.textContent = dateMatch ? dateMatch[1] : new Date().toISOString().slice(0, 10);

    /* Show results */
    var statusEl = document.getElementById('upload-status');
    statusEl.textContent = dailyPlayers.length + ' players loaded from ' + dailyGames.length + ' games';
    statusEl.style.color = 'var(--success)';

    document.getElementById('daily-upload-area').style.display = 'none';
    document.getElementById('daily-controls').style.display = '';

    renderDailyContent();
  };
  reader.readAsText(file);
}

/* ── Render ── */
function renderDailyContent() {
  if (dailyView === 'games') {
    renderDailyByGame();
  } else {
    renderDailyAllPlayers();
  }
}

/* ── Badges & Helpers ── */
function getEnvBadge(tier) {
  if (!tier) return '';
  var cls = tier.toLowerCase();
  return '<span class="env-badge ' + cls + '">' + escapeHtml(tier) + '</span>';
}

function getEnvScoreHtml(score) {
  var cls = score > 0 ? 'positive' : (score < 0 ? 'negative' : 'neutral');
  var prefix = score > 0 ? '+' : '';
  return '<span class="env-score ' + cls + '">' + prefix + score + '</span>';
}

function getPacePrefBadge(pref) {
  if (!pref || pref === 'neutral') return '<span class="env-badge average">Neutral</span>';
  return '<span class="env-badge ' + pref + '">' + pref.charAt(0).toUpperCase() + pref.slice(1) + '</span>';
}

function getDefBoostBadge(boost) {
  if (!boost || boost === 'neutral') return '<span class="env-badge average">Neutral</span>';
  if (boost === 'yes') return '<span class="env-badge weak">Boosts</span>';
  return '<span class="env-badge elite">Struggles</span>';
}

function fmtDollars(val) {
  if (!val) return '$0';
  return '$' + val.toLocaleString();
}

function getTop20Badge(match, score) {
  if (!match || match === 'cold') return '<span class="top20-badge cold">Low</span>';
  if (match === 'hot') return '<span class="top20-badge hot">\u2B50 Hot</span>';
  if (match === 'warm') return '<span class="top20-badge warm">Warm</span>';
  return '<span class="top20-badge mild">Mild</span>';
}

function buildEnvNotes(notes) {
  if (!notes || notes.length === 0) return '<span style="color:var(--text-faint);font-size:11px">\u2014</span>';
  var html = '<div class="env-notes">';
  notes.forEach(function(note) {
    var cls = '';
    if (note.indexOf('Thrives') !== -1 || note.indexOf('Exploits') !== -1 || note.indexOf('Top') !== -1) cls = 'good';
    else if (note.indexOf('Struggles') !== -1 || note.indexOf('Prefers') !== -1) cls = 'bad';
    html += '<span class="env-note-chip ' + cls + '">' + escapeHtml(note) + '</span>';
  });
  html += '</div>';
  return html;
}

/* ── Play-Type Mini Table ── */
function buildPlayTypeMini(playTypes) {
  if (!playTypes || playTypes.length === 0) return '<span style="color:var(--text-faint);font-size:11px">\u2014</span>';

  var html = '<div class="pt-mini">';
  /* Header row */
  html += '<div class="pt-mini-header">Type</div>';
  html += '<div class="pt-mini-header">FGA</div>';
  html += '<div class="pt-mini-header">FG%</div>';
  html += '<div class="pt-mini-header">Freq</div>';
  html += '<div class="pt-mini-header">Def Rk</div>';

  /* Data rows — show top play types (those with > 0 fga) */
  var shown = playTypes.slice(0, 6); /* max 6 rows */
  shown.forEach(function(pt) {
    var rankCls = '';
    if (pt.def_rank !== null) {
      if (pt.def_rank >= 26) rankCls = 'exploit';
      else if (pt.def_rank <= 10) rankCls = 'tough';
    }
    html += '<div class="pt-mini-name">' + escapeHtml(pt.name) + '</div>';
    html += '<div class="pt-mini-cell">' + fmtNum(pt.fga) + '</div>';
    html += '<div class="pt-mini-cell">' + pct(pt.fg_pct) + '</div>';
    html += '<div class="pt-mini-cell">' + pct(pt.freq) + '</div>';
    html += '<div class="pt-mini-cell ' + rankCls + '">' + (pt.def_rank !== null ? '#' + pt.def_rank : '\u2014') + '</div>';
  });
  html += '</div>';
  return html;
}

/* ── Shot Zone Mini Table ── */
function buildShotZoneMini(szPlayer, szOppDef, szNotes) {
  if (!szPlayer || !szOppDef) return '<span style="color:var(--text-faint);font-size:11px">\u2014</span>';

  var zones = [
    { name: 'PITP', avgFga: szPlayer.avg_pitp_fga, avgShare: szPlayer.avg_pitp_share,
      t20Fga: szPlayer.top20_pitp_fga, t20Share: szPlayer.top20_pitp_share,
      defRank: szOppDef.pitp_def_rank, defPct: szOppDef.pitp_fg_pct_allowed },
    { name: 'Mid', avgFga: szPlayer.avg_mid_fga, avgShare: szPlayer.avg_mid_share,
      t20Fga: szPlayer.top20_mid_fga, t20Share: szPlayer.top20_mid_share,
      defRank: szOppDef.mid_def_rank, defPct: szOppDef.mid_fg_pct_allowed },
    { name: '3PT', avgFga: szPlayer.avg_3pt_fga, avgShare: szPlayer.avg_3pt_share,
      t20Fga: szPlayer.top20_3pt_fga, t20Share: szPlayer.top20_3pt_share,
      defRank: szOppDef['3pt_def_rank'], defPct: szOppDef['3pt_fg_pct_allowed'] }
  ];

  var html = '<div class="sz-mini">';
  /* Header */
  html += '<div class="sz-mini-header">Zone</div>';
  html += '<div class="sz-mini-header">Avg</div>';
  html += '<div class="sz-mini-header">Top20%</div>';
  html += '<div class="sz-mini-header">Opp Rk</div>';

  zones.forEach(function(z) {
    var rankCls = '';
    if (z.defRank >= 25) rankCls = 'exploit';
    else if (z.defRank <= 8) rankCls = 'tough';

    /* Highlight if top-20% share is meaningfully higher than avg (player shifts here in best games) */
    var shareDiff = (z.t20Share || 0) - (z.avgShare || 0);
    var nameCls = shareDiff > 3 ? ' sz-up' : (shareDiff < -3 ? ' sz-down' : '');

    html += '<div class="sz-mini-name' + nameCls + '">' + z.name + '</div>';
    html += '<div class="sz-mini-cell">' + (z.avgShare != null ? z.avgShare.toFixed(0) + '%' : '\u2014') + '</div>';
    html += '<div class="sz-mini-cell' + (shareDiff > 3 ? ' exploit' : '') + '">' + (z.t20Share != null ? z.t20Share.toFixed(0) + '%' : '\u2014') + '</div>';
    html += '<div class="sz-mini-cell ' + rankCls + '">' + (z.defRank != null ? '#' + Math.round(z.defRank) : '\u2014') + '</div>';
  });

  html += '</div>';

  /* Add shot zone notes if any */
  if (szNotes && szNotes.length > 0) {
    html += '<div class="sz-notes">';
    szNotes.forEach(function(note) {
      var cls = '';
      if (note.indexOf('exploit') !== -1) cls = 'good';
      else if (note.indexOf('tough') !== -1) cls = 'bad';
      else if (note.indexOf('favorable') !== -1) cls = 'good';
      html += '<span class="env-note-chip ' + cls + '">' + escapeHtml(note) + '</span>';
    });
    html += '</div>';
  }

  return html;
}

/* ── Render By Game ── */
function renderDailyByGame() {
  var container = document.getElementById('daily-content');
  if (!dailyPlayers.length) { container.innerHTML = ''; return; }

  var teamEnv = DATA.team_environment || {};
  var html = '';

  dailyGames.forEach(function(game) {
    var away = game.away;
    var home = game.home;
    var awayEnv = teamEnv[away] || {};
    var homeEnv = teamEnv[home] || {};

    var gameKey = away + '_' + home;
    if (!dailyGameSortStates[gameKey]) {
      dailyGameSortStates[gameKey] = { col: null, dir: null };
    }
    sortState['dg_' + gameKey] = dailyGameSortStates[gameKey];

    var expectedPace = ((awayEnv.avg_pace || 0) + (homeEnv.avg_pace || 0)) / 2;

    html += '<div class="daily-game-card">';

    /* Banner */
    html += '<div class="daily-game-banner">';
    html += '<div class="daily-team-info away">';
    html += '<div class="daily-team-abbr">' + escapeHtml(away) + '</div>';
    html += '<div class="daily-team-meta">';
    html += getEnvBadge(awayEnv.pace_tier);
    html += getEnvBadge(awayEnv.def_tier);
    html += '<span>Pace ' + (awayEnv.avg_pace || 0).toFixed(1) + '</span>';
    html += '</div></div>';

    html += '<div class="daily-game-center">';
    html += '<div class="daily-game-vs">@</div>';
    if (game.total) html += '<div class="daily-game-total">O/U ' + game.total.toFixed(1) + '</div>';
    html += '<div class="daily-game-total">Exp Pace ' + expectedPace.toFixed(1) + '</div>';
    html += '</div>';

    html += '<div class="daily-team-info home">';
    html += '<div class="daily-team-abbr">' + escapeHtml(home) + '</div>';
    html += '<div class="daily-team-meta">';
    html += '<span>Pace ' + (homeEnv.avg_pace || 0).toFixed(1) + '</span>';
    html += getEnvBadge(homeEnv.pace_tier);
    html += getEnvBadge(homeEnv.def_tier);
    html += '</div></div>';
    html += '</div>';

    /* Players in this game */
    var gamePlayers = dailyPlayers.filter(function(p) {
      return (p.team === away || p.team === home) && (p.opponent === away || p.opponent === home);
    }).sort(function(a, b) {
      return (b.env_score || 0) - (a.env_score || 0) || (b.fc_proj || 0) - (a.fc_proj || 0);
    });

    var DAILY_HEADERS = ['Player', 'Team', 'Pos', 'Salary', 'FC Proj', 'Env', 'Top20', 'Pace Pref', 'Opp Pace', 'Opp Def', 'Avg DKFP', 'Fast', 'Slow', 'Weak D', 'Elite D', 'Pts', 'Reb', 'Ast', 'Shot Zones', 'Play Types', 'Notes'];

    html += '<div class="daily-table-wrap"><table class="daily-table">';
    html += '<thead><tr>';
    DAILY_HEADERS.forEach(function(h, i) {
      if (i >= 18) { /* Shot Zones, Play Types, Notes not sortable */
        html += '<th>' + h + '</th>';
      } else {
        html += '<th class="' + sortHeaderClass('dg_' + gameKey, i) + '" data-sort-key="dg_' + gameKey + '" data-sort-col="' + i + '">' + h + '</th>';
      }
    });
    html += '</tr></thead><tbody>';

    var rowData = gamePlayers.map(function(p) {
      return [
        p.name,           /* 0 */
        p.team,           /* 1 */
        p.pos,            /* 2 */
        p.salary,         /* 3 */
        p.fc_proj,        /* 4 */
        p.env_score,      /* 5 */
        p.top20_score,    /* 6 */
        p.pace_pref,      /* 7 */
        p.opp_pace_tier,  /* 8 */
        p.opp_def_tier,   /* 9 */
        p.avg_dkfp,       /* 10 */
        p.fast_dkfp,      /* 11 */
        p.slow_dkfp,      /* 12 */
        p.weak_def_dkfp,  /* 13 */
        p.elite_def_dkfp, /* 14 */
        p.avg_pts,        /* 15 */
        p.avg_reb,        /* 16 */
        p.avg_ast,        /* 17 */
        p,                /* 18 — full player obj for shot zones */
        p.playTypes,      /* 19 — not sortable */
        p.env_notes,      /* 20 — not sortable */
        p.top20_match     /* 21 — hidden, used for badge render */
      ];
    });

    var sorted = sortRows(rowData, 'dg_' + gameKey);
    sorted.forEach(function(r) {
      var envScore = r[5];
      var trCls = envScore >= 2 ? ' class="env-positive"' : (envScore <= -2 ? ' class="env-negative"' : '');
      html += '<tr' + trCls + '>';
      html += '<td>' + escapeHtml(r[0]) + '</td>';
      html += '<td>' + escapeHtml(r[1]) + '</td>';
      html += '<td>' + escapeHtml(r[2]) + '</td>';
      html += '<td>' + fmtDollars(r[3]) + '</td>';
      html += '<td>' + fmtNum(r[4]) + '</td>';
      html += '<td>' + getEnvScoreHtml(r[5]) + '</td>';
      html += '<td>' + getTop20Badge(r[21], r[6]) + '</td>';
      html += '<td>' + getPacePrefBadge(r[7]) + '</td>';
      html += '<td>' + getEnvBadge(r[8]) + '</td>';
      html += '<td>' + getEnvBadge(r[9]) + '</td>';
      html += '<td>' + (r[10] !== null && r[10] !== undefined ? fmtNum(r[10]) : '\u2014') + '</td>';
      html += '<td>' + (r[11] !== null && r[11] !== undefined ? fmtNum(r[11]) : '\u2014') + '</td>';
      html += '<td>' + (r[12] !== null && r[12] !== undefined ? fmtNum(r[12]) : '\u2014') + '</td>';
      html += '<td>' + (r[13] !== null && r[13] !== undefined ? fmtNum(r[13]) : '\u2014') + '</td>';
      html += '<td>' + (r[14] !== null && r[14] !== undefined ? fmtNum(r[14]) : '\u2014') + '</td>';
      html += '<td>' + (r[15] !== null && r[15] !== undefined ? fmtNum(r[15]) : '\u2014') + '</td>';
      html += '<td>' + (r[16] !== null && r[16] !== undefined ? fmtNum(r[16]) : '\u2014') + '</td>';
      html += '<td>' + (r[17] !== null && r[17] !== undefined ? fmtNum(r[17]) : '\u2014') + '</td>';
      html += '<td>' + buildShotZoneMini(r[18].sz_player, r[18].sz_opp_def, r[18].sz_notes) + '</td>';
      html += '<td>' + buildPlayTypeMini(r[19]) + '</td>';
      html += '<td>' + buildEnvNotes(r[20]) + '</td>';
      html += '</tr>';
    });

    html += '</tbody></table></div></div>';
  });

  container.innerHTML = html;
}

/* ── Render All Players ── */
function renderDailyAllPlayers() {
  var container = document.getElementById('daily-content');
  if (!dailyPlayers.length) { container.innerHTML = ''; return; }

  var ALL_HEADERS = ['Player', 'Team', 'Opp', 'Pos', 'Salary', 'FC Proj', 'Env', 'Top20', 'Pace Pref', 'Opp Pace', 'Opp Def', 'Avg DKFP', 'Fast', 'Slow', 'Weak D', 'Elite D', 'Pts', 'Reb', 'Ast', 'Shot Zones', 'Play Types', 'Notes'];

  var html = '<div class="daily-table-wrap"><table class="daily-table">';
  html += '<thead><tr>';
  ALL_HEADERS.forEach(function(h, i) {
    if (i >= 19) { /* Shot Zones, Play Types, Notes not sortable */
      html += '<th>' + h + '</th>';
    } else {
      html += '<th class="' + sortHeaderClass('dailyAll', i) + '" data-sort-key="dailyAll" data-sort-col="' + i + '">' + h + '</th>';
    }
  });
  html += '</tr></thead><tbody>';

  var rowData = dailyPlayers.map(function(p) {
    return [
      p.name,           /* 0 */
      p.team,           /* 1 */
      p.opponent,       /* 2 */
      p.pos,            /* 3 */
      p.salary,         /* 4 */
      p.fc_proj,        /* 5 */
      p.env_score,      /* 6 */
      p.top20_score,    /* 7 */
      p.pace_pref,      /* 8 */
      p.opp_pace_tier,  /* 9 */
      p.opp_def_tier,   /* 10 */
      p.avg_dkfp,       /* 11 */
      p.fast_dkfp,      /* 12 */
      p.slow_dkfp,      /* 13 */
      p.weak_def_dkfp,  /* 14 */
      p.elite_def_dkfp, /* 15 */
      p.avg_pts,        /* 16 */
      p.avg_reb,        /* 17 */
      p.avg_ast,        /* 18 */
      p,                /* 19 — full player obj for shot zones */
      p.playTypes,      /* 20 — not sortable */
      p.env_notes,      /* 21 — not sortable */
      p.top20_match     /* 22 — hidden */
    ];
  });

  var sorted = sortRows(rowData, 'dailyAll');
  sorted.forEach(function(r) {
    var envScore = r[6];
    var trCls = envScore >= 2 ? ' class="env-positive"' : (envScore <= -2 ? ' class="env-negative"' : '');
    html += '<tr' + trCls + '>';
    html += '<td>' + escapeHtml(r[0]) + '</td>';
    html += '<td>' + escapeHtml(r[1]) + '</td>';
    html += '<td>' + escapeHtml(r[2]) + '</td>';
    html += '<td>' + escapeHtml(r[3]) + '</td>';
    html += '<td>' + fmtDollars(r[4]) + '</td>';
    html += '<td>' + fmtNum(r[5]) + '</td>';
    html += '<td>' + getEnvScoreHtml(r[6]) + '</td>';
    html += '<td>' + getTop20Badge(r[22], r[7]) + '</td>';
    html += '<td>' + getPacePrefBadge(r[8]) + '</td>';
    html += '<td>' + getEnvBadge(r[9]) + '</td>';
    html += '<td>' + getEnvBadge(r[10]) + '</td>';
    html += '<td>' + (r[11] !== null && r[11] !== undefined ? fmtNum(r[11]) : '\u2014') + '</td>';
    html += '<td>' + (r[12] !== null && r[12] !== undefined ? fmtNum(r[12]) : '\u2014') + '</td>';
    html += '<td>' + (r[13] !== null && r[13] !== undefined ? fmtNum(r[13]) : '\u2014') + '</td>';
    html += '<td>' + (r[14] !== null && r[14] !== undefined ? fmtNum(r[14]) : '\u2014') + '</td>';
    html += '<td>' + (r[15] !== null && r[15] !== undefined ? fmtNum(r[15]) : '\u2014') + '</td>';
    html += '<td>' + (r[16] !== null && r[16] !== undefined ? fmtNum(r[16]) : '\u2014') + '</td>';
    html += '<td>' + (r[17] !== null && r[17] !== undefined ? fmtNum(r[17]) : '\u2014') + '</td>';
    html += '<td>' + (r[18] !== null && r[18] !== undefined ? fmtNum(r[18]) : '\u2014') + '</td>';
    html += '<td>' + buildShotZoneMini(r[19].sz_player, r[19].sz_opp_def, r[19].sz_notes) + '</td>';
    html += '<td>' + buildPlayTypeMini(r[20]) + '</td>';
    html += '<td>' + buildEnvNotes(r[21]) + '</td>';
    html += '</tr>';
  });

  html += '</tbody></table></div>';
  container.innerHTML = html;
}
