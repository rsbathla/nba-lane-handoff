"""Independent bounded identifier and saved-model readthrough audit; no fits/imports of production code."""
from pathlib import Path
import numpy as np,pandas as pd,json,hashlib
R=Path(__file__).resolve().parents[2];P=R.parent;T=P/'player_specific_pilot';A=Path(__file__).resolve().parent
checks=[];fail=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(k,a,b):
    if isinstance(a,(int,float,np.number,bool,np.bool_)) or pd.isna(a):ok=(pd.isna(a) and pd.isna(b)) or (not pd.isna(a) and not pd.isna(b) and np.isclose(float(a),float(b),atol=1e-9,rtol=1e-10))
    else:ok=str(a)==str(b)
    checks.append((k,bool(ok)))
    if not ok:fail.append({'check':k,'actual':str(a),'expected':str(b)})
def read(p):
    d=pd.read_csv(p,dtype={'game_id':str,'person_id':str});d.game_id=d.game_id.str.zfill(10)
    if 'date' in d:d.date=pd.to_datetime(d.date)
    return d
def wilson(h,n):
    zz=1.959963984540054;q=h/n;den=1+zz**2/n;half=zz*np.sqrt(q*(1-q)/n+zz**2/(4*n*n))/den;mid=(q+zz**2/(2*n))/den;return mid-half,mid+half
z=read(R/'outputs/curry_fixed48_integrated_game_ledger.csv');x=read(R/'outputs/curry_fixed_older_cutoff_2025_26_game_audit.csv');z=z.merge(x[['game_id','track_cs_fga_prior10','track_pu_fga_share_prior10']],on='game_id',how='left',validate='one_to_one');res=pd.read_csv(R/'outputs/curry_fixed_older_cutoff_2025_26_48_results.csv');pu=float(res.loc[res.rule.eq('prior10_pu_share_at_or_below_old_median'),'cutoff'].iloc[0]);sc=pd.read_csv(R/'outputs/curry_pregame_identifier_scorecard.csv');mem=read(R/'outputs/curry_pregame_identifier_game_membership.csv');allmask=np.ones(len(z),bool);recent=z.season.eq('2025-26');first=z.loc[recent&z.appearance_gap_capped30.ge(30)&z.date.gt('2025-11-01'),'date'].min()
defs={
'Away game':(z.home_away.eq('away'),z.home_away.notna(),allmask),
'Not on team back-to-back':(z.team_b2b_verified.eq(0),z.team_b2b_verified.notna(),allmask),
'Prior5 minutes at least34':(z.minutes_lag5.ge(34),z.minutes_lag5.notna(),allmask),
'Prior10 box usage at least32':(z.usage_proxy_lag10.ge(32),z.usage_proxy_lag10.notna(),allmask),
'Prior5 minutes34plus AND prior10 usage32plus':(z.minutes_lag5.ge(34)&z.usage_proxy_lag10.ge(32),z.minutes_lag5.notna()&z.usage_proxy_lag10.notna(),allmask),
'Own prior10 CS attempts above6.05':(z.track_cs_fga_prior10.gt(6.05),z.track_cs_fga_prior10.notna(),recent),
'Own prior10 PU share at most older median':(z.track_pu_fga_share_prior10.le(pu),z.track_pu_fga_share_prior10.notna(),recent),
'Historical closing absolute spread below5':(z.closing_spread.abs().lt(5),z.closing_spread.notna(),recent),
'Butler observed playing':(z.observed_butler_played,allmask,recent),
'Butler observed AND historical absolute spread below5':(z.observed_butler_played&z.closing_spread.abs().lt(5),z.closing_spread.notna(),recent)}
scopes={'before_first_within_season_30day_gap_return':recent&z.date.lt(first),'prior5_minutes30_to_below36':recent&z.minutes_lag5.ge(30)&z.minutes_lag5.lt(36)}
expected={(f,'primary') for f in defs}|{(f,s) for f in ['Own prior10 CS attempts above6.05','Own prior10 PU share at most older median'] for s in scopes};check('candidate complete keys',set(map(tuple,sc[['candidate','restriction']].values))==expected,True);check('candidate keys unique',not sc.duplicated(['candidate','restriction']).any(),True)
boot_samples=[]
for r in sc.itertuples():
    chosen,known,scope=defs[r.candidate]
    if r.restriction!='primary':scope=scopes[r.restriction]
    scoped=z[scope].copy().sort_values('date');ix=scoped.index.to_numpy();kn=np.asarray(known)[ix];sel=np.asarray(chosen)[ix]&kn;hit=scoped.dk.ge(48).to_numpy();n=len(scoped);sn=sel.sum();h=hit[sel].sum();en=kn.sum();eh=hit[kn].sum();base=eh/en;lo,hi=wilson(h,sn);other=kn&~sel
    vals={'scope_n':n,'scope_hits48':hit.sum(),'eligible_n':en,'eligible_hits48':eh,'unknown_n':(~kn).sum(),'unknown_hits48':hit[~kn].sum(),'selected_n':sn,'hits48':h,'false_positives':sn-h,'precision':h/sn,'precision_wilson95_low':lo,'precision_wilson95_high':hi,'same_eligible_baseline':base,'precision_minus_eligible_baseline':h/sn-base,'global_baseline':67/187,'captures_of_all67_hits':h,'recall_of_all67':h/67,'recall_within_eligible_hits':h/eh,'selected_fraction_of187':sn/187,'selected_fraction_of_eligible':sn/en,'unselected_known_n':other.sum(),'unselected_known_hits':hit[other].sum(),'dk_mean_selected':scoped.loc[sel,'dk'].mean(),'dk_median_selected':scoped.loc[sel,'dk'].median(),'dk_q90_selected':scoped.loc[sel,'dk'].quantile(.9),'first_selected_date':str(scoped.loc[sel,'date'].min().date()),'last_selected_date':str(scoped.loc[sel,'date'].max().date()),'prospective_validation':False}
    for f,v in vals.items():check(f'candidate:{r.candidate}:{r.restriction}:{f}',getattr(r,f),v)
    mm=mem[mem.candidate.eq(r.candidate)&mem.restriction.eq(r.restriction)].set_index('game_id');check(f'candidate membership completeness:{r.candidate}:{r.restriction}',set(mm.index)==set(scoped.game_id),True)
    for j,row in enumerate(scoped.itertuples()):
        actual=mm.loc[row.game_id]
        for f,v in [('date',row.date),('dk',row.dk),('hit48',hit[j]),('known_context',kn[j]),('selected',bool(sel[j]) if kn[j] else np.nan)]:check(f'candidate membership:{r.candidate}:{r.restriction}:{row.game_id}:{f}',actual[f],v)
    if sn>=5 and other.sum()>=5:
        seasons=scoped.season.to_numpy();rng=np.random.default_rng(20261012);draw=[]
        for season in sorted(set(seasons)):
            ids=np.where(seasons==season)[0];nn=len(ids);start=rng.integers(nn,size=(500,(nn+6)//7));rel=np.array([np.concatenate([np.arange(k,k+7)%nn for k in row])[:nn] for row in start]);draw.append(ids[rel])
        draw=np.concatenate(draw,axis=1);ss=sel[draw];kk=kn[draw];oo=other[draw];ok=ss.any(1)&kk.any(1)&oo.any(1);hh=hit[draw];sp=(hh*ss).sum(1)[ok]/ss.sum(1)[ok];ep=(hh*kk).sum(1)[ok]/kk.sum(1)[ok];op=(hh*oo).sum(1)[ok]/oo.sum(1)[ok];lift=np.quantile(sp-ep,[.025,.975]);contrast=np.quantile(sp-op,[.025,.975])
        for f,v in [('precision_lift_block95_low',lift[0]),('precision_lift_block95_high',lift[1]),('selected_minus_unselected_block95_low',contrast[0]),('selected_minus_unselected_block95_high',contrast[1]),('bootstrap_draws',ok.sum())]:check(f'candidate bootstrap:{r.candidate}:{r.restriction}:{f}',getattr(r,f),v)
        boot_samples.append({'candidate':r.candidate,'restriction':r.restriction,'draws':int(ok.sum()),'index_sha256':hashlib.sha256(draw[ok].astype('<i8').tobytes()).hexdigest()})
    else:
        for f in ['precision_lift_block95_low','precision_lift_block95_high','selected_minus_unselected_block95_low','selected_minus_unselected_block95_high','bootstrap_draws']:check(f'unsupported candidate uncertainty missing:{r.candidate}:{r.restriction}:{f}',getattr(r,f),np.nan)
# Reconstruct exact weighted probabilities with integer masses, and route each source row through frozen tree.
source=pd.concat([read(T/'outputs/player_tree_predictions.csv.gz'),read(T/'outputs/pooled_matched_predictions.csv.gz')],ignore_index=True);source=source[source.person_id.eq('201939')&source.fit_window.isin(['development','final'])];out=read(R/'outputs/curry_existing_model_fixed48_predictions.csv');keys=['fit_window','site','model','game_id'];check('probability source key completeness',set(map(tuple,source[keys].values))==set(map(tuple,out[keys].values)),True);check('probability keys unique',not out.duplicated(keys).any(),True)
core=read(T/'outputs/core_panel.csv.gz');core=core[core.person_id.eq('201939')].set_index('game_id');out=out.set_index(keys);models={};rebuilt=[];model_hashes={}
for r in source.itertuples():
    key=(r.fit_window,r.site,r.model);target=out.loc[key+(r.game_id,)];check(f'prediction source actual:{key}:{r.game_id}',target.actual_score,r.actual_score);check(f'prediction source date:{key}:{r.game_id}',target.date,r.date);check(f'prediction inclusive outcome:{key}:{r.game_id}',target.hit48,int(r.actual_score>=48));check(f'prediction ledger score:{key}:{r.game_id}',r.actual_score,z.loc[z.game_id.eq(r.game_id),r.site].iloc[0]);check(f'prediction baseline:{key}:{r.game_id}',r.personal_baseline,core.loc[r.game_id,r.site+'_lag20'])
    if r.model.startswith('player_'):
        if key not in models:
            path=T/'models'/f'{r.fit_window}_{r.site}_201939_{r.model}.json';models[key]=json.loads(path.read_text());model_hashes[str(path.relative_to(P))]=sha(path)
        model=models[key];node=model['tree'];features=core.loc[r.game_id];check(f'model earlier fit:{key}:{r.game_id}',pd.to_datetime(model['fit_date_max'])<r.date,True);check(f'model row not in training:{key}:{r.game_id}',r.game_id not in model['fit_game_ids'],True)
        while not node['leaf']:
            v=features[node['feature']];v=model['medians'][node['feature']] if pd.isna(v) else v;node=node['left'] if v<=node['threshold'] else node['right']
        check(f'frozen model route:{key}:{r.game_id}',r.leaf,node['id']);leaf=np.array(node['training_residuals']);glob=np.array(model['global_fit_residuals']);pseudo=model['leaf_shrinkage_pseudocount'];check(f'frozen shrinkage:{key}',pseudo,20)
        boundary=48-r.personal_baseline;mass=np.r_[np.full(len(leaf),len(glob)),np.full(len(glob),pseudo)];vals=np.r_[leaf,glob];p=mass[vals>=boundary].sum()/mass.sum();check(f'inclusive distribution arithmetic:{key}:{r.game_id}',p,mass[vals+r.personal_baseline>=48].sum()/mass.sum());check(f'exact probability label:{key}:{r.game_id}',target.probability_recipe.startswith('Exact shrunken empirical'),True)
    else:
        q=np.array([.1,.25,.5,.75,.85,.9,.95]);v=np.array([getattr(r,f'q{int(k*100)}_score') for k in q]);check(f'pooled noncrossing quantiles:{key}:{r.game_id}',bool((np.diff(v)>=-1e-9).all()),True);unique=sorted(set(v));cdf=np.array([q[v==vv].max() for vv in unique]);p=1-np.interp(48,unique,cdf,left=.1,right=.95);check(f'pooled approximation label:{key}:{r.game_id}',target.probability_recipe.startswith('Approximate seven-quantile'),True)
    check(f'probability:{key}:{r.game_id}',target.p48,p);rebuilt.append(dict(fit_window=r.fit_window,site=r.site,model=r.model,game_id=r.game_id,date=r.date,p48=p,hit48=int(r.actual_score>=48)))
# Independently score all twenty groups from rebuilt probabilities, including deterministic and inclusive ties.
rp=pd.DataFrame(rebuilt);card=pd.read_csv(R/'outputs/curry_existing_model_fixed48_scorecard.csv');cal=pd.read_csv(R/'outputs/curry_existing_model_fixed48_calibration.csv');check('saved model scorecards',len(card),20);check('saved model group completeness',set(map(tuple,card[['fit_window','site','model']].values))==set(map(tuple,rp[['fit_window','site','model']].drop_duplicates().values)),True)
for r in card.itertuples():
    g=rp[rp.fit_window.eq(r.fit_window)&rp.site.eq(r.site)&rp.model.eq(r.model)].sort_values(['p48','date','game_id'],ascending=[False,True,True],kind='stable');n=len(g);k=(n+4)//5;top=g.iloc[:k];boundary=top.p48.iloc[-1];inc=g[g.p48>=boundary];hits=g.hit48.sum();vals={'n':n,'hits48':hits,'misses48':n-hits,'event_rate':g.hit48.mean(),'mean_predicted_p48':g.p48.mean(),'calibration_mean_error':g.p48.mean()-g.hit48.mean(),'brier':((g.p48-g.hit48)**2).mean(),'top20_n':k,'top20_hits':top.hit48.sum(),'top20_false_positives':k-top.hit48.sum(),'top20_precision':top.hit48.mean(),'captured_hits_fraction':top.hit48.sum()/hits,'top20_mean_p48':top.p48.mean(),'boundary_tie_n':g.p48.eq(boundary).sum(),'tie_inclusive_n':len(inc),'tie_inclusive_hits':inc.hit48.sum(),'tie_inclusive_false_positives':len(inc)-inc.hit48.sum()}
    for f,v in vals.items():check(f'model scorecard:{r.fit_window}:{r.site}:{r.model}:{f}',getattr(r,f),v)
cal_keys=set()
for key,g in rp.groupby(['fit_window','site','model']):
    labels=pd.cut(g.p48,[-.001,.2,.4,.6,.8,1.001],right=False)
    for label in labels.dropna().unique():cal_keys.add(key+(str(label),))
check('calibration complete occupied bins',set(map(tuple,cal[['fit_window','site','model','probability_bin']].values))==cal_keys,True)
check('calibration bins unique',not cal.duplicated(['fit_window','site','model','probability_bin']).any(),True)
for r in cal.itertuples():
    left,right=[float(x.strip()) for x in r.probability_bin[1:-1].split(',')];g=rp[rp.fit_window.eq(r.fit_window)&rp.site.eq(r.site)&rp.model.eq(r.model)&rp.p48.ge(left)&rp.p48.lt(right)];h=g.hit48.sum();n=len(g);lo,hi=wilson(h,n);vals={'n':n,'hits48':h,'misses48':n-h,'mean_probability':g.p48.mean(),'observed_rate':h/n,'observed_wilson95_low':lo,'observed_wilson95_high':hi}
    for f,v in vals.items():check(f'model calibration:{r.fit_window}:{r.site}:{r.model}:{r.probability_bin}:{f}',getattr(r,f),v)
# Freeze/source integrity and discovery ledger factual counts.
manifest=json.loads((T/'REPRODUCIBILITY_MANIFEST.json').read_text());ref={entry['path']:entry['sha256'] for entry in manifest['files']}
for p,h in model_hashes.items():check('saved model unchanged:'+p,h,ref[P.name+'/'+p])
for p in ['outputs/player_tree_predictions.csv.gz','outputs/pooled_matched_predictions.csv.gz','outputs/core_panel.csv.gz']:check('saved predictions unchanged:'+p,sha(T/p),ref[P.name+'/player_specific_pilot/'+p])
led=json.loads((R/'audit/curry_identifier_exploration_ledger.json').read_text());shot=pd.read_csv(R/'outputs/curry_shot_context_field_inventory.csv');shotcuts=pd.read_csv(R/'outputs/curry_shot_context_exact_cutoffs.csv');check('numeric shot fields',led['shot_tracking_synergy_snapshot_numeric_fields_examined'],shotcuts.field.nunique());check('numeric shot fields233',led['shot_tracking_synergy_snapshot_numeric_fields_examined'],233);check('shot provenance total',led['shot_context_and_provenance_fields_total'],len(shot));check('discovery not prospective',led['prospective_cutoff_registration_before_2025_26_results'],False);check('first return sensitivity date',led['first_within_season_30day_gap_return'],str(first.date()));check('new model count',led['new_models_fitted'],0)
unknown=z[recent&z.track_cs_fga_prior10.isna()];check('tracking unknown dates',led['tracking_unknown_2025_26_dates']==unknown.date.dt.strftime('%Y-%m-%d').tolist(),True);check('tracking unknown count',len(unknown),10);check('tracking unknown hits',unknown.dk.ge(48).sum(),3)
files=['analysis/score_pregame_identifiers.py','outputs/curry_pregame_identifier_scorecard.csv','outputs/curry_pregame_identifier_game_membership.csv','outputs/curry_existing_model_fixed48_predictions.csv','outputs/curry_existing_model_fixed48_scorecard.csv','outputs/curry_existing_model_fixed48_calibration.csv','audit/curry_identifier_exploration_ledger.json']
report={'status':'PASS' if not fail else 'FAIL','checks':len(checks),'failed_checks':len(fail),'candidate_rows':len(sc),'primary_candidate_rows':int(sc.restriction.eq('primary').sum()),'sensitivity_rows':int(sc.restriction.ne('primary').sum()),'candidate_bootstrap_rows_reproduced':len(boot_samples),'prediction_rows':len(rp),'saved_model_scorecards':len(card),'calibration_rows':len(cal),'frozen_individual_tree_artifacts_checked':len(models),'new_models_fitted':0,'production_outputs_modified':False,'audit_code_sha256':sha(Path(__file__)),'audited_output_sha256':{f:sha(R/f) for f in files},'notes':['Candidate results are exploratory retrospective re-scoring after condition discovery, not prospective validation.','Recall denominator is all67 inclusive DK hits, even when condition coverage is smaller.','Exact player probabilities use each frozen saved leaf/global empirical residual distribution and its saved pseudocount; pooled seven-quantile inversion is approximate.','Frozen saved models retain their original feature contract, including old team_b2b; no model is refitted here.','A deterministic top20 subset breaks probability ties by date then game ID; tie-inclusive counts expose the alternate boundary interpretation.']}
(A/'identifier_audit_summary.json').write_text(json.dumps(report,indent=2));(A/'identifier_failures.json').write_text(json.dumps(fail,indent=2));(A/'identifier_bootstrap_samples.json').write_text(json.dumps(boot_samples,indent=2));pd.DataFrame(checks,columns=['check','passed']).to_csv(A/'identifier_all_checks.csv.gz',index=False,compression='gzip');print(json.dumps(report,indent=2));print('FAILURES',json.dumps(fail[:40],indent=2))
