import csv,gzip,json,hashlib
from pathlib import Path
BASE=Path('/workspace/scratch/0bd466b49713')
OUT=BASE/'nba_interaction_pilot_20261012/curry_condition_overlay_20261012/salary_audit'
records=[];matches=[];hashes={}
for p in sorted(BASE.rglob('*')):
 if not p.is_file() or OUT in p.parents or not (p.name.endswith('.csv') or p.name.endswith('.csv.gz')): continue
 if not p.relative_to(BASE).parts[0].startswith(('nba','dk_nba','fd_nba','attachments','incoming','january')):continue
 try:
  op=gzip.open if p.name.endswith('.gz') else open
  with op(p,'rt',encoding='utf-8-sig',errors='replace',newline='') as f:
   reader=csv.DictReader(f); cols=reader.fieldnames or []
   s=[c for c in cols if 'salary' in c.lower()]
   if not s:continue
   h=hashlib.sha256(p.read_bytes()).hexdigest()
   rec={'path':str(p.relative_to(BASE)),'sha256':h,'bytes':p.stat().st_size,'salary_columns':s,'columns':cols}
   if h in hashes:
    rec['duplicate_of']=hashes[h];records.append(rec);continue
   hashes[h]=str(p.relative_to(BASE));q=[]
   for i,r in enumerate(reader):
    if any('stephen curry' in str(v).lower() or 'stephencurry' in str(v).lower() for v in r.values()):q.append({'source_file':str(p.relative_to(BASE)),'source_sha256':h,'source_csv_row':i+2,'record':r})
   rec['curry_rows']=len(q);records.append(rec);matches.extend(q)
 except Exception as e:records.append({'path':str(p.relative_to(BASE)),'error':str(e)})
(OUT/'saved_csv_source_inventory.json').write_text(json.dumps(records,indent=2))
(OUT/'all_curry_salary_csv_rows.json').write_text(json.dumps(matches,indent=2))
for r in records:
 if r.get('curry_rows'):print(r['curry_rows'],r['path'])
print('INVENTORY',len(records),'unique',len(hashes),'rows',len(matches))
