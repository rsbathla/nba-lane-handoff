from pathlib import Path
import pandas as pd,numpy as np,json,hashlib,datetime
P=Path('/workspace/scratch/0bd466b49713');B=P/'dallas_review_20261012/method_comparison_20261012';O=B/'combinatorial_search'
bp=P/'nba_fd_box_outcomes_20261010/box_derived_fd_outcomes_REVIEWED.csv';tp=P/'nba_tracking_integration_20261010/deliverable/tracking_repair/corrected_tracking_2025-26_with_provenance.csv';ap=P/'dallas_review_20261012/universe_discovery/ALL_eligible_appearances_with_thresholds_traits_and_controls.csv'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cols=['date','game_id','person_id','player','minutes','fgm','fga','fg3m','fg3a','fta','ast','reb','stl','blk','tov','oreb','dreb']
b=pd.read_csv(bp,usecols=cols).query('minutes>0').sort_values(['person_id','date','game_id']).reset_index(drop=True)
assert not b.duplicated(['person_id','date']).any();g=b.groupby('person_id');b['prior_n']=g.cumcount();b['feature_last_date']=g.date.shift();b['window_first_date']=g.date.shift(30)
b['prior10_minutes']=g.minutes.transform(lambda s:s.shift().rolling(10,min_periods=10).mean());b['prior30_minutes_sd']=g.minutes.transform(lambda s:s.shift().rolling(30,min_periods=30).std())
b['two_m']=b.fgm-b.fg3m;b['two_a']=b.fga-b.fg3a
validtwo=b[['fgm','fga','fg3m','fg3a']].notna().all(axis=1)&(b[['fgm','fga','fg3m','fg3a']]>=0).all(axis=1)&(b.two_m>=0)&(b.two_a>=b.two_m)&(b.fg3a>=b.fg3m)
validreb=b[['oreb','dreb','reb']].notna().all(axis=1)&(b[['oreb','dreb','reb']]>=0).all(axis=1)&np.isclose(b.oreb+b.dreb,b.reb)
b.loc[~validtwo,['two_m','two_a']]=np.nan;b.loc[~validreb,['oreb','dreb']]=np.nan
for c in ['minutes','fga','fg3a','fta','ast','reb','stl','blk','tov','oreb','dreb','two_m','two_a']:b['sum30_'+c]=g[c].transform(lambda s:s.shift().rolling(30,min_periods=30).sum())
for c in ['fga','fta','ast','reb','stl','blk','tov','oreb','dreb']:b['prior30_'+c+'36']=36*b['sum30_'+c]/b.sum30_minutes
b['prior30_three_share']=b.sum30_fg3a/b.sum30_fga;b['prior30_fta_fga']=b.sum30_fta/b.sum30_fga;b['prior30_two_pts36']=72*b.sum30_two_m/b.sum30_minutes;b['prior30_two_pct']=b.sum30_two_m/b.sum30_two_a;b['prior30_oreb_share']=b.sum30_oreb/b.sum30_reb
tr=pd.read_csv(tp);assert len(tr)==88977;assert not tr.duplicated(['date','nba_pid','tag']).any()
tr=tr.rename(columns={'nba_pid':'person_id'}).merge(b[['date','person_id','fgm','fga','fg3m','fg3a']],on=['date','person_id'],how='left',suffixes=('_tag','_box'),validate='many_to_one')
tr['box_present']=tr.fga_box.notna(); checks={}
checks['nonnegative_integer_components']=tr[['fgm_tag','fga_tag','fg3m_tag','fg3a_tag']].notna().all(axis=1)&(tr[['fgm_tag','fga_tag','fg3m_tag','fg3a_tag']]>=0).all(axis=1)&np.isclose(tr[['fgm_tag','fga_tag','fg3m_tag','fg3a_tag']],np.round(tr[['fgm_tag','fga_tag','fg3m_tag','fg3a_tag']])).all(axis=1)
checks['tag_internal_consistency']=(tr.fgm_tag<=tr.fga_tag)&(tr.fg3m_tag<=tr.fg3a_tag)&(tr.fg3m_tag<=tr.fgm_tag)&(tr.fg3a_tag<=tr.fga_tag)&((tr.fgm_tag-tr.fg3m_tag)<=(tr.fga_tag-tr.fg3a_tag))
checks['subset_of_box_components']=(tr.fgm_tag<=tr.fgm_box)&(tr.fga_tag<=tr.fga_box)&(tr.fg3m_tag<=tr.fg3m_box)&(tr.fg3a_tag<=tr.fg3a_box)&((tr.fgm_tag-tr.fg3m_tag)<=(tr.fgm_box-tr.fg3m_box))&((tr.fga_tag-tr.fg3a_tag)<=(tr.fga_box-tr.fg3a_box))
for k,v in checks.items():tr[k]=v
tr['valid']=tr.box_present&tr[list(checks)].all(axis=1)
tr['invalid_reason']=tr.apply(lambda r:';'.join(k for k in ['box_present']+list(checks) if not r[k]),axis=1)
tr.to_csv(O/'all_tracking_source_rows_validity.csv',index=False)
for tag in ['cs','pu','lt10','wo','vtight']:
 z=tr[tr.tag.eq(tag)][['date','person_id','valid','fga_tag','fga_box']];z=z.rename(columns={'valid':'valid_'+tag,'fga_tag':'tag_attempts_'+tag,'fga_box':'observed_box_attempts_'+tag});b=b.merge(z,on=['date','person_id'],how='left',validate='one_to_one')
 v=b['valid_'+tag].fillna(False).astype(bool);b['tag_observed_'+tag]=v.astype(int);b.loc[~v,['tag_attempts_'+tag,'observed_box_attempts_'+tag]]=np.nan;g=b.groupby('person_id')
 # Empty/unobserved dates contribute no numerator or denominator; validity count prevents treating absent tags as zero.
 for c in ['tag_observed_'+tag,'tag_attempts_'+tag,'observed_box_attempts_'+tag]:b['prior30_'+c]=g[c].transform(lambda s:s.fillna(0).shift().rolling(30,min_periods=30).sum())
 n=b['prior30_tag_observed_'+tag];den=b['prior30_observed_box_attempts_'+tag];b['prior30_'+tag+'_observed_ratio']=b['prior30_tag_attempts_'+tag]/den;b.loc[(n<15)|(den<=0),'prior30_'+tag+'_observed_ratio']=np.nan
roles=['prior10_minutes','prior30_minutes_sd'];vols=['prior30_fga36','prior30_fta36'];ability=['prior30_three_share','prior30_fta_fga','prior30_ast36','prior30_reb36','prior30_stl36','prior30_blk36','prior30_tov36','prior30_two_pts36','prior30_two_pct','prior30_oreb36','prior30_dreb36','prior30_oreb_share'];tracking=['prior30_'+t+'_observed_ratio' for t in ['cs','pu','lt10','wo','vtight']];features=roles+vols+ability+tracking
idcols=['date','game_id','person_id','player','prior_n','feature_last_date','window_first_date'];trackaudit=[c for c in b if c.startswith('prior30_tag_') or c.startswith('prior30_observed_box')]
b[idcols+features+trackaudit].to_csv(O/'all_positive_minute_prior_features.csv',index=False)
a=pd.read_csv(ap,usecols=['mode','sample','date','game_id','person_id']);a=a.query("mode=='prior_only_threshold' and sample=='Dallas'")[['date','game_id','person_id']];d=a.merge(b[idcols+features+trackaudit],on=['date','game_id','person_id'],validate='one_to_one');assert len(d)==382 and d.person_id.nunique()==232 and d.game_id.nunique()==50;assert (d.feature_last_date<d.date).all();d.to_csv(O/'Dallas_features_OUTCOME_FREE.csv',index=False)
inv=[]
for fam,fs in [('role',roles),('volume',vols),('box_ability',ability),('tracking_ability',tracking)]:
 for f in fs:inv.append({'feature':f,'family':fam,'Dallas_available':int(d[f].notna().sum()),'Dallas_unknown':int(d[f].isna().sum()),'minimum_observed_tag_dates':15 if fam=='tracking_ability' else None,'window':'strictly earlier10 positive-minute player appearances' if f=='prior10_minutes' else 'strictly earlier30 positive-minute player appearances','unit':'observed tag attempts / box attempts on same valid observed dates' if fam=='tracking_ability' else 'box derived','source_path':str(tp if fam=='tracking_ability' else bp),'source_sha256':sha(tp if fam=='tracking_ability' else bp)})
pd.DataFrame(inv).to_csv(O/'FEATURE_INVENTORY.csv',index=False)
feas={'prepared_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outcome_columns_read':False,'positive_minute_rows':len(b),'Dallas_rows':len(d),'Dallas_players':d.person_id.nunique(),'Dallas_dates':d.date.nunique(),'tracking_source_rows':len(tr),'tracking_invalid_total':int((~tr.valid).sum()),'tracking_invalid_by_tag':tr[~tr.valid].groupby('tag').size().to_dict(),'tracking_rows_by_tag':tr.groupby('tag').size().to_dict(),'tracking_Dallas_coverage':{f:int(d[f].notna().sum()) for f in tracking},'features':features,'families':{'role':roles,'volume':vols,'ability':ability+tracking},'candidate_counts':{'singles':2*len(features),'pairs':4*len(features)*(len(features)-1)//2,'role_volume_ability_triples':8*len(roles)*len(vols)*(len(ability)+len(tracking))},'source_hashes':{str(p):sha(p) for p in [bp,tp,ap]},'invalid_box_two_components':int((~validtwo).sum()),'invalid_box_rebound_components':int((~validreb).sum())};feas['candidate_counts']['total']=sum(feas['candidate_counts'].values());(O/'OUTCOME_FREE_FEASIBILITY.json').write_text(json.dumps(feas,indent=2));print(json.dumps(feas,indent=2))
