"""Curry fixed-bin descriptive context tables. Offline, no fitted models or cutoff search."""
from pathlib import Path
import pandas as pd
import numpy as np
import json, hashlib

O = Path(__file__).resolve().parents[1]
I = O.parent / 'inputs/three_season'
OUT = O / 'outputs'; AUD = O / 'audit'
OUT.mkdir(exist_ok=True); AUD.mkdir(exist_ok=True)
inputs = []
def read(path, **kwargs):
    inputs.append(path)
    return pd.read_csv(path, **kwargs)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def id10(s): return s.astype(str).str.replace(r'\.0$', '', regex=True).str.zfill(10)

p = read(OUT/'curry_full_three_season_inventory.csv', dtype={'game_id':str,'person_id':str})
p['game_id'] = id10(p.game_id)
p = p.sort_values(['date','game_id']).reset_index(drop=True)
assert len(p)==187 and p.person_id.eq('201939').all() and p.team.eq('GSW').all()
assert not p.duplicated(['game_id','person_id']).any()
# Independently verify the supplied baseline/labels. Mean uses prior 20 appearances;
# q90 uses all earlier appearances, minimum 50, carried across the season boundary.
label_checks={}
for site in ['dk','fd']:
    p[f'{site}_ge48_inclusive'] = p[site].ge(48).astype(int)
    p[f'{site}_lt48'] = p[site].lt(48).astype(int)
    lag=p[site].shift(1)
    mean=lag.rolling(20,min_periods=20).mean()
    q90=lag.expanding(min_periods=50).quantile(.9)
    assert mean.isna().equals(p[f'{site}_prior20_mean'].isna())
    assert q90.isna().equals(p[f'{site}_prior_q90'].isna())
    assert np.allclose(mean.dropna(),p.loc[mean.notna(),f'{site}_prior20_mean'])
    assert np.allclose(q90.dropna(),p.loc[q90.notna(),f'{site}_prior_q90'])
    assert np.allclose(p[site]-mean,p[f'{site}_residual'],equal_nan=True)
    assert np.allclose((p[site]>q90)[q90.notna()].astype(int),p.loc[q90.notna(),f'{site}_hit_q90'])
    label_checks[site]={'prior20_residual_n':int(mean.notna().sum()),'prior_expanding_q90_n':int(q90.notna().sum()),'q90_min_prior_appearances':50,'q90_hit_operator':'>'}

contexts=[]; schedule_audit=[]
for season in ['2023-24','2024-25']:
    source=I/f'nba_historical_box_recovery_20261011/derived/team_game_components_{season}_regular.csv'
    d=read(source,dtype={'GAME_ID':str})
    d=d[d.TEAM_ABBREVIATION.eq('GSW')].copy().sort_values(['GAME_DATE','GAME_ID'])
    assert len(d)==82 and d.GAME_ID.nunique()==82
    d['game_id']=id10(d.GAME_ID);d['date']=d.GAME_DATE;d['season']=season
    d['team']='GSW';d['opponent']=d.MATCHUP.str.split().str[-1]
    d['home_away']=d.MATCHUP.map(lambda x:'home' if 'vs.' in x else 'away' if '@' in x else 'missing')
    d['venue_code']=d.home_away.map({'home':'H','away':'R'})
    d['previous_recorded_team_game_id']=d.game_id.shift()
    d['previous_recorded_team_game_date']=d.date.shift()
    d['days_without_recorded_team_game']=(pd.to_datetime(d.date)-pd.to_datetime(d.previous_recorded_team_game_date)).dt.days-1
    d['context_source_file']=str(source);d['context_source_sha256']=sha(source)
    d['rest_chronology_basis']='GSW full 82-game regular-season team schedule, sorted by actual game date; season opener missing. GSW did not play excluded Cup final.'
    d['context_source_provider']='Recovered NBA team-game components'
    d['market_source_status']='No historical market source in held three-season inputs for this season'
    cols=['season','game_id','date','team','opponent','home_away','venue_code','previous_recorded_team_game_id','previous_recorded_team_game_date','days_without_recorded_team_game','context_source_file','context_source_sha256','rest_chronology_basis','context_source_provider','market_source_status']
    contexts.append(d[cols]);schedule_audit.append({'season':season,'GSW_team_games':len(d),'first_team_date':d.date.min(),'last_team_date':d.date.max(),'source':str(source)})

source=I/'nba_three_season_ceiling_20261011/coverage_audit/team_game_descriptive_context_2025-26.csv'
m=read(source,dtype={'game_id':str});m['game_id']=id10(m.game_id)
# Verify spread signs against the source's moneyline, away from near-pickem vigorish cases.
ml=pd.to_numeric(m.moneyline_as_exported,errors='coerce')
check=m.closing_spread.abs().ge(2.5)&ml.notna()
assert (m.loc[check,'closing_spread']*ml[check]>0).all()
# Opposite team spreads and equal game totals provide a separate structural check.
struct=m.groupby('game_id').agg(n=('team','size'),closing_spread_sum=('closing_spread','sum'),total_nunique=('closing_total','nunique'))
assert struct.n.eq(2).all() and np.allclose(struct.closing_spread_sum,0) and struct.total_nunique.eq(1).all()
m=m[m.team.eq('GSW')].copy(); assert len(m)==82 and m.game_id.nunique()==82
m['season']='2025-26';m['home_away']=m.venue_code.map({'H':'home','R':'away','N':'neutral'}).fillna('missing')
m['context_source_file']=str(source);m['context_source_sha256']=sha(source)
m['context_source_provider']=m.source_provider;m['market_source_status']='Historical descriptive only; source capture time and lock-time availability unverified'
# Preserve underlying workbook provenance as well as normalization source path.
m=m.rename(columns={'source_file':'market_original_source_file','source_sha256':'market_original_source_sha256','source_sheet':'market_original_source_sheet'})
keep=contexts[0].columns.tolist()+['source_excel_row','team_rest_as_exported','team_rest_censored','team_rest_numeric_uncensored','opening_spread','opening_total','closing_spread','closing_total','opening_itt_reconstructed','closing_itt_reconstructed','opening_odds_as_exported','closing_odds_as_exported','moneyline_as_exported','source_observed_at_utc','market_asof_utc','strict_pregame_vintage_verified','is_realized_descriptive_context','market_original_source_file','market_original_source_sha256','market_original_source_sheet']
contexts.append(m[keep]);schedule_audit.append({'season':'2025-26','GSW_team_games':len(m),'first_team_date':m.date.min(),'last_team_date':m.date.max(),'source':str(source)})
c=pd.concat(contexts,ignore_index=True).sort_values(['season','date','game_id'])
assert not c.duplicated(['game_id','team']).any()
# Schedule venue transition is not an observed travel itinerary or distance.
c['previous_team_fixture_home_away']=c.groupby('season').home_away.shift()
c['team_fixture_venue_transition']=np.where(c.previous_team_fixture_home_away.isna(),'missing',c.previous_team_fixture_home_away.fillna('missing')+' to '+c.home_away)
c['team_days_since_previous_game']=c.days_without_recorded_team_game+1
c['team_b2b']=c.team_days_since_previous_game.map(lambda x:'missing' if pd.isna(x) else 'B2B' if x==1 else 'not_B2B')
c['team_rest_bin']=c.days_without_recorded_team_game.map(lambda x:'missing' if pd.isna(x) else '0_days_B2B' if x==0 else '1_day' if x==1 else '2_days' if x==2 else '3_plus_days')
# Source-rest string is retained separately. Where it exists, it must agree with chronology.
known=c.team_rest_as_exported.notna()&c.team_b2b.ne('missing')
assert (c.loc[known,'team_rest_as_exported'].str.contains('B2B')==c.loc[known,'team_b2b'].eq('B2B')).all()
p=p.merge(c,on=['season','game_id','date','team','opponent'],how='left',validate='one_to_one',indicator='context_join_status')
assert p.context_join_status.eq('both').all()
p['actual_travel_distance_miles']=np.nan
p['travel_measurement_status']='No actual travel itinerary, distance or arrival-time source in held context; not inferred from player appearance gaps or team cities'
p['market_is_pregame_certified']=False
p['market_comparison_scope']='Closing fields primary; opening fields separate sensitivity description; neither vintage certified'
for stage in ['opening','closing']:
    total=p[f'{stage}_total'];spread=p[f'{stage}_spread'];itt=p[f'{stage}_itt_reconstructed']
    p[f'{stage}_total_bin']=pd.cut(total,[-np.inf,225,235,np.inf],right=False,labels=['<225','225_to_<235','235+']).astype(object).fillna('missing')
    p[f'{stage}_abs_spread_bin']=pd.cut(spread.abs(),[-np.inf,5,10,np.inf],right=False,labels=['<5','5_to_<10','10+']).astype(object).fillna('missing')
    p[f'{stage}_favorite_status']=spread.map(lambda x:'missing' if pd.isna(x) else 'favorite' if x<0 else 'underdog' if x>0 else 'pickem')
    p[f'{stage}_team_implied_bin']=pd.cut(itt,[-np.inf,112.5,120,np.inf],right=False,labels=['<112.5','112.5_to_<120','120+']).astype(object).fillna('missing')

# Explicit missing/zero-count bins are emitted for each site and each season, including pooled.
dims={
'all':['all'],
'home_away':['home','away','neutral','missing'],
 'team_b2b':['B2B','not_B2B','missing'],
 'team_rest_bin':['0_days_B2B','1_day','2_days','3_plus_days','missing'],
 'team_fixture_venue_transition':['home to home','home to away','away to home','away to away','missing'],
}
for stage in ['closing','opening']:
    dims.update({f'{stage}_total_bin':['<225','225_to_<235','235+','missing'],f'{stage}_abs_spread_bin':['<5','5_to_<10','10+','missing'],f'{stage}_favorite_status':['favorite','underdog','pickem','missing'],f'{stage}_team_implied_bin':['<112.5','112.5_to_<120','120+','missing']})

def summaries(g,site):
    x=g[site].dropna(); r=g[f'{site}_residual'].dropna(); hit=g[f'{site}_hit_q90'].dropna()
    out={'appearances_n':len(g),'window_start':g.date.min() if len(g) else None,'window_end':g.date.max() if len(g) else None,'fullscore_n':len(x),'prior20_residual_n':len(r),'prior20_residual_missing_n':len(g)-len(r),'strict_prior_q90_eligible_n':len(hit),'strict_prior_q90_missing_n':len(g)-len(hit),'strict_prior_q90_hits':int(hit.sum()),'strict_prior_q90_misses':int(len(hit)-hit.sum()),'strict_prior_q90_hit_rate':float(hit.mean()) if len(hit) else np.nan,'fixed48_hits':int(g[site].ge(48).sum()),'fixed48_misses':int(g[site].lt(48).sum()),'fixed48_eligible_n':int(g[site].notna().sum()),'fixed48_missing_n':int(g[site].isna().sum()),'fixed48_hit_rate':float(g[site].dropna().ge(48).mean()) if len(x) else np.nan}
    for label,values in [('fullscore',x),('prior20_residual',r)]:
        out.update({f'{label}_mean':values.mean(),f'{label}_median':values.median(),f'{label}_q90':values.quantile(.90),f'{label}_q95':values.quantile(.95)})
    # Fullscore on residual-eligible rows permits like-for-like interpretation of means.
    out['fullscore_mean_on_prior20_eligible']=g.loc[g[f'{site}_residual'].notna(),site].mean()
    out['prior20_baseline_mean_on_eligible']=g[f'{site}_prior20_mean'].mean()
    return out
rows=[]
for season in ['2023-24','2024-25','2025-26','combined_three_seasons']:
    season_g=p if season=='combined_three_seasons' else p[p.season.eq(season)]
    for dim,levels in dims.items():
        if dim!='all':assert set(season_g[dim].unique()).issubset(levels)
        for level in levels:
            g=season_g if dim=='all' else season_g[season_g[dim].eq(level)]
            for site in ['dk','fd']:
                rows.append({'season':season,'site':site,'context_dimension':dim,'context_bin':level,**summaries(g,site),'pooled_year_confounding_caution':season=='combined_three_seasons','interpretation':'Unadjusted historical descriptive association; no causal or predictive claim','market_timing_caution':dim.startswith(('opening','closing'))})
splits=pd.DataFrame(rows)
for (season,site,dim),g in splits.groupby(['season','site','context_dimension']):
    n=len(p) if season=='combined_three_seasons' else int(p.season.eq(season).sum())
    assert g.appearances_n.sum()==n
    assert (g.strict_prior_q90_hits+g.strict_prior_q90_misses==g.strict_prior_q90_eligible_n).all()
    assert (g.fixed48_hits+g.fixed48_misses==g.fixed48_eligible_n).all()

coverage=[]
for season,g in p.groupby('season'):
    for field in ['home_away','team_days_since_previous_game','closing_total','closing_spread','closing_itt_reconstructed','opening_total','opening_spread','opening_itt_reconstructed','actual_travel_distance_miles']:
        available=g[field].notna() & ~g[field].astype(str).eq('missing')
        coverage.append({'season':season,'field':field,'appearances_n':len(g),'available_n':int(available.sum()),'missing_n':int((~available).sum()),'window_start':g.date.min(),'window_end':g.date.max(),'available_window_start':g.loc[available,'date'].min(),'available_window_end':g.loc[available,'date'].max()})
# High-versus-low groups are defined independently for DK and FD; no platform mixing.
features=['minutes','dk','fd','dk_residual','fd_residual','team_days_since_previous_game','days_without_recorded_team_game','opening_total','closing_total','opening_spread','closing_spread','opening_itt_reconstructed','closing_itt_reconstructed']
h=p.copy();h['is_home']=h.home_away.map({'home':1.,'away':0.});h['is_away']=h.home_away.map({'home':0.,'away':1.});h['is_team_b2b']=h.team_b2b.map({'B2B':1.,'not_B2B':0.});h['abs_closing_spread']=h.closing_spread.abs();h['abs_opening_spread']=h.opening_spread.abs()
features+=['is_home','is_away','is_team_b2b','abs_closing_spread','abs_opening_spread']
highlow=[]
for season in ['2023-24','2024-25','2025-26','combined_three_seasons']:
    sg=h if season=='combined_three_seasons' else h[h.season.eq(season)]
    for site in ['dk','fd']:
        high=sg[sg[site].ge(48)];low=sg[sg[site].lt(48)]
        for feature in features:
            a=high[feature].dropna();b=low[feature].dropna()
            highlow.append({'season':season,'threshold_site':site,'threshold_definition':site.upper()+'>=48 inclusive versus <48','feature':feature,'high_group_n':len(high),'low_group_n':len(low),'high_feature_available_n':len(a),'low_feature_available_n':len(b),'high_feature_missing_n':len(high)-len(a),'low_feature_missing_n':len(low)-len(b),'high_mean':a.mean(),'low_mean':b.mean(),'high_minus_low_mean':a.mean()-b.mean(),'high_median':a.median(),'low_median':b.median(),'high_window_start':high.date.min(),'high_window_end':high.date.max(),'low_window_start':low.date.min(),'low_window_end':low.date.max(),'source_timing':'Market columns historical descriptive only; team schedule observed; minutes/fullscore/residual realized outcomes','not_causal':True})
pd.DataFrame(highlow).to_csv(OUT/'curry_fixed48_context_high_vs_low.csv',index=False)
threshold_cols=['season','site','context_dimension','context_bin','appearances_n','window_start','window_end','fixed48_hits','fixed48_misses','fixed48_eligible_n','fixed48_missing_n','fixed48_hit_rate','fullscore_mean','fullscore_median','fullscore_q90','fullscore_q95','prior20_residual_n','prior20_residual_mean','prior20_residual_median','prior20_residual_q90','prior20_residual_q95','pooled_year_confounding_caution','interpretation','market_timing_caution']
splits[threshold_cols].to_csv(OUT/'curry_fixed48_context_splits.csv',index=False)
p.to_csv(OUT/'curry_fixed48_context_ledger.csv',index=False)
p.to_csv(OUT/'curry_market_context_join.csv',index=False)
splits.to_csv(OUT/'curry_market_context_splits.csv',index=False)
pd.DataFrame(coverage).to_csv(OUT/'curry_market_context_coverage.csv',index=False)
c.to_csv(OUT/'gsw_three_season_schedule_context.csv',index=False)
source_inventory=[{'absolute_path':str(z),'sha256':sha(z),'role':'Curry appearance/baseline inventory' if z.name.startswith('curry_full') else 'Full GSW team chronology and home/away' if 'team_game_components' in z.name else 'Normalized 2025–26 team market context, full GSW chronology, provenance retained'} for z in inputs]
original=O.parents[1]/'nba_fd_box_outcomes_20261010/source/04-12-2026-nba-season-team-feed.xlsx'
# Keep the original underlying workbook audit when available; no inference that a normalized field has lock-time certification.
if original.exists(): source_inventory.append({'absolute_path':str(original),'sha256':sha(original),'role':'Original owner-held BigDataBall 2025–26 team workbook behind normalized context'})
pd.DataFrame(source_inventory).to_csv(AUD/'curry_market_context_sources.csv',index=False)
audit={'offline_only':True,'no_model_fit':True,'no_outcome_optimized_cutoff':True,'fixed48_counts':{site:{'hits':int(p[site].ge(48).sum()),'misses':int(p[site].lt(48).sum()),'n':len(p),'inclusive':True} for site in ['dk','fd']},'curry_appearances':len(p),'unique_game_ids':p.game_id.nunique(),'all_context_joins_exact':bool(p.context_join_status.eq('both').all()),'join_keys':['season','date','game_id','team','opponent'],'schedule_audit':schedule_audit,'label_checks':label_checks,'market_primary_stage':'closing','market_certified_pregame_rows':0,'market_coverage_by_season':p.groupby('season').closing_total.count().to_dict(),'spread_sign_crosscheck_team_rows_abs_at_least_2point5':int(check.sum()),'spread_sign_crosscheck_failures':0,'opposing_team_spread_sum_max_error':float(struct.closing_spread_sum.abs().max()),'closing_GSW_total_fractional_values':sorted((m.closing_total%1).unique().tolist()),'closing_GSW_implied_total_fractional_values':sorted((m.closing_itt_reconstructed%1).unique().tolist()),'source_rest_string_chronology_agreement_checked_n':int(known.sum()),'source_rest_string_chronology_disagreements':0,'missing_team_rest_Curry_dates':p.loc[p.team_b2b.eq('missing'),['season','date','game_id']].to_dict('records'),'bins':dims,'boundary_definitions':{'total':['x < 225','225 <= x < 235','x >= 235'],'abs_spread':['abs(x) < 5','5 <= abs(x) < 10','abs(x) >= 10'],'team_implied':['x < 112.5','112.5 <= x < 120','x >= 120'],'team_implied_formula':'(team game total - signed team spread)/2','team_b2b':'Team calendar-date difference exactly 1 day; all GSW team games, not player appearance gap'},'quantile_method':'pandas linear empirical quantile, fixed probabilities .90/.95; descriptive group quantiles need not be attained observations','warnings':['Market source has no capture/as-of timestamp and is historical descriptive only; opening/closing labels do not certify pregame availability.','2023–24 and 2024–25 market data missing in held inputs, preserved as missing.','Pooled three-year splits confound season, opponent, health, rotation, minutes and other context; no causal or stable predictive interpretation.','Small cells and few q90 events are noisy. Group q90/q95 summary quantiles are distinct from prior-history q90 hit labels.','Rest chronology resets at season boundaries: opener is missing rather than inferred. Source 2025–26 opener rest=3+ is retained separately.','No actual travel mileage/itinerary provided. Fixture home/away transitions describe schedule venues, not personal travel.','Prior20 baseline and expanding prior-history q90 both carry across season boundaries; q90 minimum prior sample is 50.']}
(AUD/'curry_market_context_audit.json').write_text(json.dumps(audit,indent=2))
manifest={'script':{'path':str(Path(__file__)),'sha256':sha(Path(__file__))},'inputs':source_inventory,'outputs':{str(z):sha(z) for z in [OUT/'curry_market_context_join.csv',OUT/'curry_market_context_splits.csv',OUT/'curry_market_context_coverage.csv',OUT/'gsw_three_season_schedule_context.csv',OUT/'curry_fixed48_context_splits.csv',OUT/'curry_fixed48_context_high_vs_low.csv',OUT/'curry_fixed48_context_ledger.csv',AUD/'curry_market_context_audit.json',AUD/'curry_market_context_sources.csv']}}
(AUD/'curry_market_context_manifest.json').write_text(json.dumps(manifest,indent=2))
show=splits[(splits.season.isin(['2025-26','combined_three_seasons']))&(splits.context_dimension.isin(['home_away','team_b2b','closing_total_bin','closing_abs_spread_bin','closing_favorite_status','closing_team_implied_bin']))&splits.appearances_n.gt(0)]
print(show[['season','site','context_dimension','context_bin','appearances_n','fullscore_mean','prior20_residual_mean','strict_prior_q90_hits','strict_prior_q90_eligible_n']].to_string(index=False))
print(json.dumps({'join_rows':len(p),'split_rows':len(splits),'status':'all assertions passed','output_dir':str(OUT)},indent=2))
