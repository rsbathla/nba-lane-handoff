from pathlib import Path
import json
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT

R=Path(__file__).resolve().parents[1]
O=R/'outputs'
D=pd.read_csv(O/'curry_core_advanced_role_context.csv')
L=pd.read_csv(O/'curry_48point_game_ledger.csv')
M=pd.read_csv(O/'curry_fixed48_context_splits.csv')
S=pd.read_csv(O/'curry_shot_context_distribution_splits.csv')
F=pd.read_csv(O/'curry_shot_context_48_feature_level_comparisons.csv')
J=pd.read_csv(O/'curry_fixed48_joint_context_cells.csv')
T=pd.read_csv(R/'splits_curry_actual_teammate_coappearance_by_season.csv')
ST=pd.read_csv(R/'splits_curry_actual_starter_context_2025_26.csv')
ON=pd.read_csv(R/'splits_curry_actual_onoff_rates_scope_comparison.csv')
H=D.dk.ge(48)

doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(.65);sec.bottom_margin=Inches(.65)
sec.left_margin=Inches(.7);sec.right_margin=Inches(.7)
sec.header_distance=Inches(.25);sec.footer_distance=Inches(.25)
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
 st=doc.styles[name];st.font.name='Calibri';st.font.color.rgb=RGBColor(0,0,0)
 st.paragraph_format.space_after=Pt(6)
for st in doc.styles:
 for el in list(st.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
doc.styles['Normal'].font.size=Pt(10.5)
doc.styles['Normal'].paragraph_format.line_spacing=1.06
doc.styles['Title'].font.size=Pt(24)
doc.styles['Title'].paragraph_format.space_after=Pt(10)
doc.styles['Heading 1'].font.size=Pt(18)
doc.styles['Heading 1'].paragraph_format.space_before=Pt(0)
doc.styles['Heading 1'].paragraph_format.space_after=Pt(9)
doc.styles['Heading 2'].font.size=Pt(12)
doc.styles['Heading 2'].paragraph_format.space_before=Pt(9)
doc.styles['Heading 2'].paragraph_format.space_after=Pt(5)
foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=foot.add_run('Stephen Curry descriptive splits  |  ');r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string('666666')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');foot._p.append(fld)

def p(text, bold=False, small=False):
 x=doc.add_paragraph();r=x.add_run(text);r.bold=bold
 if small:r.font.size=Pt(8.5);r.font.color.rgb=RGBColor.from_string('555555')
 return x
def h(text): doc.add_heading(text,level=2)
def page(title): doc.add_page_break();doc.add_heading(title,level=1)
def f(x,n=1): return '—' if pd.isna(x) else f'{x:.{n}f}'
def pc(x):return f'{100*x:.1f}%'
def tab(headers,rows,widths=None,size=9):
 table=doc.add_table(rows=1,cols=len(headers));table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
 if widths is None:widths=[7.1/len(headers)]*len(headers)
 for i,w in enumerate(widths):table.columns[i].width=Inches(w)
 for i,(c,v) in enumerate(zip(table.rows[0].cells,headers)):
  c.text=str(v);c.width=Inches(widths[i])
  sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E9EDF1');c._tc.get_or_add_tcPr().append(sh)
 rep=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(rep)
 for vals in rows:
  cells=table.add_row().cells
  for i,(c,v) in enumerate(zip(cells,vals)):c.text=str(v);c.width=Inches(widths[i])
 for ri,row in enumerate(table.rows):
  pr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');pr.append(cant)
  for ci,c in enumerate(row.cells):
   c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   tcPr=c._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    el=OxmlElement('w:'+side);el.set(qn('w:w'),'65' if side in ['top','bottom'] else '75');el.set(qn('w:type'),'dxa');mar.append(el)
   tcPr.append(mar)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(0);pp.paragraph_format.line_spacing=1
    if ci:pp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    for rr in pp.runs:rr.font.size=Pt(size);rr.bold=ri==0
 blank=p('',small=True);blank.paragraph_format.space_after=Pt(0);blank.paragraph_format.line_spacing=Pt(4)
 for rr in blank.runs:rr.font.size=Pt(2)
 return table
def market(season,dim,bin):
 return M[(M.season==season)&(M.site=='dk')&(M.context_dimension==dim)&(M.context_bin==bin)].iloc[0]
def mrow(label,r):
 return [label,f"{r.fixed48_hits} / {r.fixed48_misses}",pc(r.fixed48_hit_rate),f(r.fullscore_mean),f(r.fullscore_median),f(r.fullscore_q90)]
def source(text):p('Source: '+text,small=True)

# PAGE 1
doc.add_paragraph('Stephen Curry games with at least 48 DraftKings points',style='Title')
p('Curry reached at least 48 DraftKings points in 67 of 187 games, or 35.8%. The other 120 games finished below 48. The high games shared more minutes, more shots and more made threes. Those are the clearest observed differences.',bold=True)
p('This report compares those 67 high games with the 120 lower games across the held 2023–24, 2024–25 and 2025–26 regular-season records. It then checks whether opponent, market, rest, teammate and shooting-style context explains the pattern. The threshold is inclusive: three games at exactly 48.0 are counted as hits.')
rows=[]
for season in ['2023-24','2024-25','2025-26','ALL']:
 a=S[(S.season==season)&S.site.eq('dk')&S.field.eq('BASELINE')].iloc[0]
 rows.append(['All three seasons' if season=='ALL' else season,f"{a.score_ge48_hits} / {a.score_lt48_misses}",pc(a.score_ge48_rate),f(a.score_mean),f(a.score_median),f(a.score_q90)])
tab(['Season','48+ / below 48','Hit rate','Mean DK','Median DK','90th pct DK'],rows,[1.4,1.1,1.0,1.1,1.1,1.4])
h('What the high games actually shared')
rows=[]
for field,label,mult in [('minutes','Minutes',1),('fga','Field goal attempts',1),('fg3a','Three point attempts',1),('fg3m','Made threes',1),('usage_proxy','Usage proxy percent',1),('ast','Assists',1),('reb','Rebounds',1)]:
 a=D.loc[H,field]*mult;b=D.loc[~H,field]*mult
 rows.append([label,f(a.mean(),2),f(b.mean(),2),f(a.median(),2),f(b.median(),2)])
tab(['Actual game statistic','High mean','Lower mean','High median','Lower median'],rows,[2.1,1.25,1.25,1.25,1.25])
p('The difference is volume plus execution. High games averaged 3.1 extra minutes, 5.2 extra shots and 2.7 extra made threes. Curry’s three-point share of all attempts was slightly lower in the high games, 61.1% versus 62.2%, so a larger three-point share alone was not the common feature.')
p('FanDuel is a separate outcome: 46 of 187 games reached 48 FD points (24.6%). Its overall mean, median and 90th percentile were 40.19, 41.20 and 53.56. DK and FD hit counts are not interchangeable.',small=True)
source('Curry game ledger and core context. Windows: Oct 24 2023–Apr 12 2024; Oct 23 2024–Apr 13 2025; Oct 21 2025–Apr 12 2026. All 187 have box-score outcomes.')

# PAGE 2
page('What earlier games could tell us')
p('The same-game differences on page 1 explain what happened. They were not known in advance. Earlier minutes, earlier usage and expected pace showed much smaller differences between the high and lower groups.')
rows=[]
for field,label,mult in [('minutes_lag5','Previous 5 appearance minutes',1),('usage_proxy_lag10','Prior usage proxy percent',1),('expected_fga_proxy','Expected shot volume proxy',1),('expected_box_pace','Expected box pace proxy',1),('three_attempt_share_lag10','Prior three point attempt share',100)]:
 a=D.loc[H,field].dropna()*mult;b=D.loc[~H,field].dropna()*mult
 rows.append([label,f'{len(a)} / {len(b)}',f(a.mean(),2),f(b.mean(),2),f(a.median(),2),f(b.median(),2)])
tab(['History feature','Known high / lower','High mean','Lower mean','High median','Lower median'],rows,[2.25,1.05,.95,.95,.95,.95],8.7)
h('All twelve team factors')
p('Each cell below is the high-group mean / lower-group mean of the previous 10 team games. Golden State has 162 known games (59 high, 103 lower); opponents have 161 (58 high, 103 lower). The target game is excluded. These are box-derived estimates and ratios.',small=True)
factor_labels=[('pace','Pace',1),('off_rating_box','Offensive rating',1),('def_rating_box','Defensive rating',1),('net_rating_box','Net rating',1),('efg','Effective FG percent',100),('opp_efg','Opponent effective FG percent',100),('tov_per100','Turnovers per 100',1),('oreb_share','Offensive rebound share percent',100),('fta_per_fga','FT attempts per 100 FG attempts',100),('three_att_share','Three point attempt share percent',100),('three_accuracy','Three point accuracy percent',100),('assist_per_fgm','Assists per 100 made FG',100)]
rows=[]
for field,label,mult in factor_labels:
 vals=[]
 for team in ['own','opponent']:
  c=team+'_advanced_'+field+'_prior10';vals.append(f'{D.loc[H,c].mean()*mult:.2f} / {D.loc[~H,c].mean()*mult:.2f}')
 rows.append([label,*vals])
tab(['Prior 10 game factor','Golden State high / lower','Opponent high / lower'],rows,[3.05,2.025,2.025],9)
p('Prior team averages showed modest separation overall. Expected pace was 100.76 versus 100.62. Prior Golden State three-point accuracy was 36.6% versus 36.7%. These close averages do not rule out useful probability differences for particular conditions or combinations.')
p('The same-game versions also exist for all 187 games. Golden State’s realized offensive rating was 119.96 in high games versus 112.78 in lower games; its three-point accuracy was 39.8% versus 35.8%. Curry’s own scoring contributes to those team outcomes, so they cannot serve as independent pregame explanations.',small=True)
source('Core context, full 105-field inventory and advanced-role split tables. Per-field fixed-48 counts, score means, medians, 90th and 95th percentiles, history residuals and missingness are retained in the data bundle.')

# PAGE 3
page('Shooting style and opponent allowance')
p('Opponents allowing more three-point attempts did not produce more 48+ games in this sample. Volume allowed, makes allowed, accuracy allowed and share allowed tell different stories and should not be treated as one matchup boost.')
rows=[]
for field,label in [('opp_allowed_3pa_prior10_mean','3PA per game'),('opp_allowed_3pm_prior10_mean','Made threes per game'),('opp_allowed_3p_pct_prior10_weighted','Three point accuracy'),('opp_allowed_3pa_share_prior10_weighted','Three point attempt share')]:
 for bn,bnlabel in [('above','Above median'),('below_or_equal','At or below')]:
  a=S[(S.season=='ALL')&S.site.eq('dk')&S.field.eq(field)&S.bin.eq(bn)].iloc[0]
  rows.append([label+'\n'+bnlabel,f'{a.score_ge48_hits} / {a.score_lt48_misses}',pc(a.score_ge48_rate),f(a.score_mean),f(a.score_median),f(a.score_q90)])
tab(['Opponent prior 10 games','48+ / below 48','Hit rate','Mean DK','Median DK','90th pct DK'],rows,[2.1,1.0,.9,1.0,1.0,1.1],8.8)
p('All four comparisons have 161 known games and 26 missing (9 high, 17 lower). “Above” uses each completed season’s median of the context feature, chosen without score outcomes. For attempts per game the cutoffs are 34.6, 37.6 and 35.8. These are retrospective descriptive cutoffs, not validated live thresholds.',small=True)
h('Catch and shoot and pull up shots')
rows=[]
for field,label in [('track_cs_fga','Catch and shoot attempts'),('track_pu_fga','Pull up attempts'),('track_cs_fga_prior10','Prior 10 catch and shoot attempts'),('track_pu_fga_prior10','Prior 10 pull up attempts')]:
 a=F[(F.season=='ALL')&F.site.eq('dk')&F.feature.eq(field)&F.outcome_group.eq('ge48')].iloc[0]
 b=F[(F.season=='ALL')&F.site.eq('dk')&F.feature.eq(field)&F.outcome_group.eq('lt48')].iloc[0]
 rows.append([label,f'{a.feature_observed_games} / {b.feature_observed_games}',f(a.feature_mean,2),f(b.feature_mean,2)])
tab(['Curry shooting measure','Known high / lower','High mean','Lower mean'],rows,[3.1,1.4,1.3,1.3])
p('Same-game catch-and-shoot and pull-up accuracy were also higher: 47.0% versus 37.1%, and 50.4% versus 35.1%. These are means of observed game percentages. Tracking covers 93 catch-and-shoot games and 94 pull-up games, with no 2023–24 coverage; only 61 games meet the complete prior-10 tracking requirement.')
h('Actual dashboard and play type sources')
p('The raw opponent dashboard has positional vulnerability, shot zones, catch-and-shoot and pull-up fields. In the 43 recent games, opponent PG average DK allowed was 28.05 for high games versus 28.08 for lower games. Opponent season catch-and-shoot attempts allowed were 27.64 versus 27.97; pull-up attempts allowed were 23.58 versus 22.24. These are repeated mixed-date snapshot profiles, not game-date measurements.')
p('The shot inventory also includes distance zones, very tight and wide-open shooting, and 11 Synergy play types. Synergy is undated: 2024–25 is full-season-consistent, 2025–26 is partial, and 2023–24 is absent. It is not a record of Curry possessions against each opponent.',small=True)
source('Shot-context distribution splits, field inventory, exact cutoffs and high-versus-lower feature comparisons. Dashboard metadata mixes March 15, March 26 and earlier windows; historical availability is unverified.')

# PAGE 4
page('Markets home games and rest')
p('The closest-spread recent games had the higher hit rate, but a higher total was not a consistent boost. Historical opening and closing markets exist for only the 43 games in 2025–26; their capture time and availability before lineup lock are unverified.')
rows=[]
for dim,labels in [('closing_abs_spread_bin',[('<5','Spread under 5'),('5_to_<10','Spread 5 to under 10'),('10+','Spread 10 or more')]),('closing_total_bin',[('<225','Total under 225'),('225_to_<235','Total 225 to under 235'),('235+','Total 235 or more')]),('closing_team_implied_bin',[('<112.5','GSW implied under 112.5'),('112.5_to_<120','GSW implied 112.5 to under 120'),('120+','GSW implied 120 or more')])]:
 for bn,label in labels:rows.append(mrow(label,market('2025-26',dim,bn)))
tab(['Closing market bucket','48+ / below 48','Hit rate','Mean DK','Median DK','90th pct DK'],rows,[2.3,1.0,.9,.9,1.0,1.0],8.8)
p('Spread means the absolute Golden State spread. The reconstructed Golden State total is (game total minus its signed spread) / 2. The same game can appear once in each market family. Opening-market splits are in the bundle; opening absolute spread under 5 was 8 hits in 20 games, versus 8 in 16 at the close.',small=True)
h('Full three season schedule context')
rows=[]
for dim,bn,label in [('home_away','away','Away'),('home_away','home','Home'),('team_b2b','B2B','Team back to back'),('team_b2b','not_B2B','Not a team back to back'),('team_rest_bin','1_day','One full day without a team game'),('team_rest_bin','2_days','Two full days'),('team_rest_bin','3_plus_days','Three or more full days')]:
 rows.append(mrow(label,market('combined_three_seasons',dim,bn)))
tab(['Schedule context','48+ / below 48','Hit rate','Mean DK','Median DK','90th pct DK'],rows,[2.3,1.0,.9,.9,1.0,1.0],8.8)
p('Home/away is known for every game. Team rest is known for 184 of 187; the three first-in-source games remain missing (1 hit, 2 misses). Team back-to-back describes the team schedule, not whether Curry himself played the previous game.')
p('Venue transitions are recorded, but actual travel distance, itinerary, departure time, time zones crossed and sleep are not. A home-to-away transition is not a measured travel burden. Curry’s gap between appearances is a separate field and may reflect nonparticipation as well as schedule.',small=True)
source('Fixed-48 context ledger and splits; BigDataBall owner-held historical team exports. Older seasons have no market rows in this joined coverage. Opening/closing totals, spreads, favorite status and implied totals remain separate in the bundle.')

# PAGE 5
page('Teammates starters and time on court')
p('Actual participation is available for all 187 games. It supports comparisons of who played in the same game, but does not establish a pregame injury absence, a rest decision or the lineup expected before lock.')
rows=[]
for season,player,scope in [('2023-24','Chris Paul','season_all_games'),('2023-24','Klay Thompson','season_all_games'),('2024-25','Draymond Green','season_all_games'),('2025-26','Jimmy Butler III','season_all_games'),('2025-26','Al Horford','season_all_games')]:
 z=T[(T.season==season)&T.teammate_player.eq(player)&T.scope.eq(scope)&T.site.eq('dk')]
 a=z[z.context.eq('observed_playing')].iloc[0];b=z[z.context.eq('not_observed_playing')].iloc[0]
 rows.append([player.replace(' III','')+'\n'+season,f'{a.dk_ge48_n} / {a.games}',f'{b.dk_ge48_n} / {b.games}',f'{a["mean"]:.1f} / {b["mean"]:.1f}',f'{a["median"]:.1f} / {b["median"]:.1f}'])
tab(['Teammate and season','Played hits / games','Not observed hits / games','Mean DK played / not','Median DK played / not'],rows,[2.0,1.2,1.35,1.3,1.25],8.8)
p('Across all three seasons, Green played in 55 of the 67 high games and 95 of the 120 lower games. Curry’s hit rates were 55/150 with Green and 12/37 without him observed playing. This is a modest pooled difference, with roster-era, minutes and opponent differences still present.')
h('Actual opening starters')
p('The 43 recent games have an actual opening five, with raw starters agreeing with the play-by-play opening five in all 39 games that passed the on-court validation checks. Curry started 41 games and came off the bench on April 5 and April 7, 2026. Exact five-man cells are mostly too small to interpret.')
rows=[]
for player in ['Jimmy Butler','Brandin Podziemski','Al Horford']:
 z=ST[ST.player.eq(player)&ST.site.eq('dk')]
 a=z[z.context.eq('actual_starter')].iloc[0];b=z[z.context.eq('not_an_actual_starter')].iloc[0]
 rows.append([player,f'{a.dk_ge48_n} / {a.games}',f'{b.dk_ge48_n} / {b.games}',f'{a["mean"]:.1f} / {b["mean"]:.1f}'])
tab(['Actual starter','Started hits / games','Did not start hits / games','Mean DK started / not'],rows,[2.0,1.6,1.7,1.8],9)
p('Podziemski played in all 43 recent games, so his starter split compares role, not presence versus absence. Butler’s recent starter and participation splits coincide; all 13 high games were among his 33 starts, while 10 games without him observed playing had no DK hits.')
h('Within game on court comparison')
p('In the 29 validated games where both Curry and Butler played, Curry produced 47.21 FD points per 36 minutes alongside Butler and 47.34 without him on the floor (522.58 versus 400.88 minutes). This near-flat within-game comparison is different from the large whole-game participation association.')
p('Across all 39 validated games, including games without Butler, the corresponding FD rates are 47.21 and 45.38. Changing the denominator changes the answer. The on-court files therefore preserve both scopes. DraftKings interval rates exclude double-double and triple-double bonuses, which cannot be cleanly assigned to a stint.',small=True)
source('Actual teammate coappearance, actual starter, opening-five checks and validated on/off tables. Four recent games failed or lacked lineup reconstruction; actual participation is not a certified pregame absence feed.')

# PAGE 6
page('What the combined conditions show')
p('These are directly observed combinations. Every row counts the games that met both stated conditions. Separate hit-rate changes are never multiplied into a combined probability.')
def joint_table(name,labels,ci=False):
 z=J[J.comparison.eq(name)&J.site.eq('dk')]
 rows=[]
 for av,bv,label in labels:
  a=z[z.condition_a_value.eq(av)&z.condition_b_value.eq(bv)].iloc[0]
  rows.append([label,f'{a.hits48} / {a.misses48}',pc(a.hit_rate),f(a['mean']),f(a['median']),f(a.q90)])
 tab(['Observed combination','48+ / below 48','Hit rate','Mean DK','Median DK','90th pct DK'],rows,[2.6,1.0,.85,.85,.85,.95],8.8)
h('Actual minutes and actual three point attempts')
joint_table('actual_minutes_x_actual_3PA',[(True,True,'35+ minutes and 14+ threes attempted'),(True,False,'35+ minutes and fewer than 14'),(False,True,'Under 35 minutes and 14+ attempts'),(False,False,'Under 35 minutes and fewer than 14')])
p('The 10 hits among 14 games with both high minutes and high three-point volume are an explanation of completed games. The rough 95% Wilson interval is 45%–88%, even before accounting for selection, dependence and trying many splits. It is not a 71% forecast.',small=True)
h('Prior minutes and prior usage')
joint_table('prior_minutes_x_prior_usage',[(True,True,'Prior 5 minutes 34+ and prior usage 32+'),(True,False,'Prior minutes 34+ and usage under 32'),(False,True,'Prior minutes under 34 and usage 32+'),(False,False,'Prior minutes under 34 and usage under 32')])
p('There are 182 known games and 5 missing. Both prior conditions produced 6 hits and 8 misses; the hit-rate interval is roughly 21%–67%. The combined mean was 42.64 DK, so the two conditions do not establish an automatic stronger outcome.',small=True)
h('Butler participation and close closing spreads')
joint_table('Butler_played_x_close_spread',[(True,True,'Butler played and absolute spread under 5'),(True,False,'Butler played and spread 5 or more'),(False,True,'Butler not observed and spread under 5'),(False,False,'Butler not observed and spread 5 or more')])
p('These 43 recent games include only 12 in the Butler-plus-close cell. Its 8/12 hit rate has a roughly 39%–86% interval. Zero hits in the 4- and 6-game Butler-not-observed cells do not establish zero future probability. Participation, season timing, Curry minutes and uncertified market timing remain entangled.',small=True)
p('Creator and spacing role combinations have cell sizes 0, 3, 4 and 74 among only 81 complete-history games. They are too imbalanced for a credible role-combination conclusion. Unknown teammate histories remain missing rather than being counted as zero.',small=True)
source('Fixed-48 joint context cells. Home/away by back-to-back and Butler by back-to-back are also included. Wilson intervals are descriptive binomial summaries, not adjusted tests or validated predictive intervals.')

# PAGE 7
page('Pregame candidates and salary scope')
p('A useful identifier only needs to raise the chance of reaching 48 relative to the right baseline. It does not need certainty or a hit rate above 50%. The overall reference is 67/187, or 35.8%. The seven history and schedule candidates below are retained together, including the weaker ones.')
C=pd.read_csv(O/'curry_pregame_identifier_scorecard.csv')
C=C[C.restriction.eq('primary')].head(7)
names=['Away','Not on a team back to back','Prior 5 minutes at least 34','Prior usage proxy at least 32','Both prior minutes and usage','Prior 10 catch and shoot attempts >6.05','Prior 10 pull up shot share ≤43.62%']
rows=[]
for label,(_,a) in zip(names,C.iterrows()):
 rows.append([label,f'{a.hits48} / {a.selected_n}',f'{100*a.precision:.1f}%\n({100*a.precision_wilson95_low:.0f}–{100*a.precision_wilson95_high:.0f}%)',f'{a.captures_of_all67_hits} / 67',a.false_positives,f'{a.eligible_n} / {a.scope_n}'])
tab(['Candidate','Hits / selected','Hit rate\n95% interval','Captured highs','Below 48','Known / scope'],rows,[2.25,.9,1.1,.95,.8,1.1],8.8)
p('The first five rows have eligible baselines of 35.7%–35.9%. The last two use 2024–25 feature medians applied to 2025–26: their baseline is 10/33, or 30.3%, and they capture 7/10 and 10/10 eligible hits. The exact pull-up-share cutoff is 43.6239%. Their 10 unknown-history games are the opening ten appearances, October 21–November 12, including 3 hits. Thresholds were not prospectively registered.',small=True)
p('The pull-up-share condition is the more interesting narrow candidate, but it is fragile. Restricting prior 5-game minutes to 30–under 36 raises the eligible baseline to 40%: catch-and-shoot is still 7/19 (36.8%), while pull-up share is 10/22 (45.5%) with only 3 unselected games. Season timing and role changes can explain part of the apparent enrichment.',small=True)
p('Block-bootstrap lift intervals overlap zero for the first six primary rows. Pull-up share’s unadjusted interval is positive, but the broad search and sensitivity above prevent treating it as established. The Wilson intervals in the table describe precision only; they do not adjust for dependence or selection.',small=True)
p('Timing-limited comparisons are shown on pages 4–6: close historical spread 8/16, Butler observed 13/33, and their joint cell 8/12, against the recent-season 13/43 baseline. These are not certified pre-lock identifiers.',small=True)
h('Audited salary coverage')
salary=json.loads((R/'analysis/report_salary_payload.json').read_text())
p('Salaries link to 96 DK and 97 FD appearance dates. Only 18 DK and 15 FD recent dates have saved contest/pool context; generic Classic/Full Roster workbook values are a separate evidence tier. No source certifies historical pre-lock capture.')
tab(salary['headers'],salary['rows'],salary.get('widths'),8.8)
p('Among the 96 DK salary dates, 32 were high games and 64 were lower games. Their mean salaries were $8,918.75 and $9,000.00. Duplicate sources are not extra games. Six workbook rows had reversed source DK/FD score cells; the canonical outcome ledger supplies the correct scores. A fixed 48-point threshold is not itself a salary-value target.',small=True)
p('The saved model remains mixed: its recent top 7 ranked games had 3 hits, but including ties gives 3/9; average predicted probability was 41.7% versus 31.4% observed across 35 tests. Earlier validation had 1/9 top-ranked hits, or 4/13 with ties. No new model is fitted.',small=True)
source('Pregame identifier scorecard, fixed older-cutoff results, existing-model scorecard/calibration and salary audit. All are previously explored historical evidence.')

# PAGE 8
page('Coverage definitions and source trail')
p('The report uses the full 187-game outcome population. Each context family has its own observed subset. Missing data is kept visible, and the same 48-point definition is applied to both sides of every comparison.')
rows=[
 ['Curry box score and score outcomes','187 / 187','All three seasons','Actual game explanation'],
 ['Team advanced factors','187 actual; 162 GSW prior; 161 opponent prior','All three seasons','Actual and previous 10 separated'],
 ['Home and away; team schedule rest','187 home/away; 184 rest','All three seasons','Observed schedule'],
 ['Opening and closing markets','43 / 187','2025–26 only','Historical; lock time unverified'],
 ['Opponent 3PA, 3PM, accuracy and share','161 / 187','All three seasons','Previous 10 games only'],
 ['Curry catch and shoot; pull up','93; 94 actual; 61 complete prior windows','2024–25 partial; 2025–26','Actual and prior windows separated'],
 ['Shot distance and contest categories','Field-specific','Mostly later two seasons','Reconciled actuals; coverage gates'],
 ['Dashboard positions and opponent styles','43 / 187 for cited fields','Mixed-date 2025–26 snapshot','Repeated profiles; not as of game'],
 ['Synergy play types','Later two seasons; 2025–26 partial','Undated aggregates','Not player-v-opponent possessions'],
 ['Teammates; actual opening five; on court','187 participation; 43 opening fives; 39 on-court games','Starts/stints in 2025–26','Realized participation'],
 ['Complete teammate role proxy counts','81 / 187','All three seasons','Prior role plus actual participation'],
 ['Actual travel and pregame projection vintage','0 verified','No usable history','Unavailable, not zero'],
]
tab(['Context family','Coverage','Window','Timing and use'],rows,[1.7,1.85,1.55,2.0],8.2)
h('How the splits were made')
p('A hit is DK ≥ 48 and a miss is DK < 48 unless a table explicitly says FanDuel. Most report tables show one-decimal rounding; source files retain precision. All 67 high games and all 120 lower games remain in the ledgers. Coarse bins were specified for readable comparisons; other bins use within-season medians of the feature, not cutoffs optimized on fantasy outcomes.')
p('Lagged means exclude the target game. Some player-history fields allow fewer than 10 earlier observations; complete team prior-10 and tracking prior-10 fields require their stated history. Source retrieval timestamps do not certify what was known before a historical game. The search covered 105 core fields, 233 numeric shot-context fields, 13 market/schedule dimensions, 6 joint pairs and 2 older-season rules. None was prospectively registered before the 2025–26 outcomes; no table is an adjusted causal estimate or a validated future probability.',small=True)
h('The accompanying data can be audited')
p('The game ledger identifies every date, opponent, score and 48-point result. The fixed-48 context ledger preserves source file, worksheet/row and hash where available. The core and shot inventories list definitions, temporal class and field-level coverage. Exact cutoff files preserve every threshold. Joint-cell rows preserve the included dates. Teammate and on/off files preserve separate participation, starter and exposure denominators.')
source('curry_48point_game_ledger.csv; curry_fixed48_context_ledger.csv; core_advanced_role_splits.csv; curry_shot_context_distribution_splits.csv; their inventories and cutoff files; curry_fixed48_joint_context_cells.csv; actual teammate, starter and on/off tables. These are analysis data files in the accompanying bundle, not live pregame feeds.')

doc.core_properties.title='Stephen Curry games with at least 48 DraftKings points'
doc.core_properties.subject='Three season descriptive comparison of high games and lower games'
doc.core_properties.author=''
doc.core_properties.keywords='Stephen Curry, DraftKings, descriptive splits, 48 points'
out=O/'Stephen_Curry_48_Point_Descriptive_Report.docx'
doc.save(out)
print(out)
print('Paragraphs',len(doc.paragraphs),'Tables',len(doc.tables))
