"""Bounded pregame candidate/readthrough scorecard for the user's inclusive48 outcome."""
from pathlib import Path
import json,datetime
import numpy as np,pandas as pd
R=Path(__file__).resolve().parents[1];P=R.parent;SEED=20261012;B=500

def read(p):
 d=pd.read_csv(p,dtype={'game_id':str,'person_id':str});d['game_id']=d.game_id.str.replace(r'\.0$','',regex=True).str.zfill(10);return d
z=read(R/'outputs/curry_fixed48_integrated_game_ledger.csv');z['date']=pd.to_datetime(z.date);audit=read(R/'outputs/curry_fixed_older_cutoff_2025_26_game_audit.csv');keep=['game_id','track_cs_fga_prior10','track_pu_fga_share_prior10'];z=z.merge(audit[keep],on='game_id',how='left',validate='one_to_one');y=z.dk.ge(48).to_numpy();GLOBAL=int(y.sum())

def wilson(k,n):
 if not n:return np.nan,np.nan
 p=k/n;t=1.959963984540054;a=t*t;den=1+a/n;mid=(p+a/(2*n))/den;half=t*np.sqrt(p*(1-p)/n+a/(4*n*n))/den;return mid-half,mid+half

def block_ix(a,seed):
 rng=np.random.default_rng(seed);out=[]
 for _,g in a.groupby('season',sort=True):
  ix=np.asarray(g.index);n=len(ix);starts=rng.integers(0,n,(B,int(np.ceil(n/7))));rel=((starts[:,:,None]+np.arange(7))%n).reshape(B,-1)[:,:n];out.append(ix[rel])
 return np.concatenate(out,axis=1)

cs_cut=6.05;res=pd.read_csv(R/'outputs/curry_fixed_older_cutoff_2025_26_48_results.csv');pu_cut=float(res[res.rule.eq('prior10_pu_share_at_or_below_old_median')].cutoff.iloc[0])
records=[];membership=[]
def add(name,selected,known,scope,temporal,origin,restriction='primary'):
 a=z[scope].copy().sort_values('date').reset_index(drop=True);idx=z.index[scope];sel=np.asarray(selected)[idx];kn=np.asarray(known)[idx];hit=a.dk.ge(48).to_numpy();n=len(a);s=sel&kn;h=int(hit[s].sum());m=int(s.sum())-h;eh=int(hit[kn].sum());en=int(kn.sum());base=eh/en if en else np.nan;lo,hi=wilson(h,int(s.sum()));rr={'candidate':name,'restriction':restriction,'timing_class':temporal,'cutoff_origin':origin,'scope_n':n,'scope_hits48':int(hit.sum()),'eligible_n':en,'eligible_hits48':eh,'unknown_n':int((~kn).sum()),'unknown_hits48':int(hit[~kn].sum()),'selected_n':int(s.sum()),'hits48':h,'false_positives':m,'precision':h/s.sum() if s.sum() else np.nan,'precision_wilson95_low':lo,'precision_wilson95_high':hi,'same_eligible_baseline':base,'precision_minus_eligible_baseline':h/s.sum()-base if s.sum() else np.nan,'global_baseline':GLOBAL/len(z),'captures_of_all67_hits':h,'recall_of_all67':h/GLOBAL,'recall_within_eligible_hits':h/eh if eh else np.nan,'selected_fraction_of187':s.sum()/len(z),'selected_fraction_of_eligible':s.sum()/en if en else np.nan,'unselected_known_n':int((kn&~sel).sum()),'unselected_known_hits':int(hit[kn&~sel].sum()),'dk_mean_selected':a.loc[s,'dk'].mean(),'dk_median_selected':a.loc[s,'dk'].median(),'dk_q90_selected':a.loc[s,'dk'].quantile(.9),'first_selected_date':str(a.loc[s,'date'].min().date()) if s.any() else None,'last_selected_date':str(a.loc[s,'date'].max().date()) if s.any() else None,'prospective_validation':False}
 if s.sum()>=5 and (kn&~sel).sum()>=5:
  ix=block_ix(a,SEED);yh=hit[ix];sk=s[ix];ek=kn[ix];other=(kn&~sel)[ix];ok=(sk.sum(1)>0)&(ek.sum(1)>0)&(other.sum(1)>0);sp=(yh*sk).sum(1)[ok]/sk.sum(1)[ok];ep=(yh*ek).sum(1)[ok]/ek.sum(1)[ok];op=(yh*other).sum(1)[ok]/other.sum(1)[ok];c=np.quantile(sp-ep,[.025,.975]);o=np.quantile(sp-op,[.025,.975]);rr.update(precision_lift_block95_low=float(c[0]),precision_lift_block95_high=float(c[1]),selected_minus_unselected_block95_low=float(o[0]),selected_minus_unselected_block95_high=float(o[1]),bootstrap_draws=int(ok.sum()))
 records.append(rr)
 for i,row in a.iterrows():membership.append({'candidate':name,'restriction':restriction,'game_id':row.game_id,'date':str(row.date.date()),'dk':row.dk,'hit48':bool(hit[i]),'known_context':bool(kn[i]),'selected':bool(s[i]) if kn[i] else None})
allmask=np.ones(len(z),bool);recent=z.season.eq('2025-26').to_numpy();origin='Fixed coarse descriptive cutoff specified before this threshold48 scorecard; all historical outcomes previously explored'
add('Away game',z.home_away.eq('away'),z.home_away.notna(),allmask,'schedule history; archive vintage not certified','Natural home/away category')
add('Not on team back-to-back',z.team_b2b_verified.eq(0),z.team_b2b_verified.notna(),allmask,'schedule history; archive vintage not certified','Natural one-day versus longer team-game gap')
add('Prior5 minutes at least34',z.minutes_lag5.ge(34),z.minutes_lag5.notna(),allmask,'strictly lagged player history; source vintage not certified',origin)
add('Prior10 box usage at least32',z.usage_proxy_lag10.ge(32),z.usage_proxy_lag10.notna(),allmask,'strictly lagged player history; source vintage not certified',origin)
add('Prior5 minutes34plus AND prior10 usage32plus',z.minutes_lag5.ge(34)&z.usage_proxy_lag10.ge(32),z.minutes_lag5.notna()&z.usage_proxy_lag10.notna(),allmask,'strictly lagged player history; source vintage not certified','One of six direct joint context tables, no multiplier of single-feature rates')
add('Own prior10 CS attempts above6.05',z.track_cs_fga_prior10.gt(cs_cut),z.track_cs_fga_prior10.notna(),recent,'strictly lagged measured history; source vintage not certified','Cutoff from2024-25 context-feature median; candidate highlighted after reviewing historical2025-26 associations')
add('Own prior10 PU share at most older median',z.track_pu_fga_share_prior10.le(pu_cut),z.track_pu_fga_share_prior10.notna(),recent,'strictly lagged measured history; source vintage not certified','Cutoff from2024-25 context-feature median; candidate highlighted after reviewing historical2025-26 associations')
# Alternatives with historical/source-timing limitations stay separate, not discarded or called certified pregame.
add('Historical closing absolute spread below5',z.closing_spread.abs().lt(5),z.closing_spread.notna(),recent,'historical market; closing snapshot timing uncertified','Fixed coarse spread bin; not verified prelock capture')
add('Butler observed playing',z.observed_butler_played,allmask,recent,'actual game coappearance; NOT verified pregame availability','Descriptive actual presence, a possible future availability identifier only with dated status feed')
add('Butler observed AND historical absolute spread below5',z.observed_butler_played&z.closing_spread.abs().lt(5),z.closing_spread.notna(),recent,'actual coappearance plus historical market; NOT certified pregame','One fixed joint table; no multiplication of rates')
# Role and calendar sensitivity panels use only previously defined contexts, show all rather than select the best.
first_return=z.loc[recent&z.appearance_gap_capped30.ge(30)&z.date.gt('2025-11-01'),'date'].min();pre_return=recent&z.date.lt(first_return).to_numpy();normal_role=recent&z.minutes_lag5.between(30,36,inclusive='left').to_numpy()
for label,scope in [('before_first_within_season_30day_gap_return',pre_return),('prior5_minutes30_to_below36',normal_role)]:
 for name,sel,kn in [('Own prior10 CS attempts above6.05',z.track_cs_fga_prior10.gt(cs_cut),z.track_cs_fga_prior10.notna()),('Own prior10 PU share at most older median',z.track_pu_fga_share_prior10.le(pu_cut),z.track_pu_fga_share_prior10.notna())]:add(name,sel,kn,scope,'strictly lagged measured history; exploratory sensitivity','Same earlier-season cutoff unchanged',label)
pd.DataFrame(records).to_csv(R/'outputs/curry_pregame_identifier_scorecard.csv',index=False);pd.DataFrame(membership).to_csv(R/'outputs/curry_pregame_identifier_game_membership.csv',index=False)
# Reuse already-fitted individual distributions and already-saved pooled quantiles. No fitting calls.
T=P/'player_specific_pilot';p=read(T/'outputs/player_tree_predictions.csv.gz');pool=read(T/'outputs/pooled_matched_predictions.csv.gz');pred=pd.concat([p,pool],ignore_index=True);pred=pred[pred.person_id.eq('201939')&pred.fit_window.isin(['development','final'])].copy();Q=np.array([.1,.25,.5,.75,.85,.9,.95]);prob=[]
def leafmap(node,out):
 if node['leaf']:out[int(node['id'])]=np.array(node['training_residuals'])
 else:leafmap(node['left'],out);leafmap(node['right'],out)
models={}
for key,g in pred.groupby(['fit_window','site','model']):
 window,site,model=key
 if model.startswith('player_'):
  j=json.loads((T/'models'/f'{window}_{site}_201939_{model}.json').read_text());ly={};leafmap(j['tree'],ly);gy=np.array(j['global_fit_residuals']);models[key]=(ly,gy)
 for idx,r in g.iterrows():
  if model.startswith('player_'):
   ly,gy=models[key];v=ly[int(r.leaf)];p48=((v>=48-r.personal_baseline).sum()+20*(gy>=48-r.personal_baseline).mean())/(len(v)+20);recipe='Exact shrunken empirical probability of score>=48'
  else:
   x=r[[f'q{int(q*100)}_score' for q in Q]].to_numpy(float);xx,ii=np.unique(x[::-1],return_index=True);cc=Q[::-1][ii];p48=1-np.interp(48,xx,cc,left=.1,right=.95);recipe='Approximate seven-quantile CDF inversion, bounded0.05..0.90; discrete equality not exactly resolved'
  prob.append({'fit_window':window,'site':site,'model':model,'date':r.date,'game_id':r.game_id,'actual_score':r.actual_score,'hit48':int(r.actual_score>=48),'p48':float(p48),'probability_recipe':recipe,'leaf':r.leaf})
pr=pd.DataFrame(prob);pr.to_csv(R/'outputs/curry_existing_model_fixed48_predictions.csv',index=False);sc=[];cal=[]
for key,g in pr.groupby(['fit_window','site','model']):
 g=g.sort_values(['p48','date','game_id'],ascending=[False,True,True],kind='stable');n=len(g);k=int(np.ceil(.2*n));top=g.iloc[:k];boundary=top.p48.iloc[-1];inc=g[g.p48>=boundary];meanp=g.p48.mean();event=g.hit48.mean();sc.append(dict(zip(['fit_window','site','model'],key))|{'n':n,'hits48':int(g.hit48.sum()),'misses48':int(n-g.hit48.sum()),'event_rate':event,'mean_predicted_p48':meanp,'calibration_mean_error':meanp-event,'brier':float(((g.p48-g.hit48)**2).mean()),'top20_n':k,'top20_hits':int(top.hit48.sum()),'top20_false_positives':int(k-top.hit48.sum()),'top20_precision':top.hit48.mean(),'captured_hits_fraction':top.hit48.sum()/g.hit48.sum() if g.hit48.sum() else np.nan,'top20_mean_p48':top.p48.mean(),'boundary_tie_n':int(g.p48.eq(boundary).sum()),'tie_inclusive_n':len(inc),'tie_inclusive_hits':int(inc.hit48.sum()),'tie_inclusive_false_positives':int(len(inc)-inc.hit48.sum())})
 g['probability_bin']=pd.cut(g.p48,[-.001,.2,.4,.6,.8,1.001],right=False)
 for b,gg in g.groupby('probability_bin',observed=True):
  h=int(gg.hit48.sum());lo,hi=wilson(h,len(gg));cal.append(dict(zip(['fit_window','site','model'],key))|{'probability_bin':str(b),'n':len(gg),'hits48':h,'misses48':len(gg)-h,'mean_probability':gg.p48.mean(),'observed_rate':h/len(gg),'observed_wilson95_low':lo,'observed_wilson95_high':hi})
pd.DataFrame(sc).to_csv(R/'outputs/curry_existing_model_fixed48_scorecard.csv',index=False);pd.DataFrame(cal).to_csv(R/'outputs/curry_existing_model_fixed48_calibration.csv',index=False)
# Broad search inventory. These counts describe the audit, not independent hypothesis tests.
core=pd.read_csv(R/'outputs/core_field_inventory.csv');cuts=pd.read_csv(R/'outputs/core_split_cutoffs.csv');shot=pd.read_csv(R/'outputs/curry_shot_context_field_inventory.csv');shotcuts=pd.read_csv(R/'outputs/curry_shot_context_exact_cutoffs.csv');markets=pd.read_csv(R/'outputs/curry_fixed48_context_splits.csv');
ledger={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'user_chosen_outcome':'DK>=48 inclusive, FD separately','core_fields_examined':len(core),'core_cutoff_records':len(cuts),'core_distribution_rows':len(pd.read_csv(R/'outputs/core_advanced_role_splits.csv')),'shot_tracking_synergy_snapshot_numeric_fields_examined':int(shotcuts.field.nunique()),'shot_context_and_provenance_fields_total':len(shot),'shot_season_cutoff_records':len(shotcuts),'shot_distribution_rows':len(pd.read_csv(R/'outputs/curry_shot_context_distribution_splits.csv')),'market_context_dimensions':int(markets.context_dimension.nunique()),'market_distribution_rows':len(markets),'direct_joint_context_pairs':6,'joint_context_cells_before_site_duplication':24,'older_season_tracking_rules':2,'primary_identifier_rows':10,'sensitivity_rows':4,'existing_fixed_model_scorecards':len(sc),'new_models_fitted':0,'prospective_cutoff_registration_before_2025_26_results':False,'chronology_warning':'No condition discovery in this follow-up was prospectively registered before2025-26 outcomes. Some cutoffs are computed using2024-25 context only, but their selection for attention occurred after already-explored historical associations. Within-season medians use completed descriptive feature samples. Intervals omit this discovery/multiplicity uncertainty.','first_within_season_30day_gap_return':str(first_return.date()),'tracking_unknown_2025_26_dates':z.loc[recent&z.track_cs_fga_prior10.isna(),'date'].dt.strftime('%Y-%m-%d').tolist(),'tracking_coverage_note':'All10unknown dates are the opening10Curryappearances fromOct21throughNov12, including3of13DK48hits. Known histories beginNov14; playerappearance-based histories may be stale after a long gap.'};(R/'audit/curry_identifier_exploration_ledger.json').write_text(json.dumps(ledger,indent=2));print(pd.DataFrame(records)[['candidate','restriction','selected_n','hits48','false_positives','precision','same_eligible_baseline','recall_of_all67','precision_lift_block95_low','precision_lift_block95_high']].to_string(index=False));print(pd.DataFrame(sc).query("site=='dk'").to_string(index=False));print(ledger)
