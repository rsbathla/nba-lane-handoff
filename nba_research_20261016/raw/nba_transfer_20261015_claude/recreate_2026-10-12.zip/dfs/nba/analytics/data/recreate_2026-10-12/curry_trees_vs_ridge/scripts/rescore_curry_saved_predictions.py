"""Independent re-score of the shipped saved predictions (no model refit possible: leaf/quantile sources are not shipped)."""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd
sys.dont_write_bytecode = True
R = Path(sys.argv[1]); OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
pred = pd.read_csv(R/'outputs/curry_existing_model_fixed48_predictions.csv', dtype={'game_id': str})
ship = pd.read_csv(R/'outputs/curry_existing_model_fixed48_scorecard.csv')
rows = []
for (w, s, m), g in pred.groupby(['fit_window', 'site', 'model']):
    g = g.sort_values(['p48', 'date', 'game_id'], ascending=[False, True, True], kind='stable')
    k = int(np.ceil(.2*len(g))); top = g.iloc[:k]
    rows.append(dict(fit_window=w, site=s, model=m, n=len(g), hits48=int(g.hit48.sum()),
                     mean_predicted_p48=g.p48.mean(), brier=((g.p48-g.hit48)**2).mean(),
                     top20_n=k, top20_hits=int(top.hit48.sum())))
mine = pd.DataFrame(rows)
cmp = mine.merge(ship, on=['fit_window', 'site', 'model'], suffixes=('', '_ship'))
for c in ['n', 'hits48', 'mean_predicted_p48', 'brier', 'top20_n', 'top20_hits']:
    cmp['diff_'+c] = cmp[c]-cmp[c+'_ship']
cmp.to_csv(OUT/'rescore_vs_shipped_scorecard.csv', index=False)
print('max abs diff', cmp[[c for c in cmp if c.startswith('diff_')]].abs().max().to_dict(), 'rows', len(cmp))
# tree vs matched ridge, Brier and top-20 hits, every window x site
piv = mine.pivot_table(index=['fit_window', 'site'], columns='model', values=['brier', 'top20_hits'])
tv = []
for (w, s) in piv.index:
    for tm in ['player_distribution_tree', 'player_mean_tree']:
        for rm in ['pooled_ridge_role_history', 'pooled_ridge_full_additive']:
            tv.append(dict(fit_window=w, site=s, tree=tm, ridge=rm, tree_brier=piv.loc[(w, s), ('brier', tm)],
                           ridge_brier=piv.loc[(w, s), ('brier', rm)],
                           brier_tree_minus_ridge=piv.loc[(w, s), ('brier', tm)]-piv.loc[(w, s), ('brier', rm)],
                           tree_top20_hits=piv.loc[(w, s), ('top20_hits', tm)], ridge_top20_hits=piv.loc[(w, s), ('top20_hits', rm)]))
tv = pd.DataFrame(tv); tv.to_csv(OUT/'tree_vs_ridge_pairs.csv', index=False)
print(tv.to_string(index=False))
led = pd.read_csv(R/'Curry_48_Point_Game_Ledger_20261012.csv', dtype={'game_id': str})
rec = json.loads((R/'audit/fixed48_integration_receipt.json').read_text())
out = dict(ledger_rows=len(led), dk_hits=int((led.dk >= 48).sum()), dk_misses=int((led.dk < 48).sum()),
           fd_hits=int((led.fd >= 48).sum()), fd_misses=int((led.fd < 48).sum()),
           receipt={k: rec[k] for k in ['dk_hits', 'dk_misses', 'fd_hits', 'fd_misses']})
(OUT/'ledger_counts.json').write_text(json.dumps(out, indent=2)); print(out)
