"""Independent audit: source reconstruction and frozen-space/prediction checks.
Does not import or execute producer scripts and does not tune the analysis.
"""
from pathlib import Path
import pandas as pd, numpy as np, json, hashlib, itertools, datetime, sys
ROOT=Path('/workspace/scratch/0bd466b49713')
BASE=ROOT/'dallas_review_20261012/method_comparison_20261012'
OUT=BASE/'combinatorial_search'
PROTO=json.loads((OUT/'FROZEN_COMBINATORIAL_PROTOCOL.json').read_text())
RESULT={'audited_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':{},'issues':[], 'limitations':['Exploratory reuse of outcomes previously examined; no pristine holdout.','Historical source reconstruction does not establish archival pregame tracking availability.']}
def check(name,ok,detail=None):
 RESULT['checks'][name]={'passed':bool(ok),'detail':detail}
 if not ok: RESULT['issues'].append(name)
 print(name, 'PASS' if ok else 'FAIL', detail or '',flush=True)
def comp(name,a,b,tol=1e-10):
 a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float);assert a.shape==b.shape,(name,a.shape,b.shape)
 finite=np.isfinite(a)&np.isfinite(b);err=float(np.max(np.abs(a[finite]-b[finite]))) if finite.any() else 0.
 check(name,np.array_equal(np.isnan(a),np.isnan(b)) and np.allclose(a,b,atol=tol,rtol=1e-10,equal_nan=True),{'max_abs_error':err,'n':int(a.size)})
def save():
 RESULT['issues']=[name for name,value in RESULT['checks'].items() if not value['passed']]
 RESULT['status']='PASS' if not RESULT['issues'] else 'ISSUES'
 (OUT/'independent_combinatorial_audit.json').write_text(json.dumps(RESULT,indent=2))
 (OUT/'independent_combinatorial_audit.txt').write_text('\n'.join([f"Independent combinatorial audit: {RESULT['status']}",f"UTC {RESULT['audited_at_utc']}"]+[f"{'PASS' if v['passed'] else 'FAIL'} {k}: {v['detail']}" for k,v in RESULT['checks'].items()]+['Limitations:']+RESULT['limitations']))
for path,digest in PROTO['source_hashes'].items():check('source_hash_'+Path(path).name,hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest)
for name,key in [('FROZEN_CANDIDATE_DICTIONARY.csv','candidate_dictionary_sha256'),('OUTCOME_FREE_FEASIBILITY.json','outcome_free_feasibility_sha256')]:check('frozen_hash_'+name,hashlib.sha256((OUT/name).read_bytes()).hexdigest()==PROTO[key])
features=PROTO['features'];fam=PROTO['families'];cd=pd.read_csv(OUT/'FROZEN_CANDIDATE_DICTIONARY.csv')
check('features_exact_count_and_families',len(features)==21 and len(set(features))==21 and [len(fam[x]) for x in ['role','volume','ability']]==[2,2,17] and sum([fam[x] for x in ['role','volume','ability']],[])==features)
expected=[]
for order,sets in [(1,[(f,) for f in features]),(2,list(itertools.combinations(features,2))),(3,list(itertools.product(fam['role'],fam['volume'],fam['ability'])))]:
 for fs in sets:
  for ds in itertools.product(['low','high'],repeat=order):expected.append((f'R{len(expected)+1:04d}',order,'|'.join(fs),'|'.join(ds)))
check('exact_predicate_enumeration',list(cd[['rule_id','order','features','directions']].itertuples(index=False,name=None))==expected and cd.predicate.nunique()==1426,cd.groupby('order').size().to_dict())
check('protocol_outcome_independent_support','All eligibility gates are outcome independent' in PROTO['support'] and 'selection has additional hit/miss' not in PROTO['multiplicity_diagnostic'])
check('protocol_approximate_max_t_disclosure','approximate' in PROTO['multiplicity_diagnostic'] and 'not exact finite-sample' in PROTO['multiplicity_diagnostic'])
bp=ROOT/'nba_fd_box_outcomes_20261010/box_derived_fd_outcomes_REVIEWED.csv'
tp=ROOT/'nba_tracking_integration_20261010/deliverable/tracking_repair/corrected_tracking_2025-26_with_provenance.csv'
cols=['date','game_id','person_id','player','minutes','fgm','fga','fg3m','fg3a','fta','ast','reb','stl','blk','tov','oreb','dreb']
b=pd.read_csv(bp,usecols=cols).query('minutes>0').sort_values(['person_id','date','game_id']).reset_index(drop=True)
check('unique_positive_player_dates',not b.duplicated(['person_id','date']).any(),len(b))
t=pd.read_csv(tp).rename(columns={'nba_pid':'person_id'})
t=t.merge(b[['date','person_id','fgm','fga','fg3m','fg3a']],on=['date','person_id'],how='left',suffixes=('_tag','_box'),validate='many_to_one')
z=t[['fgm_tag','fga_tag','fg3m_tag','fg3a_tag']].to_numpy(float)
counts=np.c_[z,z[:,0]-z[:,2],z[:,1]-z[:,3]]
zz=t[['fgm_box','fga_box','fg3m_box','fg3a_box']].to_numpy(float)
boxcounts=np.c_[zz,zz[:,0]-zz[:,2],zz[:,1]-zz[:,3]]
valid=np.isfinite(counts).all(axis=1)&(counts>=0).all(axis=1)&(counts==np.round(counts)).all(axis=1)&(counts<=boxcounts).all(axis=1)&(counts[:,0]<=counts[:,1])&(counts[:,2]<=counts[:,3])&(counts[:,4]<=counts[:,5])
t['audit_valid']=valid
saved_t=pd.read_csv(OUT/'all_tracking_source_rows_validity.csv')
check('independent_tracking_row_validation',np.array_equal(valid,saved_t.valid.to_numpy()),{'invalid':int((~valid).sum()),'by_tag':t.loc[~valid].groupby('tag').size().to_dict()})
check('ten_invalid_tracking_rows',int((~valid).sum())==10)
keys=['date','game_id','person_id'];a=pd.read_csv(OUT/'all_positive_minute_prior_features.csv');check('all_feature_rows_same_order',b[keys].equals(a[keys]))
r=np.full((len(b),len(features)),np.nan);prior=np.zeros(len(b),int);last=np.empty(len(b),object);first=np.empty(len(b),object)
extra={}
for tag in ['cs','pu','lt10','wo','vtight']:
 v=t[t.tag.eq(tag)].set_index(['date','person_id']);ix=pd.MultiIndex.from_frame(b[['date','person_id']]);obs=v.reindex(ix)
 vv=obs.audit_valid.fillna(False).to_numpy(bool)
 extra[tag]=(vv,np.where(vv,obs.fga_tag.to_numpy(float),0),np.where(vv,obs.fga_box.to_numpy(float),0))
nums=b.drop(columns=['date','player']).to_dict('list');vals={c:b[c].to_numpy(float) for c in cols if c not in ['date','player']}
for pid,inds in b.groupby('person_id',sort=False).indices.items():
 for k,i in enumerate(inds):
  prior[i]=k;last[i]=b.date.iloc[inds[k-1]] if k else None;first[i]=b.date.iloc[inds[k-30]] if k>=30 else None
  if k>=10:r[i,0]=vals['minutes'][inds[k-10:k]].mean()
  if k<30:continue
  wi=inds[k-30:k];s={c:vals[c][wi].sum() for c in vals};m=s['minutes']
  r[i,1]=vals['minutes'][wi].std(ddof=1)
  two_m=vals['fgm'][wi]-vals['fg3m'][wi];two_a=vals['fga'][wi]-vals['fg3a'][wi]
  validtwo=np.isfinite(np.c_[vals['fgm'][wi],vals['fga'][wi],vals['fg3m'][wi],vals['fg3a'][wi]]).all() and (np.c_[vals['fgm'][wi],vals['fga'][wi],vals['fg3m'][wi],vals['fg3a'][wi]]>=0).all() and (two_m>=0).all() and (two_a>=two_m).all() and (vals['fg3a'][wi]>=vals['fg3m'][wi]).all()
  validreb=np.isfinite(np.c_[vals['oreb'][wi],vals['dreb'][wi],vals['reb'][wi]]).all() and (np.c_[vals['oreb'][wi],vals['dreb'][wi],vals['reb'][wi]]>=0).all() and np.allclose(vals['oreb'][wi]+vals['dreb'][wi],vals['reb'][wi])
  out={f'prior30_{c}36':36*s[c]/m for c in ['fga','fta','ast','reb','stl','blk','tov','oreb','dreb']}
  out.update(prior30_three_share=s['fg3a']/s['fga'] if s['fga']>0 else np.nan,prior30_fta_fga=s['fta']/s['fga'] if s['fga']>0 else np.nan,prior30_two_pts36=72*two_m.sum()/m if validtwo else np.nan,prior30_two_pct=two_m.sum()/two_a.sum() if validtwo and two_a.sum()>0 else np.nan,prior30_oreb_share=s['oreb']/s['reb'] if validreb and s['reb']>0 else np.nan)
  if not validreb:out['prior30_oreb36']=out['prior30_dreb36']=np.nan
  for tag,(v,num,den) in extra.items():out[f'prior30_{tag}_observed_ratio']=num[wi].sum()/den[wi].sum() if v[wi].sum()>=15 and den[wi].sum()>0 else np.nan
  for j,f in enumerate(features[2:],2):r[i,j]=out[f]
comp('all_prior_count_reconstruction',a.prior_n,prior,0)
check('all_lag_dates_reconstruction',pd.Series(last).fillna('').equals(a.feature_last_date.fillna('')) and pd.Series(first).fillna('').equals(a.window_first_date.fillna('')))
for j,f in enumerate(features):comp('source_reconstruction_'+f,a[f],r[:,j])
d=pd.read_csv(OUT/'Dallas_features_OUTCOME_FREE.csv');a2=a.set_index(keys).loc[pd.MultiIndex.from_frame(d[keys])].reset_index()
check('Dallas_population',len(d)==382 and d.person_id.nunique()==232 and d.date.nunique()==50 and d.game_id.nunique()==50)
comp('Dallas_features_join',d[features],a2[features])
check('Dallas_lag_chronology',(d.feature_last_date<d.date).all() and (d.prior_n>=30).all())
inv=pd.read_csv(OUT/'FEATURE_INVENTORY.csv')
check('inventory_coverage_exact',inv.feature.tolist()==features and inv.Dallas_available.tolist()==d[features].notna().sum().tolist() and inv.Dallas_unknown.tolist()==d[features].isna().sum().tolist())
check('outcome_free_artifact_columns',not any(('hit_' in c or 'points' in c or 'control' in c or 'personal_q85' in c) for c in d.columns))
# Generator check is repeated at audit completion after a reported stale-source fix.
fp=(OUT/'freeze_protocol.py').read_text()
check('freeze_generator_no_superseded_hit_gate','>=4DKhits' not in fp and '>=8DKmisses' not in fp and 'selection has additional hit/miss support' not in fp)
RESULT['stage']='source_and_protocol'
save()

# Stage 2: audit completed analysis without importing producer code.
if not (OUT/'ALL_future_predictions.csv').exists():sys.exit(0)
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import brier_score_loss,log_loss,roc_auc_score,average_precision_score
D=pd.read_csv(OUT/'Dallas_complete_feature_outcome_ledger.csv')
PR=pd.read_csv(OUT/'ALL_future_predictions.csv')
TL=pd.read_csv(OUT/'ALL_25668_candidate_train_evaluations.csv')
SL=pd.read_csv(OUT/'ALL_selected_rules.csv')
CUT=pd.read_csv(OUT/'ALL_training_cutoffs.csv')
SA=pd.read_csv(OUT/'split_audit.csv')
FT=pd.read_csv(OUT/'ALL_4278_candidate_future_descriptive_counts.csv')
DIAG=pd.read_csv(OUT/'approximate_max_statistic_diagnostic.csv')
DR=pd.read_csv(OUT/'ALL_max_statistic_candidate_diagnostics.csv')
CC=pd.read_csv(OUT/'candidate_counts_by_fit.csv')
manifest=json.loads((OUT/'RUN_MANIFEST.json').read_text())
check('frozen_before_outcomes',PROTO['frozen_at_utc']<manifest['started_outcomes_at_utc'] and PROTO['pre_outcome_freeze_refinement']['at_utc']<manifest['started_outcomes_at_utc'] and hashlib.sha256((OUT/'FROZEN_COMBINATORIAL_PROTOCOL.json').read_bytes()).hexdigest()==manifest['protocol_sha256'])
# Independently verify expanding personal quantiles using raw outcomes.
raw=pd.read_csv(bp,usecols=['date','game_id','person_id','minutes','dk_points','fd_points']).query('minutes>0').sort_values(['person_id','date','game_id'])
for p in ['DK','FD']:
 raw['audit_q85_'+p]=raw.groupby('person_id')[p.lower()+'_points'].transform(lambda x:x.shift().expanding(min_periods=30).quantile(.85))
 q=D[keys+['personal_q85_'+p,'hit_'+p]].merge(raw[keys+['audit_q85_'+p,p.lower()+'_points']],on=keys,validate='one_to_one')
 comp('personal_prior_q85_'+p,q['personal_q85_'+p],q['audit_q85_'+p]);check('strict_hits_'+p,np.array_equal(q['hit_'+p],q[p.lower()+'_points']>q['audit_q85_'+p]))
check('model_feature_ledger_identical_keys',D[keys].sort_values(keys).reset_index(drop=True).equals(d[keys].sort_values(keys).reset_index(drop=True)))
comp('model_feature_ledger_identical_values',D.sort_values(keys)[features],d.sort_values(keys)[features])
check('artifact_row_counts',len(TL)==18*1426 and len(SL)==18*3 and len(PR)==257*20 and len(FT)==1426*3 and len(CUT)==18*21)
rng=np.random.default_rng(PROTO['seed'])
dates=np.sort(D.date.unique());fs=[x.split('|') for x in cd.features];ds=[x.split('|') for x in cd.directions];orders=cd.order.to_numpy();rids=cd.rule_id.to_numpy()
def classify(frame,cut):
 v=frame[features].to_numpy();mi={f:i for i,f in enumerate(features)};n=len(frame);T=np.zeros((n,len(cd)),bool);K=np.zeros_like(T)
 for j,(ff,dd) in enumerate(zip(fs,ds)):
  ids=[mi[f] for f in ff];xx=v[:,ids];threshold=np.asarray([cut[f] for f in ff]);known=np.isfinite(xx).all(axis=1)&np.isfinite(threshold).all();met=np.ones(n,bool)
  for k,direction in enumerate(dd):met&=(xx[:,k]<threshold[k]) if direction=='low' else (xx[:,k]>=threshold[k])
  T[:,j]=known&met;K[:,j]=known
 return T,K&~T,~K

def cts(frame,mat):
 out={'N':mat.sum(axis=0),'DK_hits':frame.hit_DK.to_numpy(int)@mat.astype(int),'FD_hits':frame.hit_FD.to_numpy(int)@mat.astype(int)}
 for col,label in [('game_id','games'),('person_id','players')]:
  out[label]=np.stack([mat[frame[col].eq(x)].any(axis=0) for x in frame[col].unique()]).sum(axis=0)
 return out
all_counts=True;all_exclusions=True;all_eligible=True;all_choice=True;all_cutoff=True;all_test=True;all_splits=True;all_prediction=True;all_branch=True;all_cc=True;all_diag=True;pred_err=0.;cut_err=0.;diag_err=0.;train_err=0.
rep_diag=[]
for ev in ['chronological','chronological_player_disjoint']:
 for fold,start in enumerate([20,30,40],1):
  for hg in ([None] if ev=='chronological' else list(range(5))):
   train=D[D.date.isin(dates[:start])].copy();test=D[D.date.isin(dates[start:start+10])].copy()
   h=lambda p:int(hashlib.sha256(str(int(p)).encode()).hexdigest()[:8],16)%5
   if hg is not None:train=train[train.person_id.map(h)!=hg];test=test[test.person_id.map(h)==hg]
   fit=f'{ev}_fold{fold}_group{hg if hg is not None else "all"}'
   sr=SA[SA.fit_id.eq(fit)].iloc[0];all_splits &= sr.train_N==len(train) and sr.test_N==len(test) and sr.train_last==train.date.max() and sr.test_first==test.date.min() and train.date.max()<test.date.min() and (hg is None or not set(train.person_id)&set(test.person_id))
   cut=train[features].replace([np.inf,-np.inf],np.nan).median();co=CUT[CUT.fit_id.eq(fit)].set_index('feature').loc[features];cut_err=max(cut_err,float(np.abs(co.cutoff-cut).max()));all_cutoff &= np.allclose(co.cutoff,cut,atol=1e-12,equal_nan=True) and np.array_equal(co.train_nonmissing,train[features].notna().sum())
   mats=classify(train,cut);counts=[cts(train,mm) for mm in mats];future=classify(test,cut);futurecounts=[cts(test,mm) for mm in future]
   tl=TL[TL.fit_id.eq(fit)].set_index('rule_id').loc[rids];m,c,u=counts
   for branch,ct in zip(['rule','complement','unknown'],counts):
    for k,v in ct.items():all_counts &= np.array_equal(tl[branch+'_'+k],v)
   elig=np.ones(len(cd),bool);reason=[[] for _ in cd.index]
   for branch,ct in zip(['rule','complement'],counts):
    for k,minimum in [('N',20),('games',5),('players',5)]:
     bad=ct[k]<minimum;elig &= ~bad
     for j in np.where(bad)[0]:reason[j].append(f'{branch}_{k}<{minimum}')
   all_exclusions &= tl.exclusion_reasons.fillna('').tolist()==[';'.join(x) for x in reason];all_eligible &= np.array_equal(elig,tl.eligible)
   p0=train.hit_DK.mean();rate=(m['DK_hits']+20*p0)/(m['N']+20);uplift=rate-p0
   train_err=max(train_err,float(abs(tl.shrunk_uplift.to_numpy()-uplift).max()),float(abs(tl.shrunk_rule_DK_rate.to_numpy()-rate).max()))
   chosen={}
   for model,order in [('best_pair',2),('best_triple',3),('best_any',0)]:
    candidates=np.flatnonzero(elig & (uplift>0) & ((orders==order) if order else True));chosen_idx=sorted(candidates,key=lambda j:(-uplift[j],rids[j]))[0] if len(candidates) else None;chosen[model]=chosen_idx
    selected=SL[(SL.fit_id==fit)&(SL.model==model)].iloc[0];all_choice &= selected.rule_id==(rids[chosen_idx] if chosen_idx is not None else 'NONE_PREVALENCE') and selected.positive_candidates==len(candidates) and selected.eligible_candidates==int((elig&((orders==order) if order else True)).sum())
    if chosen_idx is not None:
     all_choice &= np.allclose(selected.train_shrunk_uplift,uplift[chosen_idx],atol=1e-12)
     all_choice &= json.loads(selected.cutoffs_json)=={f:float(cut[f]) for f in fs[chosen_idx]}
   all_choice &= tl.selected_by.fillna('').tolist()==['|'.join(k for k,v in chosen.items() if v==j) for j in range(len(cd))]
   for order in [1,2,3,0]:
    cc=CC[(CC.fit_id==fit)&(CC.order==order)].iloc[0];choose=orders==order if order else np.ones(len(cd),bool);ee=elig&choose
    patterns={mats[0][:,j].tobytes()+mats[1][:,j].tobytes() for j in np.flatnonzero(ee)}
    all_cc &= cc.declared==int(choose.sum()) and cc.eligible==int(ee.sum()) and cc.excluded==int((choose&~elig).sum()) and cc.eligible_unique_training_patterns==len(patterns)
   if ev=='chronological':
    ft=FT[FT.fold.eq(fold)].set_index('rule_id').loc[rids]
    for branch,ct in zip(['rule','complement','unknown'],futurecounts):
     for k,v in ct.items():all_test &= np.array_equal(ft[branch+'_'+k],v)
    all_test &= np.array_equal(ft.eligible_in_train,elig)
    for unit in ['game_id','person_id']:
     y=train.hit_DK.to_numpy(float);M=mats[0][:,elig].astype(float);nr=M.sum(0);rr=y@M/nr;delta=rr-y.mean();units=train[unit].unique();G=len(units)
     # Cluster influence of raw rate difference, normalized directly by sample counts.
     contribution=M*(y[:,None]-rr)/nr-(y-y.mean())[:,None]/len(y)
     cluster=np.array([contribution[train[unit].eq(g)].sum(0) for g in units]);se=np.sqrt(G/(G-1)*np.square(cluster).sum(0));good=se>1e-12;observed=delta[good]/se[good]
     signs=rng.choice([-1.,1.],size=(2000,G));star=signs@cluster[:,good]*np.sqrt(G/(G-1))/se[good];maxima=star.max(1);pp=(1+(maxima[:,None]>=observed[None,:]).sum(0))/2001
     dr=DR[(DR.fold==fold)&(DR.cluster_unit==unit)].set_index('rule_id').loc[rids[elig][good]]
     vals=np.c_[delta[good],se[good],observed,pp];actual=dr[['raw_uplift','cluster_SE','raw_t','approx_max_t_adjusted_p']].to_numpy();diag_err=max(diag_err,float(abs(vals-actual).max()));all_diag &= np.allclose(vals,actual,atol=1e-12)
     drs=DIAG[(DIAG.fold==fold)&(DIAG.cluster_unit==unit)].iloc[0];all_diag &= drs.eligible_candidates==int(elig.sum()) and drs.valid_SE_candidates==int(good.sum()) and drs.clusters==G and np.allclose([drs.max_observed_t,drs.approx_max_t_p,drs.null_max_t_q95],[observed.max(),(1+np.sum(maxima>=observed.max()))/2001,np.quantile(maxima,.95)],atol=1e-12)
     rep_diag.append({'fold':fold,'cluster_unit':unit,'supported':int(elig.sum()),'p':float((1+np.sum(maxima>=observed.max()))/2001)})
   for platform in ['DK','FD']:
    y=train['hit_'+platform].to_numpy(int);p0=y.mean();opp=['prior10_minutes','prior30_minutes_sd','prior30_fga36'];scale=StandardScaler().fit(train[opp]);ridge=LogisticRegression(C=.1,solver='lbfgs',max_iter=2000).fit(scale.transform(train[opp]),y).predict_proba(scale.transform(test[opp]))[:,1]
    for model in ['prevalence','opportunity_ridge_C0.1','best_pair','best_triple','best_any']:
     z=PR[(PR.fit_id==fit)&(PR.platform==platform)&(PR.model==model)].set_index(keys).loc[pd.MultiIndex.from_frame(test[keys])];pred=np.full(len(test),p0);branches=np.full(len(test),'not_rule_model',object);sel=''
     if model=='opportunity_ridge_C0.1':pred=ridge
     elif model.startswith('best'):
      j=chosen[model]
      if j is None:branches[:]='no_eligible_positive_rule'
      else:
       sel=rids[j];branches=np.where(future[2][:,j],'unknown_fallback',np.where(future[0][:,j],'rule','complement'))
       for k in [0,1]:pred[future[k][:,j]]=(y[mats[k][:,j]].sum()+20*p0)/(mats[k][:,j].sum()+20)
     pred_err=max(pred_err,float(np.abs(z.prediction.to_numpy()-pred).max()));all_prediction &= np.allclose(z.prediction,pred,atol=1e-12) and np.array_equal(z.hit,test['hit_'+platform].to_numpy(int));all_branch &= np.array_equal(z.branch,branches) and z.selected_rule.fillna('').eq(sel).all()
check('all_18_splits_chronology_and_player_exclusions',all_splits)
check('all_378_train_only_medians',all_cutoff,{'max_abs_error':cut_err})
check('all_25668_candidate_branch_counts',all_counts)
check('all_25668_outcome_blind_eligibility',all_eligible)
check('all_25668_exclusion_reasons',all_exclusions)
check('all_candidate_shrunk_DK_scores',train_err<1e-12,{'max_abs_error':train_err})
check('all_54_train_only_DK_rule_selections',all_choice)
check('all_4278_future_descriptive_counts',all_test)
check('all_candidate_summary_counts',all_cc)
check('all_5140_prediction_values_and_hits',all_prediction,{'max_abs_error':pred_err})
check('all_prediction_unknown_fallback_and_FD_reuse',all_branch)
check('all_approximate_max_t_outputs',all_diag,{'max_abs_error':diag_err,'independent_results':rep_diag})
check('max_t_complete_supported_family',len(DR)==2*int(TL[TL.evaluation.eq('chronological')].eligible.sum()))
# Exact old benchmark comparison on identical row keys.
old=pd.read_csv(BASE/'all_chronological_predictions.csv');pk=['platform','evaluation','fold','model']+keys
new=PR[PR.model.isin(['prevalence','opportunity_ridge_C0.1'])].merge(old[pk+['prediction','hit']],on=pk,suffixes=('','_old'),validate='one_to_one')
check('old_benchmarks_exact_same_rows',len(new)==2056 and np.array_equal(new.hit,new.hit_old));comp('old_benchmark_probabilities',new.prediction,new.prediction_old)
check('each_method_same_257_rows',all(len(v)==257 and set(map(tuple,v[keys].to_numpy()))==set(map(tuple,PR[keys].to_numpy())) for _,v in PR.groupby(['platform','evaluation','model'])))
# Metrics, fixed-bin calibration, and paired clustered uncertainty.
SC=pd.read_csv(OUT/'prediction_scorecard.csv');CAL=pd.read_csv(OUT/'fixed_bin_calibration.csv');UNC=pd.read_csv(OUT/'paired_prediction_uncertainty.csv');metric_err=cal_err=unc_err=0.;metric_ok=cal_ok=unc_ok=True
for (platform,ev,model),g in PR.groupby(['platform','evaluation','model']):
 for period,v in [('all',g)]+[('fold'+str(f),v) for f,v in g.groupby('fold')]:
  sc=SC[(SC.platform==platform)&(SC.evaluation==ev)&(SC.model==model)&(SC.period==period)].iloc[0];y=v.hit.to_numpy();p=v.prediction.to_numpy();clip=np.clip(p,1e-8,1-1e-8)
  target=np.array([len(y),y.sum(),y.mean(),clip.mean(),clip.mean()-y.mean(),np.mean((y-clip)**2),np.mean(-y*np.log(clip)-(1-y)*np.log1p(-clip)),roc_auc_score(y,clip),average_precision_score(y,clip)])
  actual=sc[['N','hits','prevalence','mean_prediction','calibration_bias','Brier','logloss','AUROC','average_precision']].to_numpy(float);metric_err=max(metric_err,float(abs(target-actual).max()));metric_ok &= np.allclose(target,actual,atol=1e-12)
 bins=np.array([-.0001,.1,.2,.3,.4,1.0001]);ca=CAL[(CAL.platform==platform)&(CAL.evaluation==ev)&(CAL.model==model)]
 for j,(lo,hi) in enumerate(zip(bins[:-1],bins[1:])):
  v=g[(g.prediction>=lo)&(g.prediction<hi)];z=ca.iloc[j];expected=np.array([len(v),v.hit.sum(),v.prediction.mean(),v.hit.mean()],float);actual=z[['N','hits','mean_prediction','observed_rate']].to_numpy(float);cal_ok &= np.allclose(expected,actual,atol=1e-12,equal_nan=True)
  if len(v):cal_err=max(cal_err,float(abs(expected-actual).max()))
 for benchmark in ['prevalence','opportunity_ridge_C0.1']:
  if model==benchmark:continue
  other=PR[(PR.platform==platform)&(PR.evaluation==ev)&(PR.model==benchmark)];v=g.merge(other[['game_id','person_id','prediction']],on=['game_id','person_id'],suffixes=('','_base'),validate='one_to_one');y=v.hit.to_numpy();p=v.prediction.to_numpy();q=v.prediction_base.to_numpy();v['b']=(y-p)**2-(y-q)**2;v['l']=-y*np.log(p)-(1-y)*np.log1p(-p)+y*np.log(q)+(1-y)*np.log1p(-q)
  for unit in ['game_id','person_id']:
   z=v.groupby(unit).agg(n=('hit','size'),b=('b','sum'),l=('l','sum'));weights=rng.multinomial(len(z),np.repeat(1/len(z),len(z)),size=1000)
   for measure,col in [('Brier','b'),('logloss','l')]:
    u=UNC[(UNC.platform==platform)&(UNC.evaluation==ev)&(UNC.model==model)&(UNC.benchmark==benchmark)&(UNC.cluster_unit==unit)&(UNC.measure==measure)].iloc[0];draws=(weights@z[col])/(weights@z.n);expected=np.array([len(z),v[col].mean(),*np.quantile(draws,[.025,.975]),1000]);actual=u[['clusters','difference','lo','hi','replicates']].to_numpy(float);unc_err=max(unc_err,float(abs(expected-actual).max()));unc_ok &= np.allclose(expected,actual,atol=1e-12)
check('all_80_scorecards',metric_ok,{'max_abs_error':metric_err})
check('all_100_calibration_bins',cal_ok,{'max_abs_error':cal_err})
check('all_128_paired_cluster_uncertainty_rows',unc_ok,{'max_abs_error':unc_err})
# Descriptive controls are neither model inputs nor selection fields.
src=(OUT/'run_search.py').read_text();control_pos=src.index('C=a.query(');selection_pos=src.index("PR.to_csv(O/'ALL_future_predictions.csv'");check('controls_joined_only_after_predictions',control_pos>selection_pos and not any(x.startswith('other_') or 'control' in x for x in features))
ap=ROOT/'dallas_review_20261012/universe_discovery/ALL_eligible_appearances_with_thresholds_traits_and_controls.csv';ac=pd.read_csv(ap,usecols=['mode','sample','person_id','game_id','hit_DK','hit_FD']);ac=ac[(ac['mode']=='prior_only_threshold')&(ac['sample']!='Dallas')]
ctrl=ac.groupby('person_id').agg(other_N=('game_id','size'),other_DK_rate=('hit_DK','mean'),other_FD_rate=('hit_FD','mean'),other_DK_hits=('hit_DK','sum'),other_FD_hits=('hit_FD','sum'))
savedctrl=pd.read_csv(OUT/'DESCRIPTIVE_same_player_other_defense_rates.csv').set_index('person_id').loc[ctrl.index];comp('source_control_rates',ctrl,savedctrl[ctrl.columns])
pd_saved=pd.read_csv(OUT/'DESCRIPTIVE_selected_prediction_rows_with_controls.csv');v=PR[PR.model.str.startswith('best')].merge(ctrl,on='person_id',how='left',validate='many_to_one');v['own_other_rate']=np.where(v.platform.eq('DK'),v.other_DK_rate,v.other_FD_rate);v['DESCRIPTIVE_lift']=v.hit-v.own_other_rate
comp('selected_prediction_controls',v[['own_other_rate','DESCRIPTIVE_lift']],pd_saved[['own_other_rate','DESCRIPTIVE_lift']]);cl=pd.read_csv(OUT/'DESCRIPTIVE_selected_branch_control_comparisons.csv');control_ok=True;groupcols=['platform','evaluation','model','fold','branch']
for kk,g in v.groupby(groupcols):
 row=cl
 for k,x in zip(groupcols,kk):row=row[row[k]==x]
 row=row.iloc[0];expected=np.array([len(g),g.person_id.nunique(),g.hit.sum(),g.hit.mean(),g.own_other_rate.mean(),g.DESCRIPTIVE_lift.mean(),g.own_other_rate.notna().sum()]);actual=row[['N','players','hits','Dallas_rate','exposure_weighted_own_other_rate','descriptive_lift','control_rates_available']].to_numpy(float);control_ok &= np.allclose(expected,actual,atol=1e-12,equal_nan=True)
check('all_descriptive_control_branches',control_ok)
RESULT['limitations'] += ['Paired uncertainty is conditional on fitted predictions, with separate game and player clustering; it does not refit training or jointly cluster game/player dependence.','Maximum-statistic wild-cluster checks are one-sided, asymptotic conditional-on-X diagnostics, not exact finite-sample multiplicity guarantees; 20/30/40 game clusters and structural support limitations remain.','Unknown tracking inputs receive training-prevalence fallback; unknown rows are not treated as known complement.','Same-player non-Dallas controls use full-sample outcomes as hindsight descriptions only; they cannot support pregame or causal claims.']
RESULT['stage']='full_numerical_audit';save()

# Final report prose/numeric checks; these do not repeat model estimation.
report_path=OUT/'Dallas_Systematic_Combination_Search_20261012.txt'
if report_path.exists():
 report=report_path.read_text();interpret=(OUT/'INTERPRETATION.txt').read_text() if (OUT/'INTERPRETATION.txt').exists() else ''
 aliases={'prevalence':'Expanding prevalence','opportunity_ridge_C0.1':'Opportunity ridge','best_pair':'Train-selected pair','best_triple':'Train-selected triple','best_any':'Train-selected best of all'}
 ordinary=SC[(SC.platform=='DK')&(SC.evaluation=='chronological')&(SC.period=='all')]
 main_table=True;all_brier_table=True
 for model,label in aliases.items():
  row=ordinary[ordinary.model==model].iloc[0]
  expected=f'{label} | {row.Brier:.4f} | {row.logloss:.4f} | {row.AUROC:.4f} | {row.mean_prediction:.1%}'
  main_table &= expected in report
  four=[]
  for platform,ev in [('DK','chronological'),('DK','chronological_player_disjoint'),('FD','chronological'),('FD','chronological_player_disjoint')]:four.append(float(SC[(SC.platform==platform)&(SC.evaluation==ev)&(SC.period=='all')&(SC.model==model)].Brier.iloc[0]))
  all_brier_table &= label+' | '+' | '.join(f'{x:.4f}' for x in four) in report
 check('final_report_main_score_table',main_table)
 check('final_report_all_platform_Brier_table',all_brier_table)
 interval_table=True
 for model in ['best_any','best_pair','best_triple']:
  u=UNC[(UNC.platform=='DK')&(UNC.evaluation=='chronological')&(UNC.model==model)&(UNC.benchmark=='opportunity_ridge_C0.1')&(UNC.cluster_unit=='game_id')&(UNC.measure=='Brier')].iloc[0]
  interval_table &= f'{aliases[model]} | {u.difference:+.6f} | [{u.lo:+.6f}, {u.hi:+.6f}]' in report
 check('final_report_paired_interval_table',interval_table)
 repeated=PR[(PR.platform=='DK')&(PR.evaluation=='chronological')&(PR.model=='best_triple')&(PR.selected_rule=='R0915')&(PR.branch=='rule')]
 check('final_report_repeated_triple_13_of_29',len(repeated)==29 and repeated.hit.sum()==13 and '13 hits in 29 later appearances' in report)
 max_table=True
 for fold in [1,2,3]:
  z=DIAG[DIAG.fold==fold].set_index('cluster_unit');max_table &= f'{fold} | {z.loc["game_id","approx_max_t_p"]:.4f} | {z.loc["person_id","approx_max_t_p"]:.4f}' in report
 check('final_report_max_t_table',max_table)
 phrases=['not an exact finite-sample familywise error guarantee','approximate conditional diagnostic','exploratory diagnostics rather than a pristine holdout','joined only after selection','No refitting occurs','do not establish a reliable Dallas advantage','not every conceivable continuous cutoff']
 check('final_report_required_qualifications',all(p in report for p in phrases),{'phrases_checked':phrases})
 check('interpretation_required_qualifications',all(p in interpret for p in ['not an exact finite-sample familywise guarantee','not the Romano','not an independent replication sample','does not undo earlier human examination','no outcome-based support gate','crosses zero']))
 RESULT['report_review']={'numeric_or_inferential_blockers':[],'reviewed_paths':[str(report_path),str(OUT/'INTERPRETATION.txt')],'editorial_notes':['Text-export markup and the subsequent angle-bracket stripping/truncation bug were corrected; complete regenerated text passed final checks.','Final report now includes the player-block interval crossing zero beside the positive game-block pair-selector interval.']}
 RESULT['stage']='full_numerical_and_report_audit';save()
