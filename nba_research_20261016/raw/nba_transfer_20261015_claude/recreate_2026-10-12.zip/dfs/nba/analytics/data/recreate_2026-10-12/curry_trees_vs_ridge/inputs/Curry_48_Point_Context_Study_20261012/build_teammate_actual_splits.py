from pathlib import Path
import pandas as pd,numpy as np,json
O=Path(__file__).resolve().parent
c=pd.read_csv(O/'outputs/curry_full_three_season_inventory.csv',dtype={'game_id':str});c.game_id=c.game_id.str.zfill(10);co=pd.read_csv(O/'coverage_curry_teammate_coappearances_187_games.csv',dtype={'game_id':str});co.game_id=co.game_id.str.zfill(10);g=pd.read_csv(O/'coverage_gsw_positive_minute_box_games_three_seasons.csv',dtype={'game_id':str});g.game_id=g.game_id.str.zfill(10);raw=pd.read_csv(O/'coverage_gsw_actual_starter_and_player_rest_source_2025_26.csv',dtype={'game_id':str});raw.game_id=raw.game_id.str.zfill(10)
# Each condition is realized game context. The split is not a pregame availability assertion.
# Preserve the parent's exact prior-only labels and report their eligible denominators separately.
def stats(z,site):
 a=z[site];r={'games':len(z),'mean':a.mean(),'median':a.median(),'p90':a.quantile(.9),'mean_curry_minutes':z.minutes.mean(),'dk_ge48_n':int(z.dk.ge(48).sum()),'dk_lt48_n':int(z.dk.lt(48).sum()),'dk_ge48_fraction':z.dk.ge(48).mean()}
 for typ,field in [('above_prior20',f'{site}_above_prior20'),('prior_q90',f'{site}_hit_q90')]:
  v=z[field].dropna();r[typ+'_eligible_n']=len(v);r[typ+'_hits']=int(v.sum());r[typ+'_misses']=int(len(v)-v.sum());r[typ+'_hit_fraction']=v.mean()
 r['sample_warning']='fewer than 10 games; highly unstable descriptive split' if len(z)<10 else 'Descriptive co-occurrence; roster era, minutes and opponent confounding remain'
 return r
rows=[];long=[];pids=g[['person_id','player']].drop_duplicates('person_id')
for _,p in pids[pids.person_id.ne(201939)].iterrows():
 first=g[g.person_id.eq(p.person_id)].date.min();last=g[g.person_id.eq(p.person_id)].date.max()
 # Butler/new teammate comparisons must never treat games before first observed GSW appearance as absence.
 # For other established players at the left edge, all-season comparisons remain available but explicitly unscoped.
 for season in c.season.unique():
  if not len(g[(g.person_id.eq(p.person_id))&g.season.eq(season)]):continue
  for scope in ['season_all_games','on_or_after_first_observed_gsw_appearance']:
   z=c[c.season.eq(season)].copy()
   if scope.startswith('on_or_after'):z=z[z.date.ge(first)]
   if p.person_id==202710 and scope=='season_all_games' and season=='2024-25':continue
   present_games=set(co[co.teammate_person_id.eq(p.person_id)].game_id);z['observed_playing']=z.game_id.isin(present_games)
   for flag,zz in z.groupby('observed_playing'):
    for site in ['dk','fd']:
     rows.append({'season':season,'teammate_person_id':p.person_id,'teammate_player':p.player,'scope':scope,'first_observed_gsw_appearance':first,'last_observed_gsw_appearance':last,'context':'observed_playing' if flag else 'not_observed_playing','site':site,**stats(zz,site)})
   if scope.startswith('on_or_after'):
    zz=z[['season','date','game_id','observed_playing']].copy();zz['teammate_person_id']=p.person_id;zz['teammate_player']=p.player;zz['first_observed_gsw_appearance']=first;zz['last_observed_gsw_appearance']=last;zz['after_last_observed_gsw_appearance']=zz.date.gt(last);long.append(zz)
splits=pd.DataFrame(rows);splits.to_csv(O/'splits_curry_actual_teammate_coappearance_by_season.csv',index=False);pd.concat(long).to_csv(O/'splits_curry_teammate_presence_grid_scoped.csv',index=False)
# Actual starters, source Y/N, observed after game. A nonstarter can play or not appear.
srows=[]
for _,p in raw[['person_id','player']].drop_duplicates().iterrows():
 first=g[g.person_id.eq(p.person_id)].date.min();z=c[c.season.eq('2025-26')&c.date.ge(first)].copy();startergames=set(raw[raw.person_id.eq(p.person_id)&raw.starter_source_yn.eq('Y')].game_id);z['started']=z.game_id.isin(startergames)
 for flag,zz in z.groupby('started'):
  for site in ['dk','fd']:
   srows.append({'season':'2025-26','person_id':p.person_id,'player':p.player,'scope':'on_or_after_first_observed_gsw_appearance','first_observed_gsw_appearance':first,'context':'actual_starter' if flag else 'not_an_actual_starter','site':site,**stats(zz,site)})
pd.DataFrame(srows).to_csv(O/'splits_curry_actual_starter_context_2025_26.csv',index=False)
# Five-man cells retain counts and actual outcomes only. No causal or stable-delta claim.
st=pd.read_csv(O/'coverage_gsw_actual_starting_five_2025_26.csv',dtype={'game_id':str});st.game_id=st.game_id.str.zfill(10);d=c[c.season.eq('2025-26')].merge(st,on=['game_id','date'],validate='one_to_one');sr=[]
for (ids,names),z in d.groupby(['starter_ids','starter_names']):
 for site in ['dk','fd']:sr.append({'starter_ids':ids,'starter_names':names,'site':site,**stats(z,site)})
pd.DataFrame(sr).sort_values(['games','starter_names'],ascending=[False,True]).to_csv(O/'splits_curry_actual_starting_five_cells_2025_26.csv',index=False)
# Exact five threshold hits requested by parent, with starter and absence context.
h=d[d.dk_hit_q90.eq(1)].copy();non=pd.read_csv(O/'coverage_curry_game_documented_teammate_nonparticipants.csv',dtype={'game_id':str});non.game_id=non.game_id.str.zfill(10);h['documented_teammate_nonparticipants']=h.game_id.map(non.groupby('game_id').apply(lambda z:';'.join(z.player+' ['+z.participation_status+': '+z.reason+']'),include_groups=False));h=h.merge(pd.read_csv(O/'coverage_curry_coappearance_game_summary_187_games.csv',dtype={'game_id':str})[['game_id','coappearing_teammate_names']],on='game_id',validate='one_to_one');h[['date','game_id','opponent','minutes','dk','fd','dk_prior_q90','fd_prior_q90','starter_names','coappearing_teammate_names','documented_teammate_nonparticipants']].to_csv(O/'splits_curry_2025_26_five_prior_q90_hits_lineup_context.csv',index=False)
# First useful summary for parent: same-season realized presence splits for key names.
key=['Draymond Green','Jimmy Butler','Brandin Podziemski','Buddy Hield','Moses Moody','Jonathan Kuminga','Quinten Post','Al Horford']
s=splits[(splits.season.eq('2025-26'))&(splits.site.eq('fd'))&splits.teammate_player.isin(key)&splits.scope.eq('on_or_after_first_observed_gsw_appearance')];print(s[['teammate_player','context','games','mean','median','p90','above_prior20_hits','above_prior20_misses','prior_q90_hits','prior_q90_misses']].round(2).to_string(index=False))
