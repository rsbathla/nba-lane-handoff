from pathlib import Path
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import pandas as pd,numpy as np,json,hashlib,datetime
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score,average_precision_score,brier_score_loss,log_loss
P=Path('/workspace/scratch/0bd466b49713');B=P/'dallas_review_20261012/method_comparison_20261012';O=B/'combinatorial_search';SEED=20261012;rng=np.random.default_rng(SEED)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(rows,name):pd.DataFrame(rows).to_csv(O/(name+'.csv'),index=False)
proto=json.loads((O/'FROZEN_COMBINATORIAL_PROTOCOL.json').read_text());features=proto['features'];rules=pd.read_csv(O/'FROZEN_CANDIDATE_DICTIONARY.csv');rfs=[s.split('|') for s in rules.features];rdirs=[s.split('|') for s in rules.directions]
assert len(rules)==1426 and rules.predicate.nunique()==1426
start_time=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Outcomes first enter this new search only below, after frozen protocol/inventory exist.
ap=P/'dallas_review_20261012/universe_discovery/ALL_eligible_appearances_with_thresholds_traits_and_controls.csv';a=pd.read_csv(ap,usecols=['mode','sample','date','game_id','person_id','player','hit_DK','hit_FD','personal_q85_DK','personal_q85_FD','dk_points','fd_points'])
D=pd.read_csv(O/'Dallas_features_OUTCOME_FREE.csv').merge(a.query("mode=='prior_only_threshold' and sample=='Dallas'").drop(columns='player'),on=['date','game_id','person_id'],validate='one_to_one').sort_values(['date','person_id']).reset_index(drop=True)
assert len(D)==382 and D.hit_DK.sum()==91
for plat in ['DK','FD']:assert D['hit_'+plat].eq(D[plat.lower()+'_points']>D['personal_q85_'+plat]).all()
D['player_hash_group']=D.person_id.map(lambda p:int(hashlib.sha256(str(int(p)).encode()).hexdigest()[:8],16)%5);dates=sorted(D.date.unique());assert len(dates)==50
D.to_csv(O/'Dallas_complete_feature_outcome_ledger.csv',index=False)
def matrices(A,med):
 high={f:A[f].to_numpy()>=med[f] for f in features};low={f:A[f].to_numpy()<med[f] for f in features};known={f:np.isfinite(A[f].to_numpy())&np.isfinite(med[f]) for f in features}
 K=np.column_stack([np.logical_and.reduce([known[f] for f in fs]) for fs in rfs]);M=np.column_stack([np.logical_and.reduce([(high[f] if d=='high' else low[f]) for f,d in zip(fs,dirs)]) for fs,dirs in zip(rfs,rdirs)])&K;return M,K&~M,~K

def counts(A,M):
 yy={p:A['hit_'+p].astype(int).to_numpy() for p in ['DK','FD']};n=M.sum(axis=0);out={'N':n,'DK_hits':yy['DK']@M,'FD_hits':yy['FD']@M}
 for c,label in [('game_id','games'),('person_id','players')]:
  codes,gr=pd.factorize(A[c]);z=np.zeros((len(gr),M.shape[1]),int);np.add.at(z,codes,M.astype(int));out[label]=(z>0).sum(axis=0)
 return out

def support(c):return (c['N']>=20)&(c['games']>=5)&(c['players']>=5)

def max_diagnostic(A,M,eligible,fold,unit):
 ids=np.where(eligible)[0];y=A.hit_DK.to_numpy(dtype=float);n=len(A);Q=M[:,ids].astype(float);rate=y@Q/Q.sum(axis=0);delta=rate-y.mean();psi=Q*(y[:,None]-rate[None,:])/(Q.mean(axis=0)[None,:])-(y-y.mean())[:,None]
 codes,groups=pd.factorize(A[unit]);G=len(groups);z=np.zeros((G,len(ids)));np.add.at(z,codes,psi);se=np.sqrt(G/(G-1)*(z*z).sum(axis=0))/n;good=se>1e-12
 signs=rng.choice([-1.,1.],size=(2000,G));bstar=(signs@z[:,good])/n*np.sqrt(G/(G-1))/se[None,good];mx=bstar.max(axis=1);observed=delta[good]/se[good];maxt=float(observed.max());p=(1+np.sum(mx>=maxt))/(2001)
 rr=[]
 for j,t,ss,dd in zip(ids[good],observed,se[good],delta[good]):rr.append({'fold':fold,'cluster_unit':unit,'rule_id':rules.rule_id.iloc[j],'raw_uplift':dd,'cluster_SE':ss,'raw_t':t,'approx_max_t_adjusted_p':(1+np.sum(mx>=t))/2001})
 return {'fold':fold,'cluster_unit':unit,'N':n,'clusters':G,'declared_candidates':1426,'eligible_candidates':len(ids),'valid_SE_candidates':int(good.sum()),'max_observed_t':maxt,'approx_max_t_p':p,'null_max_t_q95':float(np.quantile(mx,.95)),'replicates':2000,'method':'Conditional-X centered wild cluster max-t; approximate, not exact familywise guarantee; no selection or prediction use'},rr

trainledger=[];testledger=[];pred=[];cuts=[];foldaudit=[];selected=[];diag=[];diag_rules=[];candidatecounts=[];coef=[]
models=['prevalence','opportunity_ridge_C0.1','best_pair','best_triple','best_any'];opps=['prior10_minutes','prior30_minutes_sd','prior30_fga36']
for evaluation in ['chronological','chronological_player_disjoint']:
 for fold,start in enumerate([20,30,40],1):
  for hg in ([None] if evaluation=='chronological' else range(5)):
   tr=D[D.date.isin(dates[:start])].copy();te=D[D.date.isin(dates[start:start+10])].copy()
   if hg is not None:tr=tr[tr.player_hash_group.ne(hg)];te=te[te.player_hash_group.eq(hg)]
   assert tr.date.max()<te.date.min();assert hg is None or not(set(tr.person_id)&set(te.person_id))
   fitid=f'{evaluation}_fold{fold}_group{hg if hg is not None else "all"}';meta={'fit_id':fitid,'evaluation':evaluation,'fold':fold,'player_group':hg}
   med=tr[features].median();cuts.extend([dict(**meta,feature=f,cutoff=float(med[f]),train_nonmissing=int(tr[f].notna().sum())) for f in features]);M,C,U=matrices(tr,med);m,c,u=counts(tr,M),counts(tr,C),counts(tr,U);eligible=support(m)&support(c);p0=tr.hit_DK.mean();shr=(m['DK_hits']+20*p0)/(m['N']+20);score=shr-p0
   MT,CT,UT=matrices(te,med);mt,ct,ut=counts(te,MT),counts(te,CT),counts(te,UT)
   picks={}
   for model,order in [('best_pair',2),('best_triple',3),('best_any',None)]:
    allow=eligible.copy()&(score>0)
    if order is not None:allow&=rules.order.eq(order).to_numpy()
    ids=np.where(allow)[0];j=int(ids[np.argmax(score[ids])]) if len(ids) else None;picks[model]=j
    row=dict(**meta,model=model,rule_id=rules.rule_id.iloc[j] if j is not None else 'NONE_PREVALENCE',predicate=rules.predicate.iloc[j] if j is not None else 'fallback',order=int(rules.order.iloc[j]) if j is not None else 0,train_prevalence=p0,train_shrunk_uplift=float(score[j]) if j is not None else 0,eligible_candidates=int((eligible&(rules.order.eq(order).to_numpy() if order is not None else True)).sum()),positive_candidates=len(ids))
    if j is not None:
     row.update({f'train_rule_{k}':int(v[j]) for k,v in m.items()});row.update({f'train_complement_{k}':int(v[j]) for k,v in c.items()});row.update({'cutoffs_json':json.dumps({f:float(med[f]) for f in rfs[j]}),'test_rule_N':int(mt['N'][j]),'test_complement_N':int(ct['N'][j]),'test_unknown_N':int(ut['N'][j])})
    selected.append(row)
   for j,r in rules.iterrows():
    fail=[]
    for name,v in [('rule',m),('complement',c)]:
     for k,threshold in [('N',20),('games',5),('players',5)]:
      if v[k][j]<threshold:fail.append(f'{name}_{k}<{threshold}')
    row=dict(**meta,rule_id=r.rule_id,order=int(r.order),family=r.family,eligible=bool(eligible[j]),exclusion_reasons=';'.join(fail),train_prevalence=p0,raw_rule_DK_rate=float(m['DK_hits'][j]/m['N'][j]) if m['N'][j] else np.nan,shrunk_rule_DK_rate=float(shr[j]),shrunk_uplift=float(score[j]),selected_by='|'.join(k for k,v in picks.items() if v==j))
    for name,v in [('rule',m),('complement',c),('unknown',u)]:row.update({name+'_'+k:int(x[j]) for k,x in v.items()})
    trainledger.append(row)
    if evaluation=='chronological':
     row=dict(fold=fold,rule_id=r.rule_id,order=int(r.order),eligible_in_train=bool(eligible[j]),descriptive_only=True)
     for name,v in [('rule',mt),('complement',ct),('unknown',ut)]:row.update({name+'_'+k:int(x[j]) for k,x in v.items()})
     testledger.append(row)
   for order in [1,2,3,0]:
    choose=rules.order.eq(order).to_numpy() if order else np.ones(len(rules),bool);ok=eligible&choose
    # Count actual repeated-membership patterns without reducing the declared search.
    patterns={M[:,j].tobytes()+C[:,j].tobytes() for j in np.where(ok)[0]}
    candidatecounts.append(dict(**meta,order=order,declared=int(choose.sum()),eligible=int(ok.sum()),excluded=int((choose&~eligible).sum()),eligible_unique_training_patterns=len(patterns)))
   if evaluation=='chronological':
    for unit in ['game_id','person_id']:
     z,rr=max_diagnostic(tr,M,eligible,fold,unit);diag.append(z);diag_rules.extend(rr)
   foldaudit.append(dict(**meta,train_N=len(tr),train_players=tr.person_id.nunique(),train_games=tr.game_id.nunique(),train_DK_hits=int(tr.hit_DK.sum()),test_N=len(te),test_players=te.person_id.nunique(),test_games=te.game_id.nunique(),test_DK_hits=int(te.hit_DK.sum()),train_first=tr.date.min(),train_last=tr.date.max(),test_first=te.date.min(),test_last=te.date.max(),player_overlap=len(set(tr.person_id)&set(te.person_id))))
   for platform in ['DK','FD']:
    y=tr['hit_'+platform].astype(int).to_numpy();base=y.mean();sc=StandardScaler().fit(tr[opps]);model=LogisticRegression(C=.1,max_iter=2000,solver='lbfgs').fit(sc.transform(tr[opps]),y);ridge=model.predict_proba(sc.transform(te[opps]))[:,1]
    coef.extend([dict(**meta,platform=platform,feature=f,coefficient=float(z),scaler_mean=float(mn),scaler_scale=float(ss)) for f,z,mn,ss in zip(opps,model.coef_[0],sc.mean_,sc.scale_)])
    for modelname in models:
     j=picks.get(modelname);branch=np.full(len(te),'not_rule_model',dtype=object)
     if modelname=='prevalence':pp=np.full(len(te),base)
     elif modelname=='opportunity_ridge_C0.1':pp=ridge
     elif j is None:pp=np.full(len(te),base);branch[:]='no_eligible_positive_rule'
     else:
      pp=np.full(len(te),base);pp[MT[:,j]]=(y@M[:,j]+20*base)/(M[:,j].sum()+20);pp[CT[:,j]]=(y@C[:,j]+20*base)/(C[:,j].sum()+20);branch=np.where(UT[:,j],'unknown_fallback',np.where(MT[:,j],'rule','complement'))
     for (_,r),p,br in zip(te.iterrows(),pp,branch):pred.append(dict(**meta,platform=platform,model=modelname,date=r.date,game_id=r.game_id,person_id=r.person_id,player=r.player,hit=int(r['hit_'+platform]),prediction=float(p),selected_rule=rules.rule_id.iloc[j] if j is not None else '',branch=br))
   print('FIT',fitid,'eligible',int(eligible.sum()),'picked',{k:rules.rule_id.iloc[v] if v is not None else None for k,v in picks.items()},flush=True)
for r,n in [(trainledger,'ALL_25668_candidate_train_evaluations'),(testledger,'ALL_4278_candidate_future_descriptive_counts'),(cuts,'ALL_training_cutoffs'),(foldaudit,'split_audit'),(selected,'ALL_selected_rules'),(candidatecounts,'candidate_counts_by_fit'),(diag,'approximate_max_statistic_diagnostic'),(diag_rules,'ALL_max_statistic_candidate_diagnostics'),(coef,'opportunity_ridge_coefficients')]:save(r,n)
PR=pd.DataFrame(pred);PR.to_csv(O/'ALL_future_predictions.csv',index=False)
# These benchmarks must be numerically identical to original study on exactly the same future rows.
old=pd.read_csv(B/'all_chronological_predictions.csv');keys=['platform','evaluation','fold','model','date','game_id','person_id'];q=PR[PR.model.isin(models[:2])].merge(old[keys+['hit','prediction']],on=keys,suffixes=('','_original'),validate='one_to_one');benchmax=float(abs(q.prediction-q.prediction_original).max());assert len(q)==257*2*2*2 and q.hit.eq(q.hit_original).all() and benchmax<1e-12
metrics=[];cal=[];unc=[]
for (platform,evaluation,model),G in PR.groupby(['platform','evaluation','model']):
 assert len(G)==257
 for period,V in [('all',G)]+[('fold'+str(f),z) for f,z in G.groupby('fold')]:
  y=V.hit.to_numpy();p=V.prediction.clip(1e-8,1-1e-8).to_numpy();metrics.append(dict(platform=platform,evaluation=evaluation,model=model,period=period,N=len(V),hits=int(y.sum()),prevalence=float(y.mean()),mean_prediction=float(p.mean()),calibration_bias=float(p.mean()-y.mean()),Brier=brier_score_loss(y,p),logloss=log_loss(y,p,labels=[0,1]),AUROC=roc_auc_score(y,p) if len(set(y))>1 else np.nan,average_precision=average_precision_score(y,p)))
 H=G.copy();H['probability_bin']=pd.cut(H.prediction,[-.0001,.1,.2,.3,.4,1.0001],right=False)
 for bin,V in H.groupby('probability_bin',observed=False):cal.append(dict(platform=platform,evaluation=evaluation,model=model,probability_bin=str(bin),N=len(V),hits=int(V.hit.sum()),mean_prediction=V.prediction.mean(),observed_rate=V.hit.mean()))
 for benchmark in ['prevalence','opportunity_ridge_C0.1']:
  if model==benchmark:continue
  base=PR.query('platform==@platform and evaluation==@evaluation and model==@benchmark');V=G.merge(base[['game_id','person_id','prediction']],on=['game_id','person_id'],suffixes=('','_base'),validate='one_to_one');V['Brier_difference']=(V.hit-V.prediction)**2-(V.hit-V.prediction_base)**2;V['logloss_difference']=-(V.hit*np.log(V.prediction)+(1-V.hit)*np.log1p(-V.prediction))+(V.hit*np.log(V.prediction_base)+(1-V.hit)*np.log1p(-V.prediction_base))
  for unit in ['game_id','person_id']:
   Z=V.groupby(unit).agg(n=('hit','size'),b=('Brier_difference','sum'),l=('logloss_difference','sum'));bw=rng.multinomial(len(Z),np.repeat(1/len(Z),len(Z)),size=1000)
   for measure,col in [('Brier','b'),('logloss','l')]:
    vals=(bw@Z[col])/(bw@Z.n);unc.append(dict(platform=platform,evaluation=evaluation,model=model,benchmark=benchmark,measure=measure,cluster_unit=unit,clusters=len(Z),difference=float(V[measure+'_difference'].mean()),lo=float(np.quantile(vals,.025)),hi=float(np.quantile(vals,.975)),replicates=1000))
save(metrics,'prediction_scorecard');save(cal,'fixed_bin_calibration');save(unc,'paired_prediction_uncertainty')
# Controls join only after all selection/predictions are complete and written.
C=a.query("mode=='prior_only_threshold' and sample!='Dallas'");control=C.groupby('person_id').agg(other_N=('game_id','size'),other_DK_rate=('hit_DK','mean'),other_FD_rate=('hit_FD','mean'),other_DK_hits=('hit_DK','sum'),other_FD_hits=('hit_FD','sum')).reset_index();control.to_csv(O/'DESCRIPTIVE_same_player_other_defense_rates.csv',index=False)
PD=PR[PR.model.str.startswith('best')].merge(control,on='person_id',how='left',validate='many_to_one');PD['own_other_rate']=np.where(PD.platform.eq('DK'),PD.other_DK_rate,PD.other_FD_rate);PD['DESCRIPTIVE_lift']=PD.hit-PD.own_other_rate;PD.to_csv(O/'DESCRIPTIVE_selected_prediction_rows_with_controls.csv',index=False)
controls=[]
for keys,G in PD.groupby(['platform','evaluation','model','fold','branch']):controls.append(dict(zip(['platform','evaluation','model','fold','branch'],keys))|{'N':len(G),'players':G.person_id.nunique(),'hits':int(G.hit.sum()),'Dallas_rate':G.hit.mean(),'exposure_weighted_own_other_rate':G.own_other_rate.mean(),'descriptive_lift':G.DESCRIPTIVE_lift.mean(),'control_rates_available':int(G.own_other_rate.notna().sum()),'future_controls_allowed_only_for_description':True})
save(controls,'DESCRIPTIVE_selected_branch_control_comparisons')
manifest={'started_outcomes_at_utc':start_time,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protocol_sha256':sha(O/'FROZEN_COMBINATORIAL_PROTOCOL.json'),'source_hashes':proto['source_hashes'],'script_hashes':{str(O/n):sha(O/n) for n in ['prepare_features.py','run_search.py']},'random_seed':SEED,'n_Dallas_rows':len(D),'n_Dallas_players':D.person_id.nunique(),'n_Dallas_games':D.game_id.nunique(),'DK_hits':int(D.hit_DK.sum()),'FD_hits':int(D.hit_FD.sum()),'n_candidate_definitions':len(rules),'n_training_fits':len(foldaudit),'n_candidate_train_evaluations':len(trainledger),'n_candidate_future_descriptive_evaluations':len(testledger),'n_future_prediction_rows':len(PR),'n_future_unique_appearances':PR[['game_id','person_id']].drop_duplicates().shape[0],'original_benchmark_max_abs_prediction_difference':benchmax,'no_data_acquisition':True,'no_pristine_holdout':True,'no_simulated_observations':True,'scikit_learn_version':__import__('sklearn').__version__,'deviations':[]}
(O/'RUN_MANIFEST.json').write_text(json.dumps(manifest,indent=2));print('COMPLETE');print(pd.DataFrame(metrics).query("platform=='DK' and period=='all'").to_string(index=False));print(pd.DataFrame(candidatecounts).query("evaluation=='chronological'").to_string(index=False));print(pd.DataFrame(diag).to_string(index=False))
