# Recreation: NBA individual player trees vs matched pooled ridge

Note on the brief: its wording merges two different artifacts. The Curry bundle compares individual player trees with pooled ridge on 35 final-window games (one player). The dfs repo study compares shared ridge with personal-slope ridge on 37 players (421 games, intact rotation) and 275 players (6,671 games, all availability). Neither contains both a tree and a personal ridge.

## Claim

"NBA: the tested individual player trees did not establish a clear tail improvement over matched pooled ridge. This does not prove all individual models fail."

## What the bundle ships

Artifact A (Curry fixed-48 bundle, 143 members): scorer analysis/score_pregame_identifiers.py, analysis/reproduce_packaged_key_results.py, combine_fixed48_evidence.py, independent audits, the 187-game ledger, 790 saved per-game probabilities (outputs/curry_existing_model_fixed48_predictions.csv), the 20-row scorecard and the integration receipt.

Not shipped: the upstream player_specific_pilot folder (player_tree_predictions, pooled_matched_predictions, tree JSON files, core panel). score_pregame_identifiers.py reads those for the tree leaf residuals and the seven saved pooled quantiles, then converts them to P(score>=48). The bundle README states "saved-model readthrough, no new fit", the ledger records new_models_fitted 0, and the audit says the same. No tree or ridge fitting code is in the bundle.

Answer to the question asked: the scorecard only re-scores saved predictions. The trees and ridges are not refit from shipped inputs, and the bundle cannot refit them. What I could do is re-score the shipped p48 column, and I did.

Artifact B (dfs repo): individual_ceiling_study.py, its sibling modules, both input parquets (hashes match the saved summary.json), and saved results in data/research_individual/. Everything needed to rerun is on disk.

## What I ran

1. Extracted the zip with Python zipfile into inputs/ (143 members hashed in inputs/INPUT_HASHES.json). No bundle code run from inside the zip.
2. A: shipped analysis/reproduce_packaged_key_results.py, unchanged, with python -I. Output PASS (0.74 s). It re-aggregates 14 candidate scorecards and 20 saved-model scorecards from the saved membership and probabilities.
3. A: my own scripts/rescore_curry_saved_predictions.py recomputed all 20 scorecard rows (n, hits, mean p, Brier, top-20 hits) from the saved probabilities, and the DK and FD hit counts from the ledger.
4. B: scripts/run_personal_ridge_rerun.py imports the unmodified individual_ceiling_study.py, redirects only its hard-coded OUT (and the default of its audit function) to outputs/research_individual_rerun/, and calls main(). The study's own validate_artifacts audit ran on the new outputs and passed. Runtime estimated under 10 minutes from the code; actual 26 seconds wall. research_individual/ was not touched (file times remain Oct 1).
5. B: scripts/compare_personal_ridge.py compared every output file with the original.

Interpreter: /Users/rsbathla/Downloads/Fantasy/.venv/bin/python 3.9.6, pandas 2.3.3, numpy 2.0.2, scipy 1.13.1, scikit-learn 1.6.1. No network. No PROTOCOL.json: no test was designed here.

## Claimed vs recreated

| quantity | claimed (source file) | recreated here | match | note |
|---|---|---|---|---|
| A: DK >=48 games | 67 of 187 (fixed48_integration_receipt.json) | 67 hits, 120 misses from ledger csv | EXACT | recount of shipped ledger |
| A: FD >=48 games | 46 of 187, 141 misses (receipt) | 46 hits, 141 misses | EXACT | |
| A: final DK window n, hits | 35 games, 11 hits (scorecard csv) | 35, 11 | EXACT | re-score of saved p48 |
| A: final DK player_distribution_tree Brier, mean p | 0.2268, 0.417 | 0.226849, 0.416590 | EXACT | max abs diff vs scorecard 1.1e-16 over all 20 rows |
| A: final DK pooled_ridge_role_history Brier, mean p | 0.1950, 0.330 | 0.195002, 0.329714 | EXACT | |
| A: final DK top-20 hits (7 games) | tree 3, ridge role_history 3 (scorecard) | 3 and 3 | EXACT | tied; pooled_ridge_full_additive 1 |
| A: tree minus ridge Brier, final DK | not claimed as a number | +0.0318 (tree worse) | NEW (derived) | tree Brier lower than ridge in only 2 of 16 tree-ridge pairs (FD development window, player_mean_tree, against either ridge) |
| A: trees refit from shipped inputs | not claimed | not possible | NOT_RUN | leaf residuals and pooled quantiles are not in the bundle |
| B: all-availability Brier, shared | 0.156982 (forecast_metrics.csv) | 0.156982 | EXACT | file byte-identical |
| B: all-availability Brier, personal range | 0.168470 to 0.227531 | 0.168470 to 0.227531 | EXACT | personal_shots_05 to personal_all_10 |
| B: intact Brier, shared | 0.129698 | 0.129698 | EXACT | |
| B: intact Brier, personal range | 0.137877 to 0.193347 | 0.137877 to 0.193347 | EXACT | |
| B: all 10 metric rows | forecast_metrics.csv | identical | EXACT | max abs diff 0 |
| B: forecast_comparisons (8 rows, CIs, q) | forecast_comparisons.csv | identical | EXACT | personal worse in all 8, q 0.0004 to 0.0084 |
| B: 104 nominal candidates, 0 replicated | summary.json | 96 + 8 = 104 nominal; 0 nominal and 0 corrected replicated | EXACT | summary.json equal as a whole |
| B: player_factors, coverage, per-player comparisons, predictions.parquet | saved files | identical, 35,460 prediction rows | EXACT | max probability diff 0 |

## Verdict

PARTIALLY REPRODUCED. The Curry scorecard numbers reproduce exactly, but only as a re-score of saved predictions (the tree and ridge models cannot be refit from the bundle); the personal-slope ridge study reruns end to end and matches every saved file byte for byte.

On the claim itself: in the saved Curry predictions the trees were not better than matched pooled ridge on Brier (worse in 14 of 16 pairs) and their top-20 hit counts were no better in 12 of 16 pairs (4 strictly higher, 4 tied, 8 lower), on 7 to 9 games per cell. The personal-slope ridge was worse than the shared ridge in all 8 comparisons. Both are consistent with "no clear tail improvement". Neither tests all individual models, as the claim already says.

## Limitations and what was not run

- A is one player (Curry), 35 final games and 44 development games, 7 or 9 games in each top-20 slice. The tail evidence is a handful of games. No significance test was run on the tree versus ridge differences; the counts above are descriptive.
- The pooled ridge probabilities in A are an approximate CDF inversion from seven quantiles (bounded 0.05 to 0.90), per the shipped recipe; the tree probabilities use exact shrunken empirical leaf distributions. The two sides use different probability recipes, so Brier gaps partly reflect that. Mean p for the tree (0.417) against an event rate of 0.314 shows over-prediction.
- The Curry study is retrospective, post-discovery, not prospective (README says so).
- NOT_RUN: refit of the Curry trees or ridges; the audit scripts audit_core_fixed48.py, audit_identifier_scorecards.py and score_pregame_identifiers.py (they need the missing player_specific_pilot folder and raw sources); the other Curry builders (need raw workbooks).
- B tests personal ridge slopes, not trees. It does not test individual trees. B reruns on the same two parquet files with the same code and hashes, so it confirms determinism and code integrity, not independence of data.
- Tree-vs-ridge pair table (outputs/curry_rescore/tree_vs_ridge_pairs.csv) is a derived readout, not a frozen test.

## Files produced

Hashes for every file are in OUTPUT_HASHES.json (RESULT.md itself excluded since it cannot contain its own hash). Paths below are under /Users/rsbathla/Downloads/dfs/nba/analytics/data/recreate_2026-10-12/curry_trees_vs_ridge/.

- INPUT_HASHES.json  6d28153da31c7238b7140f8e1fc91955648ddad4800974485a90c2ac34140289
- RUNTIME.json  e37563b8ea4be56fc96620f3ef7fbd1b8231383b5ba92527aa5e932903b7a777
- outputs/curry_rescore/ledger_counts.json  37275e121d10eef2b77d3ec751b96882ecadbe653902673e47c224112b09de5f
- outputs/curry_rescore/rescore_vs_shipped_scorecard.csv  b78c2fb90485ce48526fe5b555b6788f549596ac674fd209dd2c7986708f9541
- outputs/curry_rescore/tree_vs_ridge_pairs.csv  78585384e3f2f9b830dd92421097c30ab1998945d83019eef011df08f4f6d456
- outputs/personal_ridge_comparison.json  4f9b335e9dcdd1cd1b5d33d8854f24c4c483bd802277aaa9e8e7e8e92363f7e3
- outputs/personal_ridge_rerun.stderr.txt  d117fa006ba9208500b2930ce69cbde436c647afa917cb7396a9bc9111a46dd2
- outputs/personal_ridge_rerun.stdout.txt  b5951d7de1d8552305007ba36ae3d29c7c61c1bb574d0bcc27e35dec8ede1c1a
- outputs/personal_ridge_rerun.time.txt  660cf8c87fe8faa4a76518b81b558c35718b9795fba08454a1d11968f660d74d
- outputs/reproduce_packaged_key_results.stdout.txt  9648711718463ff151d1a3b090db8aba75852467b86bc12bc8b185ad5eea7517
- outputs/research_individual_rerun/audit_validation.json  cfadf3d355d0c1190b32f9feab8b53754e7f252965021faa4695a6f136483712
- outputs/research_individual_rerun/forecast_comparisons.csv  bfc3bb328d5e7093047aa77006b40b59a7cbf5129f8c5374ea2a30c8e06976c3
- outputs/research_individual_rerun/forecast_metrics.csv  1ff33e71b80c84851ca69ad3c99390101756ad410e17c433b049697ab65cac68
- outputs/research_individual_rerun/player_coverage.csv  82ebdf6ef2233bcf04195c15dd4aac88a535d637dec3d1156ae987307b98c80d
- outputs/research_individual_rerun/player_factors.csv  3b6c9c7285abf4e7db88764e0ad9de63de27efbabbe7caa0aa1195e900258f00
- outputs/research_individual_rerun/player_forecast_comparisons.csv  c70524daddae1b220b3bb6f62863e0f42d09865c9175c0c177d027c157a4481f
- outputs/research_individual_rerun/predictions.parquet  310028a6123f222c1b53789dc0419f0e3e58b1c09c66a6849056f7f7958268fa
- outputs/research_individual_rerun/summary.json  e36efa008b879f2ad23618449cda8bc228d5aaf40e5f5b0c30093aca4c07ba48
- scripts/compare_personal_ridge.py  edabde87396c3d52bf4a0980efb60e5cd9d6c537cc1e76c977b0a45e2c338f49
- scripts/rescore_curry_saved_predictions.py  234d86e0bdd642f72266ee0d4c6e2bfd1e011dabadd75970bb8f678dac3a6e91
- scripts/run_personal_ridge_rerun.py  860d12f767b2d62aa5741aeaf4866741ac1a9320eb865a9b59665a5300fd358b
- INPUT_HASHES.json, inputs/INPUT_HASHES.json, OUTPUT_HASHES.json, RUNTIME.json, RESULT.md (extracted bundle in inputs/ is hashed in INPUT_HASHES.json)
