"""Bounded historical check. Fixed 2024–25 median cutoffs, evaluated in 2025–26 only. No search or fitting."""
from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
O=Path(__file__).resolve().parents[1];D=O/'outputs';x=pd.read_csv(D/'curry_shot_context_join.csv',dtype={'game_id':str});old=x[x.season.eq('2024-25')];test=x[x.season.eq('2025-26')].copy();out=[]
specs=[('prior10_cs_fga_above_old_median','track_cs_fga_prior10','>',float(old.track_cs_fga_prior10.median())),('prior10_pu_share_at_or_below_old_median','track_pu_fga_share_prior10','<=',float(old.track_pu_fga_share_prior10.median()))]
assert np.isclose(specs[0][3],6.05)
assert np.isclose(specs[1][3],.436239,atol=.000001)
for name,f,op,cut in specs:
 eligible=test[test[f].notna()];unknown=test[test[f].isna()];selected=eligible[eligible[f].gt(cut) if op=='>' else eligible[f].le(cut)];other=eligible.drop(selected.index)
 eh=int(eligible.dk.ge(48).sum());ehp=eh/len(eligible)
 for label,u in [('selected',selected),('not_selected',other),('eligible_baseline',eligible),('unknown_history',unknown),('all_2025_26_baseline',test)]:
  hits=int(u.dk.ge(48).sum());n=len(u);p=hits/n if n else np.nan
  out.append(dict(rule=name,feature=f,comparison=op,cutoff=cut,cutoff_origin='2024-25 non-null prior10 feature median; no 2025-26 outcomes or feature values used to set cutoff',evaluation_season='2025-26',group=label,n=n,dk_ge48_hits=hits,dk_lt48_misses=n-hits,precision=p,eligible_hits=eh,eligible_n=len(eligible),eligible_baseline_rate=ehp,captured_eligible_hits_fraction=hits/eh if eh and label in ['selected','not_selected'] else np.nan,selected_fraction_of_eligible=n/len(eligible) if label in ['selected','not_selected'] else np.nan,precision_minus_same_cohort_baseline=p-ehp,precision_ratio_to_same_cohort_baseline=p/ehp if ehp else np.nan,dk_mean=u.dk.mean(),dk_median=u.dk.median(),dk_q90=u.dk.quantile(.9),dk_q95=u.dk.quantile(.95),mean_minus_prior20=(u.dk-u.dk_prior20_mean).mean(),first_date=u.date.min(),last_date=u.date.max(),not_prospectively_registered=True,already_explored_historical_evidence=True,source_vintage_certified=False))
 test[name]=np.where(test[f].isna(),None,(test[f].gt(cut) if op=='>' else test[f].le(cut)))
pd.DataFrame(out).to_csv(D/'curry_fixed_older_cutoff_2025_26_48_results.csv',index=False)
test[['season','date','game_id','opponent','dk','fd','track_cs_fga_prior10','track_pu_fga_share_prior10']+[s[0] for s in specs]].to_csv(D/'curry_fixed_older_cutoff_2025_26_game_audit.csv',index=False)
print(pd.DataFrame(out)[['rule','comparison','cutoff','group','n','dk_ge48_hits','dk_lt48_misses','precision','captured_eligible_hits_fraction','eligible_baseline_rate','precision_minus_same_cohort_baseline','precision_ratio_to_same_cohort_baseline','dk_mean','dk_median']].to_string(index=False))
