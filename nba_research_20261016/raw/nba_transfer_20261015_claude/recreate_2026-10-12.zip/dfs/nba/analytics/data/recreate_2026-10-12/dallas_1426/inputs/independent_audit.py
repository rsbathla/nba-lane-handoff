"""Independent, read-only audit of frozen Dallas combinatorial search.
Recomputes source validity, target-row features, predicates, split support and numeric
outputs without importing or executing production feature/search scripts.
Only writes independent_audit.json and independent_audit.txt.
"""
from pathlib import Path
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']: os.environ[k]='1'
import ast, datetime, hashlib, itertools, json
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, log_loss, brier_score_loss
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
O=Path(__file__).resolve().parent
ROOT=O.parents[2]
B=O.parent
checks=[]
notes=[]
facts={}
def check(name, okay, detail=None):
    checks.append(dict(check=name,passed=bool(okay),detail=detail))
    if not okay: print('FAILED:',name,detail,flush=True)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def eq(a,b): return np.allclose(np.asarray(a,dtype=float),np.asarray(b,dtype=float),rtol=1e-10,atol=1e-11,equal_nan=True)
def finite_div(a,b): return float(a/b) if b>0 else np.nan
p=json.loads((O/'FROZEN_COMBINATORIAL_PROTOCOL.json').read_text())
f=json.loads((O/'OUTCOME_FREE_FEASIBILITY.json').read_text())
features=p['features']
check('21 unique frozen features',len(features)==21 and len(set(features))==21)
check('protocol refinement removes hit/miss eligibility gates','No minimum hits/misses' in p['support'] and 'exactly same outcome-independent support' in p['multiplicity_diagnostic'])
for file,h in p['source_hashes'].items(): check('source hash '+Path(file).name,sha(file)==h)
check('candidate dictionary hash',sha(O/'FROZEN_CANDIDATE_DICTIONARY.csv')==p['candidate_dictionary_sha256'])
check('outcome-free feasibility hash',sha(O/'OUTCOME_FREE_FEASIBILITY.json')==p['outcome_free_feasibility_sha256'])
cand=pd.read_csv(O/'FROZEN_CANDIDATE_DICTIONARY.csv')
expected=[]
for order,combos in [(1,[(v,) for v in features]),(2,itertools.combinations(features,2)),(3,itertools.product(p['families']['role'],p['families']['volume'],p['families']['ability']))]:
    for fs in combos:
        for dirs in itertools.product(['low','high'],repeat=order):
            expected.append((order,'|'.join(fs),'|'.join(dirs),' AND '.join(f'{v} {"<" if d=="low" else ">="} TRAIN_MEDIAN' for v,d in zip(fs,dirs))))
actual=list(cand[['order','features','directions','predicate']].itertuples(index=False,name=None))
check('complete exact 1426-rule dictionary',actual==expected and len(set(expected))==1426 and list(cand.rule_id)==[f'R{i:04d}' for i in range(1,1427)])
check('42 singles 840 pairs 544 triples',cand.groupby('order').size().to_dict()=={1:42,2:840,3:544})
box_path=next(Path(v) for v in p['source_hashes'] if 'box_derived' in v)
tracking_path=next(Path(v) for v in p['source_hashes'] if 'corrected_tracking' in v)
ledger_path=next(Path(v) for v in p['source_hashes'] if 'ALL_eligible' in v)
box_cols=['date','game_id','person_id','player','minutes','fgm','fga','fg3m','fg3a','fta','ast','reb','stl','blk','tov','oreb','dreb']
box=pd.read_csv(box_path,usecols=box_cols).query('minutes>0').sort_values(['person_id','date','game_id'])
check('26648 positive-minute source rows',len(box)==26648)
check('unique source player dates',not box.duplicated(['person_id','date']).any())
tr=pd.read_csv(tracking_path)
check('88977 original tracking rows',len(tr)==88977)
check('unique tracking date player tag keys',not tr.duplicated(['date','nba_pid','tag']).any())
v=tr.merge(box[['date','person_id','fgm','fga','fg3m','fg3a']],left_on=['date','nba_pid'],right_on=['date','person_id'],suffixes=('_t','_b'),how='left',validate='many_to_one')
components=['fgm','fga','fg3m','fg3a']
x=v[[c+'_t' for c in components]].to_numpy(float)
nonnegative_integer=np.isfinite(x).all(axis=1)&(x>=0).all(axis=1)&np.isclose(x,x.round()).all(axis=1)
internal=(v.fgm_t<=v.fga_t)&(v.fg3m_t<=v.fg3a_t)&(v.fg3m_t<=v.fgm_t)&(v.fg3a_t<=v.fga_t)&((v.fgm_t-v.fg3m_t)<=(v.fga_t-v.fg3a_t))
subset=np.logical_and.reduce([(v[c+'_t']<=v[c+'_b']).to_numpy() for c in components]+[((v.fgm_t-v.fg3m_t)<=(v.fgm_b-v.fg3m_b)).to_numpy(),((v.fga_t-v.fg3a_t)<=(v.fga_b-v.fg3a_b)).to_numpy()])
v['audited_valid']=v.fga_b.notna()&nonnegative_integer&internal&subset
saved_valid=pd.read_csv(O/'all_tracking_source_rows_validity.csv')
check('every tracking validity result independently matches',list(zip(v.date,v.nba_pid,v.tag))==list(zip(saved_valid.date,saved_valid.person_id,saved_valid.tag)) and np.array_equal(v.audited_valid,saved_valid.valid))
invalid=v[~v.audited_valid].groupby('tag').size().to_dict()
check('10 impossible rows excluded by exact tag',invalid=={'cs':4,'lt10':1,'pu':2,'wo':3})
facts['invalid_tracking_by_tag']=invalid
valid_track={key: group.set_index('date') for key,group in v[v.audited_valid].groupby(['nba_pid','tag'])}
source_by_player={int(pid):group.reset_index(drop=True) for pid,group in box.groupby('person_id')}
d=pd.read_csv(O/'Dallas_features_OUTCOME_FREE.csv')
check('382 Dallas appearances 232 players 50 games/dates',len(d)==382 and d.person_id.nunique()==232 and d.game_id.nunique()==50 and d.date.nunique()==50)
check('target feature ledger outcome-free',not any(c in d for c in ['hit_DK','hit_FD','dk_points','fd_points','personal_q85_DK','personal_q85_FD']))
rebuilt=[]
for r in d.itertuples():
    history=source_by_player[int(r.person_id)]
    history=history[history.date<r.date]
    h=history.tail(30)
    z={'date':r.date,'game_id':r.game_id,'person_id':r.person_id,'prior_n':len(history),'feature_last_date':history.date.iloc[-1],'window_first_date':h.date.iloc[0]}
    check('strict history eligibility '+str(r.game_id)+' '+str(r.person_id),len(history)>=30 and len(h)==30 and h.date.max()<r.date)
    z['prior10_minutes']=history.tail(10).minutes.mean()
    z['prior30_minutes_sd']=h.minutes.std(ddof=1)
    sm=h[['minutes','fga','fg3a','fta','ast','reb','stl','blk','tov','oreb','dreb']].sum(min_count=30)
    for c in ['fga','fta','ast','reb','stl','blk','tov','oreb','dreb']: z['prior30_'+c+'36']=finite_div(36*sm[c],sm['minutes'])
    two_m=(h.fgm-h.fg3m).sum(min_count=30)
    two_a=(h.fga-h.fg3a).sum(min_count=30)
    z.update(prior30_three_share=finite_div(sm.fg3a,sm.fga),prior30_fta_fga=finite_div(sm.fta,sm.fga),prior30_two_pts36=finite_div(72*two_m,sm.minutes),prior30_two_pct=finite_div(two_m,two_a),prior30_oreb_share=finite_div(sm.oreb,sm.reb))
    for tag in ['cs','pu','lt10','wo','vtight']:
        observed=valid_track.get((r.person_id,tag),pd.DataFrame())
        observed=observed.loc[observed.index.isin(h.date)] if len(observed) else observed
        n=len(observed); num=observed.fga_t.sum() if n else 0.; den=observed.fga_b.sum() if n else 0.
        z['prior30_tag_observed_'+tag]=n
        z['prior30_tag_attempts_'+tag]=num
        z['prior30_observed_box_attempts_'+tag]=den
        z['prior30_'+tag+'_observed_ratio']=finite_div(num,den) if n>=15 else np.nan
    rebuilt.append(z)
rd=pd.DataFrame(rebuilt)
max_feature_error={}
for c in features+[v for v in d if v.startswith('prior30_tag_') or v.startswith('prior30_observed_box_')]:
    check('independent strict-history rebuild '+c,eq(d[c],rd[c]))
    max_feature_error[c]=float(np.nanmax(np.abs(d[c]-rd[c])))
check('all saved history counts match',np.array_equal(d.prior_n,rd.prior_n))
check('all saved history dates match',(d.feature_last_date==rd.feature_last_date).all() and (d.window_first_date==rd.window_first_date).all())
facts['max_feature_absolute_error']=max_feature_error
inventory=pd.read_csv(O/'FEATURE_INVENTORY.csv').set_index('feature')
check('inventory covers exact features',set(inventory.index)==set(features))
check('inventory missingness matches actual',all(inventory.loc[c,'Dallas_available']==d[c].notna().sum() and inventory.loc[c,'Dallas_unknown']==d[c].isna().sum() for c in features))
facts['tracking_Dallas_coverage']={c:int(d[c].notna().sum()) for c in features if c.endswith('_observed_ratio')}
# Full feature ledger ensures history construction excludes contemporaneous source dates.
all_features=pd.read_csv(O/'all_positive_minute_prior_features.csv')
check('all feature ledger rows align positive-minute box source',len(all_features)==len(box))
check('all nonempty feature timestamps precede target',(all_features.loc[all_features.feature_last_date.notna(),'feature_last_date']<all_features.loc[all_features.feature_last_date.notna(),'date']).all())
notes.append('Feature values independently reconstructed directly from strictly earlier source rows for every Dallas appearance, including all five matched-observation tracking denominators. This verifies reconstruction chronology, not archival pregame availability of the source snapshots.')
# Search result checks are appended below once the run is available.
outputs_ready=False


if (O/'RUN_MANIFEST.json').exists():
    outputs_ready=True
    manifest=json.loads((O/'RUN_MANIFEST.json').read_text())
    check('run uses exactly frozen protocol',manifest['protocol_sha256']==sha(O/'FROZEN_COMBINATORIAL_PROTOCOL.json'))
    for path,hashvalue in manifest['script_hashes'].items(): check('run script hash '+Path(path).name,sha(path)==hashvalue)
    check('freeze and refinement precede outcome run',p['frozen_at_utc']<p['pre_outcome_freeze_refinement']['at_utc']<manifest['started_outcomes_at_utc'])
    frozen_src=(O/'freeze_protocol.py').read_text()
    check('generator has current eligibility text','No minimum hits/misses' in frozen_src and 'selection has additional hit/miss support' not in frozen_src)
    correction=json.loads((O/'GENERATOR_ONLY_CORRECTION.json').read_text()) if (O/'GENERATOR_ONLY_CORRECTION.json').exists() else {}
    facts['generator_only_correction']=correction
    a=pd.read_csv(ledger_path,usecols=['mode','sample','date','game_id','person_id','hit_DK','hit_FD','personal_q85_DK','personal_q85_FD','dk_points','fd_points'])
    target=a[(a['mode']=='prior_only_threshold')&(a['sample']=='Dallas')]
    D=d.merge(target,on=['date','game_id','person_id'],validate='one_to_one').sort_values(['date','person_id']).reset_index(drop=True)
    check('Dallas total hits DK91 FD94',D.hit_DK.sum()==91 and D.hit_FD.sum()==94)
    original_points=pd.read_csv(box_path,usecols=['person_id','date','minutes','dk_points','fd_points']).query('minutes>0')
    qerrors=[]
    for r in D.itertuples():
        history=original_points[(original_points.person_id==r.person_id)&(original_points.date<r.date)]
        for plat in ['DK','FD']:
            q=float(np.quantile(history[plat.lower()+'_points'],.85))
            qerrors.append(abs(getattr(r,'personal_q85_'+plat)-q))
            check('strict q85 hit '+plat+' '+str(r.game_id)+' '+str(r.person_id),getattr(r,'hit_'+plat)==(getattr(r,plat.lower()+'_points')>q))
    check('all personal q85 thresholds independently match',max(qerrors)<1e-10)
    dates=sorted(D.date.unique())
    D['audit_hash_group']=D.person_id.map(lambda pid:int(hashlib.sha256(str(int(pid)).encode()).hexdigest()[:8],16)%5)
    predictions=pd.read_csv(O/'ALL_future_predictions.csv')
    training=pd.read_csv(O/'ALL_25668_candidate_train_evaluations.csv').set_index(['fit_id','rule_id'])
    testcounts=pd.read_csv(O/'ALL_4278_candidate_future_descriptive_counts.csv').set_index(['fold','rule_id'])
    cutoffs=pd.read_csv(O/'ALL_training_cutoffs.csv').set_index(['fit_id','feature'])
    splits=pd.read_csv(O/'split_audit.csv').set_index('fit_id')
    selections=pd.read_csv(O/'ALL_selected_rules.csv').set_index(['fit_id','model'])
    pattern_counts=pd.read_csv(O/'candidate_counts_by_fit.csv').set_index(['fit_id','order'])
    maxstats=pd.read_csv(O/'approximate_max_statistic_diagnostic.csv').set_index(['fold','cluster_unit'])
    maxrules=pd.read_csv(O/'ALL_max_statistic_candidate_diagnostics.csv').set_index(['fold','cluster_unit','rule_id'])
    check('18 fits 25668 training and 4278 descriptive rows',len(splits)==18 and len(training)==25668 and len(testcounts)==4278 and len(cutoffs)==378 and len(selections)==54)
    check('5140 predictions and 257 distinct appearances',len(predictions)==5140 and len(predictions[['game_id','person_id']].drop_duplicates())==257)
    check('unique prediction keys',not predictions.duplicated(['evaluation','platform','model','game_id','person_id']).any())
    candidate_indices=[[features.index(f) for f in fs.split('|')] for fs in cand.features]
    candidate_directions=[dirs.split('|') for dirs in cand.directions]
    def masksets(frame,cut):
        values=frame[features].to_numpy(float)
        masks=[];unknown=[]
        for ids,dirs in zip(candidate_indices,candidate_directions):
            known=np.isfinite(values[:,ids]).all(axis=1)&np.isfinite(cut[ids]).all()
            match=np.ones(len(frame),dtype=bool)
            for fi,direction in zip(ids,dirs):match &= (values[:,fi]>=cut[fi]) if direction=='high' else (values[:,fi]<cut[fi])
            masks.append(known&match);unknown.append(~known)
        yes=np.asarray(masks).T;missing=np.asarray(unknown).T
        return yes,~yes&~missing,missing
    def auditcounts(frame,matrix):
        out={'N':matrix.sum(axis=0),'DK_hits':(matrix*frame.hit_DK.to_numpy()[:,None]).sum(axis=0),'FD_hits':(matrix*frame.hit_FD.to_numpy()[:,None]).sum(axis=0)}
        for col,key in [('game_id','games'),('person_id','players')]:
            out[key]=np.sum([matrix[frame[col].to_numpy()==value].any(axis=0) for value in frame[col].unique()],axis=0)
        return out
    rng=np.random.default_rng(20261012)
    expected_predictions=[]
    max_forecast_error=0.
    max_diagnostic_error=0.
    for ev in ['chronological','chronological_player_disjoint']:
        for fold,start in enumerate([20,30,40],1):
            for group in ([None] if ev=='chronological' else range(5)):
                trn=D[D.date.isin(dates[:start])].copy()
                tst=D[D.date.isin(dates[start:start+10])].copy()
                if group is not None:
                    trn=trn[trn.audit_hash_group!=group];tst=tst[tst.audit_hash_group==group]
                fit=f'{ev}_fold{fold}_group{group if group is not None else "all"}'
                split=splits.loc[fit]
                check('chronology '+fit,trn.date.max()<tst.date.min())
                check('disjointness '+fit,group is None or not set(trn.person_id).intersection(tst.person_id))
                expected_split={'train_N':len(trn),'train_players':trn.person_id.nunique(),'train_games':trn.game_id.nunique(),'train_DK_hits':trn.hit_DK.sum(),'test_N':len(tst),'test_players':tst.person_id.nunique(),'test_games':tst.game_id.nunique(),'test_DK_hits':tst.hit_DK.sum(),'train_first':trn.date.min(),'train_last':trn.date.max(),'test_first':tst.date.min(),'test_last':tst.date.max(),'player_overlap':len(set(trn.person_id)&set(tst.person_id))}
                check('saved split exact '+fit,all(split[k]==v for k,v in expected_split.items()))
                med=np.array([np.median(trn.loc[np.isfinite(trn[f]),f]) for f in features])
                check('train-only finite medians '+fit,eq(cutoffs.loc[fit].reindex(features).cutoff,med))
                ms=masksets(trn,med);ts=masksets(tst,med)
                cs=[auditcounts(trn,mask) for mask in ms];cts=[auditcounts(tst,mask) for mask in ts]
                table=training.loc[fit].reindex(cand.rule_id)
                for branch,cnts in zip(['rule','complement','unknown'],cs):
                    check('all candidate train counts '+fit+' '+branch,all(np.array_equal(table[branch+'_'+key],val) for key,val in cnts.items()))
                if ev=='chronological':
                    later=testcounts.loc[fold].reindex(cand.rule_id)
                    for branch,cnts in zip(['rule','complement','unknown'],cts):check('all candidate future descriptive counts fold'+str(fold)+' '+branch,all(np.array_equal(later[branch+'_'+key],val) for key,val in cnts.items()))
                supported=np.logical_and.reduce([cs[k][v]>=minimum for k in [0,1] for v,minimum in [('N',20),('games',5),('players',5)]])
                prevalence=trn.hit_DK.mean()
                shrunk=(cs[0]['DK_hits']+20*prevalence)/(cs[0]['N']+20)
                score=shrunk-prevalence
                check('outcome-independent eligibility '+fit,np.array_equal(table.eligible,supported))
                check('fixed shrinkage20 rankings '+fit,eq(table.shrunk_rule_DK_rate,shrunk) and eq(table.shrunk_uplift,score) and eq(table.train_prevalence,np.repeat(prevalence,len(cand))))
                expected_failures=[]
                for j in range(len(cand)):
                    expected_failures.append(';'.join(f'{b}_{col}<{minimum}' for b,cnt in zip(['rule','complement'],cs) for col,minimum in [('N',20),('games',5),('players',5)] if cnt[col][j]<minimum))
                check('all structural exclusion reasons '+fit,list(table.exclusion_reasons.fillna(''))==expected_failures)
                chosen={}
                for model,order in [('best_pair',2),('best_triple',3),('best_any',None)]:
                    allow=supported&(score>0)&(cand.order.eq(order).to_numpy() if order else True)
                    eligible_ids=np.flatnonzero(allow)
                    ranked=sorted(eligible_ids,key=lambda j:(-score[j],cand.rule_id.iloc[j]))
                    j=ranked[0] if ranked else None
                    chosen[model]=j
                    selected=selections.loc[(fit,model)]
                    expected_rule=cand.rule_id.iloc[j] if j is not None else 'NONE_PREVALENCE'
                    check('train-only selected argmax '+fit+' '+model,selected.rule_id==expected_rule)
                    check('selected positive candidate count '+fit+' '+model,selected.positive_candidates==len(eligible_ids))
                    if j is not None:
                        check('selected score and branch supports '+fit+' '+model,eq([selected.train_shrunk_uplift],[score[j]]) and all(selected['train_rule_'+k]==val[j] for k,val in cs[0].items()) and all(selected['train_complement_'+k]==val[j] for k,val in cs[1].items()))
                assigned=['|'.join(model for model,j in chosen.items() if j==i) for i in range(len(cand))]
                check('all selected-by flags '+fit,list(table.selected_by.fillna(''))==assigned)
                for order in [1,2,3,0]:
                    which=cand.order.eq(order).to_numpy() if order else np.ones(len(cand),bool)
                    active=which&supported
                    unique_patterns=len(set(tuple(ms[0][:,j].astype(int)+2*ms[1][:,j].astype(int)) for j in np.flatnonzero(active)))
                    row=pattern_counts.loc[(fit,order)]
                    check('unique supported patterns '+fit+' order'+str(order),row.declared==which.sum() and row.eligible==active.sum() and row.excluded==(which&~supported).sum() and row.eligible_unique_training_patterns==unique_patterns)
                if ev=='chronological':
                    eligible_ids=np.flatnonzero(supported)
                    included=ms[0][:,eligible_ids].astype(float)
                    y=trn.hit_DK.to_numpy(float);n=len(trn)
                    raw_rate=np.sum(included*y[:,None],axis=0)/included.sum(axis=0)
                    effect=raw_rate-y.mean()
                    # Influence contributions for difference of two estimated means,
                    # expressed directly on the final-estimator (not n-scaled) scale.
                    influence=included*(y[:,None]-raw_rate)/included.sum(axis=0)-(y-y.mean())[:,None]/n
                    for unit in ['game_id','person_id']:
                        groups=list(trn[unit].unique());G=len(groups)
                        clusters=np.array([influence[trn[unit].to_numpy()==g].sum(axis=0) for g in groups])
                        se=np.sqrt((clusters**2).sum(axis=0)*G/(G-1))
                        good=se>1e-12
                        signs=rng.choice([-1.,1.],size=(2000,G))
                        simulated=(signs@clusters[:,good])*np.sqrt(G/(G-1))/se[good]
                        maxima=simulated.max(axis=1)
                        t=effect[good]/se[good]
                        pvals=(1+(maxima[:,None]>=t[None,:]).sum(axis=0))/2001
                        saved=maxrules.loc[(fold,unit)].reindex(cand.rule_id.iloc[eligible_ids[good]])
                        check('all max-t candidate raw diagnostics fold'+str(fold)+' '+unit,eq(saved.raw_uplift,effect[good]) and eq(saved.cluster_SE,se[good]) and eq(saved.raw_t,t))
                        check('all approximate multiplicity p-values fold'+str(fold)+' '+unit,eq(saved.approx_max_t_adjusted_p,pvals))
                        s=maxstats.loc[(fold,unit)]
                        check('max-t summary fold'+str(fold)+' '+unit,s.N==n and s.clusters==G and s.eligible_candidates==supported.sum() and s.valid_SE_candidates==good.sum() and s.replicates==2000 and eq([s.max_observed_t,s.approx_max_t_p,s.null_max_t_q95],[t.max(),(1+(maxima>=t.max()).sum())/2001,np.quantile(maxima,.95)]))
                        max_diagnostic_error=max(max_diagnostic_error,float(np.abs(saved.raw_t.to_numpy()-t).max()))
                for plat in ['DK','FD']:
                    ys=trn['hit_'+plat].to_numpy(int);base=ys.mean()
                    opportunity=['prior10_minutes','prior30_minutes_sd','prior30_fga36']
                    scaler=StandardScaler().fit(trn[opportunity])
                    reg=LogisticRegression(C=.1,max_iter=2000,solver='lbfgs').fit(scaler.transform(trn[opportunity]),ys)
                    ridge=reg.predict_proba(scaler.transform(tst[opportunity]))[:,1]
                    for model in ['prevalence','opportunity_ridge_C0.1','best_pair','best_triple','best_any']:
                        j=chosen.get(model)
                        probs=np.repeat(base,len(tst));branch=np.repeat('not_rule_model',len(tst)).astype(object)
                        if model=='opportunity_ridge_C0.1':probs=ridge
                        elif model.startswith('best'):
                            if j is None:branch[:]='no_eligible_positive_rule'
                            else:
                                for branch_idx,branch_name in [(0,'rule'),(1,'complement')]:
                                    in_train=ms[branch_idx][:,j];in_test=ts[branch_idx][:,j]
                                    probs[in_test]=(ys[in_train].sum()+20*base)/(in_train.sum()+20)
                                    branch[in_test]=branch_name
                                branch[ts[2][:,j]]='unknown_fallback'
                        source=predictions[(predictions.fit_id==fit)&(predictions.platform==plat)&(predictions.model==model)].set_index(['game_id','person_id']).reindex(pd.MultiIndex.from_frame(tst[['game_id','person_id']]))
                        check('exact forecast test population '+fit+' '+plat+' '+model,len(source)==len(tst) and source.prediction.notna().all() and np.array_equal(source.hit,tst['hit_'+plat].astype(int)))
                        check('independent train-only forecasts '+fit+' '+plat+' '+model,eq(source.prediction,probs))
                        check('known-complement and unknown fallback labels '+fit+' '+plat+' '+model,list(source.branch)==list(branch))
                        check('same DK-selected rule FD sensitivity '+fit+' '+plat+' '+model,(source.selected_rule.fillna('')==(cand.rule_id.iloc[j] if j is not None else '')).all())
                        max_forecast_error=max(max_forecast_error,float(np.abs(source.prediction.to_numpy()-probs).max()))
    facts['max_independent_forecast_absolute_error']=max_forecast_error
    facts['max_independent_max_t_statistic_absolute_error']=max_diagnostic_error
    old=pd.read_csv(B/'all_chronological_predictions.csv')
    old=old[old.model.isin(['prevalence','opportunity_ridge_C0.1'])]
    new=predictions[predictions.model.isin(['prevalence','opportunity_ridge_C0.1'])]
    key=['platform','evaluation','fold','model','date','game_id','person_id']
    oldmatch=old.merge(new,on=key,validate='one_to_one',suffixes=('_old','_new'))
    check('exact original benchmark population and hits',len(oldmatch)==len(old)==len(new)==2056 and (oldmatch.hit_old==oldmatch.hit_new).all())
    check('original benchmark forecasts reproduced',eq(oldmatch.prediction_old,oldmatch.prediction_new))
    facts['original_benchmark_max_difference']=float(np.abs(oldmatch.prediction_old-oldmatch.prediction_new).max())
    scorecard=pd.read_csv(O/'prediction_scorecard.csv').set_index(['platform','evaluation','model','period'])
    calibration=pd.read_csv(O/'fixed_bin_calibration.csv').set_index(['platform','evaluation','model','probability_bin'])
    uncertainty=pd.read_csv(O/'paired_prediction_uncertainty.csv').set_index(['platform','evaluation','model','benchmark','cluster_unit','measure'])
    max_metric_error=0.;max_interval_error=0.
    for (plat,ev,model),g in predictions.groupby(['platform','evaluation','model']):
        check('same257 rows per scorecard '+plat+' '+ev+' '+model,len(g)==257)
        for period,z in [('all',g)]+[('fold'+str(int(fold)),z) for fold,z in g.groupby('fold')]:
            y=z.hit.to_numpy();pr=z.prediction.clip(1e-8,1-1e-8).to_numpy()
            vals={'N':len(z),'hits':int(y.sum()),'prevalence':y.mean(),'mean_prediction':pr.mean(),'calibration_bias':pr.mean()-y.mean(),'Brier':np.mean((y-pr)**2),'logloss':-np.mean(y*np.log(pr)+(1-y)*np.log(1-pr)),'AUROC':roc_auc_score(y,pr),'average_precision':average_precision_score(y,pr)}
            saved=scorecard.loc[(plat,ev,model,period)]
            check('all scorecard metrics '+plat+' '+ev+' '+model+' '+period,eq([saved[k] for k in vals],list(vals.values())))
            max_metric_error=max(max_metric_error,max(abs(saved[k]-val) for k,val in vals.items()))
        bins=pd.cut(g.prediction,[-.0001,.1,.2,.3,.4,1.0001],right=False)
        for label in bins.cat.categories:
            z=g[bins==label];saved=calibration.loc[(plat,ev,model,str(label))]
            check('fixed calibration bins '+plat+' '+ev+' '+model+' '+str(label),saved.N==len(z) and saved.hits==z.hit.sum() and eq([saved.mean_prediction,saved.observed_rate],[z.prediction.mean(),z.hit.mean()]))
        for baseline in ['prevalence','opportunity_ridge_C0.1']:
            if model==baseline:continue
            base=predictions[(predictions.platform==plat)&(predictions.evaluation==ev)&(predictions.model==baseline)]
            aligned=g.merge(base[['game_id','person_id','prediction']],on=['game_id','person_id'],suffixes=('','_baseline'),validate='one_to_one')
            y=aligned.hit.to_numpy();pr=aligned.prediction.to_numpy();pb=aligned.prediction_baseline.to_numpy()
            differences={'Brier':(y-pr)**2-(y-pb)**2,'logloss':-y*np.log(pr)-(1-y)*np.log1p(-pr)+y*np.log(pb)+(1-y)*np.log1p(-pb)}
            for unit in ['game_id','person_id']:
                ids=np.sort(aligned[unit].unique());G=len(ids)
                n=np.array([(aligned[unit]==v).sum() for v in ids])
                draws=rng.multinomial(G,np.repeat(1/G,G),size=1000)
                for measure,difference in differences.items():
                    total=np.array([difference[(aligned[unit]==v).to_numpy()].sum() for v in ids])
                    values=(draws@total)/(draws@n)
                    bounds=np.quantile(values,[.025,.975])
                    row=uncertainty.loc[(plat,ev,model,baseline,unit,measure)]
                    check('paired block bootstrap '+plat+' '+ev+' '+model+' '+baseline+' '+unit+' '+measure,row.clusters==G and row.replicates==1000 and eq([row.difference,row.lo,row.hi],[difference.mean(),*bounds]))
                    max_interval_error=max(max_interval_error,max(abs(row.lo-bounds[0]),abs(row.hi-bounds[1])))
    facts['max_scorecard_absolute_error']=max_metric_error
    facts['max_bootstrap_interval_absolute_error']=max_interval_error
    controls=a[(a['mode']=='prior_only_threshold')&(a['sample']!='Dallas')].groupby('person_id').agg(other_N=('game_id','size'),other_DK_rate=('hit_DK','mean'),other_FD_rate=('hit_FD','mean'),other_DK_hits=('hit_DK','sum'),other_FD_hits=('hit_FD','sum'))
    saved_controls=pd.read_csv(O/'DESCRIPTIVE_same_player_other_defense_rates.csv').set_index('person_id').reindex(controls.index)
    check('same-player other-defense descriptive control rates',eq(saved_controls[controls.columns],controls))
    described=pd.read_csv(O/'DESCRIPTIVE_selected_prediction_rows_with_controls.csv')
    check('all selector predictions retained in descriptive control join',len(described)==3084)
    for plat in ['DK','FD']:
        zz=described[described.platform==plat]
        expected_rate=zz.person_id.map(controls['other_'+plat+'_rate'])
        check('exact exposure-level control assignment '+plat,eq(zz.own_other_rate,expected_rate) and eq(zz.DESCRIPTIVE_lift,zz.hit-expected_rate))
    grouped=pd.read_csv(O/'DESCRIPTIVE_selected_branch_control_comparisons.csv').set_index(['platform','evaluation','model','fold','branch'])
    for keys,g in described.groupby(['platform','evaluation','model','fold','branch']):
        row=grouped.loc[keys]
        check('all descriptive branch arithmetic '+' '.join(map(str,keys)),row.N==len(g) and row.players==g.person_id.nunique() and row.hits==g.hit.sum() and eq([row.Dallas_rate,row.exposure_weighted_own_other_rate,row.descriptive_lift],[g.hit.mean(),g.own_other_rate.mean(),(g.hit-g.own_other_rate).mean()]))
    facts['DK_overall_scorecard']=pd.read_csv(O/'prediction_scorecard.csv').query("platform=='DK' and period=='all'").to_dict('records')
    facts['chronological_supported_counts']=pd.read_csv(O/'candidate_counts_by_fit.csv').query("evaluation=='chronological' and order==0").to_dict('records')
    facts['multiplicity_summaries']=pd.read_csv(O/'approximate_max_statistic_diagnostic.csv').to_dict('records')
    facts['total_checked_predictions']=len(predictions)
    facts['total_checked_training_candidate_evaluations']=len(training)
    notes.extend([
        'Independently reproduced all 25,668 candidate-training evaluations, structural exclusions, training medians, 54 selected rules and all 5,140 forecasts. FD uses the same DK-selected rule, re-estimating only FD branch hit rates. Unknown branches use training prevalence.',
        'Reproduced the exact 20/30/40-date expanding splits and every modulo-five player exclusion. Both benchmarks and all selectors are scored on the same 257 later appearances per platform/evaluation.',
        'Reproduced all reported score metrics, fixed probability-bin calibration, 2,000-replicate max-t diagnostics, and 1,000-replicate separate game/player block-bootstrap Brier/logloss intervals using the saved seed and draw order.',
        'Static review of run_search.py and independent numerical reconstruction confirm that rule cutoffs, support, ranking, selection and predictions use training rows only. Same-player other-defense controls are merged after predictions are written and serve only as descriptive references.',
        'The feature dictionary was fixed before outcome loading for this search, but earlier exploratory work had already examined these historical outcomes. These results are not a pristine holdout or causal Dallas evidence. The approximate max-t diagnostic is conditional on observed features, and bootstrap intervals condition on fitted predictions rather than refitting selection or jointly clustering games and players.',
        'The audit establishes implementation consistency for the declared 1,426-rule bounded space; it does not establish exhaustiveness over arbitrary traits, cutoffs, interactions, positions, missing playtypes, or unobserved data.'
    ])


def strict_json_value(value):
    """Convert non-finite numeric values to JSON null without changing results."""
    if isinstance(value, dict):
        return {key: strict_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [strict_json_value(item) for item in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def write_report():
    failures=[c for c in checks if not c['passed']]
    status=('PASS' if not failures else 'FAIL') if outputs_ready else ('FEATURES_PASS_OUTPUTS_PENDING' if not failures else 'FAIL')
    report=dict(audited_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=status,scope='Frozen Dallas combinatorial search; independent local reconstruction without acquisition, production changes, or push.',outputs_audited=outputs_ready,checks_run=len(checks),checks_passed=sum(c['passed'] for c in checks),failures=failures,facts=facts,notes=notes,checks=checks,source_hashes={str(x):sha(x) for x in [O/'prepare_features.py',O/'freeze_protocol.py',O/'FROZEN_COMBINATORIAL_PROTOCOL.json',O/'FROZEN_CANDIDATE_DICTIONARY.csv',O/'Dallas_features_OUTCOME_FREE.csv']})
    report=strict_json_value(report)
    (O/'independent_audit.json').write_text(json.dumps(report,indent=2,allow_nan=False))
    lines=['INDEPENDENT DALLAS COMBINATORIAL AUDIT',status,f"{report['checks_passed']}/{report['checks_run']} checks passed.",'']
    lines.extend(notes)
    lines+=['','Key facts:',json.dumps(report['facts'],indent=2,allow_nan=False)]
    if failures: lines+=['','Failed checks:',json.dumps(report['failures'],indent=2,allow_nan=False)]
    (O/'independent_audit.txt').write_text('\n'.join(lines)+'\n')
    print(status,report['checks_passed'],report['checks_run'],flush=True)
    return report

if __name__=='__main__': write_report()
