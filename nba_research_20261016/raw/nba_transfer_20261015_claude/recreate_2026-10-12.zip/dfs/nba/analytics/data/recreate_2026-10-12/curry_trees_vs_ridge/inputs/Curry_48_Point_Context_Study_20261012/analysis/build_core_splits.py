"""Full Curry descriptive core, advanced-team and player-role splits. No model fits."""
from pathlib import Path
import json,importlib.util,hashlib
import numpy as np,pandas as pd
R=Path(__file__).resolve().parents[1];P=R.parent;S=P/'inputs/three_season/nba_three_season_ceiling_20261011/results/player_game_mechanism_spine.csv'
spec=importlib.util.spec_from_file_location('core',P/'player_specific_pilot/analysis/build_core_panel.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
d=pd.read_csv(S,dtype={'person_id':str,'game_id':str},parse_dates=['date']);p,t=m.build_from_spine(d);z=p[p.person_id.eq('201939')].sort_values('date').copy();z.to_csv(R/'outputs/curry_full_core_context.csv',index=False)
# Box-derived actual team factors and strictly prior current-season 10-game means.
t['off_rating_box']=100*t.pts/t.poss_proxy;t['def_rating_box']=100*t.opp_pts/t.poss_proxy;t['net_rating_box']=t.off_rating_box-t.def_rating_box
t['efg']= (t.fgm+.5*t.fg3m)/t.fga;t['opp_efg']=(t.opp_fgm+.5*t.opp_fg3m)/t.opp_fga
t['tov_per100']=100*t.tov/t.poss_proxy;t['oreb_share']=t.oreb/(t.oreb+t.opp_dreb);t['fta_per_fga']=t.fta/t.fga;t['three_att_share']=t.fg3a/t.fga;t['three_accuracy']=t.fg3m/t.fg3a.replace(0,np.nan);t['assist_per_fgm']=t.ast/t.fgm.replace(0,np.nan)
factors=['pace','off_rating_box','def_rating_box','net_rating_box','efg','opp_efg','tov_per100','oreb_share','fta_per_fga','three_att_share','three_accuracy','assist_per_fgm']
for f in factors:t[f+'_prior10']=t.groupby(['season','team'])[f].transform(lambda s:s.shift().rolling(10,min_periods=10).mean())
extra=factors+[f+'_prior10' for f in factors]
for side,key in [('own','team'),('opponent','opponent')]:
 a=t[['game_id','team']+extra].rename(columns={'team':key,**{f:side+'_advanced_'+f for f in extra}});z=z.merge(a,on=['game_id',key],how='left',validate='one_to_one')
# Full source appearance inventory, both retrospective season and known prior definitions.
for s in ['dk','fd']:
 z[s+'_residual']=z[s]-z[s+'_lag20'];z[s+'_season_mean']=z.groupby('season')[s].transform('mean');z[s+'_season_q90']=z.groupby('season')[s].transform(lambda a:a.quantile(.9));z[s+'_above_season_mean']=(z[s]>z[s+'_season_mean']).astype(int);z[s+'_retrospective_season_top_decile']=(z[s]>z[s+'_season_q90']).astype(int)
# Actual teammates, with roles assigned from their own strictly prior20 history.
p['three_att_per36_actual']=p.fg3a/p.minutes*36
for field in ['minutes','ast','reb','fg3a']:
 p[field+'_prior20_sum']=p.groupby('person_id')[field].transform(lambda a:a.shift().rolling(20,min_periods=20).sum())
p['ast_prior20_per36']=p.ast_prior20_sum/p.minutes_prior20_sum*36;p['reb_prior20_per36']=p.reb_prior20_sum/p.minutes_prior20_sum*36;p['three_att_prior20_per36']=p.fg3a_prior20_sum/p.minutes_prior20_sum*36
te=p[p.team.eq('GSW')&~p.person_id.eq('201939')].copy();te=te[te.game_id.isin(z.game_id)];te['rotation_proxy_known']=te.minutes_prior20_sum.notna();te['rotation_proxy']=(te.minutes_prior20_sum/20>=15);te['creator_proxy']=te.rotation_proxy&(te.ast_prior20_per36>=4.5);te['spacing_proxy']=te.rotation_proxy&(te.three_att_prior20_per36>=5);te['interior_big_proxy']=te.rotation_proxy&(te.reb_prior20_per36>=8)&(te.three_att_prior20_per36<4)
roles=te.groupby('game_id').agg(observed_teammates=('person_id','size'),unknown_teammate_prior20_roles=('rotation_proxy_known',lambda a:int((~a).sum())),played_creator_proxy_count=('creator_proxy','sum'),played_spacing_proxy_count=('spacing_proxy','sum'),played_interior_big_proxy_count=('interior_big_proxy','sum')).reset_index()
for cc in ['played_creator_proxy_count','played_spacing_proxy_count','played_interior_big_proxy_count']:
 roles[cc+'_known_only_lower_bound']=roles[cc];roles.loc[roles.unknown_teammate_prior20_roles.gt(0),cc]=np.nan
z=z.merge(roles,on='game_id',validate='one_to_one');te.to_csv(R/'outputs/curry_actual_teammates_prior_role_proxies.csv.gz',index=False,compression='gzip');z.to_csv(R/'outputs/curry_core_advanced_role_context.csv',index=False)
# Every real available scalar in these families; all predeclared before evaluating split outcomes.
actual=['minutes','pts','reb','ast','stl','blk','tov','fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','usage_proxy','assist_team_share','rebound_team_share','fga_per_min','three_attempt_share','fta_per_fga','assist_per_min','rebound_per_min','stocks_per_min','turnover_per_min']
lagged=['minutes_lag5','minutes_lag10','minutes_lag20','minutes_sd20','minutes_trend','appearance_gap_capped30','usage_proxy_lag10','assist_team_share_lag10','rebound_team_share_lag10','orebound_team_share_lag10','drebound_team_share_lag10','fga_per_min_lag10','three_attempt_share_lag10','fta_per_fga_lag10','assist_per_min_lag10','rebound_per_min_lag10','stocks_per_min_lag10','turnover_per_min_lag10','expected_fga_proxy','expected_box_pace','team_win_fraction','opponent_win_fraction','opponent_allowed_pts_per100_lag10','opponent_allowed_ast_per100_lag10','opponent_allowed_reb_per100_lag10','opponent_allowed_stocks_per100_lag10','opponent_allowed_3pa_share_lag10','opponent_allowed_fta_per_fga_lag10']
rolecols=['played_creator_proxy_count','played_spacing_proxy_count','played_interior_big_proxy_count','unknown_teammate_prior20_roles']
fielddefs=[]
for f in actual+lagged+rolecols+[a+'_advanced_'+b for a in ['own','opponent'] for b in extra]:
 layer='actual_game_explanatory' if f in actual or ('_advanced_' in f and not f.endswith('_prior10')) else 'lagged_game_history' if f in lagged or f.endswith('_prior10') else 'actual_coappearance_with_prior_role_proxy'
 fielddefs.append({'field':f,'layer':layer,'source':str(S.relative_to(P)),'total_games':len(z),'known_games':int(z[f].notna().sum()),'unknown_games':int(z[f].isna().sum()),'first_known':str(z.loc[z[f].notna(),'date'].min().date()),'last_known':str(z.loc[z[f].notna(),'date'].max().date()),**{season+'_known':int(g[f].notna().sum()) for season,g in z.groupby('season')}})
# Coarse interpretable cutoffs; other fields use each season's context-feature median, never score-optimized.
fixed={'minutes':[30,35],'fga':[18,22],'fg3a':[10,14],'fta':[4,8],'usage_proxy':[28,32],'minutes_lag5':[30,34],'minutes_lag20':[30,34],'usage_proxy_lag10':[28,32],'appearance_gap_capped30':[1.5,2.5,7.5],'played_creator_proxy_count':[1.5],'played_spacing_proxy_count':[2.5],'played_interior_big_proxy_count':[.5,1.5],'unknown_teammate_prior20_roles':[.5]}
cutoffs=[];members=[]
for fd in fielddefs:
 f=fd['field'];b=pd.Series(index=z.index,dtype=object)
 if f in fixed:
  cuts=fixed[f];edges=[-np.inf]+cuts+[np.inf];labels=[f'[{edges[i]}, {edges[i+1]})' for i in range(len(edges)-1)];b=pd.cut(z[f],edges,right=False,labels=labels).astype(object);cutoffs.append({'field':f,'season':'all','rule':'fixed coarse bins','cutoffs':str(cuts)})
 else:
  for season,g in z.groupby('season'):
   v=g[f].median();b.loc[g.index]=np.where(g[f].isna(),'missing',np.where(g[f]<=v,'at_or_below_season_feature_median','above_season_feature_median'));cutoffs.append({'field':f,'season':season,'rule':'descriptive within-season feature median; not a forecast cutoff','cutoffs':float(v) if pd.notna(v) else None})
 b=b.fillna('missing');members.append(pd.DataFrame({'game_id':z.game_id,'field':f,'bin':b,'layer':fd['layer']}))
mem=pd.concat(members,ignore_index=True);mem.to_csv(R/'outputs/core_split_membership.csv.gz',index=False,compression='gzip');pd.DataFrame(cutoffs).to_csv(R/'outputs/core_split_cutoffs.csv',index=False);pd.DataFrame(fielddefs).to_csv(R/'outputs/core_field_inventory.csv',index=False)
rows=[]
for field,memb in mem.groupby('field'):
 zz=z.merge(memb[['game_id','bin','layer']],on='game_id',validate='one_to_one');layer=memb.layer.iloc[0]
 for scope,a in [('all',zz)]+list(zz.groupby('season')):
  for label,b in a.groupby('bin'):
   others=a[(a.bin!=label)&a.bin.ne('missing')];known=a[a.bin.ne('missing')]
   for site in ['dk','fd']:
    y=b[site];r=b[site+'_residual'];qm=b[site+'_q90_prior'].notna();hits=int((b.loc[qm,site]>b.loc[qm,site+'_q90_prior']).sum());row={'field':field,'layer':layer,'scope':scope,'bin':label,'site':site,'n':len(b),'fixed48_hits':int((y>=48).sum()),'fixed48_misses':int((y<48).sum()),'fixed48_rate':float((y>=48).mean()),'known_context_n':len(known),'context_missing_n':int(a.bin.eq('missing').sum()),'mean':y.mean(),'median':y.median(),'q90':y.quantile(.9),'q95':y.quantile(.95),'residual_n':int(r.notna().sum()),'residual_mean':r.mean(),'residual_median':r.median(),'residual_q90':r.quantile(.9),'above_prior20_hits':int((r>0).sum()),'above_prior20_misses':int((r<=0).sum()),'prior_q90_n':int(qm.sum()),'prior_q90_hits':hits,'prior_q90_misses':int(qm.sum())-hits,'other_n':len(others),'mean_minus_other':y.mean()-others[site].mean() if len(others) and label!='missing' else np.nan,'median_minus_other':y.median()-others[site].median() if len(others) and label!='missing' else np.nan,'q90_minus_other':y.quantile(.9)-others[site].quantile(.9) if len(others) and label!='missing' else np.nan,'residual_mean_minus_other':r.mean()-others[site+'_residual'].mean() if len(others) and label!='missing' else np.nan,'fixed48_rate_minus_other':float((y>=48).mean()-(others[site]>=48).mean()) if len(others) and label!='missing' else np.nan,'support_10_each_side':bool(len(b)>=10 and len(others)>=10 and label!='missing'),'interpretation':'Descriptive association; no multiplicative boosts, causal or out-of-sample validation claim'};rows.append(row)
out=pd.DataFrame(rows);out.to_csv(R/'outputs/core_advanced_role_splits.csv',index=False)
# Compact first returned facts, with full distributions in CSV.
print(out[(out.scope=='all')&(out.site=='dk')&out.field.isin(['minutes','fga','fg3a','usage_proxy','minutes_lag5','played_creator_proxy_count','played_spacing_proxy_count','played_interior_big_proxy_count'])][['field','layer','bin','n','mean','median','q90','residual_mean','prior_q90_hits','prior_q90_misses']].to_string(index=False))
(R/'audit/core_overlay_receipt.json').write_text(json.dumps({'rows':len(z),'games':z.game_id.nunique(),'counts_by_season':z.groupby('season').size().to_dict(),'field_count':len(fielddefs),'split_rows':len(out),'same_day_actuals_are_descriptive_only':True,'no_model_fitted':True,'no_outcome_based_cutoff_optimization':True,'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest()},indent=2))
