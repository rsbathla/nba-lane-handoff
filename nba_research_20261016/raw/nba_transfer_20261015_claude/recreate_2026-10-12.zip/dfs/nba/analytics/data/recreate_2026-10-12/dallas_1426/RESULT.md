# Dallas 1,426-rule search: recreation

## Claim

"Dallas: a 1,426-rule search over 21 prior features produced best-any DK Brier 0.201153 versus opportunity ridge 0.199416 on 257 later appearances. Lower is better. Player-disjoint performance was worse. The final separate audit passed 80/80 checks; the earlier numerical audit passed 71/71. Preserve each audit's scope. No dependable predictive edge was established."

Dallas here is an NBA study (opponents of the Dallas defense, DK and FD fantasy points thresholds), not NFL.

## What the bundle ships

- Code: prepare_features.py, freeze_protocol.py, run_search.py, build_search_report.py, independent_audit.py, independent_combinatorial_audit.py, build_interpretation.py.
- Inputs that let the search rerun: Dallas_complete_feature_outcome_ledger.csv (382 appearances, features plus outcomes), Dallas_features_OUTCOME_FREE.csv, FROZEN_CANDIDATE_DICTIONARY.csv, FROZEN_COMBINATORIAL_PROTOCOL.json.
- Results: prediction_scorecard.csv, paired_prediction_uncertainty.csv, ALL_future_predictions.csv, the 25,668-row training ledger, KEY_RESULTS.json, RUN_MANIFEST.json, run_log.txt, both audit outputs.
- Missing: every source the scripts read from /workspace/scratch (box_derived_fd_outcomes_REVIEWED.csv, corrected tracking CSV, ALL_eligible_appearances ledger with other-defense controls, all_chronological_predictions.csv). README also lists all_tracking_source_rows_validity.csv and all_positive_minute_prior_features.csv, which are not among the 46 members. So prepare_features.py and both audit scripts cannot rerun here.

## What I ran

Interpreter: /Users/rsbathla/Downloads/Fantasy/.venv/bin/python with -I (details in RUNTIME.json). scikit-learn 1.6.1 here against 1.8.0 in the original run.

1. Extracted all 46 members with zipfile into inputs/ and hashed them (inputs/INPUT_HASHES.json).
2. scripts/run_search_adapted.py: shipped run_search.py with only these edits (outputs/run_search_adaptation.diff): paths pointed at this folder; outcomes read from the shipped Dallas_complete_feature_outcome_ledger.csv instead of the missing source ledger; the benchmark cross-check compares against the shipped ALL_future_predictions.csv instead of the missing original predictions file; the same-player other-defense control section removed. Protocol, dictionary, seed 20261012, selection, scoring and bootstrap code are untouched. Wall time 4.7 s (original about 3.7 s).
3. Ran independent_combinatorial_audit.py and independent_audit.py as shipped from a scratch copy: both stop with FileNotFoundError (sources absent).
4. Compared every recreated CSV to the shipped one.

## Claimed vs recreated

| quantity | claimed (source file) | recreated here | match | note |
|---|---|---|---|---|
| Rule count | 1,426 (protocol, dictionary) | 1,426 declared, 1,426 unique predicates (42 + 840 + 544) | EXACT | dictionary byte-identical on read |
| Prior features | 21 | 21 | EXACT | |
| Training fits / train evaluations | 18 / 25,668 (RUN_MANIFEST) | 18 / 25,668 | EXACT | training ledger byte-identical |
| Later appearances N | 257 | 257 (70 DK hits) | EXACT | |
| best_any DK Brier (chronological) | 0.201153 (prediction_scorecard.csv) | 0.201153 | EXACT | max difference from shipped 1.1e-16 |
| Opportunity ridge DK Brier | 0.199416 | 0.199416 | EXACT | |
| Prevalence DK Brier | 0.203593 | 0.203593 | EXACT | |
| Paired difference best_any minus ridge, Brier | +0.001737 (paired_prediction_uncertainty.csv) | +0.001737, game-cluster interval -0.009690 to 0.012922 | EXACT | positive means best_any is worse; interval spans zero. Person-cluster interval -0.008080 to 0.011917 |
| Game clusters in paired interval | 30 | 30 | EXACT | 199 player clusters |
| best_any minus prevalence, Brier | -0.002440 | -0.002440, interval -0.009864 to 0.004339 | EXACT | spans zero |
| Player-disjoint DK Brier | best_any 0.208284, ridge 0.200319, prevalence 0.203276 | same three | EXACT | best_any worse than ridge by +0.007965 (interval -0.002116 to 0.018675) |
| Calibration bias, best_any DK | -0.082581 | -0.082581 (mean prediction 0.189792 vs 0.272374 observed) | EXACT | ridge -0.071923, prevalence -0.076008 |
| Later hit rate | 27.2% | 70/257 = 27.2374% | EXACT | |
| Approximate max-t p (game clusters, folds 1/2/3) | in approximate_max_statistic_diagnostic.csv | 0.489755 / 0.192904 / 0.030985 | EXACT | fold 3 alone is below 0.05; approximate and conditional, not familywise |
| Combinatorial audit | 80 PASS lines, 0 FAIL (independent_combinatorial_audit.txt) | NOT_RUN. Shipped text counted: 80 PASS, 0 FAIL | NOT_RUN | script needs /workspace sources; tally is from the shipped file, not a rerun |
| Numerical audit | 2810/2810 (independent_audit.txt, json checks_run 2810, checks_passed 2810) | NOT_RUN. Shipped json tally 2810 of 2810 | NOT_RUN | script needs the missing source CSVs |
| "Earlier numerical audit passed 71/71" | owner brief | No 71/71 appears in the bundle. The numerical audit is 2810/2810, the 80 is the combinatorial audit | DIFFERS | the brief's 71/71 is unsupported by any shipped file I found |
| Same-player other-defense controls | DESCRIPTIVE_* files | NOT_RUN | NOT_RUN | other-defense ledger not shipped |

Other agreements: all ten DK scorecard rows and the 54 selected rules match the shipped file (cutoff strings differ only in the last floating-point digit, up to 3.6e-15). Selected rules are unstable across folds (run_log shows R0505, R0915, R0915 for best_any chronologically).

## Verdict

PARTIALLY REPRODUCED. Every Dallas search number in the claim (counts, Briers, paired difference and interval, player-disjoint result, calibration bias, hit rate) reproduces exactly from the shipped ledger and frozen protocol, but the feature construction and both audits could not be rerun because their source data is not in the bundle, and the 71/71 figure does not exist in it.

## Limitations and what was not run

- The search was rerun on the shipped feature and outcome ledger. The feature-building step (prepare_features.py) was not rerun, so the 21 features are trusted as shipped, and the outcome labels come from the same ledger the original run produced. This tests the frozen search and scoring, not the upstream data.
- The benchmark equality check against the original study used the shipped ALL_future_predictions.csv, which is the original run's own output, so it is a consistency check, not independent.
- The 80-check and 2810-check audits were not rerun. Their scopes as shipped: the combinatorial audit (80 checks) verifies source hashes, the exact 1,426 predicate enumeration, tracking validity (10 invalid rows), feature reconstruction, search outputs and report claims; the numerical audit (2810 checks) independently rebuilds features for every Dallas appearance and reproduces 25,668 evaluations, 54 selections, 5,140 forecasts and the scorecards. Both verify implementation consistency only, not archival pregame availability, not a pristine holdout, and not exhaustiveness beyond the declared dictionary.
- Not run: prepare_features.py, freeze_protocol.py, build_search_report.py (PDF render, needs files not recreated), the DESCRIPTIVE control files, FD-specific comparison beyond the shared code path.
- Substantive reading: best_any is 0.0017 worse than the opportunity ridge on Brier, with an interval that spans zero, and worse again player-disjoint. The data are historical outcomes already examined, so no dependable predictive edge is shown.

## Files produced

SHA-256 of each output below (also in OUTPUT_HASHES.json; RUNTIME.json and this file are not self-hashed). Input hashes are in inputs/INPUT_HASHES.json. Shipped originals remain untouched in inputs/; my copies are in outputs/work/.

- outputs/audit_attempt/comb.out  3be93a71eacc985c2d7550c32b31451c12ba8457c999551682bfa97babad75c2
- outputs/audit_attempt/independent_audit.py  617b4af2eea996bce3b4c0f7a70e161a209408bc1dcf1cd422beb914cf3223cc
- outputs/audit_attempt/independent_combinatorial_audit.py  26b8a72ba2dc7ef2097a675a7c785d544e39088be90f60cf66c112d390e7e7c0
- outputs/audit_attempt/num.out  d39632bef79a0fa88ba4a299838ebb1d9b45e684d7f1f5032e2d140473fca376
- outputs/run_err.txt  206df3899b7154d1a261e06a571054d0fea9e79553fa4585aa0e439802589ed2
- outputs/run_log_recreated.txt  056ca33ff7111778ecfe9de732a0d97b50f90c664b033388faebac69bf612c38
- outputs/run_search_adaptation.diff  5c1f87480992c2bf3d6ab7a82e3cc00331ea66a0ffc9309ade6b9f4bccf9d588
- outputs/time.txt  31030da3a2b091748d00e92c7a452c710bececa712247048a393cfe30232eb1a
- outputs/work/ALL_25668_candidate_train_evaluations.csv  c14d9de77fe0c26aeb1f1c8c53c1c9397cff5e966f0622a69c350bcbd107010c
- outputs/work/ALL_4278_candidate_future_descriptive_counts.csv  f13c6fb6eb6ae666ec395a4ea91b47a5c77b0be0ca080022a42f7e4496a95666
- outputs/work/ALL_future_predictions.csv  742f47f18b8611f696f9e24a9f4edde41e67df826ca805fd5109925cd4fbe180
- outputs/work/ALL_max_statistic_candidate_diagnostics.csv  22d0be9a5cc206334f269953d02f7d8bf8ab087331d7d7770f0956be4fe96ff8
- outputs/work/ALL_selected_rules.csv  7b5f0f36c2ba9d7f99b982406eaefc28d7e2aa6dc2cf40de09e4370374631c54
- outputs/work/ALL_training_cutoffs.csv  b85c554868f5e57ea43a30473d3b85b9e96b3f94457739732258d7d51138cbcf
- outputs/work/Dallas_complete_feature_outcome_ledger.csv  4b12cdbfe8420a391595cc18c0e0b82b8db7e58d7f0f6277e22804a62dc0f1ea
- outputs/work/Dallas_features_OUTCOME_FREE.csv  6173fb7131bbe8a7751e6df2f6857be1443cdfb7cba9ba7d006b0843dc6a4009
- outputs/work/FROZEN_CANDIDATE_DICTIONARY.csv  ef3076ab8d633fe6e486f3753bc1e1f4d797ac7f2792898e87b7e3f48d003440
- outputs/work/FROZEN_COMBINATORIAL_PROTOCOL.json  facd3bd198c7a032e0f11f42d59f9201110ab472fd6fc7be2122583ad6354fca
- outputs/work/RUN_MANIFEST.json  56c75617f63b43c0d2ecd878b240ca049e1bd576f9146f6775ccadfc5b73ea60
- outputs/work/approximate_max_statistic_diagnostic.csv  6b1e62b7fab2bd511d80a9249dcb16c967b72e2a04e32eb48e70c8f5665d742a
- outputs/work/candidate_counts_by_fit.csv  67dc765a08953ee75fc6cc2bf9a8e425da644565a573852974821afabd99eac9
- outputs/work/end.txt  9300434c0e6dc9a8e64fa44fa48249e07e2c18e7cc74ec56d75bc1679b0785bf
- outputs/work/fixed_bin_calibration.csv  a6aca2c1dfbb0acac5c54bf95610d10cc33fe5c8822971fa88edbdf42c0fa6ab
- outputs/work/opportunity_ridge_coefficients.csv  9d3312500b762d7a0d5ca8820701a98ca2546e11d4fb2807c1fcde789dfc0291
- outputs/work/paired_prediction_uncertainty.csv  013ead092ce4ae0cb0ae8479bf2276586a94b40ef445bf4c4b31dae9b8ab23af
- outputs/work/prediction_scorecard.csv  eee8a52b69b0f66b625d40a14d5739a62fbd671e907edecfbe5bce2effb9bc72
- outputs/work/split_audit.csv  e77c88c42dde702ce2917677b00bbf0c982d8d845ef4de866c2825a91a47d310
- outputs/work/start.txt  0def90065a6abdd50c66f2b52c12e84a4b519ec744d8427bf76da507f06dc9f1
- scripts/run_search_adapted.py  9f56e7ee1ae0a6ed39f6d7f8c40e75faab1d1b94b0c06984d3c310f120e28e4a
