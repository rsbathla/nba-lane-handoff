"""Independent output reconciliation against exact saved source salary cells and audited outcomes."""
from pathlib import Path
import json, hashlib, math
import pandas as pd
import numpy as np
import openpyxl
P=Path(__file__).resolve().parent
B=Path('/workspace/scratch/0bd466b49713')
inv=pd.read_csv(P.parent/'outputs/curry_full_three_season_inventory.csv',dtype={'game_id':str,'person_id':str})
long=pd.read_csv(P/'curry_salary_evidence_long.csv',dtype={'game_id':str,'person_id':str})
cover=pd.read_csv(P/'curry_salary_game_site_coverage.csv',dtype={'game_id':str,'person_id':str})
assert len(inv)==187 and len(cover)==374
assert not long.evidence_id.duplicated().any()
check=long.merge(inv[['date','game_id','person_id','dk','fd']],on=['date','game_id','person_id'],validate='many_to_one')
assert len(check)==len(long)
assert np.allclose(check.dk_actual_score,check.dk) and np.allclose(check.fd_actual_score,check.fd)
assert np.allclose(check.actual_score,np.where(check.site=='dk',check.dk,check.fd))
assert np.allclose(check.points_per_1000_salary,check.actual_score/(check.salary/1000))
assert not long.pregame_capture_verified.any()
assert len(long.groupby(['date','site']).salary.nunique().loc[lambda s:s>1])==0
missing=cover[~cover.salary_available];assert missing.salary_min.isna().all() and missing.salary_max.isna().all() and missing.points_per_1000_min.isna().all()
expected={('2023-24','dk'):0,('2023-24','fd'):0,('2024-25','dk'):59,('2024-25','fd'):59,('2025-26','dk'):37,('2025-26','fd'):38}
for k,v in expected.items():assert int(cover[(cover.season==k[0]) & (cover.site==k[1])].salary_available.sum())==v
# Direct source workbook read with formulas retained: ensure observed salaries are literal numbers,
# check their exact cells, and independently reproduce historical date coverage.
p=B/'attachments/e9cd7073-a049-403e-b54b-3014ad59a527/NBA 2025 (1) (2) (2).xlsx'
w=openpyxl.load_workbook(p,read_only=True,data_only=False)
wbrows=long[long.source_family=='owner_held_dfs_workbook'];checked=0;literal=0;idsmissing=0;rawdates={'dk':set(),'fd':set()}
for sheet,g in wbrows.groupby('source_sheet'):
 wanted={int(k):v for k,v in g.groupby('source_row')}
 for i,row in enumerate(w[sheet].iter_rows(),1):
  if i not in wanted:continue
  assert str(row[3].value)=='201939'
  assert pd.to_datetime(row[2].value).strftime('%Y-%m-%d')==wanted[i].date.iloc[0]
  for r in wanted[i].itertuples():
   c=row[15 if r.site=='dk' else 16]
   assert c.data_type!='f' and float(c.value)==r.salary
   literal+=1;checked+=1;rawdates[r.site].add(r.date)
  if row[1].value is None:idsmissing+=1
assert checked==len(wbrows)==260
source_disagreements=long[long.source_score_discrepancy]
assert source_disagreements.date.nunique()==6
assert np.allclose(source_disagreements.source_dk_score,source_disagreements.fd_actual_score)
assert np.allclose(source_disagreements.source_fd_score,source_disagreements.dk_actual_score)
result={'passed':True,'long_evidence_rows_checked':len(long),'game_site_rows_checked':len(cover),'direct_workbook_literal_salary_cells_checked':literal,'matched_workbook_rows_with_missing_source_game_id':idsmissing,'workbook_distinct_dates_dk':len(rawdates['dk']),'workbook_distinct_dates_fd':len(rawdates['fd']),'duplicate_game_site_conflicting_salary_values':0,'score_disagreement_dates_confirmed_swapped_in_source':6,'verification_uses_audited_scores_not_source_score_columns':True}
(P/'independent_salary_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
