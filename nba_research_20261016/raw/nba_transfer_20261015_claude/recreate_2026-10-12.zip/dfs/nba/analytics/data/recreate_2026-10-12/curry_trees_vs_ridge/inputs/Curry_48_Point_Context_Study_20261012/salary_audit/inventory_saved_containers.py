"""Read-only schema/member inventory of saved NBA Parquet and ZIP inputs."""
import json,sys,zipfile
from pathlib import Path
BASE=Path('/workspace/scratch/0bd466b49713');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'nfl_parquet_deps'))
import pyarrow.parquet as pq
schemas=[];zips=[]
for p in BASE.rglob('*.parquet'):
 if p.relative_to(BASE).parts[0].startswith('nba'):
  names=pq.read_schema(p).names;schemas.append({'path':str(p.relative_to(BASE)),'columns':names,'salary_columns':[n for n in names if 'salary' in n.lower()]})
for p in BASE.rglob('*.zip'):
 if 'nba' in str(p.relative_to(BASE)).lower():
  with zipfile.ZipFile(p) as z:
   names=z.namelist();zips.append({'path':str(p.relative_to(BASE)),'member_count':len(names),'salary_or_xlsx_members':[n for n in names if n.endswith('.xlsx') or 'salary' in n.lower()]})
(OUT/'parquet_schema_inventory.json').write_text(json.dumps(schemas,indent=2));(OUT/'zip_member_inventory.json').write_text(json.dumps(zips,indent=2))
print('Parquet schemas:',len(schemas),'ZIP member listings:',len(zips))
