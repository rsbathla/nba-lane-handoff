"""Rerun nba/analytics/individual_ceiling_study.py unmodified, redirecting only its output directory.
The study hard-codes OUT = data/research_individual; this wrapper imports the study as a module,
points OUT (and the default of validate_artifacts) at a separate directory, and calls main()."""
import sys, time, json
from pathlib import Path
sys.dont_write_bytecode = True
ANALYTICS = '/Users/rsbathla/Downloads/dfs/nba/analytics'
sys.path.insert(0, ANALYTICS)
NEW = Path(sys.argv[1]).resolve()
assert 'recreate_2026-10-12' in str(NEW) and 'research_individual' != NEW.name
import individual_ceiling_study as m
m.OUT = NEW
m.validate_artifacts.__defaults__ = (NEW,)
sys.argv = ['individual_ceiling_study.py']
t0 = time.time(); m.main()
print(json.dumps({'elapsed_seconds': time.time() - t0}))
