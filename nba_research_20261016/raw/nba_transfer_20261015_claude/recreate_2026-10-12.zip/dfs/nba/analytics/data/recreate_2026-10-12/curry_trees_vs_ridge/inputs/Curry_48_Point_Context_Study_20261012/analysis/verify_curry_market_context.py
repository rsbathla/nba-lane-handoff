"""Independent ledger/count and underlying workbook checks; no recomputation from generator outputs alone."""
from pathlib import Path
import pandas as pd
import zipfile, xml.etree.ElementTree as E, json, hashlib
O=Path(__file__).resolve().parents[1];I=O.parent/'inputs/three_season'
d=pd.read_csv(O/'outputs/curry_fixed48_context_ledger.csv',dtype={'game_id':str,'person_id':str});checks={}
for season in ['2023-24','2024-25']:
    ix=pd.read_csv(I/f'nba_historical_box_recovery_20261011/derived/game_index_{season}_regular.csv',dtype={'game_id':str});ix.game_id=ix.game_id.str.zfill(10)
    j=d[d.season.eq(season)].merge(ix,on=['season','date','game_id'],validate='one_to_one')
    assert len(j)==sum(d.season.eq(season))
    assert ((j.home_away=='home')==(j.home_team=='GSW')).all()
    assert ((j.home_away=='away')==(j.away_team=='GSW')).all()
    checks[season+'_game_index_home_away_matches']=len(j)
p=O.parents[1]/'nba_fd_box_outcomes_20261010/source/04-12-2026-nba-season-team-feed.xlsx'
z=zipfile.ZipFile(p);ss=[''.join(x.itertext()) for x in E.fromstring(z.read('xl/sharedStrings.xml'))]
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};rows=[]
for row in E.fromstring(z.read('xl/worksheets/sheet1.xml')).findall('.//m:sheetData/m:row',ns):
    r={}
    for cell in row:
        v=cell.find('m:v',ns);v=v.text if v is not None else ''
        r[''.join(x for x in cell.get('r') if x.isalpha())]=ss[int(v)] if cell.get('t')=='s' else v
    rows.append(r)
headers={k:' '.join(v.split()) for k,v in rows[0].items()}
raw=pd.DataFrame([{**{headers.get(k,k):v for k,v in x.items()},'raw_excel_row':n+2} for n,x in enumerate(rows[1:])]);raw['game_id']=raw['GAME-ID'].str.zfill(10)
x=raw[raw.TEAM.eq('Golden State')].copy();c=d[d.season.eq('2025-26')].merge(x,on='game_id',validate='one_to_one');assert len(c)==43
for col,original in [('opening_total','OPENING TOTAL'),('closing_total','CLOSING TOTAL'),('opening_spread','OPENING SPREAD'),('closing_spread','CLOSING SPREAD')]:assert (c[col].astype(float)==c[original].astype(float)).all()
assert (c.venue_code==c['VENUE (R/H/N)']).all()
assert (c.source_excel_row.astype(int)==c.raw_excel_row.astype(int)).all()
checks['2025_26_original_workbook_market_venue_and_Excel_row_exact_matches']=43
s=pd.read_csv(O/'outputs/curry_fixed48_context_splits.csv');checks['split_rows']=len(s);checks['Curry_ledger_rows']=len(d)
for _,r in s.iterrows():
    g=d if r.season=='combined_three_seasons' else d[d.season.eq(r.season)]
    if r.context_dimension!='all':g=g[g[r.context_dimension].eq(r.context_bin)]
    assert int(r.appearances_n)==len(g)
    assert int(r.fixed48_hits)==g[r.site].ge(48).sum()
    assert int(r.fixed48_misses)==g[r.site].lt(48).sum()
checks['all_fixed48_split_counts_independently_reconciled']=True
checks['DK_exactly48_games']=d.loc[d.dk.eq(48),['date','game_id','dk']].to_dict('records')
checks['FD_exactly48_games']=d.loc[d.fd.eq(48),['date','game_id','fd']].to_dict('records')
checks['status']='passed'
(O/'audit/curry_market_context_independent_qa.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
