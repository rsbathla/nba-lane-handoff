"""Independent source-to-output audit. Does not import production builders or fit models."""
from pathlib import Path
import ast, hashlib, json, warnings
import numpy as np
import pandas as pd
warnings.filterwarnings('ignore', category=RuntimeWarning)
R=Path(__file__).resolve().parents[2]; P=R.parent; A=Path(__file__).resolve().parent
checks=[]; failures=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check(label,actual,expected):
    if isinstance(actual,(float,int,np.number,bool,np.bool_)) or pd.isna(actual):
        ok=(pd.isna(actual) and pd.isna(expected)) or (not pd.isna(actual) and not pd.isna(expected) and np.isclose(float(actual),float(expected),atol=1e-8,rtol=1e-10))
    else: ok=str(actual)==str(expected)
    checks.append((label,bool(ok)))
    if not ok: failures.append({'check':label,'actual':str(actual),'expected':str(expected)})
def read(p):
    d=pd.read_csv(p,dtype={'game_id':str,'person_id':str,'player_id':str})
    if 'game_id' in d:d.game_id=d.game_id.str.replace(r'\.0$','',regex=True).str.zfill(10)
    if 'date' in d:d.date=pd.to_datetime(d.date)
    return d
S=P/'inputs/three_season/nba_three_season_ceiling_20261011/results/player_game_mechanism_spine.csv'
x=read(S); z=read(R/'outputs/curry_fixed48_integrated_game_ledger.csv').sort_values('date').reset_index(drop=True)
x=x.sort_values(['person_id','date']); c=x[x.person_id.eq('201939')].sort_values('date').reset_index(drop=True)
check('Curry rows',len(z),187); check('unique appearances',z.game_id.nunique(),187);check('source complete game keys',set(z.game_id)==set(c.game_id),True)
counts=['minutes','pts','reb','ast','stl','blk','tov','fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb']
def scores(q):
    bonus=(q[['pts','reb','ast','stl','blk']]>=10).sum(axis=1)
    return {'dk':q.pts+.5*q.fg3m+1.25*q.reb+1.5*q.ast+2*q.stl+2*q.blk-.5*q.tov+1.5*bonus.ge(2)+3*bonus.ge(3),'fd':q.pts+1.2*q.reb+1.5*q.ast+3*q.stl+3*q.blk-q.tov}
for site,v in scores(x).items():x[site]=v
for site,v in scores(c).items():c[site]=v
for i in range(187):
    for f in ['season','date','game_id','person_id','player','team','opponent']+counts+['dk','fd']:check(f'source_identity:{i}:{f}',z.loc[i,f],c.loc[i,f])
for s,h in [('dk',67),('fd',46)]:
    check(s+' inclusive hits',int(z[s].ge(48).sum()),h)
    for i in range(187):check(f'inclusive_label:{i}:{s}',z.loc[i,s+'_ge48'],z.loc[i,s]>=48)
# Verify Curry identity/components against original unfiltered raw sources, separately from spine.
a=read(P/'inputs/three_season/nba_historical_box_recovery_20261011/derived/player_game_components_2023-24_2024-25_regular.csv').rename(columns={'player_id':'person_id','player_name':'player'})
b=read(P/'inputs/three_season/nba_fd_box_outcomes_20261010/box_derived_fd_outcomes_REVIEWED.csv').rename(columns={'game_team':'team','game_opponent':'opponent'});b['season']='2025-26'
bridge=pd.read_csv(S.parent/'team_identity_bridge.csv');cities=dict(zip(bridge.reviewed_box_team,bridge.nba_abbreviation));b.team=b.team.map(cities);b.opponent=b.opponent.map(cities)
raw=pd.concat([a,b],ignore_index=True);raw=raw[raw.person_id.eq('201939')&raw.minutes.gt(0)].sort_values('date').reset_index(drop=True)
check('original raw Curry positive-minute rows',len(raw),187)
for i in range(187):
    for f in ['season','date','game_id','person_id','team','opponent']+counts:check(f'original_raw:{i}:{f}',z.loc[i,f],raw.loc[i,f])
# Independent team aggregate, opponent lookup, and advanced values.
t=x.groupby(['season','date','game_id','team','opponent'],as_index=False)[counts].sum(); tm=t.set_index(['game_id','team'])
for stat in counts:t['opp_'+stat]=[tm.loc[(q.game_id,q.opponent),stat] for q in t.itertuples()]
t['poss_proxy']=(t.fga+.44*t.fta-t.oreb+t.tov+t.opp_fga+.44*t.opp_fta-t.opp_oreb+t.opp_tov)/2
formulas={'pace':t.poss_proxy*240/t.minutes,'off_rating_box':100*t.pts/t.poss_proxy,'def_rating_box':100*t.opp_pts/t.poss_proxy,'net_rating_box':100*(t.pts-t.opp_pts)/t.poss_proxy,'efg':(t.fgm+.5*t.fg3m)/t.fga,'opp_efg':(t.opp_fgm+.5*t.opp_fg3m)/t.opp_fga,'tov_per100':100*t.tov/t.poss_proxy,'oreb_share':t.oreb/(t.oreb+t.opp_dreb),'fta_per_fga':t.fta/t.fga,'three_att_share':t.fg3a/t.fga,'three_accuracy':t.fg3m/t.fg3a.replace(0,np.nan),'assist_per_fgm':t.ast/t.fgm.replace(0,np.nan)}
for f,v in formulas.items():t[f]=v
for f in ['pts','ast','reb']:t['allowed_'+f+'_per100']=100*t['opp_'+f]/t.poss_proxy
t['allowed_stocks_per100']=100*(t.opp_stl+t.opp_blk)/t.poss_proxy;t['allowed_3pa_share']=t.opp_fg3a/t.opp_fga;t['allowed_fta_per_fga']=t.opp_fta/t.opp_fga;t['won']=t.pts>t.opp_pts
t=t.sort_values('date');tm=t.set_index(['game_id','team']);th={k:g for k,g in t.groupby(['season','team'])}
# Current raw player mixtures are independently built for source history.
x=x.merge(t[['game_id','team','minutes','fga','fta','tov','ast','reb','oreb','dreb']].rename(columns={f:'team_'+f for f in counts if f in t}),on=['game_id','team'],how='left',validate='many_to_one')
x['usage_proxy']=100*(x.fga+.44*x.fta+x.tov)*x.team_minutes/(5*x.minutes*(x.team_fga+.44*x.team_fta+x.team_tov))
for name,stat in [('assist','ast'),('rebound','reb'),('orebound','oreb'),('drebound','dreb')]:x[name+'_team_share']=x[stat]/x['team_'+stat].replace(0,np.nan)
x['fga_per_min']=x.fga/x.minutes;x['three_attempt_share']=x.fg3a/x.fga.replace(0,np.nan);x['fta_per_fga']=x.fta/x.fga.replace(0,np.nan)
for name,stat in [('assist','ast'),('rebound','reb'),('turnover','tov')]:x[name+'_per_min']=x[stat]/x.minutes
x['stocks_per_min']=(x.stl+x.blk)/x.minutes
mix=['usage_proxy','assist_team_share','rebound_team_share','orebound_team_share','drebound_team_share','fga_per_min','three_attempt_share','fta_per_fga','assist_per_min','rebound_per_min','stocks_per_min','turnover_per_min'];ph={pid:g.sort_values('date') for pid,g in x.groupby('person_id')}
for i,row in z.iterrows():
    hist=ph['201939'];hist=hist[hist.date<row.date];current=ph['201939'].set_index('game_id').loc[row.game_id]
    check(f'prior_n:{i}',row.prior_n,len(hist))
    for f in mix:check(f'actual_mix:{i}:{f}',row[f],current[f]);v=hist[f].tail(10);check(f'prior_mix:{i}:{f}',row[f+'_lag10'],v.mean() if v.notna().sum()>=5 else np.nan)
    for f in ['minutes','dk','fd']:
        for w in [5,10,20]:check(f'player_history:{i}:{f}:{w}',row[f+'_lag'+str(w)],hist[f].tail(w).mean() if len(hist)>=w else np.nan)
        check(f'player_sd:{i}:{f}',row[f+'_sd20'],hist[f].tail(20).std() if len(hist)>=20 else np.nan)
    check(f'appearance_gap:{i}',row.appearance_gap_capped30,min((row.date-hist.date.max()).days,30) if len(hist) else np.nan)
    check(f'prior_date:{i}',row.prior_date,str(hist.date.max().date()) if len(hist) else np.nan)
    for s in ['dk','fd']:
        for q in [85,90,95]:check(f'prior_quantile:{i}:{s}:{q}',row[f'{s}_q{q}_prior'],hist[s].quantile(q/100) if len(hist)>=50 else np.nan)
        check(f'residual:{i}:{s}',row[s+'_residual'],row[s]-hist[s].tail(20).mean() if len(hist)>=20 else np.nan)
        season=c[c.season.eq(row.season)][s]
        check(f'season_mean:{i}:{s}',row[s+'_season_mean'],season.mean());check(f'season_q90:{i}:{s}',row[s+'_season_q90'],season.quantile(.9))
    for side,team in [('own',row.team),('opponent',row.opponent)]:
        actual=tm.loc[(row.game_id,team)];past=th[(row.season,team)];past=past[past.date<row.date].tail(10)
        for f in formulas:
            check(f'advanced_actual:{i}:{side}:{f}',row[f'{side}_advanced_{f}'],actual[f]);check(f'advanced_prior10:{i}:{side}:{f}',row[f'{side}_advanced_{f}_prior10'],past[f].mean() if len(past)==10 and past[f].notna().all() else np.nan)
        fullpast=th[(row.season,team)];fullpast=fullpast[fullpast.date<row.date]
        check(f'win_fraction:{i}:{side}',row['team_win_fraction' if side=='own' else 'opponent_win_fraction'],fullpast.won.mean())
        if side=='opponent':
            for f in ['allowed_pts_per100','allowed_ast_per100','allowed_reb_per100','allowed_stocks_per100','allowed_3pa_share','allowed_fta_per_fga']:check(f'opponent_lag:{i}:{f}',row[f'opponent_{f}_lag10'],past[f].mean() if len(past)==10 else np.nan)
    check(f'expected_fga:{i}',row.expected_fga_proxy,row.minutes_lag5*row.fga_per_min_lag10);check(f'expected_pace:{i}',row.expected_box_pace,(row.own_advanced_pace_prior10+row.opponent_advanced_pace_prior10)/2);check(f'minutes_trend:{i}',row.minutes_trend,row.minutes_lag5-row.minutes_lag20)
# All 1,956 actual teammates: roles based on their prior appearances, never current-game production.
te=read(R/'outputs/curry_actual_teammates_prior_role_proxies.csv.gz'); role_records=[]
for r in te.itertuples():
    hist=ph[r.person_id];hist=hist[hist.date<r.date].tail(20);known=len(hist)==20
    for f in ['minutes','ast','reb','fg3a']:check(f'teammate_prior20:{r.game_id}:{r.person_id}:{f}',getattr(r,f+'_prior20_sum'),hist[f].sum() if known else np.nan)
    mins=hist.minutes.sum() if known else np.nan; ast36=hist.ast.sum()*36/mins;reb36=hist.reb.sum()*36/mins;three36=hist.fg3a.sum()*36/mins
    rot=known and mins/20>=15; roles=[rot and ast36>=4.5,rot and three36>=5,rot and reb36>=8 and three36<4]
    check(f'teammate_known:{r.game_id}:{r.person_id}',r.rotation_proxy_known,known)
    for f,v in zip(['creator_proxy','spacing_proxy','interior_big_proxy'],roles):check(f'teammate_role:{r.game_id}:{r.person_id}:{f}',getattr(r,f),v)
    role_records.append((r.game_id,known,*roles))
rdf=pd.DataFrame(role_records,columns=['game_id','known','creator','spacing','interior_big'])
for i,r in z.iterrows():
    g=rdf[rdf.game_id.eq(r.game_id)];unknown=(~g.known).sum();check(f'role_unknown:{i}',r.unknown_teammate_prior20_roles,unknown);check(f'role_teammates:{i}',r.observed_teammates,len(g))
    for f in ['creator','spacing','interior_big']:
        check(f'role_lowerbound:{i}:{f}',r[f'played_{f}_proxy_count_known_only_lower_bound'],g[f].sum());check(f'role_masked:{i}:{f}',r[f'played_{f}_proxy_count'],g[f].sum() if unknown==0 else np.nan)
check('complete role games',z.played_creator_proxy_count.notna().sum(),81)
source_teammates=x[x.game_id.isin(z.game_id)&x.team.eq('GSW')&~x.person_id.eq('201939')]
check('teammate complete source keys',set(map(tuple,te[['game_id','person_id']].values))==set(map(tuple,source_teammates[['game_id','person_id']].values)),True)
check('teammate unique source keys',not te.duplicated(['game_id','person_id']).any(),True)
# Preserve exact core output in integrated ledger, and independently certify coappearance/schedule labels.
core=read(R/'outputs/curry_core_advanced_role_context.csv').set_index('game_id'); market=read(R/'outputs/curry_fixed48_context_ledger.csv').set_index('game_id')
for i,r in z.iterrows():
    for f in core.columns:check(f'integrated_preserve:{i}:{f}',r[f],core.loc[r.game_id,f])
    for pid,label in [('203110','green'),('202710','butler')]:check(f'coappearance:{i}:{label}',r['observed_'+label+'_played'],((x.game_id==r.game_id)&(x.person_id==pid)&(x.team=='GSW')&(x.minutes>0)).any())
    rest=market.loc[r.game_id,'team_days_since_previous_game'];check(f'verified_b2b:{i}',r.team_b2b_verified,rest==1 if pd.notna(rest) else np.nan)
# Independent bins for all 105 fields / 19,635 field-game memberships and all summaries.
fi=pd.read_csv(R/'outputs/core_field_inventory.csv'); cut=pd.read_csv(R/'outputs/core_split_cutoffs.csv');mem=read(R/'outputs/core_split_membership.csv.gz');spl=pd.read_csv(R/'outputs/core_advanced_role_splits.csv'); hv=pd.read_csv(R/'outputs/curry_fixed48_core_high_vs_low.csv'); bins={}
fixed={'minutes':[30,35],'fga':[18,22],'fg3a':[10,14],'fta':[4,8],'usage_proxy':[28,32],'minutes_lag5':[30,34],'minutes_lag20':[30,34],'usage_proxy_lag10':[28,32],'appearance_gap_capped30':[1.5,2.5,7.5],'played_creator_proxy_count':[1.5],'played_spacing_proxy_count':[2.5],'played_interior_big_proxy_count':[.5,1.5],'unknown_teammate_prior20_roles':[.5]}
for r in fi.itertuples():
    f=r.field;v=z[f];check(f'inventory_known:{f}',r.known_games,v.notna().sum());check(f'inventory_unknown:{f}',r.unknown_games,v.isna().sum());check(f'inventory_first:{f}',r.first_known,str(z.loc[v.notna(),'date'].min().date()));check(f'inventory_last:{f}',r.last_known,str(z.loc[v.notna(),'date'].max().date()))
    expected_layer='actual_coappearance_with_prior_role_proxy' if f.startswith('played_') or f=='unknown_teammate_prior20_roles' else 'lagged_game_history' if ('lag' in f or f.endswith('_prior10') or f in ['minutes_sd20','minutes_trend','appearance_gap_capped30','expected_fga_proxy','expected_box_pace','team_win_fraction','opponent_win_fraction']) else 'actual_game_explanatory'
    check(f'temporal_layer:{f}',r.layer,expected_layer)
    out=[]
    for i,row in z.iterrows():
        val=row[f]
        if pd.isna(val):lab='missing'
        elif f in fixed:
            edges=[-np.inf]+fixed[f]+[np.inf];j=int(np.searchsorted(fixed[f],val,side='right'));lab=f'[{edges[j]}, {edges[j+1]})'
        else:lab='at_or_below_season_feature_median' if val<=z.loc[z.season.eq(row.season),f].median() else 'above_season_feature_median'
        out.append(lab)
    bins[f]=np.array(out)
    g=mem[mem.field.eq(f)].set_index('game_id')
    for i,row in z.iterrows():check(f'bin_membership:{f}:{row.game_id}',g.loc[row.game_id,'bin'],out[i]);check(f'membership_layer:{f}:{row.game_id}',g.loc[row.game_id,'layer'],expected_layer)
    for season,gg in z.groupby('season'):
        check(f'field_season_coverage:{f}:{season}',getattr(r,'_0',0) if False else fi.loc[fi.field.eq(f),season+'_known'].iloc[0],gg[f].notna().sum())
    for ss in cut[cut.field.eq(f)].itertuples():check(f'cutoff:{f}:{ss.season}',ss.cutoffs if f in fixed else float(ss.cutoffs),str(fixed[f]) if f in fixed else float(z.loc[z.season.eq(ss.season),f].median()))
expected_split_keys=set()
for f,labels in bins.items():
    for scope in ['all']+sorted(z.season.unique().tolist()):
        valid=np.ones(len(z),bool) if scope=='all' else z.season.eq(scope)
        for label in set(labels[valid]):
            for site in ['dk','fd']:expected_split_keys.add((f,scope,label,site))
check('core split key completeness',set(map(tuple,spl[['field','scope','bin','site']].values))==expected_split_keys,True)
check('core split keys unique',not spl.duplicated(['field','scope','bin','site']).any(),True)
check('high vs low key completeness',set(map(tuple,hv[['field','outcome']].values))=={(f,s+'_ge48_inclusive') for f in bins for s in ['dk','fd']},True)
for row in spl.itertuples():
    m=bins[row.field];scope=np.ones(len(z),dtype=bool) if row.scope=='all' else z.season.eq(row.scope).to_numpy();selected=scope&(m==row.bin);other=scope&(m!=row.bin)&(m!='missing');g=z.loc[selected];b=z.loc[other];s=row.site;y=g[s];r=g[s+'_residual'];qm=g[s+'_q90_prior'].notna();hits=(g.loc[qm,s]>g.loc[qm,s+'_q90_prior']).sum();vals={'n':len(g),'fixed48_hits':y.ge(48).sum(),'fixed48_misses':y.lt(48).sum(),'fixed48_rate':y.ge(48).mean(),'known_context_n':(scope&(m!='missing')).sum(),'context_missing_n':(scope&(m=='missing')).sum(),'mean':y.mean(),'median':y.median(),'q90':y.quantile(.9),'q95':y.quantile(.95),'residual_n':r.notna().sum(),'residual_mean':r.mean(),'residual_median':r.median(),'residual_q90':r.quantile(.9),'above_prior20_hits':r.gt(0).sum(),'above_prior20_misses':r.le(0).sum(),'prior_q90_n':qm.sum(),'prior_q90_hits':hits,'prior_q90_misses':qm.sum()-hits,'other_n':len(b),'support_10_each_side':len(g)>=10 and len(b)>=10 and row.bin!='missing'}
    for name,fun,col in [('mean',lambda t:t.mean(),s),('median',lambda t:t.median(),s),('q90',lambda t:t.quantile(.9),s),('residual_mean',lambda t:t.mean(),s+'_residual'),('fixed48_rate',lambda t:t.ge(48).mean(),s)]:vals[name+'_minus_other']=fun(g[col])-fun(b[col]) if len(b) and row.bin!='missing' else np.nan
    for f,v in vals.items():check(f'core_split:{row.field}:{row.scope}:{row.bin}:{s}:{f}',getattr(row,f),v)
for row in hv.itertuples():
    s=row.outcome[:2];h=z[s]>=48;a=z.loc[h,row.field];b=z.loc[~h,row.field]
    vals={'high_games':h.sum(),'low_games':(~h).sum(),'high_known':a.notna().sum(),'high_missing':a.isna().sum(),'low_known':b.notna().sum(),'low_missing':b.isna().sum(),'feature_mean_high':a.mean(),'feature_mean_low':b.mean(),'feature_median_high':a.median(),'feature_median_low':b.median(),'mean_high_minus_low':a.mean()-b.mean()}
    for f,v in vals.items():check(f'feature_highlow:{row.field}:{s}:{f}',getattr(row,f),v)
# Direct four-cell cross classifications are reconstructed using values, not production memberships.
joint=pd.read_csv(R/'outputs/curry_fixed48_joint_context_cells.csv');jm=read(R/'outputs/curry_fixed48_joint_context_membership.csv');jdef={
'home_away_x_team_B2B':(z.home_away.eq('away'),z.team_b2b_verified.eq(1),z.home_away.notna()&z.team_b2b_verified.notna()),
'prior_minutes_x_prior_usage':(z.minutes_lag5.ge(34),z.usage_proxy_lag10.ge(32),z.minutes_lag5.notna()&z.usage_proxy_lag10.notna()),
'actual_minutes_x_actual_3PA':(z.minutes.ge(35),z.fg3a.ge(14),z.minutes.notna()&z.fg3a.notna()),
'Butler_played_x_close_spread':(z.observed_butler_played,z.closing_spread.abs().lt(5),z.closing_spread.notna()),
'Butler_played_x_team_B2B':(z.observed_butler_played,z.team_b2b_verified.eq(1),z.team_b2b_verified.notna()),
'creator_x_spacing_roles':(z.played_creator_proxy_count.ge(2),z.played_spacing_proxy_count.ge(3),z.played_creator_proxy_count.notna()&z.played_spacing_proxy_count.notna())}
for row in joint.itertuples():
    aa,bb,known=jdef[row.comparison];scope=np.ones(len(z),bool) if row.scope=='all' else z.season.eq(row.scope);known=known&scope;g=z[known&aa.eq(row.condition_a_value)&bb.eq(row.condition_b_value)];s=row.site;n=len(g);k=g[s].ge(48).sum();p=k/n if n else np.nan;zz=1.959963984540054;den=1+zz*zz/n if n else np.nan;center=(p+zz*zz/(2*n))/den if n else np.nan;half=zz*np.sqrt((p*(1-p)+zz*zz/(4*n))/n)/den if n else np.nan
    vals={'n':n,'known_context_n':known.sum(),'missing_context_n':(scope&~known).sum(),'hits48':k,'misses48':n-k,'hit_rate':p,'hit_rate_wilson95_low':center-half,'hit_rate_wilson95_high':center+half,'mean':g[s].mean(),'median':g[s].median(),'q90':g[s].quantile(.9),'q95':g[s].quantile(.95),'residual_n':g[s+'_residual'].notna().sum(),'residual_mean':g[s+'_residual'].mean(),'atleast10_games':n>=10,'dates':';'.join(g.date.dt.strftime('%Y-%m-%d')) if n else np.nan}
    for f,v in vals.items():check(f'joint:{row.comparison}:{row.condition_a_value}:{row.condition_b_value}:{s}:{f}',getattr(row,f),v)
check('joint complete four-cell keys',set(map(tuple,joint[['comparison','condition_a_value','condition_b_value','site']].values))=={(name,a,b,s) for name in jdef for a in [False,True] for b in [False,True] for s in ['dk','fd']},True)
check('joint keys unique',not joint.duplicated(['comparison','condition_a_value','condition_b_value','site']).any(),True)
for r in jm.itertuples():
    i=z.index[z.game_id.eq(r.game_id)][0];aa,bb,known=jdef[r.comparison]
    check(f'joint_membership:{r.comparison}:{r.game_id}:a',r.condition_a,float(aa.iloc[i]) if known.iloc[i] else np.nan);check(f'joint_membership:{r.comparison}:{r.game_id}:b',r.condition_b,float(bb.iloc[i]) if known.iloc[i] else np.nan)
# Audit all bootstrap row counts and point estimates; independently reproduce selected full endpoint vectors.
u=pd.read_csv(R/'outputs/curry_fixed48_split_uncertainty.csv'); boot_saved=[]; selected_fields={'minutes','minutes_lag5','usage_proxy_lag10','own_advanced_pace_prior10','opponent_advanced_def_rating_box_prior10','played_creator_proxy_count','home_away','team_rest_bin','observed_green_played','observed_butler_played','closing_abs_spread_bin'}
expected_u=set()
for f,labels in bins.items():
    if f.startswith(('pts','fgm','fg3m','ftm')):continue
    known=labels!='missing'
    for label in set(labels[known]):
        n=(labels==label).sum();other=known.sum()-n
        if n>=10 and other>=10:
            for site in ['dk','fd']:expected_u.add((f,label,'all',site))
for f in ['home_away','team_rest_bin','closing_abs_spread_bin','closing_total_bin','closing_team_implied_bin','observed_green_played','observed_butler_played']:
    for scope in (['2025-26'] if f=='observed_butler_played' else ['all']+sorted(z.season.unique().tolist())):
        zz=z if scope=='all' else z[z.season.eq(scope)]
        known=zz[f].notna()&~zz[f].astype(str).str.contains('missing|unknown',case=False)
        labs=['True'] if f.startswith('observed_') else sorted(zz.loc[known,f].astype(str).unique())
        for label in labs:
            n=(known&zz[f].astype(str).eq(label)).sum();other=known.sum()-n
            if n>=10 and other>=10:
                for site in ['dk','fd']:expected_u.add((f,label,scope,site))
check('uncertainty eligible key completeness',set(map(tuple,u[['field','bin','scope','site']].values))==expected_u,True)
check('uncertainty keys unique',not u.duplicated(['field','bin','scope','site']).any(),True)
for row in u.itertuples():
    scope=np.ones(len(z),bool) if row.scope=='all' else z.season.eq(row.scope).to_numpy()
    if row.field in bins:known=scope&(bins[row.field]!='missing');sel=bins[row.field]==row.bin
    elif row.field.startswith('observed_'):known=scope;sel=z[row.field].to_numpy()
    else: known=scope&z[row.field].notna().to_numpy()&~z[row.field].astype(str).str.contains('missing|unknown',case=False).to_numpy();sel=z[row.field].astype(str).eq(row.bin).to_numpy()
    inds=np.where(known)[0];mask=sel[inds];y=z.loc[known,row.site].to_numpy();check(f'bootstrap_n:{row.field}:{row.bin}:{row.scope}:{row.site}',row.n,len(y));check(f'bootstrap_condition_n:{row.field}:{row.bin}:{row.scope}:{row.site}',row.condition_n,mask.sum());check(f'bootstrap_other_n:{row.field}:{row.bin}:{row.scope}:{row.site}',row.other_n,(~mask).sum())
    est=[y[mask].mean()-y[~mask].mean(),np.median(y[mask])-np.median(y[~mask]),np.quantile(y[mask],.9)-np.quantile(y[~mask],.9),(y[mask]>=48).mean()-(y[~mask]>=48).mean()]
    for f,v in zip(['mean','median','q90','hit48_rate'],est):check(f'bootstrap_point:{row.field}:{row.bin}:{row.scope}:{row.site}:{f}',getattr(row,f+'_delta'),v)
    rng=np.random.default_rng(20261012);sample_groups=[];seasons=z.loc[known,'season'].to_numpy()
    for season in sorted(set(seasons)):
        offsets=np.where(seasons==season)[0];n=len(offsets);starts=rng.integers(n,size=(500,(n+6)//7));rel=np.array([np.concatenate([np.arange(st,st+7)%n for st in starts[j]])[:n] for j in range(500)]);sample_groups.append(offsets[rel])
    draws=np.concatenate(sample_groups,axis=1);bmask=mask[draws];ok=bmask.any(axis=1)&(~bmask).any(axis=1);draws=draws[ok];bmask=bmask[ok];check(f'bootstrap_draws:{row.field}:{row.bin}:{row.scope}:{row.site}',row.bootstrap_draws,len(draws));check(f'bootstrap_length:{row.field}:{row.bin}:{row.scope}:{row.site}',row.block_length,7)
    for season in sorted(set(seasons)):check(f'bootstrap_stratum:{row.field}:{row.bin}:{row.scope}:{row.site}:{season}',bool(((seasons[draws]==season).sum(axis=1)==(seasons==season).sum()).all()),True)
    if row.field not in selected_fields:continue
    yy=y[draws];left=np.where(bmask,yy,np.nan);right=np.where(~bmask,yy,np.nan);lh=np.where(bmask,yy>=48,np.nan);rh=np.where(~bmask,yy>=48,np.nan)
    delta=np.vstack([np.nanmean(left,axis=1)-np.nanmean(right,axis=1),np.nanmedian(left,axis=1)-np.nanmedian(right,axis=1),np.nanquantile(left,.9,axis=1)-np.nanquantile(right,.9,axis=1),np.nanmean(lh,axis=1)-np.nanmean(rh,axis=1)]);bounds=np.quantile(delta,[.025,.975],axis=1)
    for j,f in enumerate(['mean','median','q90','hit48_rate']):
        for bnd,index in [('low',0),('high',1)]:check(f'bootstrap_endpoint:{row.field}:{row.bin}:{row.scope}:{row.site}:{f}:{bnd}',getattr(row,f+'_block95_'+bnd),bounds[index,j])
    boot_saved.append({'field':row.field,'bin':row.bin,'scope':row.scope,'site':row.site,'draws':len(draws),'index_sha256':hashlib.sha256(draws.astype('<i8').tobytes()).hexdigest(),'first_two_draw_game_ids':z.iloc[inds[draws[:2].ravel()]].game_id.to_numpy().reshape(2,-1).tolist()})
# Historical source hashes, including all original input files in root manifest and supporting receipts.
source_refs={}
manifest=json.loads((P/'REPRODUCIBILITY_MANIFEST.json').read_text())
for name,v in manifest['files'].items():
    if name.startswith('inputs/'):source_refs[str(P/name)]=v['sha256']
for f,key in [(R/'coverage_audit_receipt.json','input_hashes'),(P/'player_specific_pilot/audit/core_panel_validation.json','source_hashes')]:
    obj=json.loads(f.read_text())
    for name,h in obj[key].items():source_refs[str(Path(name) if Path(name).is_absolute() else P/name)]=h
for v in json.loads((R/'audit/curry_market_context_manifest.json').read_text())['inputs']:source_refs[v['absolute_path']]=v['sha256']
source_results=[]
for name,h in source_refs.items():
    p=Path(name);actual=sha(p) if p.exists() else 'MISSING';check('source_hash:'+name,actual,h);source_results.append({'path':name,'expected_sha256':h,'actual_sha256':actual,'match':actual==h})
metadata={'status':'PASS' if not failures else 'FAIL','checks':len(checks),'failed_checks':len(failures),'full_source_appearances':187,'season_counts':z.groupby('season').size().to_dict(),'dk_ge48':int(z.dk.ge(48).sum()),'fd_ge48':int(z.fd.ge(48).sum()),'equal_48_dk_dates':z.loc[z.dk.eq(48),'date'].dt.strftime('%Y-%m-%d').tolist(),'equal_48_fd_dates':z.loc[z.fd.eq(48),'date'].dt.strftime('%Y-%m-%d').tolist(),'core_fields':len(fi),'core_split_rows':len(spl),'membership_rows':len(mem),'high_vs_low_rows':len(hv),'joint_rows':len(joint),'joint_membership_rows':len(jm),'uncertainty_rows_checked':len(u),'bootstrap_endpoint_rows_reproduced':len(boot_saved),'source_hashes_checked':len(source_refs),'models_fitted':0,'production_builders_imported':False,'production_outputs_modified':False,'notes':['Player history spans seasons; team prior10 history resets each season.','Known-only teammate role lower bounds are explicitly named; aggregate role counts remain missing whenever any observed teammate lacks prior20 history.','Actual coappearance and same-game box variables are retrospective, never pregame availability.','Season-median cutoffs are descriptive full-season cutoffs, not deployment thresholds.','Bootstrap keeps circular blocks of 7 observed known-context appearances within seasons; excluded context rows compress the time index.','500 bootstrap draws are approximate exploratory uncertainty; no multiple-testing adjustment or selection adjustment.','Integrated ledger retains original core team_b2b which assigns first fixture false; team_b2b_verified is the audited schedule label used by joint conditions.','Original source release vintage remains uncertified; audit confirms saved bytes, not real-time point-in-time availability.']}
audit_files=['analysis/build_core_splits.py','analysis/combine_fixed48_evidence.py','outputs/curry_core_advanced_role_context.csv','outputs/curry_fixed48_integrated_game_ledger.csv','outputs/core_field_inventory.csv','outputs/core_split_cutoffs.csv','outputs/core_split_membership.csv.gz','outputs/core_advanced_role_splits.csv','outputs/curry_fixed48_core_high_vs_low.csv','outputs/curry_fixed48_joint_context_cells.csv','outputs/curry_fixed48_joint_context_membership.csv','outputs/curry_fixed48_split_uncertainty.csv']
metadata['audited_output_sha256']={f:sha(R/f) for f in audit_files};metadata['audit_code_sha256']=sha(Path(__file__))
(A/'audit_summary.json').write_text(json.dumps(metadata,indent=2));(A/'failures.json').write_text(json.dumps(failures,indent=2));(A/'source_hash_checks.json').write_text(json.dumps(source_results,indent=2));(A/'selected_bootstrap_samples.json').write_text(json.dumps(boot_saved,indent=2));pd.DataFrame(checks,columns=['check','passed']).to_csv(A/'all_checks.csv.gz',index=False,compression='gzip')
print(json.dumps(metadata,indent=2));print('FAILURES',json.dumps(failures[:30],indent=2))
