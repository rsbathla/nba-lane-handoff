STEPHEN CURRY: 48-POINT GAME CONTEXT STUDY
Completed October 12, 2026. Historical, exploratory evidence.

START HERE
1. outputs/Stephen_Curry_48_Point_Descriptive_Report.docx: the 8-page readable report.
2. Curry_48_Point_Game_Ledger_20261012.csv: all 187 appearance dates, DK/FD scores, >=48 flags, actual minutes/shots, history contexts, teammates, salaries and source references.
3. outputs/curry_67_DK_high_games_source_ledger.csv: the 67 DK highs only. Use the full ledger for misses and denominators.
4. outputs/curry_pregame_identifier_scorecard.csv: all 7 history/schedule candidates, 3 timing-limited comparisons, and 4 role/calendar sensitivities, including nulls.
5. outputs/curry_full_context_master_187_games.csv.gz: 187 rows, 1,074 columns. This is an analysis join, NOT a pregame forecasting matrix.

BOTTOM LINE
DK >=48 inclusive: 67/187 (35.8%). FD >=48 separately: 46/187 (24.6%). Prior five-game minutes >=34: 14/32 hits, 18 false positives. Prior box usage >=32: 25/60, 35 false positives. Both together: 6/14, not an automatic combined boost. Recent measured prior pull-up share <=43.6239%: 10/24, versus 10/33 on covered dates. On normal prior minutes, it is 10/22 versus 10/25, leaving only 3 unselected games. These are candidate associations, not established live probabilities.

POPULATION AND TIMING
74 appearances in 2023-24 (Oct 24 2023-Apr 12 2024); 70 in 2024-25 (Oct 23 2024-Apr 13 2025); 43 in 2025-26 (Oct 21 2025-Apr 12 2026). All are positive-minute regular-season appearances. Conditional on appearance; nonappearance cannot be assigned a score of zero.
All historical outcomes had already been explored. No conditions in this follow-up were prospectively registered before 2025-26 outcomes. Some numerical cutoffs use earlier-season contexts only; highlighting those candidates happened retrospectively. Source archive vintage is not certified as historical pregame publication.

SEARCH SIZE AND UNCERTAINTY
The full descriptive inventory examined 105 core context fields with 289 cutoff records, 233 numeric shooting/tracking/Synergy/snapshot fields with 699 season-cutoff records, and 13 market/schedule dimensions. Thus 988 core+shot cutoff records, plus the 13-dimension market/schedule tables, were available before candidate highlighting. These are correlated records, not 988 independent tests. Six directly tabulated pairs create 24 joint cells; site duplication produces 48 output rows. Two earlier-season tracking thresholds and four explicit sensitivities are retained. The small identifier scorecard has 10 primary rows: 7 history/schedule and 3 timing-limited; all are shown, not just winners. No new model was fitted.
Wilson precision intervals are unadjusted binomial descriptions. Block intervals use 500 circular, seven-observed-game blocks stratified by season. They do not include multiplicity, discovery, causal confounding, data-vintage or coverage uncertainty. One sensitivity has only three unselected games and correctly omits bootstrap intervals.

COVERAGE AND MEANING
- Actual box outcomes and teammate coappearance: 187 games.
- Home/away: 187. Verified team rest: 184; first season fixtures unknown.
- Prior ten team factors: GSW 162, opponent 161. All target games excluded.
- Opponent three-point attempts/makes/accuracy/share: 161 previous-ten-game contexts. Per-game volume is not per-possession volume or attempt share.
- Own measured catch-and-shoot/pull-up: 93/94 actual games, 61 complete prior-ten windows across later two seasons. In the latest season the ten unknown-history games are Oct 21-Nov 12, including three highs; histories start Nov 14. Appearance-based windows can become stale after long gaps.
- Opponent C&S, positional and Synergy sources include undated, full-season or mixed-March snapshots. These can contain future information relative to a historical game. They are descriptive only. Do not infer C&S allowance from ordinary 3PA.
- Historical opening/closing markets: 43 latest games, capture time not certified.
- Actual starters: 43 latest games. Validated lineup stints: 39. Actual coappearance, actual starter status and on-court overlap are three different concepts, none certifies pregame availability. DNP does not prove rest.
- Salary: DK 96/187, FD 97/187. Older season none; middle season 59/70 each; latest 37/43 DK and 38/43 FD. Only 18 DK and 15 FD dates have contest/pool-specific context; generic Classic/Full Roster workbook values are a separate tier. No prelock capture time is verified. Canonical scores override six source rows with swapped DK/FD score cells. No universal salary multiple defines ceiling.
- Actual travel distance/sleep and certified dated pregame absence/projection history are unavailable.
Legacy team_b2b remains in source and frozen historical models. The NEW descriptive and candidate contexts use team_b2b_verified, retaining unknown first fixtures. Do not substitute the legacy field in those summaries.

REPRODUCING THE INCLUDED ANALYSIS
Run: python analysis/reproduce_packaged_key_results.py
Requirements: Python 3, pandas, numpy. This portable check derives all 14 candidate scorecards from included game-level membership, verifies the full 187-game scores, all 67 hit IDs, salary joins and included saved-probability scorecards. It needs no network or model fitting.
Original generation and independent audit scripts are retained. They reproduce full extraction in the original project layout, using owner-held upstream sources and models referenced by exact path/hash. Those large raw workbook/PBP archives are NOT duplicated in this compact bundle. Source extraction checks are documented in audit/ and salary_audit/. The included context extracts, exact cutoffs, memberships, saved forecasts, summaries and check receipts are sufficient for re-aggregation of this report; re-extraction from raw workbooks requires the original source archives. Do not claim the bundle alone recreates every upstream field from raw NBA data.
Core and identifier independent audit: 203,321 checks, no substantive mismatches. This verifies arithmetic and source consistency, not predictive validity.

FILE MAP
outputs/core_*: 105-field inventory, exact cutoffs, memberships, distribution tables.
outputs/curry_shot_context_*: measured tracking, opponent shooting, snapshots, Synergy, coverage and temporal inventory.
outputs/curry_fixed48_context_*: schedule and market ledgers, split tables and source references.
outputs/curry_fixed48_joint_*: all direct combinations and game membership.
outputs/curry_fixed48_split_uncertainty.csv: descriptive block intervals.
outputs/curry_existing_model_fixed48_*: saved-model readthrough, no new fit. Pooled probabilities approximate a CDF using seven saved quantiles; individual probabilities use exact shrunken empirical leaf distributions. Tied ranking boundaries are disclosed.
coverage_* and splits_*: teammate participation, actual starters, PBP validation, on/off exposure and split scopes.
salary_audit/: distinct salaries, all source evidence, full coverage grid, duplicate and scoring-cell audits.
audit/: independent receipts, reproduction code and timing/coverage checks.
