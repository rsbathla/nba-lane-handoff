"""Empirical Curry context audit; no fitted models, no outcome-selected cutoffs."""
from pathlib import Path
import pandas as pd, numpy as np, json, hashlib, warnings
warnings.filterwarnings('ignore', category=pd.errors.PerformanceWarning)
O=Path(__file__).resolve().parents[1]; B=O.parent/'inputs/three_season/nba_three_season_ceiling_20261011'; D=O/'outputs'; A=O/'audit'
SOURCES={}; FIELDS=[]; SPLIT=[]; CUTS=[]; COVER=[]
def read(rel):
 p=B/rel; SOURCES[str(p.relative_to(O.parent))]=hashlib.sha256(p.read_bytes()).hexdigest()
 return pd.read_csv(p,low_memory=False,dtype={'game_id':str})
def add(field,family,temporal,source,definition,split=True):
 FIELDS.append(dict(field=field,family=family,temporal_class=temporal,source=source,definition=definition,split_eligible=split,strict_source_vintage_certified=False))
def merge(y,keys):
 global x
 assert not y.duplicated(keys).any(), keys
 x=x.merge(y,on=keys,how='left',validate='many_to_one');assert len(x)==187
x=pd.read_csv(D/'curry_full_three_season_inventory.csv',dtype={'game_id':str}).sort_values(['date','game_id']).reset_index(drop=True)
x.game_id=x.game_id.str.zfill(10)
# Reconstruct opponent allowance from all observed box appearances; DNP zero counts cannot change totals.
b=read('results/player_game_mechanism_spine.csv'); b.game_id=b.game_id.str.zfill(10)
counts=['fga','fg3a','fg3m']
t=b.groupby(['season','date','game_id','team','opponent'],as_index=False)[counts].sum()
t=t.sort_values(['season','opponent','date','game_id']).reset_index(drop=True)
g=t.groupby(['season','opponent'],sort=False)
t['opp_three_prior_games']=g.cumcount();t['opp_three_prior_last_date']=g.date.shift();t['opp_three_prior10_start_date']=g.date.shift(10)
for c in counts:t[c+'_prior10sum']=g[c].transform(lambda s:s.shift().rolling(10,min_periods=10).sum())
t['opp_allowed_3pa_prior10_mean']=t.fg3a_prior10sum/10
t['opp_allowed_3pm_prior10_mean']=t.fg3m_prior10sum/10
t['opp_allowed_3p_pct_prior10_weighted']=t.fg3m_prior10sum/t.fg3a_prior10sum.replace(0,np.nan)
t['opp_allowed_3pa_share_prior10_weighted']=t.fg3a_prior10sum/t.fga_prior10sum.replace(0,np.nan)
t['opp_allowed_3pa_prior10_attempts']=t.fg3a_prior10sum
for c in ['opp_allowed_3pa_prior10_mean','opp_allowed_3pm_prior10_mean','opp_allowed_3p_pct_prior10_weighted','opp_allowed_3pa_share_prior10_weighted']:
 add(c,'opponent_three_point_allowance','strictly_lagged_prior_games','results/player_game_mechanism_spine.csv','Last 10 opponent team games within season, strictly before target date; ratios use summed counts, not average game percentages.')
for c in ['opp_three_prior_games','opp_three_prior_last_date','opp_three_prior10_start_date','opp_allowed_3pa_prior10_attempts']:
 add(c,'opponent_three_point_allowance','strictly_lagged_prior_games','results/player_game_mechanism_spine.csv','Source exposure/window audit.',False)
merge(t[['game_id','opponent']+[f['field'] for f in FIELDS]],['game_id','opponent'])
valid=x.opp_three_prior_last_date.notna(); assert (x.loc[valid,'opp_three_prior_last_date']<x.loc[valid,'date']).all()
# Same-game tracking. Do not convert absent published observations to zero.
tr=read('tracking_mechanisms/observed_tracking_box_ceiling_join.csv.gz');tr.game_id=tr.game_id.str.zfill(10)
labels={'cs':'catch_and_shoot','pu':'pull_up','lt10':'less_than_10ft','vtight':'very_tight','wo':'wide_open'}
for (season,tag),u in tr.groupby(['season','tag']):
 c=u[u.person_id.eq(201939)]
 COVER.append(dict(family='tracking',season=season,tag=tag,source_rows=len(u),source_games=u.game_id.nunique(),source_first=u.date.min(),source_last=u.date.max(),curry_raw_rows=len(c),curry_clean_rows=int(c.clean_observation.sum()),curry_first=c.date.min(),curry_last=c.date.max(),source_component_conflicts=int((~c.clean_observation).sum())))
for tag,label in labels.items():
 u=tr[(tr.person_id.eq(201939))&tr.tag.eq(tag)].copy()
 cols=['tracking_fga','tracking_fgm','tracking_fg3a','tracking_fg3m','clean_observation','source_component_conflict','input_source_sha256','source_sha256','retrieved_at','source_original_file']
 names={c:'track_'+tag+'_'+c.removeprefix('tracking_') for c in cols}
 u=u[['game_id']+cols].rename(columns=names)
 merge(u,['game_id'])
 prefix='track_'+tag+'_'
 for c in ['fga','fgm','fg3a','fg3m']:
  field=prefix+c; x[field]=x[field].where(x[prefix+'clean_observation'].eq(True))
  add(field,'player_'+label,'contemporaneous_game_explanation','tracking_mechanisms/observed_tracking_box_ceiling_join.csv.gz','Observed, component-reconciled same-game tracking count; absent observations remain null.')
 for suffix,nom,den in [('fga_share',prefix+'fga','fga'),('fg3a_share',prefix+'fg3a','fg3a'),('fg_pct',prefix+'fgm',prefix+'fga'),('fg3_pct',prefix+'fg3m',prefix+'fg3a')]:
  field=prefix+suffix;x[field]=x[nom]/x[den].replace(0,np.nan)
  add(field,'player_'+label,'contemporaneous_game_explanation','tracking_mechanisms/observed_tracking_box_ceiling_join.csv.gz','Observed same-game ratio; zero denominator and missing observation remain null.')
 for c in cols[4:]:add(names[c],'tracking_audit','contemporaneous_game_explanation','tracking_mechanisms/observed_tracking_box_ceiling_join.csv.gz','Preserved tracking provenance/quality field.',False)
 # Complete consecutive prior appearance windows only; within season, no bridging a missing observation.
 for c in ['fga','fg3a','fga_share','fg3a_share']:
  raw=prefix+c;field=raw+'_prior10';x[field]=x.groupby('season')[raw].transform(lambda s:s.shift().rolling(10,min_periods=10).mean())
  add(field,'player_'+label+'_prior_window','strictly_lagged_prior_games','tracking_mechanisms/observed_tracking_box_ceiling_join.csv.gz','Mean over immediately preceding 10 Curry appearances within season, all 10 required observed and clean; source vintage not certified.')
# Opponent season tracking profiles are observed subsets, never complete defensive funnels.
p=read('shot_profile_matchups/opponent_tracking_observed_subset_profiles.csv')
for tag in labels:
 u=p[p.tag.eq(tag)].drop(columns='tag'); fields=[c for c in u if c not in ['season','opponent']]; names={c:'opp_track_subset_'+tag+'_'+c for c in fields};merge(u.rename(columns=names),['season','opponent'])
 for c in fields:
  add(names[c],'opponent_'+labels[tag]+'_observed_subset','completed_season_or_partial_undated_profile','shot_profile_matchups/opponent_tracking_observed_subset_profiles.csv','Season aggregate of only observed player-tag rows; exposure coverage retained; not a complete defensive funnel and not pregame.',c in ['tag_share_of_observed_subset_box_fga','tag_fg_percentage','observed_box_fga_coverage_fraction'])
# Per-game shot zones and same-season opponent profiles.
z=read('pbp_descriptive_panels/shot_mechanisms_with_box_ceiling_labels.csv.gz'); z.game_id=z.game_id.str.zfill(10);z=z[z.person_id.eq(201939)]
zones=[c[:-4] for c in z if c.endswith('_fga') and c.startswith(('2pt_','3pt_'))]
cols=[v+s for v in zones for s in ['_fga','_fgm']]+['complete_shot_location_coverage','location_coverage_fraction','location_invalid_or_blocked_fga','pbp_source_sha256','reviewed_box_shot_counts_reconciled']
merge(z[['game_id']+cols].rename(columns={c:'zone_game_'+c for c in cols}),['game_id'])
for zone in zones:
 for c in ['fga','fgm']:
  f='zone_game_'+zone+'_'+c;x[f]=x[f].where(x.zone_game_complete_shot_location_coverage.eq(True)&x.zone_game_reviewed_box_shot_counts_reconciled.eq(True))
  add(f,'player_shot_zone','contemporaneous_game_explanation','pbp_descriptive_panels/shot_mechanisms_with_box_ceiling_labels.csv.gz','Same-game complete, reconciled shot-location count; incomplete locations masked.')
 for suffix,nom,den in [('share','zone_game_'+zone+'_fga','fga'),('fg_pct','zone_game_'+zone+'_fgm','zone_game_'+zone+'_fga')]:
  f='zone_game_'+zone+'_'+suffix;x[f]=x[nom]/x[den].replace(0,np.nan)
  add(f,'player_shot_zone','contemporaneous_game_explanation','pbp_descriptive_panels/shot_mechanisms_with_box_ceiling_labels.csv.gz','Same-game observed zone ratio; missing/zero denominator remains null.')
for c in cols[len(zones)*2:]: add('zone_game_'+c,'shot_zone_audit','contemporaneous_game_explanation','pbp_descriptive_panels/shot_mechanisms_with_box_ceiling_labels.csv.gz','Shot-location quality/provenance.',False)
p=read('shot_profile_matchups/opponent_defense_zone_profiles.csv').rename(columns={'defense_team':'opponent'})
for zone in zones:
 u=p[p.zone.eq(zone)].drop(columns='zone');fields=[c for c in u if c not in ['season','opponent']];names={c:'opp_zone_profile_'+zone+'_'+c for c in fields};merge(u.rename(columns=names),['season','opponent'])
 for c in fields:add(names[c],'opponent_shot_zone_profile','completed_season_or_partial_undated_profile','shot_profile_matchups/opponent_defense_zone_profiles.csv','Same-season final profile, requires full shot-location release per contributing team-game. Includes target/future observations; never pregame.',c in ['frequency','fg_percentage'])
# Reconstruct dated lagged zone allowance independently, require all ten previous opponent team games to have valid locations.
z=read('shot_profile_matchups/team_game_zone_coverage.csv');z.game_id=z.game_id.str.zfill(10);z=z.sort_values(['season','opponent','date','game_id'])
zg=z.groupby(['season','opponent']);z['opp_zone_prior10_valid_games']=zg.team_game_profile_released.transform(lambda s:s.shift().rolling(10,min_periods=10).sum())
for c in ['box_fga']+[v+s for v in zones for s in ['_fga','_fgm']]:
 z[c+'_prior10sum']=zg[c].transform(lambda s:s.shift().rolling(10,min_periods=10).sum()).where(z.opp_zone_prior10_valid_games.eq(10))
fs=['opp_zone_prior10_valid_games']
add(fs[0],'opponent_shot_zone_prior_window','strictly_lagged_prior_games','shot_profile_matchups/team_game_zone_coverage.csv','Number of valid location games among immediately prior 10 team games; all 10 required for numeric profile.',False)
for zone in zones:
 for suffix,nom,den in [('fga_mean',zone+'_fga_prior10sum',None),('share',zone+'_fga_prior10sum','box_fga_prior10sum'),('fg_pct',zone+'_fgm_prior10sum',zone+'_fga_prior10sum')]:
  f='opp_zone_'+zone+'_prior10_'+suffix;z[f]=z[nom]/(z[den].replace(0,np.nan) if den else 10);fs.append(f)
  add(f,'opponent_shot_zone_prior_window','strictly_lagged_prior_games','shot_profile_matchups/team_game_zone_coverage.csv','Immediately prior 10 team games, all with full location coverage; target excluded; ratio of counts. 2025–26 only.')
merge(z[['game_id','opponent']+fs],['game_id','opponent'])
# Synergy: preserve real playtypes, source exposure and undated snapshot limitations.
identity=read('synergy/team_identity_map.csv');idmap=identity.set_index('team_id').team_abbreviation
p=read('synergy/normalized_team_defense.csv');p['opponent']=p.team_id.map(idmap)
q=read('synergy/normalized_player_offense.csv');q=q[q.player_id.eq(201939)&q.team_id.eq(1610612744)]
playtypes=sorted(p.play_type.unique())
for typ in playtypes:
 for side,src,keys in [('opp',p,['season','opponent']),('curry',q,['season'])]:
  u=src[src.play_type.eq(typ)].copy();cols=['gp','frequency','ppp_reported','possessions','points','snapshot_status','source_file','source_sha256','source_observation_last_date','source_fetch_timestamp','minimum_possessions','meets_minimum_possessions','ppp_from_points']
  names={c:'synergy_'+side+'_'+typ+'_'+c for c in cols};merge(u[keys+cols].rename(columns=names),keys)
  for c in cols:add(names[c],'synergy_'+side+'_'+typ,'completed_season_or_partial_undated_profile','synergy/normalized_'+('team_defense' if side=='opp' else 'player_offense')+'.csv','2024–25 undated full-season-consistent; 2025–26 undated partial. Not actual player-v-opponent possessions. No 2023–24 source. Curry source GP 70/40 versus actual 70/43.',side=='opp' and c in ['frequency','ppp_reported'])
# Mixed-date dashboard source: real extra defenses/DvP exist, but never infer per-game availability.
dashpath=B.parent/'nba_tracking_integration_20261010/sources_v1/NBA_Derived_DFS_Dashboard_20261010/nba-dashboard/data.json'
dash=json.loads(dashpath.read_text());dashsrc=str(dashpath.relative_to(O.parent));SOURCES[dashsrc]=hashlib.sha256(dashpath.read_bytes()).hexdigest()
(A/'curry_dashboard_source_metadata.json').write_text(json.dumps(dash['meta'],indent=2))
def safekey(k):
 import re
 return re.sub(r'[^A-Za-z0-9]+','_',str(k)).strip('_')
def flatten(obj,prefix=''):
 out={}
 for k,v in obj.items():
  key=prefix+safekey(k)
  if isinstance(v,dict):out.update(flatten(v,key+'_'))
  elif isinstance(v,list):out[key]=json.dumps(v,sort_keys=True)
  else:out[key]=v
 return out
for section in ['defenses','team_environment','defense_shot_zones','defense_pos_vulnerability']:
 rows=[]
 for opp,values in dash[section].items():rows.append({'season':'2025-26','opponent':opp,**{'dashboard_opp_'+section+'_'+k:v for k,v in flatten(values).items() if k!='team'}})
 u=pd.DataFrame(rows);merge(u,['season','opponent'])
 for f in u.columns:
  if f in ['season','opponent']:continue
  numeric=pd.api.types.is_numeric_dtype(u[f]);split=numeric and not any(q in f for q in ['rank','pctile','games','outperformed','weakness_count'])
  add(f,'dashboard_'+section,'mixed_date_dashboard_snapshot',dashsrc,'Raw snapshot. Metadata: date March15 2026; last_updated March26; L7 through March26; environment Jan1–Mar8 456 games; daily slate March10. Repeated across 2025–26 games only for descriptive association, never per-game or time-safe context. Position labels are source categories, not verified matchup assignments.',split)
# Curry aggregate profiles retained as source descriptors only, including outcome-conditioned top20 fields.
for section in ['players','player_splits','player_shot_zones']:
 matches=[(k,v) for k,v in dash[section].items() if k in ['Stephen Curry','Stephen Curry|GSW']]
 for key,values in matches:
  fs=flatten(values)
  for k,v in fs.items():
   f='dashboard_curry_'+section+'_'+k;x[f]=np.where(x.season.eq('2025-26'),v,np.nan) if isinstance(v,(int,float)) else x.season.map(lambda season:v if season=='2025-26' else None)
   add(f,'dashboard_curry_aggregate','outcome_conditioned_aggregate_do_not_use_as_context' if 'top20' in k else 'mixed_date_dashboard_snapshot',dashsrc,'Original Curry dashboard aggregate retained, not recomputed. Top20 values select on realized high outcomes and are not independent explanatory context. No per-game membership or timestamp verified.',False)

# Preserve known no-coverage families explicitly.
for f,desc in [('time_safe_position_specific_defense_history','No verified time-safe position-specific defensive history. A mixed-date dashboard snapshot exists and is retained separately; historical box position labels do not establish matchup assignment.'),('dated_synergy_prior_game_profile','No dated cumulative Synergy snapshots; all same-season source profiles excluded from pregame.'),('complete_opponent_catch_shoot_or_pullup_allowance','Only observed-subset tracking profiles available; unobserved player/tag rows cannot be treated as zero.')]:
 x[f]=np.nan;add(f,'unavailable','unavailable','held source inventory',desc,False)
# Save raw observation distributions, not only metrics.
x.to_csv(D/'curry_shot_context_join.csv',index=False)
fields=pd.DataFrame(FIELDS)
for _,f in fields.iterrows():
 for season,u in x.groupby('season'):
  s=u[f.field];n=int(s.notna().sum());COVER.append(dict(family=f.family,field=f.field,temporal_class=f.temporal_class,season=season,curry_games=len(u),non_null=n,null=len(u)-n,distinct_non_null=s.nunique(),first_non_null_date=u.loc[s.notna(),'date'].min(),last_non_null_date=u.loc[s.notna(),'date'].max()))
fields.to_csv(D/'curry_shot_context_field_inventory.csv',index=False);pd.DataFrame(COVER).to_csv(D/'curry_shot_context_coverage.csv',index=False)

def summary(u,season,field,label,method,cutoff=None,temporal=None):
 for site in ['dk','fd']:
  s=u[site];h=u[site+'_hit_q90'];delta=u[site]-u[site+'_prior20_mean'];base=u[site+'_prior20_mean'];rel=(s/base-1)*100
  SPLIT.append(dict(season=season,field=field,bin=label,method=method,temporal_class=temporal,cutoff=cutoff,site=site,n=len(u),score_mean=s.mean(),score_median=s.median(),score_q10=s.quantile(.1),score_q25=s.quantile(.25),score_q75=s.quantile(.75),score_q90=s.quantile(.9),score_q95=s.quantile(.95),score_min=s.min(),score_max=s.max(),score_ge48_hits=int(s.ge(48).sum()),score_lt48_misses=int(s.lt(48).sum()),score_ge48_rate=s.ge(48).mean(),dk_ge48_hits=int(u.dk.ge(48).sum()),dk_lt48_misses=int(u.dk.lt(48).sum()),dk_ge48_rate=u.dk.ge(48).mean(),threshold48_inclusive=True,prior20_n=int(base.notna().sum()),prior20_mean=base.mean(),mean_minus_prior20=delta.mean(),median_minus_prior20=delta.median(),mean_pct_above_prior20=rel.mean(),q90_threshold_known_n=int(h.notna().sum()),strict_prior_q90_hits=int(h.eq(1).sum()),strict_prior_q90_misses=int(h.eq(0).sum()),strict_prior_q90_null=int(h.isna().sum()),strict_prior_q90_rate=h.mean(),small_sample_lt20=len(u)<20,exploratory_not_validated=True))
for season,u in [('ALL',x)]+list(x.groupby('season')):summary(u,season,'BASELINE','all','unconditional')
# Every eligible numeric field gets season-specific median bins, independent of scores. Ties go below/equal.
for _,f in fields[fields.split_eligible].iterrows():
 field=f.field; bins=pd.Series('missing',index=x.index,dtype=object)
 for season,u in x.groupby('season'):
  vals=u[field].dropna();cut=vals.median()
  CUTS.append(dict(field=field,season=season,method='exploratory_within_season_feature_median',cutoff=cut,non_null=len(vals),distinct=vals.nunique(),ties_at_cutoff=int(vals.eq(cut).sum()),outcome_used_to_choose_cutoff=False))
  if len(vals)==0:summary(u,season,field,'missing','exploratory_within_season_feature_median',cut,f.temporal_class);continue
  if vals.nunique()<2:
   bins.loc[u.index[u[field].notna()]]='constant_observed';summary(u[u[field].notna()],season,field,'constant_observed','no_split_constant',cut,f.temporal_class)
  else:
   bins.loc[u.index[u[field].notna()&u[field].le(cut)]]='below_or_equal';bins.loc[u.index[u[field].notna()&u[field].gt(cut)]]='above'
   for label,mask in [('below_or_equal',u[field].notna()&u[field].le(cut)),('above',u[field].notna()&u[field].gt(cut))]:summary(u[mask],season,field,label,'exploratory_within_season_feature_median',cut,f.temporal_class)
  if u[field].isna().any():summary(u[u[field].isna()],season,field,'missing','exploratory_within_season_feature_median',cut,f.temporal_class)
 for label,u in x.groupby(bins):summary(u,'ALL',field,label,'pooled_season_normalized_exploratory_median',None,f.temporal_class)
# Transparent domain-scale coarse sensitivity bins; no selection by outcome.
fixed={'opp_allowed_3pa_prior10_mean':[-np.inf,32,36,40,np.inf],'opp_allowed_3p_pct_prior10_weighted':[-np.inf,.34,.36,.38,np.inf],'opp_allowed_3pa_share_prior10_weighted':[-np.inf,.35,.4,.45,np.inf]}
for field,edges in fixed.items():
 bins=pd.cut(x[field],edges,right=False).astype(str).replace('nan','missing')
 for season,u in [('ALL',x)]+list(x.groupby('season')):
  for label,v in u.groupby(bins.loc[u.index]):summary(v,season,field,label,'fixed_coarse_bins_no_outcome_selection',json.dumps(edges),'strictly_lagged_prior_games')
pd.DataFrame(SPLIT).to_csv(D/'curry_shot_context_distribution_splits.csv',index=False)
pd.DataFrame(CUTS).to_csv(D/'curry_shot_context_exact_cutoffs.csv',index=False)
# Outcome-defined descriptive comparison with full winner/miss denominators, never used to select splits.
contrasts=[]
for _,f in fields[fields.split_eligible].iterrows():
 for season,u in [('ALL',x)]+list(x.groupby('season')):
  for site in ['dk','fd']:
   for label,v in [('ge48',u[u[site].ge(48)]),('lt48',u[u[site].lt(48)])]:
    a=v[f.field]
    contrasts.append(dict(season=season,site=site,score_threshold=48,threshold_inclusive=True,outcome_group=label,total_group_games=len(v),feature=f.field,temporal_class=f.temporal_class,feature_observed_games=int(a.notna().sum()),feature_missing_games=int(a.isna().sum()),feature_mean=a.mean(),feature_median=a.median(),feature_q25=a.quantile(.25),feature_q75=a.quantile(.75),feature_min=a.min(),feature_max=a.max(),descriptive_association_only=True))
pd.DataFrame(contrasts).to_csv(D/'curry_shot_context_48_feature_level_comparisons.csv',index=False)
# Input schemas: every original source field classified as retained or source-only/audit.
schema=[]
for src in SOURCES:
 pth=O.parent/src
 for c in (pd.read_csv(pth,nrows=0).columns if pth.suffix!='.json' else [section+'.'+field for section,values in dash.items() if isinstance(values,dict) and section!='meta' for field in sorted(set(k for v in values.values() if isinstance(v,dict) for k in flatten(v)))]):schema.append(dict(source=src,original_field=c,source_sha256=SOURCES[src],disposition='Raw source retained unchanged; derived/joined field mappings in field inventory. Identifiers, outcomes and duplicate shrinkage/support metadata remain in original source when not joined.'))
pd.DataFrame(schema).to_csv(D/'curry_shot_context_source_schema_inventory.csv',index=False)
# Assertions and precise temporal caveats.
checks={'curry_games':len(x),'unique_game_ids':x.game_id.nunique(),'seasons':x.groupby('season').size().to_dict(),'context_fields':len(fields),'numeric_split_fields':int(fields.split_eligible.sum()),'distribution_rows':len(SPLIT),'strictly_lagged_opponent_three_coverage':x.groupby('season').opp_allowed_3p_pct_prior10_weighted.count().to_dict(),'curry_tracking_clean_count_by_season_tag':tr[tr.person_id.eq(201939)&tr.clean_observation].groupby(['season','tag']).size().to_dict(),'source_hashes':SOURCES,'models_fitted':0,'outcome_optimized_thresholds':0,'time_safe_position_allowance_available':False,'mixed_date_position_allowance_snapshot_available':True,'dashboard_metadata':dash['meta'],'three_rolling_window':'10 previous opponent team games, same season; 10/10 required; target game excluded','prior20_and_q90':'Inherited unmodified from parent full inventory. q90 comparison strictly > with missing threshold preserved. See parent baseline threshold protocol.','source_vintage_note':'Strictly prior games means chronological historical reconstruction, not proof that this corrected source version was available pregame.','median_cutoffs_note':'Each season feature median computed over that season descriptive sample; cutoffs use no outcomes but are retrospective exploratory, not deployable pregame cutoffs.','tracking_note':'All 5 tags overlap and cannot be summed. Missing published player-tag observations remain missing; prior10 requires all 10 immediately prior appearances observed. Opponent tracking profiles cover observed subsets only.','synergy_note':'2024–25 undated full-season-consistent, 2025–26 undated partial, no 2023–24. No true per-game Synergy, no snapshot-in-game membership.'}
checks['curry_tracking_clean_count_by_season_tag']={str(k):int(v) for k,v in checks['curry_tracking_clean_count_by_season_tag'].items()}
(A/'curry_shot_context_audit.json').write_text(json.dumps(checks,indent=2,default=str))
print(json.dumps({k:v for k,v in checks.items() if k!='source_hashes'},indent=2))
s=pd.DataFrame(SPLIT);print(s[(s.season=='ALL')&s.field.isin(['opp_allowed_3pa_prior10_mean','opp_allowed_3p_pct_prior10_weighted','opp_allowed_3pa_share_prior10_weighted'])&s.method.eq('pooled_season_normalized_exploratory_median')][['field','bin','site','n','score_mean','score_median','score_q90','score_q95','mean_minus_prior20','strict_prior_q90_hits','strict_prior_q90_misses','strict_prior_q90_null']].to_string(index=False))
