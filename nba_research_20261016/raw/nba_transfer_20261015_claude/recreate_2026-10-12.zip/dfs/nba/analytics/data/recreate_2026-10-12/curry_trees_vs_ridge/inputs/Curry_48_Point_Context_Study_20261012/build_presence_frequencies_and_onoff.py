from pathlib import Path
import pandas as pd,numpy as np,json
O=Path(__file__).resolve().parent
c=pd.read_csv(O/'outputs/curry_full_three_season_inventory.csv',dtype={'game_id':str});c.game_id=c.game_id.str.zfill(10);c['dk_group']=np.where(c.dk.ge(48),'DK >=48','DK <48');co=pd.read_csv(O/'coverage_curry_teammate_coappearances_187_games.csv',dtype={'game_id':str});co.game_id=co.game_id.str.zfill(10);g=pd.read_csv(O/'coverage_gsw_positive_minute_box_games_three_seasons.csv',dtype={'game_id':str});g.game_id=g.game_id.str.zfill(10)
# Group incidence denominators: P(teammate present | high or low outcome), distinct from P(high | teammate present).
res=[]
for pid,gg in g[g.person_id.ne(201939)].groupby('person_id'):
 name=gg.sort_values('date').player.iloc[-1]
 first=gg.date.min();last=gg.date.max();present=set(co[co.teammate_person_id.eq(pid)].game_id)
 for season in ['ALL_THREE_SEASONS']+list(c.season.unique()):
  if season!='ALL_THREE_SEASONS' and season not in set(gg.season):continue
  d=c if season=='ALL_THREE_SEASONS' else c[c.season.eq(season)]
  for scope in ['entire_selected_season_window','on_or_after_first_observed_gsw_appearance']:
   if pid==202710 and scope=='entire_selected_season_window':continue
   z=d[d.date.ge(first)] if scope.startswith('on_or_after') else d
   for label,zz in z.groupby('dk_group'):
    yes=zz.game_id.isin(present);res.append({'season':season,'scope':scope,'teammate_person_id':pid,'teammate_player':name,'first_observed_gsw_appearance':first,'last_observed_gsw_appearance':last,'dk_group':label,'outcome_group_n':len(zz),'teammate_observed_n':int(yes.sum()),'teammate_not_observed_n':int((~yes).sum()),'teammate_observed_fraction':yes.mean(),'dk_mean_when_observed':zz.loc[yes,'dk'].mean(),'fd_mean_when_observed':zz.loc[yes,'fd'].mean(),'warning':'Presence is a postgame observation. Entire windows can combine roster eras; use season and first-observed scope, especially for newcomers.'})
f=pd.DataFrame(res);f.to_csv(O/'splits_curry_dk48_high_low_teammate_presence_frequencies.csv',index=False)
# Starter incidence among all43 Curry2025-26 appearances, scoped at first observed GSW game for each teammate.
raw=pd.read_csv(O/'coverage_gsw_actual_starter_and_player_rest_source_2025_26.csv',dtype={'game_id':str});raw.game_id=raw.game_id.str.zfill(10);sr=[]
for (pid,name),rr in raw.groupby(['person_id','player']):
 first=g[g.person_id.eq(pid)].date.min();z=c[c.season.eq('2025-26')&c.date.ge(first)];yesgames=set(rr[rr.starter_source_yn.eq('Y')].game_id)
 for label,zz in z.groupby('dk_group'):
  yes=zz.game_id.isin(yesgames);sr.append({'person_id':pid,'player':name,'scope':'2025-26 on or after first observed GSW appearance','dk_group':label,'outcome_group_n':len(zz),'started_n':int(yes.sum()),'not_started_n':int((~yes).sum()),'started_fraction':yes.mean()})
pd.DataFrame(sr).to_csv(O/'splits_curry_dk48_high_low_starter_frequencies.csv',index=False)
# Actual on-court time across all passing games. This differs from original same-game coparticipant pair tables.
x=pd.read_csv(O/'coverage_curry_component_on_off_games.csv',dtype={'game_id':str});x.game_id=x.game_id.str.zfill(10);assert x.fd_additive_on_off_release_pass.all() and x.dk_additive_base_on_off_release_pass.all()
st=pd.read_csv(O/'coverage_curry_oncourt_lineup_stints_39_games.csv',dtype={'game_id':str});st.game_id=st.game_id.str.zfill(10);game_seconds=st.groupby('game_id').duration_seconds.sum();out=[];pg=[]
for (pid,name),gg in g[g.season.eq('2025-26')&g.person_id.ne(201939)].groupby(['person_id','player']):
 first=g[g.person_id.eq(pid)].date.min();z=c[c.game_id.isin(game_seconds.index)&c.date.ge(first)]
 for _,r in z.iterrows():
  q=x[(x.game_id.eq(r.game_id))&x.teammate_person_id.eq(pid)];tt=st[st.game_id.eq(r.game_id)];withseconds=tt.loc[tt.gsw_person_ids.map(lambda a:str(pid) in a.split(';')),'duration_seconds'].sum();total=game_seconds[r.game_id]
  if len(q):
   q=q.iloc[0];assert abs(q.shared_court_seconds-withseconds)<.001;fd_with=q.fd_points_with;fd_without=q.fd_points_without;dk_with=q.dk_base_points_with;dk_without=q.dk_base_points_without;basis='validated same-game component attribution'
  else:
   assert withseconds==0;fd_with=0.;fd_without=r.fd;dk_with=0.;dk_without=r.dk-1.5*(sum(r[a]>=10 for a in ['pts','reb','ast','stl','blk'])>=2)-3*(sum(r[a]>=10 for a in ['pts','reb','ast','stl','blk'])>=3);basis='teammate had no observed court time; all Curry seconds and reconciled full-game additive components are off'
  assert abs(fd_with+fd_without-r.fd)<1e-6
  pg.append({'game_id':r.game_id,'date':r.date,'teammate_person_id':pid,'teammate_player':name,'scope':'validated Curry games on or after first observed GSW appearance','teammate_observed_in_same_game':len(x[(x.game_id.eq(r.game_id))&x.teammate_person_id.eq(pid)])>0,'with_seconds':withseconds,'without_seconds':total-withseconds,'fd_with':fd_with,'fd_without':fd_without,'dk_base_with':dk_with,'dk_base_without':dk_without,'fullgame_dk_ge48':r.dk>=48,'basis':basis})
y=pd.DataFrame(pg);y.to_csv(O/'splits_curry_onoff_all_validated_games_with_noncoappearance.csv',index=False)
for (pid,name),z in y.groupby(['teammate_person_id','teammate_player']):
 for mode in ['all_validated_games_in_scope','same_game_coparticipants_only']:
  zz=z[z.teammate_observed_in_same_game] if mode.startswith('same_game') else z
  for state in ['with','without']:
   seconds=zz[state+'_seconds'].sum();row={'teammate_person_id':pid,'teammate_player':name,'scope':mode,'state':state,'eligible_games':len(zz),'positive_exposure_games':int(zz[state+'_seconds'].gt(0).sum()),'minutes':seconds/60,'fd_additive_points':zz['fd_'+state].sum(),'fd_per36':zz['fd_'+state].sum()/seconds*2160 if seconds else np.nan,'dk_base_points':zz['dk_base_'+state].sum(),'dk_base_per36':zz['dk_base_'+state].sum()/seconds*2160 if seconds else np.nan,'warning':'Actual on-court descriptive rates; DK double/triple-double bonuses excluded from interval attribution. Not causal.'};out.append(row)
s=pd.DataFrame(out);s.to_csv(O/'splits_curry_actual_onoff_rates_scope_comparison.csv',index=False)
print(s[s.teammate_player.str.contains('Green|Butler')][['teammate_player','scope','state','eligible_games','positive_exposure_games','minutes','fd_per36','dk_base_per36']].round(3).to_string(index=False))
