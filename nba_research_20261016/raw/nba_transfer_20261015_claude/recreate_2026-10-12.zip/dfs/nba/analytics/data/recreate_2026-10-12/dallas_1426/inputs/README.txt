DALLAS BOUNDED COMBINATORIAL SEARCH — 2026-10-12

Start with INTERPRETATION.txt and KEY_RESULTS.json. This is a new exploratory supplement. Original comparison and ability-opportunity analyses are unchanged.

Inventory: 21 strictly prior features, 1,426 formal predicates (42 signed singles, 840 signed pairs, 544 signed role × volume × ability triples). Formal predicates are not independent tests. Three train-only selectors and two fixed benchmarks are evaluated on identical future rows, with a separate player-exclusion sensitivity. All candidates, failures, missingness and null findings are retained.

Key evidence:
- FROZEN_COMBINATORIAL_PROTOCOL.json: complete frozen statistical design
- FROZEN_CANDIDATE_DICTIONARY.csv: every predicate and its feature references
- FEATURE_DEFINITIONS.csv and FEATURE_INVENTORY.csv: formulas, coverage and provenance
- ALL_25668_candidate_train_evaluations.csv: all 1,426 rules × 18 training fits, all branch counts and support reasons
- ALL_4278_candidate_future_descriptive_counts.csv: future descriptive counts for all rules × 3 ordinary folds; never selected using these counts
- ALL_training_cutoffs.csv, ALL_selected_rules.csv, split_audit.csv and candidate_counts_by_fit.csv
- ALL_future_predictions.csv: all 5,140 forecasts, labels, identities and fallback branches
- prediction_scorecard.csv, fixed_bin_calibration.csv, paired_prediction_uncertainty.csv and selection_stability.csv
- approximate_max_statistic_diagnostic.csv and ALL_max_statistic_candidate_diagnostics.csv: conditional, approximate training multiplicity diagnostics; not exact familywise guarantees
- all_tracking_source_rows_validity.csv: complete 88,977-row source validation including 10 invalid rows
- all_positive_minute_prior_features.csv and Dallas_features_OUTCOME_FREE.csv: reconstructed strictly prior inputs, tracking valid observation counts and matched denominators
- Dallas_complete_feature_outcome_ledger.csv: the 382 validated Dallas appearances
- DESCRIPTIVE_* files: same-player other-defense controls, joined only after predictions
- independent_audit.py/json/txt: independent 2,810-check verification, all passed
- SOURCE_REGISTRY.csv, RUN_MANIFEST.json and OUTPUT_MANIFEST.json: hashes and run scope

Reproduction:
Use the saved feature ledger and frozen dictionary to run run_search.py. It reads the reviewed source outcomes/eligibility ledger from its recorded local path and verifies the original benchmark forecasts. It needs pandas, numpy and scikit-learn (version 1.8.0 used). It performs no acquisition or external write. prepare_features.py demonstrates reconstruction from reviewed sources; independent_audit.py independently rebuilds those features and all model outputs. Keep a copy of frozen deliverables before rerunning preparation: preparation timestamps are provenance and are intentionally not treated as new independent data.

The final support gates are outcome-independent: at least 20 appearances, 5 games and 5 players in both the known rule and known complement. The pre-outcome refinement and subsequent generator-only reproducibility correction are explicitly recorded. No minimum hit/miss gate remains.

The search did not establish a predictive advantage over the existing opportunity ridge. It is exhaustive within this finite dictionary only, not all mathematical functions or all unseen traits. Historical outcomes had already been examined. None is a pristine holdout, and tracking reconstruction does not establish archival pregame availability. Resampling adds no observations. No new data, production engine, repository push or contest action was taken.
