CURRY HISTORICAL SALARY AUDIT — SAVED SOURCES ONLY
Audit date: October 12, 2026. No new acquisition, paid data, model fit, or salary imputation.

RESULT
Of the 187 audited positive-minute regular-season appearances (74 / 70 / 43):
2023–24: DK 0/74; FD 0/74.
2024–25: DK 59/70; FD 59/70.
2025–26: DK 37/43; FD 38/43.
Total: DK 96/187; FD 97/187. These are salary-linked appearance dates, NOT counts of verified operator slates or pregame snapshots.

EVIDENCE STRENGTH
1. Actual saved contest/pool context covers only 2025–26: DK 18 dates, FD 15 dates. DK contains 38 source contest dictionaries on 14 dates, plus 6 pool-export observations on 5 dates (opening night overlaps). FD contains 23 export observations on 15 dates: 15 recovered file versions on 12 dates plus 8 SaberSim main exports on 8 dates.
2. Generic dated/game-linked salaries in the owner-held BigDataBall-labeled workbook add substantial history: 59 dates per site in 2024–25 and 35 DK / 36 FD dates in 2025–26. The workbook explicitly labels its salary columns DraftKings Classic and FanDuel Full Roster. Its individual operator slate IDs are unavailable. This tier must not silently become a verified main-slate salary or pregame-captured predictor.
3. No preserved salary source establishes a verified pregame capture timestamp. Historical date labels, source modification times, archived projection fields, and later retrieval times are not proof of contemporaneous prelock capture. All pregame verification fields are false, with as-of timestamps empty.

IMPORTANT DISCOVERY
The owner-held workbook sheet named "2019-2021" actually contains 2024–25 and 2025–26 records. NBA person ID 201939 and exact dates, team/opponent and normalized game IDs identify Curry. All 59 2024–25 salary dates have his explicit NBA person ID; 51 also have an exact normalized game ID, while 8 have blank source game IDs and are joined by exact person/date/team/opponent. Zero-padding numeric NBA game IDs is formatting restoration, not an inferred game match. The first sheet and "2019-2021" duplicate 37 2025–26 game records; duplicated salary observations are preserved and explicitly marked so coverage is never inflated.

SALARY VERSIONS, POOLS AND SLATE TYPE
No matched date/site has different positive numeric salary values across the saved sources checked. The long data retain every separate contest, export version and workbook cell provenance rather than selecting one arbitrary salary. The compact distinct-values data combine equal salary values while listing all evidence IDs and pool/contest IDs.
The bounded 94-pool FD layer omitted two recovered CSV file versions, including a second Jan 30 version with Curry; the original 87-file archive preserves these. The extra matched Jan 30 version adds an observation but no appearance date or different salary. The original archive is used here.
All 38 matched DK contest dictionaries have ordinary positional roster evidence; 12 are independently labeled Classic in the saved catalogue. Another 23 have complete standard eight-position roster sets. Three Nov 18 dictionaries contain both standard eight-slot and incomplete seven-slot entries, so their slate type is left unknown conservatively. Recovered generic CSV exports without confirmed style metadata remain unknown; SaberSim Main export provenance and workbook column headers support their labeled full-roster types. No matched Showdown-specific or captain-multiplier salary was identified. Absence of a Showdown record is not a guarantee that every unknown slate is Classic.
Native operator slate IDs remain unverified. An assisted catalogue slate key, pool name or provider player ID is preserved without being promoted into a verified native slate ID.

OUTCOMES AND VALUE CALCULATION
All analysis outcomes come from outputs/curry_full_three_season_inventory.csv, joined on Curry's canonical person/date/game identity. Both DK and FD actual-score reconstructions are included, and points_per_1000_salary uses only the matching site's actual score divided by salary/1000. These scores are reconstructed outcomes, not independent operator settlement verification.
Six 2024–25 workbook rows have reversed DK and FD source-score cells: Nov 12, 15, 18, 20, 22 and 23, 2024. The raw source scores and discrepancy flags are preserved, while the audited outcome inventory supplies the correct site score. No source score was used to infer identity or overwrite the audited outcome.
No 5x or other universal threshold has been labeled a ceiling. Missing salary is unknown, never zero or imputed. Salaries for dates where Curry is not in the 187 positive-appearance inventory are retained separately, with no zero outcome inferred for DNP, absent, postponed or out-of-scope dates.

EXAMPLES (DESCRIPTIVE, MATCHED SITE)
2025-04-01, Memphis: DK 95.00 / $9,100 = 10.4396 per $1k; FD 92.00 / $8,600 = 10.6977. Generic workbook evidence.
2025-10-23, Denver: DK 70.00 / $9,000 = 7.7778; FD 69.70 / $8,400 = 8.2976. Generic workbook evidence.
2025-11-11, Oklahoma City: DK 14.25 / $8,800 = 1.6193; FD 14.20 / $8,200 = 1.7317. DK has contest and workbook evidence; FD generic workbook evidence.
2026-01-07, Milwaukee: DK 50.00 / $8,700 = 5.7471; FD 47.70 / $8,800 = 5.4205. FD has a saved Main pool export; DK generic workbook evidence.

REMAINING MISSING DATES
2023–24: all 74 appearances, both sites.
2024–25: Dec 6, 8, 11, 15, 2024; Apr 3, 4, 6, 8, 9, 11, 13, 2025; both sites.
2025–26: Jan 25 and Apr 5, 7, 10, 12, 2026, both sites; additionally Dec 31, 2025 for DK.

FILES
curry_salary_evidence_long.csv: 327 matched positive-salary evidence rows, full source, pool/contest, raw and canonical identity, slate/as-of flags, actual scores and value. Workbook copy duplicates remain marked.
curry_salary_distinct_game_site_values.csv: 193 distinct game/site/salary values with every supporting evidence ID. This is the simplest salary-relative join without repeated contest weighting.
curry_salary_game_site_coverage.csv: complete 374-row grid (187 games times 2 sites), salary availability, all distinct values/range, evidence-tier coverage and value ranges. Missing values stay blank.
curry_salary_coverage_by_season_site.csv: six summary rows.
curry_salary_all_observations_including_unmatched.csv and curry_salary_excluded_or_missing.csv: preserved source rows beyond the target appearances and missing/non-numeric salaries.
curry_salary_source_score_discrepancies.csv: explicit source-score conflicts, with correct audited scores.
curry_saved_workbook_rows.csv/json: exact raw workbook-cell extraction, with original sheet and Excel row.
used_source_inventory.csv: actual source files and SHA-256 hashes.
searched_csv_source_inventory.csv and saved_csv_source_inventory.json: 513 candidate salary-schema CSV paths, 217 unique byte hashes, no scan errors, including duplicate paths.
raw_contest_dictionary_inventory.csv: 325 original saved contest dictionaries inspected across seven source ZIPs; includes source member hashes and Curry presence.
workbook_sheet_inventory.json: all 23 workbook sheets inspected, initial headers and Curry salary-table rows.
parquet_schema_inventory.json: 27 NBA Parquet schemas inspected; none has a salary field.
zip_member_inventory.json: 92 NBA archive member listings inspected for hidden salary/workbook inputs. Listing inspection is not a claim that every unrelated member was parsed.
salary_audit_validation.json and independent_salary_verification.json: output counts, coverage, formulas, provenance and direct literal workbook-salary-cell checks.

REPRODUCTION
Run scan_saved_salary_csv.py, extract_saved_workbook.py, inventory_saved_containers.py, build_curry_salary_audit.py, then verify_curry_salary_audit.py from this directory or with absolute script paths. The code uses saved workspace sources only. The scope is the currently saved NBA workspace and owner-provided workbook, not a claim that no other historical salary data exists elsewhere.
