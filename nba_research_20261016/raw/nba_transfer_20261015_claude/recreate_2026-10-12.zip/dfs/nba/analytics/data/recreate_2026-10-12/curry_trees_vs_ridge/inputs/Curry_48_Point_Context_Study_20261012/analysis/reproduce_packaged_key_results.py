"""Portable re-aggregation of the included outcome, membership and saved-probability extracts."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
def read(p):
 return pd.read_csv(R/p,dtype={'game_id':str})
def eq(a,b):
 assert np.isclose(a,b,rtol=1e-10,atol=1e-10),(a,b)
ledger=read('Curry_48_Point_Game_Ledger_20261012.csv')
assert len(ledger)==187 and ledger.game_id.nunique()==187
assert (ledger.dk>=48).sum()==67 and (ledger.fd>=48).sum()==46
assert ledger.dk_salary_salary.notna().sum()==96
assert ledger.fd_salary_salary.notna().sum()==97
hi=read('outputs/curry_67_DK_high_games_source_ledger.csv')
assert set(hi.game_id)==set(ledger.loc[ledger.dk>=48,'game_id'])
mem=read('outputs/curry_pregame_identifier_game_membership.csv')
score=read('outputs/curry_pregame_identifier_scorecard.csv')
for _,s in score.iterrows():
 g=mem[(mem.candidate==s.candidate)&(mem.restriction==s.restriction)].copy()
 known=g.known_context.astype(str).str.lower().eq('true')
 selected=g.selected.astype(str).str.lower().eq('true') & known
 hit=g.dk.ge(48)
 n=int(selected.sum()); h=int(hit[selected].sum()); en=int(known.sum()); eh=int(hit[known].sum())
 for x,y in [(len(g),s.scope_n),(n,s.selected_n),(h,s.hits48),(n-h,s.false_positives),(en,s.eligible_n),(eh,s.eligible_hits48),(h/n,s.precision),(eh/en,s.same_eligible_baseline),(h/67,s.recall_of_all67),(g.loc[selected,'dk'].mean(),s.dk_mean_selected),(g.loc[selected,'dk'].median(),s.dk_median_selected),(g.loc[selected,'dk'].quantile(.9),s.dk_q90_selected)]:eq(x,y)
pred=read('outputs/curry_existing_model_fixed48_predictions.csv'); mod=read('outputs/curry_existing_model_fixed48_scorecard.csv')
for _,s in mod.iterrows():
 g=pred[(pred.fit_window==s.fit_window)&(pred.site==s.site)&(pred.model==s.model)].sort_values(['p48','date','game_id'],ascending=[False,True,True],kind='stable')
 k=int(np.ceil(.2*len(g)));top=g.iloc[:k];ties=g[g.p48>=top.p48.iloc[-1]]
 for x,y in [(len(g),s.n),(g.hit48.sum(),s.hits48),(g.p48.mean(),s.mean_predicted_p48),(((g.p48-g.hit48)**2).mean(),s.brier),(top.hit48.sum(),s.top20_hits),(len(ties),s.tie_inclusive_n),(ties.hit48.sum(),s.tie_inclusive_hits)]:eq(x,y)
print(json.dumps({'status':'PASS','games':187,'DK48_hits':67,'FD48_hits':46,'DK_salary_games':96,'FD_salary_games':97,'candidate_rows_reproduced':len(score),'saved_model_scorecards_reproduced':len(mod)},indent=2))
