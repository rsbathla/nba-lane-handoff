from pathlib import Path
import openpyxl,json,hashlib,pandas as pd
BASE=Path('/workspace/scratch/0bd466b49713');out=BASE/'nba_interaction_pilot_20261012/curry_condition_overlay_20261012/salary_audit'
p=BASE/'attachments/e9cd7073-a049-403e-b54b-3014ad59a527/NBA 2025 (1) (2) (2).xlsx'
w=openpyxl.load_workbook(p,read_only=True,data_only=True);rows=[];sheets=[]
for s in w:
 headers=[];isdfs=False;found=[]
 for i,row in enumerate(s.iter_rows(values_only=True),1):
  if i<=4:
   headers.append([str(v) if v is not None else None for v in row]);isdfs|=any('Classic' in str(v) for v in row)
  if not isdfs:continue
  if len(row)>4 and (str(row[3])=='201939' or row[4]=='Stephen Curry'):
   found.append(dict(source_file=str(p.relative_to(BASE)),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_sheet=s.title,source_excel_row=i,dataset=row[0],game_id=row[1],date=row[2],person_id=row[3],player=row[4],team=row[5],opponent=row[6],minutes=row[9],dk_position=row[12],fd_position=row[13],dk_salary=row[15],fd_salary=row[16],dk_source_score=row[18],fd_source_score=row[19]))
 rows.extend(found);sheets.append({'sheet':s.title,'declared_rows':s.max_row,'dfs_salary_table':isdfs,'curry_rows':len(found),'first_four_rows':headers})
(out/'curry_saved_workbook_rows.json').write_text(json.dumps(rows,indent=2,default=str));(out/'workbook_sheet_inventory.json').write_text(json.dumps(sheets,indent=2,default=str))
d=pd.DataFrame(rows);d['date']=pd.to_datetime(d.date).dt.strftime('%Y-%m-%d');d.to_csv(out/'curry_saved_workbook_rows.csv',index=False)
inv=pd.read_csv(out.parent/'outputs/curry_full_three_season_inventory.csv',dtype={'game_id':str});q=d.merge(inv[['date','game_id','season']],on='date',suffixes=('_source','_canonical'));q['dk_salary']=pd.to_numeric(q.dk_salary,errors='coerce');q['fd_salary']=pd.to_numeric(q.fd_salary,errors='coerce');print('Total source rows',len(d),'Matched by date for inspection',len(q));print(q.groupby(['season','source_sheet']).agg(rows=('date','size'),dates=('date','nunique'),dk_numeric_salary=('dk_salary','count'),fd_numeric_salary=('fd_salary','count')).to_string());print('Full identity checks are applied by build_curry_salary_audit.py.');print('all',d.groupby(['source_sheet','dataset'],dropna=False).size().to_string())
