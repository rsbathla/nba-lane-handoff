"""Read-only source audit. Writes only new audit deliverables; no acquisition or models.
Run scan_saved_salary_csv.py, extract_saved_workbook.py, then this script.
"""
from pathlib import Path
import csv, gzip, hashlib, json, re, sys, zipfile
import numpy as np
import pandas as pd
BASE=Path('/workspace/scratch/0bd466b49713')
OUT=Path(__file__).resolve().parent
INV=OUT.parent/'outputs/curry_full_three_season_inventory.csv'
THREE=BASE/'nba_interaction_pilot_20261012/inputs/three_season'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rel(p):return str(Path(p).relative_to(BASE))
def num(v):
 try:
  f=float(v)
  return f if np.isfinite(f) else np.nan
 except:return np.nan
def gid(v):
 try:return str(int(float(v))).zfill(10)
 except:return ''
def clean(v):return '' if pd.isna(v) else str(v)
TEAM={'Golden State':'GSW','GS':'GSW','LA Lakers':'LAL','Denver':'DEN','Portland':'POR','Memphis':'MEM','LA Clippers':'LAC','Milwaukee':'MIL','Indiana':'IND','Phoenix':'PHX','Oklahoma City':'OKC','San Antonio':'SAS','New Orleans':'NOP','Orlando':'ORL','Utah':'UTA','Houston':'HOU','Minnesota':'MIN','Dallas':'DAL','Toronto':'TOR','Brooklyn':'BKN','Charlotte':'CHA','Sacramento':'SAC','Atlanta':'ATL','New York':'NYK','Miami':'MIA','Washington':'WAS','Boston':'BOS','Cleveland':'CLE','Philadelphia':'PHI','Detroit':'DET','Chicago':'CHI'}
def team(v):
 s=clean(v).replace('vs ','').replace('@ ','').strip();return TEAM.get(s,s)
inv=pd.read_csv(INV,dtype={'game_id':str,'person_id':str});assert len(inv)==187 and inv.date.nunique()==187
bydate=inv.set_index('date').to_dict('index');records=[];sources=[];raw_archive_rows=[]
def source(p,role,**kwargs):
 p=Path(p);r={'source_file':rel(p),'sha256':sha(p),'bytes':p.stat().st_size,'role':role}|kwargs;sources.append(r);return r

def add(**r):
 r.setdefault('source_game_id_raw','');r.setdefault('source_person_id_raw','');r.setdefault('source_player','Stephen Curry')
 r.setdefault('source_team','GSW');r.setdefault('source_opponent','');r.setdefault('source_dk_score',np.nan);r.setdefault('source_fd_score',np.nan)
 r.setdefault('source_row','');r.setdefault('source_sheet','');r.setdefault('source_member','');r.setdefault('source_capture_at_utc','')
 r.setdefault('native_operator_slate_id','');r.setdefault('assisted_slate_key','');r.setdefault('slate_name','');r.setdefault('contest_title','')
 r.setdefault('slate_operator_id_verified',False);r.setdefault('classic_metadata_verified',False)
 r['pregame_capture_verified']=False;r['pregame_asof_utc']='';r['asof_status']='historical_archive; capture_not_verified_pregame'
 r['salary']=num(r['salary']);r['salary_numeric_positive']=bool(pd.notna(r['salary']) and r['salary']>0)
 r['person_id']='201939';r['source_game_id_normalized']=gid(r['source_game_id_raw'])
 match=bydate.get(r['date']);r['matched_inventory_appearance']=False;r['join_status']='date_not_in_187_regular_season_positive_appearances'
 r['season']='';r['game_id']='';r['dk_actual_score']=np.nan;r['fd_actual_score']=np.nan;r['actual_score']=np.nan;r['points_per_1000_salary']=np.nan
 if match:
  idok=not clean(r['source_person_id_raw']) or gid(r['source_person_id_raw'])==gid('201939')
  gameok=not r['source_game_id_normalized'] or r['source_game_id_normalized']==match['game_id']
  opponentok=not clean(r['source_opponent']) or team(r['source_opponent'])==match['opponent']
  teamok=not clean(r['source_team']) or team(r['source_team'])==match['team']
  assert idok and gameok and opponentok and teamok,(r,match)
  r.update(season=match['season'],game_id=match['game_id'],dk_actual_score=match['dk'],fd_actual_score=match['fd'],actual_score=match[r['site']],matched_inventory_appearance=True)
  r['join_status']='exact_person_date_game' if r['source_game_id_normalized'] else ('exact_person_date_team_opponent; source_game_id_missing' if clean(r['source_person_id_raw']) else 'exact_name_date_team_opponent; source_nba_game_and_person_ids_missing')
  if r['salary_numeric_positive']:r['points_per_1000_salary']=r['actual_score']/(r['salary']/1000.)
 r['outcome_source_file']=rel(INV);r['outcome_source_sha256']=sha(INV);r['actual_score_basis']='audited_Curry_inventory_box_formula_reconstruction; not_operator_settlement_verification'
 r['source_dk_minus_audited']=num(r['source_dk_score'])-r['dk_actual_score'];r['source_fd_minus_audited']=num(r['source_fd_score'])-r['fd_actual_score']
 r['source_score_discrepancy']=bool((pd.notna(r['source_dk_minus_audited']) and abs(r['source_dk_minus_audited'])>1e-7) or (pd.notna(r['source_fd_minus_audited']) and abs(r['source_fd_minus_audited'])>1e-7))
 r['evidence_id']=hashlib.sha256('|'.join(str(r.get(k,'')) for k in ['site','source_sha256','source_sheet','source_row','source_member','pool_or_contest_id','date','salary']).encode()).hexdigest()[:20]
 records.append(r)

# 1. Original owner-held workbook, all historically dated DFS salary tables.
workbook=BASE/'attachments/e9cd7073-a049-403e-b54b-3014ad59a527/NBA 2025 (1) (2) (2).xlsx'
source(workbook,'owner-held DFS workbook; header labels DK Classic and FD Full Roster; generic slate identity')
for r in json.loads((OUT/'curry_saved_workbook_rows.json').read_text()):
 date=pd.to_datetime(r['date']).strftime('%Y-%m-%d')
 for site in ['dk','fd']:
  add(site=site,date=date,salary=r[f'{site}_salary'],source_file=r['source_file'],source_sha256=r['source_sha256'],source_sheet=r['source_sheet'],source_row=r['source_excel_row'],pool_or_contest_id='',source_family='owner_held_dfs_workbook',evidence_tier='game_linked_generic_site_salary',source_game_id_raw=r['game_id'],source_person_id_raw=r['person_id'],source_team=r['team'],source_opponent=r['opponent'],source_dk_score=r['dk_source_score'],source_fd_score=r['fd_source_score'],slate_type='Classic' if site=='dk' else 'Full Roster',slate_type_basis='original_workbook_row2_salary_column_header',position=r[f'{site}_position'],dataset_label=r['dataset'])

# 2. Original recovered provider CSVs, preserved individually, including versions omitted by pool reduction.
rec=BASE/'nba_recovered_validation_20261010/normalized/salary_position_source_preserving.csv'
source(rec,'normalized source-preserving recovered snapshots')
ziprec=BASE/'nba_recovered_validation_20261010/raw/NBA_2025_26_Missing_Salary_Position_Snapshots.zip'
source(ziprec,'original archived CSV members, hash verified')
norm=pd.read_csv(rec);norm=norm[norm.player.eq('Stephen Curry')]
fdpres=THREE/'nba_three_season_ceiling_20261011/integrated_context/fd_preserved_pool_salary_box_join.csv.gz'
fd=pd.read_csv(fdpres);fd=fd[fd.source_player_name.eq('Stephen Curry')]
source(fdpres,'bounded FD 94-pool integrated context; used for pool identifiers and identity provenance')
poolmap=fd.set_index('original_salary_source').to_dict('index')
with zipfile.ZipFile(ziprec) as z:
 for idx,r in norm.iterrows():
  m='originals/'+r.source_file;b=z.read(m);assert hashlib.sha256(b).hexdigest()==r.source_sha256
  rawlines=b.decode('utf-8-sig').splitlines();header_idx=next(i for i,l in enumerate(rawlines) if l.startswith('Player,'))
  rawrows=list(csv.DictReader(rawlines[header_idx:]));matches=[(i+header_idx+2,x) for i,x in enumerate(rawrows) if x['Player']=='Stephen Curry'];assert len(matches)==1
  rownum,rr=matches[0];assert num(rr['Salary'])==num(r.salary_as_exported)
  extra=poolmap.get(r.source_file,{})
  add(site='dk' if r.site=='draftkings' else 'fd',date=r.slate_date_from_filename,salary=r.salary_as_exported,source_file=rel(ziprec),source_sha256=r.source_sha256,source_container_sha256=sha(ziprec),source_member=m,source_row=rownum,pool_or_contest_id=extra.get('pool_id','snapshot:'+r.source_sha256[:16]),source_family='recovered_salary_snapshot',evidence_tier='dated_player_pool_snapshot',source_team=r.team,source_opponent=r.opponent,source_game_id_raw=extra.get('game_id',''),source_person_id_raw=extra.get('person_id',''),slate_type='unknown',slate_type_basis='position_salary_export_no_confirmed_contest_style',position=r.position_as_exported,source_derivative_file=rel(rec))

# 3. Original saved SaberSim main exports (copies hash-deduplicated across the workspace).
for p in sorted(BASE.glob('*_nba_*/sabersim_*_main_original.csv')):
 d=pd.read_csv(p);q=d[d.Name.eq('Stephen Curry')]
 source(p,'SaberSim historical main pool original export',curry_rows=len(q))
 for idx,r in q.iterrows():
  site='dk' if p.name.startswith('sabersim_dk') else 'fd';date=re.search(r'\d{4}-\d{2}-\d{2}',p.name).group()
  extra=poolmap.get(rel(p),{})
  add(site=site,date=date,salary=r.Salary,source_file=rel(p),source_sha256=sha(p),source_row=idx+2,pool_or_contest_id=extra.get('pool_id',f'sabersim_main_{date}'),source_family='sabersim_main',evidence_tier='dated_player_pool_snapshot',source_team=r.Team,source_opponent=r.Opp,source_game_id_raw=extra.get('game_id',''),source_person_id_raw=extra.get('person_id',''),slate_type='Classic' if site=='dk' else 'Full Roster',slate_type_basis='preserved_Main_export_provenance',position=r.Pos,operator_player_id=str(r['DFS ID']),source_dk_score=r.Actual if site=='dk' else np.nan,source_fd_score=r.Actual if site=='fd' else np.nan)

# 4. Original FantasyLabs archive idmap: one row per source contest dictionary, not repeated entry copies.
meta_path=BASE/'nba_full_season_study/owned_archive_20261009/ingestion/contest_acceptance_inventory.corrected_roles.csv'
source(meta_path,'contest style/slate metadata with native-identity limits preserved')
meta=pd.read_csv(meta_path).set_index('contest_key').to_dict('index');archive_inventory=[]
for p in sorted((BASE/'nba_full_season_study/owned_archive_20261009/library_inputs').glob('*Research*zip')):
 sr=source(p,'owner-held FantasyLabs historical contest dictionaries')
 with zipfile.ZipFile(p) as z:
  for member in z.namelist():
   if not member.startswith('users/'):continue
   b=z.read(member);d=json.loads(gzip.decompress(b));ck='DK:'+str(d['contestId']);md=meta.get(ck,{})
   found=[(pid,r) for pid,r in d.get('idmap',{}).items() if isinstance(r,list) and r[0]=='Stephen Curry']
   archive_inventory.append({'source_file':rel(p),'source_member':member,'member_sha256':hashlib.sha256(b).hexdigest(),'date':d['date'],'contest_key':ck,'curry_rows':len(found)})
   if not found:continue
   lm=member.replace('users/','lineups/');ld=json.loads(gzip.decompress(z.read(lm)));slots=sorted({tuple(sorted(v.get('lineupPlayers',{}))) for v in ld.get('lineups',{}).values()})
   classic_slots=bool(slots and all(set(s)==set(['C1','F1','G1','PF1','PG1','SF1','SG1','UTIL1']) for s in slots))
   style='Classic' if md.get('classic_style_established') is True or classic_slots else 'unknown'
   basis='saved_catalogue_Classic_metadata' if md.get('classic_style_established') is True else ('observed_8_standard_DK_roster_slots; native_slate_identity_unverified' if classic_slots else 'unverified')
   for pid,r in found:
    raw_archive_rows.append({'source_zip':rel(p),'source_member':member,'date':d['date'],'contest_id':d['contestId'],'source_player_id':pid,'raw_idmap':r})
    add(site='dk',date=d['date'],salary=r[3],source_file=rel(p),source_sha256=hashlib.sha256(b).hexdigest(),source_container_sha256=sr['sha256'],source_member=member,source_row='idmap:'+str(pid),pool_or_contest_id=ck,source_family='fantasylabs_saved_contest_dictionary',evidence_tier='contest_linked_salary',source_team=r[2],source_opponent='',source_dk_score=r[6],source_event_id=r[7],source_provider_player_id=pid,slate_type=style,slate_type_basis=basis,position=r[1],classic_metadata_verified=md.get('classic_style_established') is True,assisted_slate_key=clean(md.get('assisted_slate_key','')),slate_name=clean(md.get('assisted_slate_name','')),contest_title=clean(md.get('title','')),observed_roster_slot_sets=json.dumps(slots))

allrows=pd.DataFrame(records);assert not allrows.evidence_id.duplicated().any()
allrows['source_workbook_duplicate_of']=''
# Preserve workbook evidence locations, but mark duplicates in same workbook with same date/game/site/value.
wb=allrows[allrows.source_family.eq('owner_held_dfs_workbook')]
for _,g in wb.groupby(['source_file','date','site','salary'],dropna=False):
 if len(g)>1:
  first=g.index[0]
  for i in g.index[1:]:allrows.loc[i,'source_workbook_duplicate_of']=allrows.loc[first,'evidence_id']
matched=allrows[allrows.matched_inventory_appearance & allrows.salary_numeric_positive].copy()
matched.to_csv(OUT/'curry_salary_evidence_long.csv',index=False)
allrows.to_csv(OUT/'curry_salary_all_observations_including_unmatched.csv',index=False)
allrows[~allrows.matched_inventory_appearance | ~allrows.salary_numeric_positive].to_csv(OUT/'curry_salary_excluded_or_missing.csv',index=False)
allrows[allrows.source_score_discrepancy].to_csv(OUT/'curry_salary_source_score_discrepancies.csv',index=False)
summary=[]
for r in inv.to_dict('records'):
 for site in ['dk','fd']:
  q=matched[(matched.date==r['date']) & (matched.site==site)];vals=sorted(q.salary.unique());pool=q[q.evidence_tier.ne('game_linked_generic_site_salary')]
  summary.append({**{k:r[k] for k in ['season','date','game_id','person_id','player','team','opponent','dk','fd']},'site':site,'salary_available':bool(vals),'salary_missing_is_unknown':not bool(vals),'salary_distinct_values':';'.join(str(int(x)) for x in vals),'salary_distinct_count':len(vals),'salary_min':min(vals) if vals else np.nan,'salary_max':max(vals) if vals else np.nan,'salary_evidence_rows':len(q),'source_observations_after_workbook_copy_dedup':len(q[q.source_workbook_duplicate_of.eq('')]),'contest_or_pool_observations':len(pool),'contest_or_pool_ids':';'.join(sorted(pool.pool_or_contest_id.unique())),'contest_or_pool_salary_available':bool(len(pool)),'generic_workbook_salary_available':bool(q.evidence_tier.eq('game_linked_generic_site_salary').any()),'slate_types_present':';'.join(sorted(q.slate_type.unique())),'verified_pregame_salary_available':False,'actual_score':r[site],'points_per_1000_min':r[site]/(max(vals)/1000) if vals else np.nan,'points_per_1000_max':r[site]/(min(vals)/1000) if vals else np.nan})
coverage=pd.DataFrame(summary);coverage.to_csv(OUT/'curry_salary_game_site_coverage.csv',index=False)
distinct=[]
for keys,g in matched.groupby(['season','date','game_id','person_id','site','salary']):
 distinct.append(dict(zip(['season','date','game_id','person_id','site','salary'],keys))|{'dk_actual_score':g.dk_actual_score.iloc[0],'fd_actual_score':g.fd_actual_score.iloc[0],'actual_score':g.actual_score.iloc[0],'points_per_1000_salary':g.points_per_1000_salary.iloc[0],'evidence_rows':len(g),'pool_or_contest_ids':';'.join(sorted(set(g.pool_or_contest_id.dropna())-{''})),'evidence_tiers':';'.join(sorted(g.evidence_tier.unique())),'slate_types':';'.join(sorted(g.slate_type.unique())),'source_evidence_ids':';'.join(g.evidence_id),'pregame_capture_verified':False})
pd.DataFrame(distinct).to_csv(OUT/'curry_salary_distinct_game_site_values.csv',index=False)
season=coverage.groupby(['season','site']).agg(appearances=('date','size'),salary_linked_appearances=('salary_available','sum'),contest_or_pool_linked_appearances=('contest_or_pool_salary_available','sum'),generic_workbook_linked_appearances=('generic_workbook_salary_available','sum'),multiple_salary_values=('salary_distinct_count',lambda s:int((s>1).sum())),pregame_verified=('verified_pregame_salary_available','sum')).reset_index();season['salary_missing_appearances']=season.appearances-season.salary_linked_appearances;season.to_csv(OUT/'curry_salary_coverage_by_season_site.csv',index=False)
pd.DataFrame(sources).to_csv(OUT/'used_source_inventory.csv',index=False)
pd.DataFrame(archive_inventory).to_csv(OUT/'raw_contest_dictionary_inventory.csv',index=False)
(OUT/'curry_raw_contest_dictionary_rows.json').write_text(json.dumps(raw_archive_rows,indent=2,default=str))
# Save all examined CSV candidate paths and their deduplication relation in an accessible flat inventory.
scan=json.loads((OUT/'saved_csv_source_inventory.json').read_text());pd.DataFrame(scan).to_csv(OUT/'searched_csv_source_inventory.csv',index=False)
check={'audited_at_utc':'2026-10-12','inventory_rows':len(inv),'coverage_rows':len(coverage),'matched_salary_evidence_rows':len(matched),'distinct_game_site_salary_rows':len(distinct),'salary_coverage_by_season_site':season.to_dict('records'),'multiple_salary_value_game_sites':int((coverage.salary_distinct_count>1).sum()),'source_score_discrepancy_rows':int(allrows.source_score_discrepancy.sum()),'source_score_discrepancy_distinct_dates':allrows[allrows.source_score_discrepancy].date.nunique(),'verified_pregame_captures':0,'showdown_rows_found':int(matched.slate_type.eq('Showdown').sum()),'raw_contest_dictionaries_examined':len(archive_inventory),'csv_candidates_examined':len(scan),'csv_unique_byte_hashes':len({x.get('sha256') for x in scan if x.get('sha256')}),'no_new_acquisition':True,'no_model_fit':True,'no_salary_imputation':True,'no_5x_ceiling_assumption':True}
(OUT/'salary_audit_validation.json').write_text(json.dumps(check,indent=2,default=str))
print(season.to_string(index=False));print(json.dumps({k:v for k,v in check.items() if k!='salary_coverage_by_season_site'},indent=2));print('MISSING2025',coverage[(coverage.season=='2025-26') & ~coverage.salary_available][['site','date']].to_dict('records'));print('SOURCES',matched.groupby(['site','evidence_tier']).agg(rows=('date','size'),dates=('date','nunique')).to_string())
