"""User-chosen inclusive 48-point outcome: direct joint cells and uncertainty, no model."""
from pathlib import Path
import json,hashlib,datetime
import numpy as np,pandas as pd
R=Path(__file__).resolve().parents[1];SEED=20261012;B=500

def read(path):
 d=pd.read_csv(path,dtype={'game_id':str,'person_id':str});d['game_id']=d.game_id.str.replace(r'\.0$','',regex=True).str.zfill(10);return d
z=read(R/'outputs/curry_core_advanced_role_context.csv');z['date']=pd.to_datetime(z.date);market=read(R/'outputs/curry_fixed48_context_ledger.csv');mc=[c for c in market if c.startswith(('opening_','closing_')) or c in ['home_away','team_days_since_previous_game','team_rest_bin']];z=z.merge(market[['game_id']+mc],on='game_id',how='left',validate='one_to_one')
# Previous core B2B marks missing first fixture as false; use source-certified chronology instead.
z['team_b2b_verified']=np.where(z.team_days_since_previous_game.notna(),z.team_days_since_previous_game.eq(1).astype(float),np.nan)
te=read(R/'coverage_curry_teammate_coappearances_187_games.csv')
for pid,label in [('203110','green'),('202710','butler')]:
 games=set(te.loc[te.teammate_person_id.astype(str).eq(pid),'game_id']);z['observed_'+label+'_played']=z.game_id.isin(games)
for s in ['dk','fd']:z[s+'_ge48']=z[s]>=48
z.to_csv(R/'outputs/curry_fixed48_integrated_game_ledger.csv',index=False)
(R/'outputs/curry_48plus_dates_scores_minutes.csv').write_text(z[z.dk_ge48][['season','date','game_id','opponent','home_away','minutes','dk','fd','fga','fg3a','fg3m','fta','usage_proxy','team_b2b_verified','observed_green_played','observed_butler_played']].to_csv(index=False))

def wilson(k,n):
 if n==0:return np.nan,np.nan
 p=k/n;a=1.959963984540054**2;den=1+a/n;mid=(p+a/(2*n))/den;half=1.959963984540054*np.sqrt(p*(1-p)/n+a/(4*n*n))/den;return mid-half,mid+half

def block_indices(a,seed=SEED):
 rng=np.random.default_rng(seed);allix=[]
 for _,g in a.groupby('season',sort=True):
  ix=np.asarray(g.index);n=len(ix);st=rng.integers(0,n,(B,int(np.ceil(n/7))));rel=((st[:,:,None]+np.arange(7))%n).reshape(B,-1)[:,:n];allix.append(ix[rel])
 return np.concatenate(allix,axis=1)

# Direct joint cells, no multiplication or addition of separate associations.
specs=[
 ('home_away_x_team_B2B','all','history_schedule','away',lambda a:a.home_away.eq('away'),'team_B2B',lambda a:a.team_b2b_verified.eq(1),lambda a:a.home_away.notna()&a.team_b2b_verified.notna()),
 ('prior_minutes_x_prior_usage','all','lagged_game_history','prior5_minutes_atleast34',lambda a:a.minutes_lag5>=34,'prior10_usage_atleast32',lambda a:a.usage_proxy_lag10>=32,lambda a:a.minutes_lag5.notna()&a.usage_proxy_lag10.notna()),
 ('actual_minutes_x_actual_3PA','all','actual_game_explanatory','actual_minutes_atleast35',lambda a:a.minutes>=35,'actual_3PA_atleast14',lambda a:a.fg3a>=14,lambda a:a.minutes.notna()&a.fg3a.notna()),
 ('Butler_played_x_close_spread','2025-26','actual_coappearance_and_uncertified_historical_market','Butler_observed_playing',lambda a:a.observed_butler_played,'absolute_closing_spread_below5',lambda a:a.closing_spread.abs()<5,lambda a:a.closing_spread.notna()),
 ('Butler_played_x_team_B2B','2025-26','actual_coappearance_and_history_schedule','Butler_observed_playing',lambda a:a.observed_butler_played,'team_B2B',lambda a:a.team_b2b_verified.eq(1),lambda a:a.team_b2b_verified.notna()),
 ('creator_x_spacing_roles','all','actual_coappearance_with_prior_role_proxies','atleast2_creator_proxies',lambda a:a.played_creator_proxy_count>=2,'atleast3_spacing_proxies',lambda a:a.played_spacing_proxy_count>=3,lambda a:a.played_creator_proxy_count.notna()&a.played_spacing_proxy_count.notna())]
rows=[];membership=[]
for name,scope,layer,an,af,bn,bf,knownf in specs:
 a=z.copy() if scope=='all' else z[z.season.eq(scope)].copy();known=knownf(a);a['condition_a']=np.where(known,af(a),np.nan);a['condition_b']=np.where(known,bf(a),np.nan)
 for site in ['dk','fd']:
  for av,bv in [(False,False),(False,True),(True,False),(True,True)]:
   g=a[known&af(a).eq(av)&bf(a).eq(bv)];hits=int(g[site+'_ge48'].sum());n=len(g);lo,hi=wilson(hits,n);rows.append({'comparison':name,'scope':scope,'layer':layer,'condition_a':an,'condition_a_value':av,'condition_b':bn,'condition_b_value':bv,'site':site,'n':n,'known_context_n':int(known.sum()),'missing_context_n':int((~known).sum()),'hits48':hits,'misses48':n-hits,'hit_rate':hits/n if n else np.nan,'hit_rate_wilson95_low':lo,'hit_rate_wilson95_high':hi,'mean':g[site].mean(),'median':g[site].median(),'q90':g[site].quantile(.9),'q95':g[site].quantile(.95),'residual_n':g[site+'_residual'].notna().sum(),'residual_mean':g[site+'_residual'].mean(),'atleast10_games':n>=10,'dates':';'.join(g.date.dt.strftime('%Y-%m-%d'))})
 for row in a.itertuples():membership.append({'game_id':row.game_id,'comparison':name,'condition_a':row.condition_a,'condition_b':row.condition_b})
pd.DataFrame(rows).to_csv(R/'outputs/curry_fixed48_joint_context_cells.csv',index=False);pd.DataFrame(membership).to_csv(R/'outputs/curry_fixed48_joint_context_membership.csv',index=False)
# Context means in high games vs misses for every core/advanced/role field.
fi=pd.read_csv(R/'outputs/core_field_inventory.csv');comps=[]
for s in ['dk','fd']:
 for f in fi.to_dict('records'):
  name=f['field'];hit=z[s+'_ge48'];v=z[name];h=v[hit];lo=v[~hit];comps.append({'outcome':s+'_ge48_inclusive','field':name,'layer':f['layer'],'high_games':int(hit.sum()),'low_games':int((~hit).sum()),'high_known':int(h.notna().sum()),'high_missing':int(h.isna().sum()),'low_known':int(lo.notna().sum()),'low_missing':int(lo.isna().sum()),'feature_mean_high':h.mean(),'feature_mean_low':lo.mean(),'feature_median_high':h.median(),'feature_median_low':lo.median(),'mean_high_minus_low':h.mean()-lo.mean()})
pd.DataFrame(comps).to_csv(R/'outputs/curry_fixed48_core_high_vs_low.csv',index=False)
# Uncertainty for transparent single-context contrasts and all complete core split groups.
mem=read(R/'outputs/core_split_membership.csv.gz');single=[]
for f,g in mem.groupby('field'):
 if f.startswith(('pts','fgm','fg3m','ftm')):continue # deterministic score components remain in descriptive table; no pseudo-inference.
 for lab in sorted(g.loc[g.bin.ne('missing'),'bin'].unique()):single.append((f,lab,'all',g[g.bin.eq(lab)].game_id.tolist(),g[g.bin.ne('missing')].game_id.tolist()))
for f in ['home_away','team_rest_bin','closing_abs_spread_bin','closing_total_bin','closing_team_implied_bin']:
 for scope in ['all','2023-24','2024-25','2025-26']:
  a=z if scope=='all' else z[z.season.eq(scope)];known=a[f].notna()&~a[f].astype(str).str.contains('missing|unknown',case=False)
  for lab in sorted(a.loc[known,f].astype(str).unique()):single.append((f,lab,scope,a.loc[known&a[f].astype(str).eq(lab),'game_id'].tolist(),a.loc[known,'game_id'].tolist()))
for f in ['observed_green_played','observed_butler_played']:
 scopes=['2025-26'] if 'butler' in f else ['all','2023-24','2024-25','2025-26']
 for scope in scopes:
  a=z if scope=='all' else z[z.season.eq(scope)];single.append((f,'True',scope,a[a[f]].game_id.tolist(),a.game_id.tolist()))
unc=[]
for f,lab,scope,sel,knownids in single:
 a=z[z.game_id.isin(knownids)].sort_values('date').reset_index(drop=True);n=len(a);mask=a.game_id.isin(sel).to_numpy();na=int(mask.sum());nb=n-na
 if na<10 or nb<10:continue
 ix=block_indices(a);bm=mask[ix];ok=(bm.sum(axis=1)>0)&((~bm).sum(axis=1)>0);ix=ix[ok];bm=bm[ok]
 for s in ['dk','fd']:
  y=a[s].to_numpy();hit=(y>=48).astype(float);ra=y[ix];hh=hit[ix];aa=np.where(bm,ra,np.nan);bb=np.where(~bm,ra,np.nan);ha=np.where(bm,hh,np.nan);hb=np.where(~bm,hh,np.nan);delta=np.column_stack([np.nanmean(aa,axis=1)-np.nanmean(bb,axis=1),np.nanmedian(aa,axis=1)-np.nanmedian(bb,axis=1),np.nanquantile(aa,.9,axis=1)-np.nanquantile(bb,.9,axis=1),np.nanmean(ha,axis=1)-np.nanmean(hb,axis=1)]);ci=np.quantile(delta,[.025,.975],axis=0)
  rr={'field':f,'bin':lab,'scope':scope,'site':s,'n':n,'condition_n':na,'other_n':nb,'bootstrap_draws':len(ix),'block_length':7,'scheme':'Within-season circular observed-game blocks; fixed descriptive bins; no multiple-testing correction'}
  estimates=[y[mask].mean()-y[~mask].mean(),np.median(y[mask])-np.median(y[~mask]),np.quantile(y[mask],.9)-np.quantile(y[~mask],.9),hit[mask].mean()-hit[~mask].mean()]
  for j,nm in enumerate(['mean','median','q90','hit48_rate']):rr[nm+'_delta']=float(estimates[j]);rr[nm+'_block95_low']=float(ci[0,j]);rr[nm+'_block95_high']=float(ci[1,j])
  unc.append(rr)
pd.DataFrame(unc).to_csv(R/'outputs/curry_fixed48_split_uncertainty.csv',index=False)
receipt={'fixed_threshold':48,'inclusive':True,'dk_hits':int(z.dk_ge48.sum()),'dk_misses':int((~z.dk_ge48).sum()),'fd_hits':int(z.fd_ge48.sum()),'fd_misses':int((~z.fd_ge48).sum()),'joint_rows':len(rows),'uncertainty_rows':len(unc),'all_games_unique':not z.game_id.duplicated().any(),'role_proxy_full_coverage_games':int(z.played_creator_proxy_count.notna().sum()),'role_unknown_is_not_zero':True,'no_new_model':True};(R/'audit/fixed48_integration_receipt.json').write_text(json.dumps(receipt,indent=2));print(pd.DataFrame(rows).query("site=='dk'")[['comparison','condition_a_value','condition_b_value','n','hits48','misses48','mean','median','q90']].to_string(index=False));print(receipt)
