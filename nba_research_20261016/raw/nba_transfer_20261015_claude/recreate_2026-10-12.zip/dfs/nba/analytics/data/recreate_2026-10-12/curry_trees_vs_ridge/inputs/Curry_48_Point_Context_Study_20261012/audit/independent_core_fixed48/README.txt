INDEPENDENT CURRY CORE / FIXED-48 / IDENTIFIER AUDIT

Scope: Independent source-to-output audit, no model fits, no production-builder imports, no production-output changes. Original raw player sources and the mechanism spine independently reconcile to all 187 Curry appearances (74 / 70 / 43 by season). Inclusive outcomes are 67 DraftKings hits and 46 FanDuel hits. Site outcomes remain separate.

Audit core and integrated evidence:
  python audit/independent_core_fixed48/audit_core_fixed48.py

Audit bounded identifiers and saved model readthrough:
  python audit/independent_core_fixed48/audit_identifier_scorecards.py

Run from any directory; paths are resolved from each script's location.

Primary receipts:
- audit_summary.json: full core/source replay and tested output SHA256 values
- identifier_audit_summary.json: bounded candidates and saved models, output SHA256 values
- failures.json / identifier_failures.json: complete discrepancy lists, empty on PASS
- all_checks.csv.gz / identifier_all_checks.csv.gz: full individual check records
- source_hash_checks.json: 25 source hash comparisons against prior recorded provenance
- selected_bootstrap_samples.json: selected full 500-draw sample hashes plus two draw examples
- identifier_bootstrap_samples.json: bounded candidate resampling hashes

Coverage:
- All 105 core fields, 19,635 field/game memberships, 2,106 core distribution rows and 210 high/low feature summaries.
- Actual own/opponent advanced box factors and all strictly prior current-season 10-game means.
- All 1,956 actual teammate rows and prior-20 role definitions; 81 complete-role games. Aggregate roles remain missing if any observed teammate history is unknown. Separately named known-only lower bounds are not complete counts.
- All 48 direct joint cells including empty cells, exact counts, distributions, Wilson intervals and memberships.
- All 482 uncertainty rows' membership, point estimates and resampling support; 82 full endpoint vectors independently reproduced.
- All 14 bounded candidate rows and memberships, same-eligible baselines, global 67-hit recall denominator, four sensitivity rows; all 13 reported bootstrap interval rows independently reproduced. The remaining sensitivity has only three known unselected games, below the declared support rule; its uncertainty fields correctly remain missing.
- All 790 saved-model probabilities, 20 scorecards, 45 occupied calibration bins and deterministic/tie-inclusive boundary counts. Routes through all eight frozen individual-tree JSON artifacts independently match saved leaf IDs. Individual probabilities use the saved weighted empirical distribution; pooled seven-quantile CDF inversion remains explicitly approximate.

Interpretation that must remain visible:
- Actual same-game boxes and observed coappearance are retrospective explanatory variables, not certified pregame identifiers.
- Player history carries across seasons; team prior-10 histories reset by season. Source vintage is not independently certified by a byte-level audit.
- Full-season feature-median splits are descriptive, not deployment cutoffs.
- All follow-up condition discovery is exploratory. Intervals omit multiplicity/condition-selection uncertainty and use only 500 resamples.
- Core split bootstrap blocks run through the observed known-context sequence within season; missing-context exclusions can compress chronological gaps. Candidate bootstrap uses all scoped rows and resamples the knownness/selection flags.
- The integrated legacy team_b2b field is not used by new direct schedule/candidate conditions, which use team_b2b_verified. Frozen original models retain their pre-existing feature contract including team_b2b; they were neither changed nor refitted.

Results: See both JSON summaries for exact final check counts and audited file hashes. No substantive mismatch was found.
