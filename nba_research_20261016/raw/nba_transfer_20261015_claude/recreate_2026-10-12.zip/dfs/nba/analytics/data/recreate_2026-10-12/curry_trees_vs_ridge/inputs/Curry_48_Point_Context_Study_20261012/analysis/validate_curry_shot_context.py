from pathlib import Path
import pandas as pd,numpy as np,json
O=Path(__file__).resolve().parents[1];D=O/'outputs';B=O.parent/'inputs/three_season/nba_three_season_ceiling_20261011'
x=pd.read_csv(D/'curry_shot_context_join.csv',dtype={'game_id':str});base=pd.read_csv(D/'curry_full_three_season_inventory.csv',dtype={'game_id':str});base.game_id=base.game_id.str.zfill(10)
a=x.merge(base,on='game_id',suffixes=('_x','_b'),validate='one_to_one')
for c in ['dk','fd','dk_prior20_mean','fd_prior20_mean','dk_hit_q90','fd_hit_q90']:assert np.allclose(a[c+'_x'],a[c+'_b'],equal_nan=True)
s=pd.read_csv(D/'curry_shot_context_distribution_splits.csv');p=s[s.method.eq('pooled_season_normalized_exploratory_median')]
assert (p.groupby(['field','site']).n.sum()==187).all()
assert (s.score_ge48_hits+s.score_lt48_misses==s.n).all()
assert (s.dk_ge48_hits+s.dk_lt48_misses==s.n).all()
assert (s.strict_prior_q90_hits+s.strict_prior_q90_misses+s.strict_prior_q90_null==s.n).all()
assert (p.groupby(['field','site']).dk_ge48_hits.sum()==67).all()
raw=pd.read_csv(B/'results/player_game_mechanism_spine.csv',dtype={'game_id':str});raw.game_id=raw.game_id.str.zfill(10)
t=raw.groupby(['season','date','game_id','opponent'],as_index=False)[['fga','fg3a','fg3m']].sum();tested=0
for row in x.itertuples():
 past=t[(t.season==row.season)&(t.opponent==row.opponent)&(t.date<row.date)].sort_values(['date','game_id']).tail(10)
 if len(past)==10:
  assert np.isclose(row.opp_allowed_3pa_prior10_mean,past.fg3a.mean())
  assert np.isclose(row.opp_allowed_3pm_prior10_mean,past.fg3m.mean())
  assert np.isclose(row.opp_allowed_3p_pct_prior10_weighted,past.fg3m.sum()/past.fg3a.sum())
  assert np.isclose(row.opp_allowed_3pa_share_prior10_weighted,past.fg3a.sum()/past.fga.sum())
  assert row.opp_three_prior10_start_date==past.date.min()
  assert row.opp_three_prior_last_date==past.date.max()
  tested+=1
 else:assert np.isnan(row.opp_allowed_3p_pct_prior10_weighted)
checks={'pass':True,'games':len(x),'score_and_baseline_columns_unchanged':True,'feature_median_split_partition_sum':187,'dk_ge48_partition_hits':67,'dk_lt48_partition_misses':120,'rolling_windows_independently_recomputed':tested,'no_target_or_future_games_in_prior10':True,'all_missing_thresholds_preserved':True,'dashboard_available_only_2025_26':all(x.loc[x.season.ne('2025-26'),c].isna().all() for c in x if c.startswith('dashboard_'))}
(O/'audit/curry_shot_context_independent_validation.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
