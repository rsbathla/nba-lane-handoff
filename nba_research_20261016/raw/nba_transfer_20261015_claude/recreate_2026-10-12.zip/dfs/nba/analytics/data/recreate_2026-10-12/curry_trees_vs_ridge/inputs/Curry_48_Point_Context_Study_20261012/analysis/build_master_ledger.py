from pathlib import Path
import json,hashlib,pandas as pd
R=Path(__file__).resolve().parents[1]
def read(p):
 d=pd.read_csv(p,dtype={'game_id':str,'person_id':str});d.game_id=d.game_id.str.replace(r'\.0$','',regex=True).str.zfill(10);return d
base=read(R/'outputs/curry_fixed48_integrated_game_ledger.csv');paths=[R/'outputs/curry_shot_context_join.csv',R/'outputs/curry_fixed48_context_ledger.csv'];added=[]
for p in paths:
 d=read(p);assert not d.game_id.duplicated().any()
 check=base[['game_id','dk','fd']].merge(d[['game_id','dk','fd']],on='game_id',suffixes=('_a','_b'),validate='one_to_one');assert len(check)==187 and (check.dk_a==check.dk_b).all() and (check.fd_a==check.fd_b).all()
 cols=[c for c in d if c not in base];base=base.merge(d[['game_id']+cols],on='game_id',how='left',validate='one_to_one');added.append({'source':str(p.relative_to(R)),'new_columns':len(cols)})
s=read(R/'coverage_curry_actual_starters_and_player_rest_43_games.csv');keep=['starter_source_yn','player_days_rest_source','position_source','source_file','source_sheet','source_excel_row','source_sha256','starter_ids','starter_names'];s=s[['game_id']+keep].rename(columns={c:'actual_starting_'+c for c in keep});base=base.merge(s,on='game_id',how='left',validate='one_to_one')
a=read(R/'coverage_curry_coappearance_game_summary_187_games.csv');cs=['teammate_positive_minute_count','coappearing_teammate_ids','coappearing_teammate_names'];base=base.merge(a[['game_id']+cs],on='game_id',how='left',validate='one_to_one')
sal=read(R/'salary_audit/curry_salary_distinct_game_site_values.csv');ss=['salary','points_per_1000_salary','evidence_rows','pool_or_contest_ids','evidence_tiers','slate_types','source_evidence_ids','pregame_capture_verified']
for site in ['dk','fd']:
 a=sal[sal.site.eq(site)][['game_id']+ss].rename(columns={c:site+'_salary_'+c for c in ss});base=base.merge(a,on='game_id',how='left',validate='one_to_one')
assert len(base)==187 and base.game_id.nunique()==187 and base.dk.ge(48).sum()==67 and base.fd.ge(48).sum()==46
out=R/'outputs/curry_full_context_master_187_games.csv.gz';base.to_csv(out,index=False,compression={'method':'gzip','mtime':0})
# Readable, source-linked compact ledger, all rows plus a separate high-game slice.
cols=['season','date','game_id','opponent','home_away','dk','fd','dk_ge48','fd_ge48','minutes','fga','fg3a','fg3m','fta','usage_proxy','team_b2b_verified','minutes_lag5','usage_proxy_lag10','expected_box_pace','observed_green_played','observed_butler_played','actual_starting_starter_names','dk_salary_salary','fd_salary_salary','dk_salary_points_per_1000_salary','fd_salary_points_per_1000_salary','dk_salary_evidence_tiers','fd_salary_evidence_tiers','context_source_file','context_source_sha256','market_original_source_file','market_original_source_sheet','source_excel_row','actual_starting_source_file','actual_starting_source_sheet','actual_starting_source_excel_row']
base[cols].to_csv(R/'Curry_48_Point_Game_Ledger_20261012.csv',index=False);base.loc[base.dk_ge48,cols].to_csv(R/'outputs/curry_67_DK_high_games_source_ledger.csv',index=False)
info={'rows':187,'columns':len(base.columns),'DK48_hits':67,'FD48_hits':46,'layer_joins':added,'no_game_dropped':True,'no_context_missing_imputation':True,'DK_salary_games':int(base.dk_salary_salary.notna().sum()),'FD_salary_games':int(base.fd_salary_salary.notna().sum()),'master_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'usage_warning':'This master contains outcomes, same-game explanations, strictly lagged game history, and undated/mixed-date retrospective snapshots. It is NOT a pregame predictor matrix. Use temporal field inventories. Legacy team_b2b retains old first-fixture unknown-filled-zero values for provenance; NOT USED in any current rest split. Use team_b2b_verified instead. Actual starter and coappearance columns are postgame records, not certified pregame availability.'};(R/'audit/master_ledger_receipt.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2))
