import sys, json, hashlib
from pathlib import Path
import numpy as np, pandas as pd
sys.dont_write_bytecode = True
A = Path('/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_individual'); B = Path(sys.argv[1]); O = Path(sys.argv[2])
res = {}
for f in ['forecast_metrics.csv','forecast_comparisons.csv','player_forecast_comparisons.csv','player_factors.csv','player_coverage.csv']:
    a, b = pd.read_csv(A/f), pd.read_csv(B/f)
    r = dict(shape_a=list(a.shape), shape_b=list(b.shape), same_columns=list(a.columns)==list(b.columns), byte_identical=hashlib.sha256((A/f).read_bytes()).hexdigest()==hashlib.sha256((B/f).read_bytes()).hexdigest())
    if a.shape == b.shape and r['same_columns']:
        num = a.select_dtypes('number').columns
        r['max_abs_numeric_diff'] = float(np.nanmax(np.abs(a[num].to_numpy(float)-b[num].to_numpy(float)))) if len(num) else 0.
        r['nan_pattern_equal'] = bool((a[num].isna().to_numpy()==b[num].isna().to_numpy()).all())
        oth = [c for c in a.columns if c not in num]
        r['nonnumeric_equal'] = bool(a[oth].fillna('NA').astype(str).equals(b[oth].fillna('NA').astype(str)))
    res[f] = r
pa, pb = pd.read_parquet(A/'predictions.parquet'), pd.read_parquet(B/'predictions.parquet')
res['predictions.parquet'] = dict(shape_a=list(pa.shape), shape_b=list(pb.shape), max_abs_probability_diff=float(np.abs(pa.probability.to_numpy()-pb.probability.to_numpy()).max()) if pa.shape==pb.shape else None, frames_equal=bool(pa.reset_index(drop=True).equals(pb.reset_index(drop=True))))
sa, sb = json.loads((A/'summary.json').read_text()), json.loads((B/'summary.json').read_text())
res['summary.json'] = dict(equal=sa==sb, cohort_counts_equal=sa['cohort_counts']==sb['cohort_counts'], folds_equal=sa['folds']==sb['folds'], sources_equal=sa['sources']==sb['sources'])
res['audit_validation.json_equal'] = json.loads((A/'audit_validation.json').read_text())==json.loads((B/'audit_validation.json').read_text())
res['cohort_counts_rerun'] = sb['cohort_counts']
m = pd.read_csv(B/'forecast_metrics.csv'); res['metrics_rerun'] = m.round(6).to_dict('records')
O.write_text(json.dumps(res, indent=1)); print(json.dumps({k:v for k,v in res.items() if k not in ('metrics_rerun',)}, indent=1))
