from pathlib import Path
import pandas as pd,json,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
P=Path(__file__).parent;S=getSampleStyleSheet();S.add(ParagraphStyle(name='T2',fontName='Helvetica-Bold',fontSize=25,leading=29,textColor=colors.HexColor('#153950'),spaceAfter=15));S.add(ParagraphStyle(name='H2b',fontName='Helvetica-Bold',fontSize=15,leading=19,textColor=colors.HexColor('#153950'),spaceAfter=10));S.add(ParagraphStyle(name='B2',fontSize=9.5,leading=13.5,spaceAfter=9));S.add(ParagraphStyle(name='Sm',fontSize=8,leading=11,spaceAfter=7));S.add(ParagraphStyle(name='C',fontSize=7.8,leading=10));S.add(ParagraphStyle(name='HC',fontName='Helvetica-Bold',fontSize=7.8,leading=10,textColor=colors.white));story=[];text=[]
def p(t,style='B2'):story.append(Paragraph(t,S[style]));text.append(t.replace('<b>','').replace('</b>',''))
def h(t):p(t,'H2b')
def page(t):story.append(PageBreak());h(t)
def table(head,rows,widths):
 t=Table([[Paragraph(str(x),S['HC']) for x in head]]+[[Paragraph(str(x),S['C']) for x in r] for r in rows],colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#153950')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F1F5F7'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story.extend([t,Spacer(1,10)]);text.append(' | '.join(head));text.extend(' | '.join(map(str,r)) for r in rows)
def pct(v):return 'unknown' if pd.isna(v) else f'{100*v:.1f}%'
def pp(v):return f'{100*v:+.1f}'
def f(v):return f'{v:.4f}'
M=pd.read_csv(P/'prediction_scorecard.csv');A=pd.read_csv(P/'ALL_selected_rules.csv');B=pd.read_csv(P/'DESCRIPTIVE_selected_branch_control_comparisons.csv');U=pd.read_csv(P/'paired_prediction_uncertainty.csv');cnt=pd.read_csv(P/'candidate_counts_by_fit.csv');D=pd.read_csv(P/'approximate_max_statistic_diagnostic.csv')
p('Dallas: a systematic<br/>combination search','T2');p('21 earlier-game features | 1,426 declared rules | Pairwise and role x volume x ability combinations','H2b');p('Separate exploratory supplement, October 12, 2026. The completed three-method and ability/opportunity findings are preserved.','Sm')
h('Bottom line')
p('<b>Expanding the search did not produce a better predictive rule.</b> On the same 257 later Dallas appearances, every train-selected rule model is worse than the simpler opportunity ridge on DK Brier score, log loss and AUC. The rules also deteriorate when test players are excluded from training.')
p('A low-prior-minutes / low-shot-volume / low-steals combination repeats in two date folds and has 13 hits in 29 later appearances. That is a specific hypothesis worth recording, but its small sample, shifting selection, probability underprediction and overall benchmark results do not establish a reliable Dallas advantage.')
q=M[(M.platform=='DK')&(M.evaluation=='chronological')&(M.period=='all')];order=['prevalence','opportunity_ridge_C0.1','best_pair','best_triple','best_any'];labels={'prevalence':'Expanding prevalence','opportunity_ridge_C0.1':'Opportunity ridge','best_pair':'Train-selected pair','best_triple':'Train-selected triple','best_any':'Train-selected best of all'}
table(['Fixed selection strategy','Brier','Log loss','AUC','Mean probability'],[[labels[n],f(q[q.model==n].iloc[0].Brier),f(q[q.model==n].iloc[0].logloss),f(q[q.model==n].iloc[0].AUROC),pct(q[q.model==n].iloc[0].mean_prediction)] for n in order],[220,65,65,65,85])
p('Actual DK hit rate is 70/257 = 27.2%. Lower Brier/log loss and higher AUC are better. The strongest rule strategy by point estimate (best of all) predicts only 19.0% on average. The simpler opportunity model predicts 20.0% and also underpredicts, so none is ready to be treated as calibrated decision probabilities.','Sm')
h('What “systematic” means here')
table(['Declared family','Formal rules','Definition'],[['Singles','42','High or low for each of 21 features'],['All distinct-feature pairs','840','Every pair, all four high/low directions'],['Role x volume x ability triples','544','2 role features x 2 volume features x 17 ability/mix features x 8 directions'],['Total per training fit','1,426','Fixed medians and fixed support; no threshold optimization']],[150,65,285])
p('The search evaluates the entire declared rule dictionary. It is not every conceivable continuous cutoff, derived feature, interaction order or basketball concept. Enumerating rules is the search; Monte Carlo resampling quantifies conditional uncertainty and does not add observations. Historical outcomes and previous analyses were already seen, so later-date tests are exploratory diagnostics rather than a pristine holdout.','Sm')
page('1. Feature inventory, missingness and fixed rules')
table(['Family','Features included'],[['Role (2)','Prior-ten mean minutes; prior-thirty minutes standard deviation'],['Volume (2)','FGA per 36; FTA per 36'],['Box ability / mix (12)','3PA/FGA; FTA/FGA; AST, REB, STL, BLK and TOV per 36; inside-arc points per 36; two-point FG%; OREB per 36; DREB per 36; OREB / total REB'],['Dated tracking style (5)','Observed catch-and-shoot, pull-up, under-ten-foot, wide-open and very-tight attempt ratios']],[130,370])
p('All rates use summed components from the strictly earlier 30 positive-minute appearances. Prior-minute opportunity uses the previous ten appearances. No target-game components, full-season style labels, personal scores from future games or player ID enter the rule inputs. Inside-arc scoring includes midrange; rebounding per minute is a proxy, not measured rebound-chance conversion.','Sm')
table(['Tracking feature','Available Dallas rows / 382','Unavailable rows'],[['Catch-and-shoot','345','37'],['Pull-up','252','130'],['Under ten feet','366','16'],['Wide open','344','38'],['Very tight','153','229']],[230,170,100])
p('Tracking ratios require at least 15 valid observed tag dates among the earlier 30 appearances. Their denominator is box FGA only on those observed dates. Ten of 88,977 source tag rows fail component/subset consistency checks and are marked invalid. Missing or invalid tags remain unknown, never zero. Tracking contexts overlap and cannot be added. Reconstruction from earlier dated records does not prove the source was archived and available before each historical game.','Sm')
h('Frozen support and selection')
p('Each feature splits at its training-only median. High is >= median; low is < median. A rule and its known complement each need at least 20 training appearances, five games and five players. These support gates use no hit outcomes. If an input is unknown, the prediction falls back to training prevalence.')
p('For a supported rule, the training hit rate is shrunk toward the training prevalence with 20 pseudo-appearances. The largest positive shrunk DK uplift selects one pair, one triple and one best-of-all rule. Ties use the fixed rule ID. Each selected rule has separately pooled probabilities for its true and known-complement branches. FD reuses the DK-selected rule with FD probabilities, so no separate FD rule hunt occurs.','Sm')
h('Explicitly excluded')
p('Unknown-vintage partial Synergy snapshots; current roster position as historical role; unavailable height and rebound-chance data; unrestricted continuous cutoffs; four-way and higher rules; new acquisition; simulations treated as real games. These are coverage limits, not evidence that those basketball dimensions do not matter.','Sm')
page('2. What was actually selected?')
p('Selections use training outcomes only. The cutoffs below are medians recalculated within that training period. The table retains all nine ordinary-fold selections, including repeated rules, and their later hit/miss counts.')
name={'prior10_minutes':'Prior minutes','prior30_minutes_sd':'Minutes SD','prior30_fga36':'FGA/36','prior30_fta36':'FTA/36','prior30_tov36':'TOV/36','prior30_ast36':'AST/36','prior30_reb36':'REB/36','prior30_stl36':'STL/36','prior30_pu_observed_ratio':'Observed pull-up ratio'}
rows=[]
for _,r in A[A.evaluation=='chronological'].iterrows():
 cuts=json.loads(r.cutoffs_json);parts=[]
 for literal in r.predicate.split(' AND '):
  feat,op=literal.split()[:2];parts.append(f'{name.get(feat,feat)} {html.escape(op)} {cuts[feat]:.3f}')
 z=B[(B.platform=='DK')&(B.evaluation=='chronological')&(B.model==r.model)&(B.fold==r.fold)&(B.branch=='rule')].iloc[0]
 rows.append([str(int(r.fold)),{'best_any':'Any','best_pair':'Pair','best_triple':'Triple'}[r.model],'<br/>'.join(parts),f'{int(r.train_rule_DK_hits)}/{int(r.train_rule_N)}',f'{int(z.hits)}/{int(z.N)}',pct(z.exposure_weighted_own_other_rate),pp(z.descriptive_lift)])
table(['Fold','Selector','Selected rule','Train H/N','Later H/N','Own control','Lift pp'],rows,[32,47,201,55,55,60,50])
p('Other-defense rates are the same players\' full-sample personal baselines, weighted to the later Dallas exposure. They are joined only after selection, can include later control observations, and are descriptive references. They never enter feature construction, medians, selection scores or predicted probabilities.','Sm')
h('Why the first impressive rate was fragile')
p('The first selected pair had 8/23 training hits but only 2/11 later hits. Another 29 later rows lacked the required observed pull-up feature and fell back to prevalence; 12 of those 29 hit. Missingness cannot be silently discarded when scoring the complete prediction task.','Sm')
p('The repeated low-minutes / low-FGA / low-steals triple has 4/8 then 9/21 later hits. Its thresholds vary slightly with the training window. It may describe players whose role subsequently expanded or whose personal threshold was relatively low; the observed associations do not show that low steals is a defensive mechanism. The predictor built from the selected triple still loses to the opportunity benchmark.','Sm')
page('3. Chronology, player dependence and uncertainty')
p('The 382 eligible appearances span 232 players and 50 Dallas dates. Three expanding folds train on the first 20/30/40 dates and test the next ten, giving 257 later appearances in 30 Dallas games. Each later game stays intact. A separate five-group deterministic player exclusion removes all test-group players from training in every fold; it still evaluates the same 257 rows.')
rows=[]
for fold in [1,2,3]:
 v=cnt[(cnt.evaluation=='chronological')&(cnt.fold==fold)];allr=v[v.order==0].iloc[0];rows.append([str(fold),str([125,208,294][fold-1]),str(int(v[v.order==1].iloc[0].eligible)),str(int(v[v.order==2].iloc[0].eligible)),str(int(v[v.order==3].iloc[0].eligible)),str(int(allr.eligible)),str(int(allr.eligible_unique_training_patterns))])
table(['Fold','Train N','Singles','Pairs','Triples','All supported','Distinct masks'],rows,[40,60,65,65,65,100,105])
p('Across 18 date/player training fits, all 25,668 nominal predicate evaluations are retained. All 4,278 ordinary-fold future predicate summaries are also saved as descriptive records, not used to select a universal best future rule. Formal predicates are correlated and may produce identical observed masks; they are not 1,426 independent tests.','Sm')
rows=[]
for n in order:
 vals=[]
 for plat in ['DK','FD']:
  for ev in ['chronological','chronological_player_disjoint']:
   r=M[(M.platform==plat)&(M.evaluation==ev)&(M.period=='all')&(M.model==n)].iloc[0];vals.append(f(r.Brier))
 rows.append([labels[n]]+vals)
table(['Strategy','DK chrono','DK unseen player','FD chrono','FD unseen player'],rows,[200,70,85,65,80])
h('Paired uncertainty against opportunity ridge')
q=U[(U.platform=='DK')&(U.evaluation=='chronological')&(U.measure=='Brier')&(U.cluster_unit=='game_id')&(U.benchmark=='opportunity_ridge_C0.1')&U.model.isin(['best_pair','best_triple','best_any'])]
table(['Rule selector','Brier change','95% game-block interval'],[[labels[r.model],f'{r.difference:+.6f}',f'[{r.lo:+.6f}, {r.hi:+.6f}]'] for _,r in q.iterrows()],[230,100,170])
p('All ordinary chronological DK rule-versus-ridge intervals cross zero; the point estimates favor ridge. In the player-disjoint evaluation, the pair selector is worse by +0.009930 Brier with a game-block interval +0.002502 to +0.019991. That is conditional evidence of harm under game grouping. Its player-block interval is -0.000324 to +0.021256 and crosses zero, so the dependence sensitivity matters. Both-platform results are retained. No refitting occurs inside these 1,000-draw paired score bootstraps.','Sm')
page('4. Multiple comparisons, interpretation and evidence')
p('Scanning many rules can produce an impressive training subgroup by chance. The primary protection here is fixed search space, training-only selection, complete later-row scoring, a simpler benchmark, and player-disjoint sensitivity. It does not undo the fact that this historical dataset and earlier hypotheses were already seen.')
h('Approximate maximum-statistic check')
p('A centered wild-cluster max-t diagnostic uses 2,000 Rademacher resamples over the structurally supported rule family in each ordinary training fold. It compares the largest observed training statistic with the resampled maximum. Game and player clusters are checked separately. This is an approximate conditional diagnostic, not an exact finite-sample familywise error guarantee, and it never gates selection or prediction.','Sm')
table(['Training fold','Game-cluster reference p','Player-cluster reference p'],[[str(fold),f(D[(D.fold==fold)&(D.cluster_unit=='game_id')].iloc[0].approx_max_t_p),f(D[(D.fold==fold)&(D.cluster_unit=='person_id')].iloc[0].approx_max_t_p)] for fold in [1,2,3]],[100,200,200])
p('The last-fold game-cluster value is 0.031, but player-cluster sensitivity is 0.105; earlier folds are less persuasive. The differing dependence assumptions matter. This isolated training statistic is not a verified new archetype and does not outweigh the later prediction scores.','Sm')
h('What this changes, and what it does not')
p('This search goes beyond three broad styles: it exhausts the declared high/low pair dictionary and the specified role x volume x ability triples. It produces a transparent candidate list and one recurring low-role/low-volume hypothesis. It does not establish a reliable advantage over the small opportunity model, isolate a Dallas scheme mechanism, or support carrying the pattern to a new roster and season.')
p('The earlier three-cluster result and the negative ability/opportunity refinement remain unchanged. A useful next validation would require genuinely new, prospectively frozen games and reliable pregame role/lineup information. Additional searches on the same observed season should not be relabeled independent confirmation.','Sm')
h('Primary references')
for label,url in [('Time- and group-aware validation (official scikit-learn)','https://scikit-learn.org/stable/modules/cross_validation.html'),('Probability calibration and scoring (official scikit-learn)','https://scikit-learn.org/stable/modules/calibration.html'),('Romano and Wolf (2005): multiple testing and data snooping','https://onlinelibrary.wiley.com/doi/10.1111/j.1468-0262.2005.00615.x'),('Cameron, Gelbach and Miller (2008): inference with clustered errors','https://direct.mit.edu/rest/article/90/3/414/57731/Bootstrap-Based-Improvements-for-Inference-with')]:p(f'<link href="{html.escape(url)}" color="#185B83">{label}</link>','Sm')
p('References support the methodological cautions. The custom max-t diagnostic is not claimed to reproduce every procedure or theoretical guarantee in those papers. Basketball findings come from the previously saved reviewed 2025-26 box layer and corrected dated tracking sources; no new basketball data were acquired.','Sm')
h('Evidence and audit trail')
p('The separate independent audit passed 80 checks including report verification, reproducing the prior features, full candidate ledger, training-only selection, forecasts, scorecards, calibration, uncertainty and controls. Final prose also preserves the exploratory and dependence limitations.', 'Sm')
p('The compact bundle contains the frozen protocol, 21-feature inventory, all 1,426 predicates, all 25,668 training evaluations, every selected rule, all 4,278 future descriptive counts, prior feature/outcome ledger, predictions, calibration, both-platform uncertainty, retrospective own-player comparisons, source hashes and independent audit. Large source reconstructions and original paid data files are not duplicated.','Sm')
def footer(c,d):c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#536A79'));c.setStrokeColor(colors.HexColor('#CDD9E0'));c.line(47,37,547,37);c.drawString(47,24,'DALLAS DECLARED-SPACE SEARCH | EXPLORATORY | OCT 12, 2026');c.drawRightString(547,24,str(d.page))
SimpleDocTemplate(str(P/'Dallas_Systematic_Combination_Search_20261012.pdf'),pagesize=(595.28,841.89),leftMargin=47,rightMargin=47,topMargin=43,bottomMargin=49,title='Dallas Systematic Combination Search',author='dot').build(story,onFirstPage=footer,onLaterPages=footer);import re
plain='\n\n'.join(text).replace('<br/>','; ');plain=html.unescape(re.sub(r'</?(?:link|b|i|br)(?:\s[^>]*)?/?>','',plain));(P/'Dallas_Systematic_Combination_Search_20261012.txt').write_text(plain+'\n')
