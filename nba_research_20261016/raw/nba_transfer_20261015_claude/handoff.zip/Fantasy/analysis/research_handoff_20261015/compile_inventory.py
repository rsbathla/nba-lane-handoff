"""Metadata inventory of the saved NBA and weekly NFL work; no model rebuild."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DFS = ROOT.parent / 'dfs'
STAMP = '2026-10-15'
SESSION_ROOTS = [ROOT / 'analysis' / n for n in (
    'nba_bp_continuation_20261012', 'nba_bestball_20261013',
    'weekly_nfl_contests_20261014', 'nba_2026_team_guide_20261014')]
TREE_ROOTS = SESSION_ROOTS + [DFS / 'nba', DFS / 'nba-dashboard',
    ROOT.parent / 'nba-dashboard', ROOT.parent / 'fd_nba_contests',
    ROOT / 'analysis/underdog_2026w4',
    ROOT / 'analysis/nfl_2026w1_w4_prelock_rebuild',
    ROOT / 'analysis/nfl_2026w5/retrospective_20261012',
    Path('/Users/rsbathla/.codex/worktrees/7288/DFS_NFL/work/2026_coaching_companion_20260929/stacks'),
    Path('/Users/rsbathla/Documents/Codex/2026-10-10/task-2/nba_traditional_boxscores_20261010')]
SENSITIVE = re.compile(r'(?i)(bearer|\.pem|(^|/)\.env($|[./])|brain\.conf|cookie|credential|secret|token)')
SKIP_DIRS = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', '.cache', 'graphify-out'}

def safe(p):
    return not SENSITIVE.search(str(p)) and not any(x in SKIP_DIRS for x in p.parts)

def history(p):
    return any(x in str(p).lower() for x in ('/archive/', '/development_receipts/',
        '/prior_page/', '/receipt_custody', '/v1/', '/initial_no_dvp/'))

def kind(p):
    name = p.name.lower()
    if any(x in str(p).lower() for x in ('/raw/', '/raw_', '/tracking/', '/synergy/')):
        return 'saved_source'
    if p.suffix in ('.py', '.js', '.mjs', '.css', '.sh'):
        return 'code_or_style'
    if p.suffix in ('.md', '.html'):
        return 'report_or_document'
    if p.suffix in ('.parquet', '.csv', '.gz', '.xlsx', '.db', '.sqlite', '.zip'):
        return 'data_or_archive'
    return 'metadata_or_other'

def walk_paths(base):
    import os
    if not base.exists():
        return
    for directory, dirs, files in os.walk(base, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and safe(Path(directory) / d))
        for name in sorted(files):
            p = Path(directory) / name
            if safe(p) and not p.is_symlink():
                yield p

def strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from strings(v)

def document_catalog(ordered):
    out = ['# Saved document catalog — October 15, 2026', '',
        'Scope and source families are explained in [the handoff report](REPORT.md). '
        'This is a location index: a listed document can be historical, superseded or source-limited. '
        'Current authority and correction priority are stated in that report.', '',
        'The accompanying FILE_CATALOG.json contains all inventoried safe file paths, sizes and timestamps. '
        'Archived copies and report assembly fragments are retained as provenance; they are not additional studies.', '']
    docs = [r for r in ordered if r['kind'] == 'report_or_document']
    scopes = sorted(set(r['inventory_scope'] for r in docs))
    for scope in scopes:
        out += ['## ' + scope, '', '| Document | Inventory classification |', '| --- | --- |']
        for row in docs:
            if row['inventory_scope'] != scope: continue
            p = Path(row['path'])
            with p.open(errors='replace') as f:
                head = f.read(8192)
            if p.suffix == '.md':
                titles = [s.lstrip('#').strip() for s in head.splitlines() if s.startswith('#')]
                title = titles[0] if titles else p.name
            else:
                m = re.search(r'<title[^>]*>(.*?)</title>', head, re.I | re.S)
                title = re.sub(r'\s+', ' ', m.group(1)).strip() if m else p.name
            title = title.replace('|', '/').replace('[', '(').replace(']', ')')
            label = 'Preserved version' if row['preserved_history'] else 'Saved report/document; authority depends on its scope'
            out.append(f'| [{title} — {p.name}](<{p}>) | {label} |')
        out.append('')
    ledger = ROOT / 'analysis/nba_bp_continuation_20261012/family_ledger.json'
    families = json.loads(ledger.read_text())['families']
    out += ['## BP evidence-family statuses', '',
        'The following rows preserve the saved family_ledger.json status and its remaining limitations. '
        'USED denotes consumption, not predictive validity. The final coverage correction and completed '
        'on/off acceptance described in REPORT.md take precedence over earlier inventory wording.', '',
        '| Family | Saved status | Remaining limitation |', '| --- | --- | --- |']
    for row in families:
        values = [row.get('family', ''), row.get('status', ''), row.get('limits_or_open_item', '')]
        values = [str(v).replace('|', '/').replace('\n', ' ') for v in values]
        out.append('| ' + ' | '.join(values) + ' |')
    out += ['', f'Indexed documents: **{len(docs)}**. BP evidence families: **{len(families)}**.', '']
    (HERE / 'CATALOG.md').write_text('\n'.join(out))
    return len(docs), len(families)

def main():
    records = {}
    roots = []
    def add(p, scope):
        if not safe(p) or not p.is_file() or p.is_symlink():
            return
        p = p.absolute()
        if str(p) in records:
            return
        s = p.stat()
        records[str(p)] = {'path': str(p), 'bytes': s.st_size,
            'modified_utc': datetime.fromtimestamp(s.st_mtime, timezone.utc).isoformat(),
            'kind': kind(p), 'inventory_scope': scope,
            'preserved_history': history(p),
            'evidence_status': 'Location inventoried; presence is not validation of scientific or pre-lock claims.'}
    for base in TREE_ROOTS:
        roots.append({'path': str(base), 'exists': base.exists(), 'mode': 'recursive metadata only'})
        for p in walk_paths(base):
            add(p, str(base))
    for pattern in ('NBA*', 'HANDOFF_NBA*', 'HANDOFF_PLAYER_LEVERS.md'):
        for p in (DFS / 'docs').glob(pattern):
            add(p, 'older NBA reports')
    for p in (DFS / 'core').glob('*nba*.py'):
        add(p, 'older NBA analysis code')
    for p in (DFS / 'tools').glob('*nba*.py'):
        add(p, 'older NBA source tools')
    fl = DFS / 'tools/data/fantasylabs'
    for p in sorted(fl.glob('nba*')):
        if p.is_dir():
            roots.append({'path': str(p), 'exists': True, 'mode': 'recursive metadata only'})
            for q in walk_paths(p): add(q, str(p))
        else:
            add(p, 'older NBA contest derivatives')
    # Only explicit local file paths in saved session manifests are followed.
    # Large originals are inventoried without reopening or rehashing their bytes.
    manifests = []
    for base in SESSION_ROOTS:
        manifests += [p for p in base.rglob('*manifest.json') if not history(p)]
        manifests += [p for p in base.rglob('*MANIFEST.json') if not history(p)]
    pointers = []
    for p in sorted(set(manifests)):
        if not safe(p): continue
        d = json.loads(p.read_text())
        for s in sorted(set(strings(d))):
            if not s.startswith('/Users/rsbathla/') or '\n' in s or len(s) > 2000:
                continue
            q = Path(s)
            if not safe(q): continue
            exists = q.exists()
            pointers.append({'manifest': str(p), 'path': s, 'exists': exists,
                'type': 'file' if q.is_file() else 'directory' if q.is_dir() else 'missing'})
            add(q, 'explicit saved manifest pointer')
    db = Path('/Users/rsbathla/.dfs_core/dfs_core.db')
    roots.append({'path': str(db), 'exists': db.exists(),
        'mode': 'file metadata only; no account table read'})
    add(db, 'historical DK ledger file location')
    ordered = [records[k] for k in sorted(records)]
    (HERE / 'FILE_CATALOG.json').write_text(json.dumps(ordered, indent=2) + '\n')
    (HERE / 'SOURCE_POINTERS.json').write_text(json.dumps(pointers, indent=2) + '\n')
    document_count, family_count = document_catalog(ordered)
    counts = Counter(r['inventory_scope'] for r in ordered)
    total_bytes = sum(r['bytes'] for r in ordered)
    summary = {'generated_for_date': STAMP, 'snapshot_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Saved NBA estate and this chat weekly NFL review; not a whole-computer or all-NFL certification.',
        'files': len(ordered), 'bytes': total_bytes,
        'preserved_history_files': sum(r['preserved_history'] for r in ordered),
        'by_scope': dict(sorted(counts.items())),
        'by_kind': dict(Counter(r['kind'] for r in ordered)), 'roots': roots,
        'indexed_documents': document_count, 'bp_evidence_families': family_count,
        'manifest_pointer_rows': len(pointers),
        'missing_manifest_pointer_rows': sum(not r['exists'] for r in pointers),
        'limits': ['No credential files opened or included.',
            'Raw archives were not rehashed or rerun; existing receipts remain the provenance authority.',
            'Copied archives and repeated entries are not independent games or observations.',
            'File count is a metadata inventory count, not a playable slate or qualified sample count.']}
    (HERE / 'INVENTORY_SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
    check = subprocess.run(['python3', 'run_all.py', '--check'], cwd=ROOT,
        capture_output=True, text=True)
    (HERE / 'BUILD_INVENTORY.log').write_text(check.stdout + check.stderr)
    print(json.dumps({'files': len(ordered), 'bytes': total_bytes,
        'missing_manifest_pointer_rows': summary['missing_manifest_pointer_rows'],
        'run_all_check_exit_code': check.returncode, 'scope_count': len(counts)}))

if __name__ == '__main__':
    main()
