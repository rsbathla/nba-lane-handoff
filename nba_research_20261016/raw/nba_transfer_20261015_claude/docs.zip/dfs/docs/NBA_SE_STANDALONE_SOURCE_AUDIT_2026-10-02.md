# Historical NBA SE sources outside the owner ledger

Source qualification recorded October 2, 2026. This is a mechanical source audit. It contains no player-choice model, private decision rationale or profitability estimate.

## BPCologna source notes

The selected `bpcologna` blocks qualify in five contests on five dates in 2024–25: February 21 and 25, and March 5, 6 and 12, 2025. Each is a DraftKings NBA Classic contest with a $2,120 entry fee and an official maximum of one entry per user. Each retained block contains exactly one complete eight-player roster. Collapsing by user, date, exact candidate pool and canonical roster leaves five variants and five decision episodes. These are source observations of this handle; they do not establish how the user made the decisions. Provenance: `standalone_portfolios.parquet` · `user/date/season/fee/cap/headline_verified`; `standalone_selection_episodes.parquet` · `candidate_pool_signature/hash/source_contests`; `standalone_coverage.json` · `by_user`.

The February 21, February 25, March 5 and March 12 feeds have unresolved player IDs in other users' rosters. The selected BPCologna blocks have eight resolvable, unique players and pass the salary and multiplicity checks. The other-user defects remain recorded; those feeds do not certify complete field rosters. Provenance: `standalone_qualified_receipts.json` · `field_roster_defects`; all normalized tables · `field_rosters_verified`; `standalone_coverage.json` · `field_roster_defect_contests`.

## Youdacao source notes

The selected `youdacao` blocks qualify in five contests on five dates: May 13, 2022, then February 20 and 21 and March 5 and 12, 2025. These span 2021–22 and 2024–25. All five entry fees are $2,120, all official entry caps are one, and all retained blocks contain exactly one complete eight-player roster. The collapse leaves five variants and five decision episodes. These records do not create contemporaneous owner comparisons. Provenance: `standalone_portfolios.parquet` · `user/date/season/fee/cap/owner_pairing_available`; `standalone_selection_episodes.parquet`; `standalone_coverage.json` · `by_user/by_user_season`.

The February 21, March 5 and March 12 sources share the field-roster limitations described above. The May 2022 source also predates the recent shot-feature window used by the existing process study. This source audit performs no shot-feature join and does not count a recovered roster as a complete historical usage, shot, injury or news context.

## Contest-by-contest identity checks

The official `contestDetail` responses were already saved when this extraction began. The extractor performs no network retrieval. It checks exact contest ID, title, fee, entry cap, filled count and maximum size against the FantasyLabs header, plus official NBA sport, Classic game type and scoring style. Official UTC start times are converted to America/New_York and compared with the source's local start time. Both calendar date and time must match. Official identity corroboration does not independently prove the third-party player rosters.

| CID | Local date | Official filled / maximum | Retained requested handles | Other-user defective rosters |
|---|---|---:|---|---:|
| 126748469 | 2022-05-13 | 18 / 18 | youdacao | 0 |
| 174065879 | 2025-02-20 | 15 / 15 | youdacao | 0 |
| 174148129 | 2025-02-21 | 15 / 15 | bpcologna, youdacao | 2 |
| 174268433 | 2025-02-25 | 18 / 18 | bpcologna | 3 |
| 174498341 | 2025-03-05 | 23 / 25 | bpcologna, youdacao | 4 |
| 174530149 | 2025-03-06 | 15 / 15 | bpcologna | 0 |
| 174717069 | 2025-03-12 | 25 / 25 | bpcologna, youdacao | 2 |

Every row above has a matching saved official header and a complete selected peer block. The canonical outputs contain seven contests, seven dates, ten selected portfolios, ten canonical lineups and eighty selected player slots. They contain 1,563 usable candidate player contexts; five additional raw candidate rows lack usable team/game metadata and appear in the player-pool quarantine. Exact candidate-pool signatures include all raw candidate IDs, positions, salaries and event IDs, including those five unusable rows. No selected peer roster loses a player. Provenance: `standalone_qualification.parquet`; `standalone_coverage.json` · `row_counts`; `standalone_quarantine.parquet` · `stage=player_pool`; reused `peer_process_sources.candidate_pool_signature/source_players`.

## Rejected sources and owner absence

The broader catalog recovery attempted 1,261 contest feeds outside the 9,503 owner-one-bullet inventory: 1,161 HTTP 200 responses and 100 HTTP 403 responses. That discovery inventory is not an SE sample and is not necessarily absent from the full owner ledger. This extraction considers only its fifteen reported-cap-one responses. Provenance: `standalone_retrievals.json`; `standalone_coverage.json` · `catalog_probes/catalog_statuses/reported_cap1_sources`.

Eight cap-one headers accompany contradictory multi-entry bodies and are rejected: 125623505, 126011736, 126241797, 158793542, 159300516, 159352977, 159628666 and 160048076. Their maximum user entry counts exceed one and their source filled counts disagree with the official counts. Official SE headers cannot repair those bodies. CID 160048076 additionally contains an `rsbathla` block reporting 150 entries while its claimed CID is absent from the owner ledger; that ambiguity is independently rejected. Provenance: original `standalone_raw` feeds · `users.*.totalRosters/contest.totalLineupsEntered`; official `standalone_official_raw` responses · `contestDetail.entries/maximumEntriesPerUser`; qualification · `reasons/source_owner_entries`.

The full owner check reads all 388,343 NBA `entry_history` rows across 20,372 distinct contest IDs, with no game-type or season filter. None of these fifteen claimed CIDs appears. Each accepted feed also has no owner handle. The retained lane is therefore `standalone_no_owner_ledger_anchor`, with `owner_pairing_available=false` and zero owner pairs. Absence means absence from this stored ledger, not independently audited absence from the owner's entire account history. Provenance: `standalone_coverage.json` · `full_owner_ledger_rows/full_owner_ledger_contests/owner_pairs`; qualification · `owner_ledger_rows/source_owner_entries`; full read-only database query in `owner_ledger()`.

## Verification lanes and interpretation limits

Accepted normalized records use `verification_lane=official_header_corroborated` and `headline_verified=true`. An internally consistent feed without an available official header would instead use `FL_only_uncorroborated` and `headline_verified=false`; that lane contributes no headline verified total. There are zero accepted uncorroborated contests in this extraction. Contradictory feeds have `verification_lane=rejected` in qualification and contribute no normalized selected records.

Selected-block certification and full-field certification are separate. There are eleven other-user defective blocks across four accepted feeds. `ownership_verified=false` is explicit throughout; raw source ownership and projection fields remain archived metadata and do not become forecasts, field ranks or selection reasons. `prelock_timing_verified=false` is also explicit throughout. The files do not certify initial-lock lineups, late-swap history, private news interpretation or profitability. Realized fantasy points are retained for source arithmetic closure, not used as prospective player-choice features. Header agreement and a coherent complete block support a corroborated third-party source observation; they are not independent first-party verification of the lineup.

The two requested peers were specified before this extraction. The extractor does not choose their retained contests by winnings, points or finishing position. Availability remains a catalog/public-feed sample, and these five dates per peer cannot establish a general private selection process.

## Mechanical checks and raw re-derivations

For BPCologna, the original February 21, 2025 block in CID 174148129 independently yields eight unique players, one entry, $50,000 salary and 267.5 realized DraftKings points. For youdacao, the original May 13, 2022 block in CID 126748469 yields eight unique players, one entry, $50,000 salary and 270.5 points. These numbers are sums of the original player fields and are compared with the normalized canonical roster, portfolio salary and score. They are arithmetic checks, not examples offered as profitable player-selection recommendations. Provenance: `standalone_coverage.json` · `raw_rechecks`; `raw_recheck()`.

The validator checks code, full-ledger content, retrieval evidence, original source and official-header hashes, plus hashes of every scientific output. It then re-extracts the raw sources, recomputes qualifications, episodes and summaries, and compares all normalized tables exactly. Exposure expansion requires eight slots per entry and exact source score and salary closure. Originals are read only. The existing paired source modules and namespace are not written by this extraction.

The standalone acceptance run passed 28 tests and `peer_se_standalone_sources.py --validate` returned seven verified contests, seven dates, ten portfolios, zero owner pairs and two raw rechecks. Known-bad tests cover an MME body under an SE header, incomplete/duplicate/missing selected players, salary overflow, multiplicity and hash conflicts, official-header disagreement, owner participation ambiguity, another user's unresolved player ID, repeated-room collapse and modified outputs. A corruption test also rewrites the output hash and still fails raw recomputation. Repository strict integration gates remain the orchestrator's final shipping check.

Artifacts: `nba/analytics/peer_se_standalone_sources.py`, `test_peer_se_standalone_sources.py`, and `nba/analytics/data/research_peer_se/standalone_{portfolios,lineups,players,exposures,selection_episodes,qualification,quarantine}.parquet`, `standalone_coverage.json`, `standalone_qualified_receipts.json`, `standalone_validation_receipt.json`. Saved immutable inputs remain in `standalone_raw/`, `standalone_official_raw/`, `standalone_retrievals.json` and `standalone_official_receipts.json`.
