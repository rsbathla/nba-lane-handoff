# NBA single entry player selection review

This review extends the recovered single-entry records for BPCologna and youdacao and compares their observable choices with yours where the same contest is available. Your stated method combines usage, player skill, shot or play-type volume, opponent allowance and pace; you introduced it in 2025–26. The records contain submitted rosters, rather than private projections or decision notes.

## BPCologna observations

The expanded sources contain **22 BPCologna SE entries on 20 distinct dates** across four seasons. Eleven entries, representing nine dates, are in contests you also entered. Eleven additional entries are in owner-absent contests: five from 2024–25 at $2,120, plus six from 2025–26 with fees from $333 to $5,300. Identical rosters entered into multiple rooms on the same date and exact player pool count as one selection episode. Sources: [paired episode support](../nba/analytics/data/research_peer_se/episode_summary.json), `support`; [standalone coverage](../nba/analytics/data/research_peer_se/standalone_coverage.json), `by_user` and `by_user_season`; [catalog qualification](../nba/analytics/data/research_peer_se/catalog_qualification_summary.json), `selected_peer_support`.

On the nine directly paired dates, BP shares an average **3.44 of eight players** with you. Relative to your roster on those dates, his average salary remaining is $22 lower, his cheapest player costs $178 more, and his counts of players costing at least $8,000 and at most $5,000 are each 0.11 higher. These are date-weighted price descriptions; they do not establish stronger roles, better projections or a salary construction advantage. Source: [paired descriptors](../nba/analytics/data/research_peer_se/paired_episode_descriptors.csv), `peer=bpcologna`.

## Youdacao observations

The expanded sources contain **21 youdacao SE entries on 19 distinct dates** across six seasons. Fourteen entries, representing 12 dates, are directly paired with you. Seven additional owner-absent entries include one from 2021–22 and four from 2024–25 at $2,120, plus two from 2025–26 at $2,120 and $5,300. Sources: paired episode support, standalone coverage and catalog qualification above.

On the 12 directly paired dates, youdacao shares an average **3.83 of eight players** with you. His average salary remaining is $158 lower, his cheapest player costs $158 less, and his counts of players costing at least $8,000 and at most $5,000 are respectively 0.08 and 0.17 lower. The opposite cheapest-player directions for BP and youdacao do not suggest a common large price-based difference from your choices. That is a descriptive inference from this small sample. Source: paired descriptors, `peer=youdacao`.

## What the additional archive contains

The qualified recovery grew from **seven SE contests to 32 contests on 30 dates**. Nineteen contests on 17 dates are owner anchored; thirteen additional contests have matching official DraftKings headers and complete selected-peer rosters, but no entry in the full retained owner ledger. Seven came from the earlier catalog inventory and six from the bounded 2025–26 catalog extension. The extraction lanes remain separate. Sources: [paired source coverage](../nba/analytics/data/research_peer_se/source_coverage.json), `verified_contests` and `verified_distinct_dates`; standalone coverage, `headline_verified_contests`, `headline_verified_dates` and `owner_pairs`.

| Observed source support | BPCologna | youdacao | You |
|---|---:|---:|---:|
| SE entries across the qualified source lanes | 22 | 21 | 19 |
| Distinct dates across the source lanes | 20 | 19 | 17 |
| Directly owner-paired dates | 9 | 12 | 17 |
| Additional owner-absent dates | 11 | 7 | 0 |
| Observed dates in 2025–26 | 10 | 4 | 4 |

The last row is especially relevant to your process change. The bounded catalog adds recent records, but those owner-absent dates cannot increase the same-contest comparison count. The existing recent direct comparison remains two observed dates for youdacao and four for BP before feature completeness checks. The paired source tables also include other members of the previously frozen peer cohort; standalone extraction in this extension is restricted to BPCologna and youdacao. Sources: the two coverage files, `by_user_season`, and catalog qualification, `selected_peer_support`.

Recovery attempted all **9,503 owner-one-bullet NBA Classic candidates**. There were 340 returned JSON feeds and 9,163 HTTP 403 responses. Only 27 returned feeds claimed cap one; eight had contradictory user entry counts or source identity and were rejected, leaving 19 qualified contests. A separate broader catalog search attempted 1,261 contests outside that one-bullet inventory, returning 1,161 feeds. Of its 15 cap-one claims, seven qualified and eight contained incompatible multi-entry bodies. These search counts measure retrieval coverage, not SE decisions. HTTP 403 does not establish that a historical contest never existed. Sources: paired coverage, `retrieval_statuses`; [standalone qualification](../nba/analytics/data/research_peer_se/standalone_qualification.parquet); standalone coverage, `catalog_statuses`.

The bounded 2025–26 extension attempted 7,640 public group IDs, receiving 601 HTTP 200 and 7,039 HTTP 403 responses. Its 272 NBA lists contain 571 in-window archived headers on 160 dates. Eleven distinct explicit cap-one Classic candidates appear: four were already attempted and seven were new. All seven new full feeds returned, six qualified, and the November 12 feed was rejected because both requested peer rosters contain unresolved player IDs. This is complete within the tested group interval, not a complete inventory of every contest held during the season. Source: [catalog audit](NBA_SE_CATALOG_AUDIT_2026-10-02.md), catalog qualification and `catalog_group_retrievals.jsonl`.

All seven standalone headers match official contest ID, NBA Classic type, date, name, fee, cap and filled entry count. The selected peer blocks contain eight distinct resolvable players with valid counts and salary closure. Four feeds contain unresolved player IDs in other users' rosters. Their selected BP/you rosters are retained, while full-field roster and ownership certification remain separate and qualified. An official header alone cannot repair a wrong roster payload. No complete peer account returns or certified pre-lock roster timing are inferred. Source: [standalone audit](NBA_SE_STANDALONE_SOURCE_AUDIT_2026-10-02.md), and standalone coverage, `field_roster_defects`, `prelock_timing_verified` and `peer_profitability_inferred`.

## Role and shot evidence

The added rosters are joined to the existing strictly prior-game feature definitions, with each metric's observed slot coverage shown separately. The target-user sample has 62 source rosters and 496 slots, collapsing to 56 canonical roster choices. A partial roster mean cannot be treated as a complete lineup profile. Same-contest comparisons require the metric on all eight selected players for both users. Owner-absent rosters describe the peer alone and cannot become a direct paired owner comparison. Source: [trait summary](../nba/analytics/data/research_peer_se/trait_summary.json), `row_counts`, `support_by_user_season` and `semantics`.

Across all qualified 2025–26 source lanes, BP has complete prior minutes and usage on seven of ten observed dates and a complete combined shot bundle on four. Youdacao has complete role data on all four observed dates, but a complete shot bundle on only one. These are per-peer selection profiles; direct comparisons require both rosters to be complete on the same contest. Source: [selected profiles](../nba/analytics/data/research_peer_se/trait_profiles.parquet), `user`, `season=2025-26`, `metric=min_l10/usg_l10/shot_bundle`, `observed_dates` and `complete_dates`.

For 2025–26, the complete same-contest role comparisons contain only **two dates per peer**:

| Peer | Prior minutes per selected player, peer / you | Prior usage percent, peer / you | Complete paired dates |
|---|---:|---:|---:|
| BPCologna | 26.436 / 26.304 | 21.781 / 22.874 | 2 |
| youdacao | 27.148 / 26.304 | 22.083 / 22.874 | 2 |

These use each selected player's previous ten games and equal date weights. BP's older complete comparison covers two dates, with fewer prior minutes and higher usage than you; both directions reverse in the later sample. Youdacao has no complete older owner-paired role date in this vintage. Each peer has only one complete later shot-bundle comparison date, and neither has a complete owner-paired Synergy-bundle comparison. No significance test is fitted to these tiny samples. Source: [paired trait profiles](../nba/analytics/data/research_peer_se/trait_paired_profiles.parquet), `season`, `metric`, `peer_value`, `owner_value` and `complete_dates`.

The new owner-absent 2025–26 records describe the following roster profiles. These are separate date sets, with no matching owner player pool in the existing archive, so the values cannot be subtracted from your profile or used as a controlled comparison between the peers.

| New catalog profile | BPCologna | youdacao |
|---|---:|---:|
| Observed dates / complete role dates | 6 / 5 | 2 / 2 |
| Prior minutes per selected player | 27.12 | 24.86 |
| Prior usage percent per selected player | 22.16 | 23.94 |
| Players with at least 30 prior minutes, per roster | 3.2 | 3.0 |
| Players with at least 25% prior usage, per roster | 1.8 | 3.5 |
| Lowest prior-minute player, averaged across rosters | 17.10 | 10.65 |
| Complete shot-bundle dates | 3 | 0 |

Both samples mix players with sustained minutes and players with lower historical minutes. The last row prevents a full-roster shot comparison for youdacao's new dates: only 12 of 16 selected slots have the combined shot inputs. BP has three complete new shot dates, which remain descriptive. Counts use the existing 30-minute and 25% usage thresholds. The minimum-minute observation is especially sensitive to a new role after news; it does not establish that a selected player was expected to play few minutes that night. Source: [lane profiles](../nba/analytics/data/research_peer_se/trait_lane_profiles.parquet), `source_origin=catalog`, `season=2025-26`, `metric`, `complete_dates`, `complete_date_mean` and `known_slots`.

The earlier standalone sources add five dates with some prior-history support, seven complete role rosters, and three complete shot-bundle rosters. Both owner-absent lanes add zero owner pairs. We cannot assume missing complete coverage is random: early-season players and changing injury-driven roles may be precisely the decisions worth examining. Sources: trait summary, `source_support_by_lane` and metric coverage; [selection episodes](../nba/analytics/data/research_peer_se/trait_selection_episodes.parquet), `source_origin`, `evidence_scope` and metric coverage; method audit.

The repaired feature frame spans October 22, 2024 through March 10, 2025 for 2024–25, and October 21, 2025 through April 12, 2026 for 2025–26. The new March 12, 2025 source therefore adds observed rosters without adding feature-supported player decisions in this vintage. Much older sources likewise remain outside the frame. Frame appearance and legacy shot completeness are inventory checks; they do not certify the full player-strength, all-30-team opponent allowance and pace intersection. Source: paired coverage, `frame_windows`; [method audit](NBA_SE_EXPANDED_METHOD_AUDIT_2026-10-02.md).

The broader earlier MME review found small repeated differences in recent minutes and minutes growth for BPCologna and youdacao. Those remain MME descriptions. They are not newly established SE selection rules. Your combined shot-type method remains unresolved as a manual process: the proxy tests do not reconstruct your expected minutes, injury interpretation, projected shot volume or private Synergy judgment. A sparse or unreplicated preference test does not establish that usage plus shot advantage is incorrect. See [the earlier process review](NBA_PEER_PROCESS_PATTERNS_2026-10-02.md), per-peer notes, feature definitions and uncertainty.

## SaberSim and FantasyLabs access

The current signed-in SaberSim interface exposed historical NBA slate and contest metadata on April 10 and February 24, 2026. The tested SE contest-title clicks did not open attributed peer rosters or a Flashback result view. This is a limitation of those observed probes, rather than a statement about the entire archive or subscription. The older interface requires separate sign-in; no account was selected. After you signed in, FantasyLabs' [NBA contest dashboard](https://www.fantasylabs.com/nba/contests-dashboard/) displayed the February 24 SE field and BP's complete attributed roster. This independently corroborates a previously recovered lineup; it is not an additional date. Its daily menus list a selective archive, rather than every contest held that day. The separate public catalog extension supplies six additional qualified recent sources; the known February 24 UI roster remains corroboration only. Source: [access receipts](../nba/analytics/data/research_peer_se/alternate_source_probes.json).

SaberSim's [Flashback documentation](https://support.sabersim.com/en/articles/12079605-using-contest-flashback) describes real DraftKings lineups, user and lineup views, and 100,000 model simulations. It also says in-slate swaps are not incorporated. That makes it a useful archive lead. Simulated ROI would remain conditional on the vendor model; it would not reveal private player-selection reasons or supply 100,000 independent historical dates. DraftKings' [published export policy](https://support.draftkings.com/dk/en-us/how-does-draftkings-keep-fantasy-sports-contests-transparent?id=kb_article_view&sysparm_article=KB0010720) limits completed-contest CSV availability to ten days, so older coverage depends on retained exports or archives.

## Audit and limits

The source gates require real cap-one contests, exact identities, complete selected rosters, canonical multiplicity, raw receipts and immutable source hashes. Every admitted paired normalized portfolio, lineup and candidate table is now independently recomputed from its original feed. Published price descriptors, user and seasonal support, and frame overlap are also recomputed. Known-bad fixtures cover multi-entry bodies posing as SE, incomplete rosters, changed normalized rows, altered support and altered descriptors. An isolated guard-removal test proves that the new original-source correspondence check rejects a coordinated wrong player-pool signature that the older internal checks accepted. The unchanged positive control passes; no actual corrupted source rows were found. Source: [guard-removal receipt](../nba/analytics/data/research_peer_se/raw_reconstruction_guard_removal_evidence.json). No production scoring weights or optimizer rules changed.

The source expansion is concrete progress, but a much larger comparable recent SE archive remains the important missing input. Authenticated recovery should include losing dates and all recovered qualifying entries, rather than selecting peers' winning examples. The comparison still needs dated expected minutes, injury/news availability, projected usage and shot volume, and the alternatives considered before lock to distinguish similar rosters produced by different reasoning. Those gaps are not evidence against your shot matchup analysis.

The integration gate covers these qualified research artifacts. The full historical construction corpus retains a separate source-quality gate with unresolved conflicts; passing this scoped review cannot certify that entire corpus. Final test, source, code, report and integration receipts are recorded in [the validation receipt](../nba/analytics/data/research_peer_se/final_validation_receipt_2026-10-02.json).
