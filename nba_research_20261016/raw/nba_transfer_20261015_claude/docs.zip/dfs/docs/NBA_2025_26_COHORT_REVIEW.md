# DK NBA 2025-26 — how the top players built vs how we built

Same per-lineup formula for every population; entry-weighted. TOP-1% = every lineup that finished in its contest's top 1%. REGULARS = the 10 best FL-measured season ROIs at ≥300 entries in the cohort (FL money runs ~17pts low — rankings only). Partial-snapshot contests excluded from any scored measure.


## A · High-fee non-SE (≥$150, multi-entry)

Contests 107 (complete field sets 107, trimmed 0; 2 excluded from scoring). His entries 1,263, fees $941,876, **ROI +27.2%** (DK export).
 His ceiling: top-1% 1.23% (base 1), top-5% 6.55% (5), top-20% 22.67% (20), cash 23.6%.
 Among 27 volume-gated regulars (FL formula both sides) he ranks #7 by ROI.


| metric | HIS | TOP-1% | REGULARS | FIELD |
|---|---|---|---|---|
| ownership sum | 255 | 242 | 244 | 242 |
| sub-10% players | 1.31 | 1.69 | 1.54 | 1.67 |
| max player own | 64 | 63 | 64 | 63 |
| salary unspent | $161 | $110 | $141 | $139 |
| studs (≥$9K) | 1.09 | 1.10 | 1.02 | 1.03 |
| punts (<$4K) | 1.05 | 1.11 | 1.02 | 1.04 |
| games used | 3.80 | 3.84 | 3.88 | 3.78 |
| 3+ same game | 86% | 85% | 85% | 87% |
| 4+ same game | 56% | 53% | 50% | 53% |
| 3+ same team | 67% | 59% | 61% | 62% |
| entries on duplicated builds | 5% | 9% | 6% | 8% |
| lineup-entries | 1,127 | 417 | 5,629 | 40,875 |

**Top regulars (FL ROI rank, volume-gated):**

| user | entries | FL ROI | top-1% | own sum | sub-10 | 4+ game | dup |
|---|---|---|---|---|---|---|---|
| invertedcheese | 468 | +311% | 1.9% | 243 | 1.24 | 53% | 3% |
| needlunchmoney | 364 | +81% | 2.5% | 197 | 2.53 | 39% | 4% |
| moklovin | 1,217 | +77% | 1.0% | 253 | 1.48 | 55% | 8% |
| wilson1 | 341 | +68% | 2.1% | 245 | 1.56 | 60% | 6% |
| bpcologna | 1,383 | +37% | 1.6% | 265 | 1.02 | 54% | 7% |
| dtadiello | 391 | +23% | 1.0% | 272 | 1.22 | 53% | 9% |
| mazwa | 813 | +14% | 1.5% | 223 | 2.07 | 41% | 1% |
| LeVerticalDFS | 329 | +1% | 1.5% | 244 | 1.41 | 73% | 8% |
| dacoltz | 406 | -1% | 1.0% | 238 | 1.67 | 28% | 9% |
| zokin | 594 | -3% | 1.3% | 224 | 1.93 | 38% | 5% |

**Month arc (own sum / 4+ game): HIS vs TOP-1%**

| month | HIS own | TOP-1% own | HIS 4+g | TOP-1% 4+g |
|---|---|---|---|---|
| 2025-10 | 285 | 276 | 40% | 44% |
| 2025-11 | 293 | 275 | 56% | 40% |
| 2025-12 | 285 | 258 | 66% | 54% |
| 2026-01 | 244 | 231 | 45% | 45% |
| 2026-02 | 279 | 254 | 48% | 63% |
| 2026-03 | 186 | 177 | 40% | 58% |
| 2026-04 | 189 | 192 | 95% | 90% |

## B · Daily flagship 150-max

Contests 125 (complete field sets 125, trimmed 0; 2 excluded from scoring). His entries 17,931, fees $286,083, **ROI +14.5%** (DK export).
 His ceiling: top-1% 1.08% (base 1), top-5% 5.63% (5), top-20% 20.71% (20), cash 22.2%.
 Among 1058 volume-gated regulars (FL formula both sides) he ranks #163 by ROI.


| metric | HIS | TOP-1% | REGULARS | FIELD |
|---|---|---|---|---|
| ownership sum | 216 | 188 | 167 | 175 |
| sub-10% players | 1.22 | 1.86 | 2.65 | 2.32 |
| max player own | 51 | 48 | 46 | 47 |
| salary unspent | $134 | $119 | $190 | $164 |
| studs (≥$9K) | 1.07 | 1.04 | 0.97 | 0.99 |
| punts (<$4K) | 1.10 | 1.04 | 0.95 | 1.01 |
| games used | 3.40 | 3.74 | 3.90 | 3.80 |
| 3+ same game | 90% | 87% | 84% | 85% |
| 4+ same game | 67% | 54% | 49% | 51% |
| 3+ same team | 73% | 61% | 51% | 56% |
| entries on duplicated builds | 26% | 22% | 9% | 16% |
| lineup-entries | 15,835 | 26,034 | 4,844 | 2,415,461 |

**Top regulars (FL ROI rank, volume-gated):**

| user | entries | FL ROI | top-1% | own sum | sub-10 | 4+ game | dup |
|---|---|---|---|---|---|---|---|
| j.alexk | 366 | +2527% | 1.4% | 160 | 3.12 | 49% | 2% |
| yaomania11 | 384 | +1669% | 1.0% | 141 | 3.32 | 59% | 3% |
| apena28 | 431 | +1627% | 1.6% | 216 | 1.45 | 51% | 24% |
| hchawk89 | 1,084 | +1535% | 1.7% | 211 | 1.74 | 51% | 15% |
| inotnec | 345 | +1467% | 0.9% | 123 | 3.23 | 83% | 1% |
| RunitupChick | 831 | +1446% | 0.6% | 146 | 3.27 | 47% | 5% |
| Ramarosa922 | 543 | +1409% | 1.3% | 190 | 2.24 | 43% | 22% |
| Beaudoin3232 | 418 | +1382% | 0.7% | 125 | 3.20 | 54% | 10% |
| Touchdowntom62 | 511 | +1336% | 0.8% | 161 | 2.79 | 33% | 2% |
| MrFoot | 563 | +1268% | 1.1% | 144 | 3.04 | 37% | 2% |

**Month arc (own sum / 4+ game): HIS vs TOP-1%**

| month | HIS own | TOP-1% own | HIS 4+g | TOP-1% 4+g |
|---|---|---|---|---|
| 2025-10 | 249 | 208 | 44% | 36% |
| 2025-11 | 256 | 199 | 61% | 48% |
| 2025-12 | 256 | 216 | 71% | 49% |
| 2026-01 | 256 | 214 | 72% | 58% |
| 2026-02 | 215 | 186 | 57% | 52% |
| 2026-03 | 136 | 120 | 51% | 49% |
| 2026-04 | 147 | 148 | 89% | 84% |
| 2026-05 | 148 | 147 | 100% | 100% |

## C · ~$2K single-entry

Contests 4 (complete field sets 4, trimmed 0; 0 excluded from scoring). His entries 4, fees $14,840, **ROI -12.4%** (DK export).
 His ceiling: top-1% 0.00% (base 1), top-5% 0.00% (5), top-20% 25.00% (20), cash 25.0%.
 Among 13 volume-gated regulars (FL formula both sides) he ranks #7 by ROI.


| metric | HIS | TOP-1% | REGULARS | FIELD |
|---|---|---|---|---|
| ownership sum | 381 | — | 346 | 339 |
| sub-10% players | 0.50 | — | 0.88 | 0.85 |
| max player own | 71 | — | 73 | 70 |
| salary unspent | $25 | — | $81 | $110 |
| studs (≥$9K) | 1.50 | — | 1.23 | 1.27 |
| punts (<$4K) | 0.50 | — | 0.58 | 0.70 |
| games used | 4.00 | — | 4.23 | 4.17 |
| 3+ same game | 100% | — | 81% | 85% |
| 4+ same game | 50% | — | 54% | 47% |
| 3+ same team | 75% | — | 54% | 45% |
| entries on duplicated builds | 0% | — | 8% | 7% |
| lineup-entries | 4 | — | 26 | 60 |

**Top regulars (FL ROI rank, volume-gated):**

| user | entries | FL ROI | top-1% | own sum | sub-10 | 4+ game | dup |
|---|---|---|---|---|---|---|---|
| youdacao | 2 | +372% | 0.0% | 402 | 0.50 | 50% | 0% |
| LeVerticalDFS | 2 | +183% | 0.0% | 236 | 1.50 | 50% | 0% |
| sami123 | 2 | +100% | 0.0% | 224 | 3.00 | 0% | 0% |
| cheddabisque | 2 | +89% | 0.0% | 258 | 1.50 | 100% | 0% |
| wilson1 | 3 | +57% | 0.0% | 330 | 1.00 | 33% | 0% |
| bpcologna | 4 | +35% | 0.0% | 386 | 0.50 | 100% | 0% |
| moklovin | 3 | -37% | 0.0% | 431 | 0.33 | 67% | 33% |
| papagates | 2 | -100% | 0.0% | 297 | 1.00 | 50% | 0% |
| bkreider | 3 | -100% | 0.0% | 445 | 0.33 | 33% | 33% |
| zokin | 3 | -100% | 0.0% | 333 | 0.33 | 33% | 0% |

## C · contest by contest — his build vs the winner (name, own%, salary)


**2025-10-24 — NBA $26K Hall of Famer [$13K to 1st] ($2120, field 13)** — his own-sum 292.3 vs winner 292.3 (winner 297.25 pts, 8/8 overlap; winner users: rsbathla)

| HIS | own | sal | WINNER | own | sal |
|---|---|---|---|---|---|
| Victor Wembanyama | 38.5 | 11300 | Victor Wembanyama | 38.5 | 11300 |
| P.J. Washington | 46.1 | 5000 | P.J. Washington | 46.1 | 5000 |
| Stephon Castle | 53.9 | 6800 | Stephon Castle | 53.9 | 6800 |
| Derik Queen | 7.7 | 4000 | Derik Queen | 7.7 | 4000 |
| Javon Small | 15.4 | 3300 | Javon Small | 15.4 | 3300 |
| Andrew Wiggins | 46.1 | 5800 | Andrew Wiggins | 46.1 | 5800 |
| Nickeil Alexander-Walker | 53.9 | 4000 | Nickeil Alexander-Walker | 53.9 | 4000 |
| Anthony Davis | 30.8 | 9800 | Anthony Davis | 30.8 | 9800 |

**2025-11-05 — NBA $50K Hall of Famer [Single Entry] ($2120, field 25)** — his own-sum 312.0 vs winner 264.0 (winner 324.75 pts, 3/8 overlap; winner users: wilson1)

| HIS | own | sal | WINNER | own | sal |
|---|---|---|---|---|---|
| Isaiah Stewart | 56.0 | 5200 | Nic Claxton | 20.0 | 5600 |
| Herbert Jones | 24.0 | 4700 | Jaylen Brown | 12.0 | 8400 |
| Jose Alvarado | 56.0 | 3300 | Jose Alvarado | 56.0 | 3300 |
| Pascal Siakam | 52.0 | 9500 | Pascal Siakam | 52.0 | 9500 |
| Cade Cunningham | 36.0 | 10200 | Amen Thompson | 12.0 | 7700 |
| Ausar Thompson | 4.0 | 6300 | Jarace Walker | 48.0 | 5800 |
| D'Angelo Russell | 28.0 | 6100 | Christian Braun | 8.0 | 5000 |
| Daniel Gafford | 56.0 | 4700 | Daniel Gafford | 56.0 | 4700 |

**2026-02-19 — NBA $50K Thunderdome [Single Entry] ($5300, field 10)** — his own-sum 620.0 vs winner 480.0 (winner 294.25 pts, 4/8 overlap; winner users: youdacao)

| HIS | own | sal | WINNER | own | sal |
|---|---|---|---|---|---|
| Tristan Vukcevic | 90.0 | 4300 | Tristan Vukcevic | 90.0 | 4300 |
| Jarace Walker | 100.0 | 5900 | Jay Huff | 70.0 | 5200 |
| Andrew Nembhard | 90.0 | 7300 | Tyrese Maxey | 100.0 | 9600 |
| Jay Huff | 70.0 | 5200 | Micah Potter | 40.0 | 3900 |
| Tyrese Maxey | 100.0 | 9600 | Quentin Grimes | 30.0 | 4200 |
| RJ Barrett | 60.0 | 6300 | Jarace Walker | 100.0 | 5900 |
| Aaron Nesmith | 50.0 | 5600 | VJ Edgecombe | 20.0 | 6500 |
| Paul Reed | 60.0 | 5700 | Jalen Johnson | 30.0 | 10400 |

**2026-02-24 — NBA $60K Thunderdome [Single Entry] ($5300, field 12)** — his own-sum 300.0 vs winner 300.0 (winner 305.0 pts, 4/8 overlap; winner users: ShaidyAdvice)

| HIS | own | sal | WINNER | own | sal |
|---|---|---|---|---|---|
| Marvin Bagley | 25.0 | 4700 | Draymond Green | 25.0 | 5500 |
| Khris Middleton | 33.3 | 5000 | Zion Williamson | 41.7 | 7700 |
| Collin Sexton | 33.3 | 4600 | Kevin Porter | 66.7 | 7800 |
| Jalen Johnson | 25.0 | 10800 | Micah Potter | 8.3 | 4200 |
| Kevin Porter | 66.7 | 7800 | Brandin Podziemski | 75.0 | 6200 |
| Moses Moody | 16.7 | 5400 | Moses Moody | 16.7 | 5400 |
| Brandin Podziemski | 75.0 | 6200 | Quenton Jackson | 58.3 | 4400 |
| Draymond Green | 25.0 | 5500 | Bam Adebayo | 8.3 | 8800 |
## FanDuel 2025-26 — his side (own scoreboard; field side pending your exports)

Source: your FanDuel entries-upload-template CSVs (one per slate, every contest you entered). Players are FD slate ids, so this is build-structure only until the FD player lists and contest results land in `~/Downloads/fd_nba_contests/` (request file there lists every contest to export).


| FD cohort | contests | your entries | fees | entries on duplicated builds | max single-player exposure | one-build contests (of ≥20-entry) |
|---|---|---|---|---|---|---|
| A · WFBC Qualifier $2,000–$2,975 | 66 | 247 | $529,175 | 0% | 80% | 0/2 |
| B · daily Shot flagship $5.55–$15 | 89 | 15,154 | $138,644 | 62% | 83% | 31/83 |
| C · Assist Single Entry $5 ($2–3K pools) | 264 | 311 | $27,291 | 0% | 100% | 0/0 |
| other (Floater/Crossover/etc.) | 1132 | 14,645 | $539,762 | 60% | 87% | 38/99 |

Readings: FD high-fee qualifiers are entered as singles/small blocks with zero self-dups; the Shot flagships carry the one-build×150 habit on 37% of max-entry days (31 of 83) (e.g. 2026-04-28, 05-06, 05-19: 150 entries, 1 build) alongside fully-distinct days — the same bimodal pattern DK showed in 2020-21. The same builds are routinely entered into the $3 Floater and the $15 Shot on one slate (cross-contest reuse), which is a train, not diversification. No FD equivalent of DK's $2,120 SE exists in your entries; FD's SE lane is the $5 Assist with $2–3K pools.
