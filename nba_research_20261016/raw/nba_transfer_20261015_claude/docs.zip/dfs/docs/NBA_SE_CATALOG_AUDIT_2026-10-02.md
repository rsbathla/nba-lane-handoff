# Bounded NBA single-entry catalog recovery

Recorded October 2, 2026. This audit extends public-source discovery and qualification. It does not fit player-selection models or change weights, and all new normalized records retain `promotion_status=candidate_unpromoted` until the orchestrator incorporates them.

## BPCologna source notes

Six newly discovered `bpcologna` single-entry blocks pass the existing selected-roster guards and matching official contest-header checks. They occur on October 23, 2025, January 16, 22 and 23, 2026, and March 11 and 17, 2026. The entry fees are $333, $2,120, $2,120, $2,120, $2,120 and $5,300, respectively. Each block has one complete eight-player roster. These yield six contests, six dates, six exact-pool decision episodes and six canonical variants. All are in the 2025–26 season and have no same-contest owner ledger anchor. Provenance: `catalog_candidate_portfolios.parquet` · `user/date/season/fee/entries/headline_verified/owner_pairing_available`; `catalog_candidate_episodes.parquet`; `catalog_qualification_summary.json` · `selected_peer_support`.

The November 12, 2025 feed also reports a BPCologna entry, but its selected roster references player IDs missing from the candidate metadata. That block is quarantined without filling the missing players. It contributes no normalized selected lineup or decision support. Provenance: `catalog_raw/data_2025-11-12_184788944.response` · `users/players`; `catalog_candidate_quarantine.parquet` · `user=bpcologna/stage=portfolio`; disposition · `cid=184788944`.

## Youdacao source notes

Two newly discovered `youdacao` blocks qualify: March 11 and 17, 2026, at $2,120 and $5,300. Both have one complete eight-player roster, matching official NBA Classic headers, and no owner ledger anchor. They yield two contests, two dates, two exact-pool decision episodes and two canonical variants in 2025–26. Provenance: normalized portfolios and episodes; qualification summary · `selected_peer_support`.

The November 12 feed reports a youdacao entry but has the same selected-player resolution failure described above. The presence of the handle and a valid official header cannot repair an incomplete selected source block. Provenance: original CID184788944 body and portfolio quarantine.

## New source dispositions

| CID | Date | Fee | Retained requested handles | Disposition |
|---|---|---:|---|---|
| 183877515 | 2025-10-23 | $333 | bpcologna | Qualified source candidate |
| 184788944 | 2025-11-12 | $2,120 | none | Both selected blocks have unresolved player IDs |
| 187351358 | 2026-01-16 | $2,120 | bpcologna | Qualified source candidate |
| 187549820 | 2026-01-22 | $2,120 | bpcologna | Qualified source candidate |
| 187572958 | 2026-01-23 | $2,120 | bpcologna | Qualified source candidate |
| 188750204 | 2026-03-11 | $2,120 | bpcologna, youdacao | Qualified source candidate |
| 188927072 | 2026-03-17 | $5,300 | bpcologna, youdacao | Qualified source candidate |

All seven full feeds and all seven official-header requests returned HTTP 200. Six sources supply eight qualified requested-peer portfolios, eight canonical lineups, 1,055 usable candidate contexts and 64 selected player slots. Twenty-seven field-roster defects belong to the rejected November 12 feed; one other-user defective block appears in each of the accepted January 16 and March 17 feeds. Field defects and selected-peer qualification remain separate. There are two player-pool quarantine rows and two selected-portfolio quarantine rows, giving 33 quarantine records across these distinct stages. Provenance: data/official retrieval journals; qualification summary · `row_counts/disposition_counts`; quarantine · `stage/cid`.

## Tested discovery interval

The scan requested every integer group ID from **127037 through 134676**, inclusive: **7,640 IDs**. These bounds were supplied from saved NBA anchors for October 21, 2025 and April 20, 2026. The endpoint is the existing repository's published `GROUP` endpoint in `tools/fl_nba_showdown_lib.py`, `https://d3ttxfuywgi7br.cloudfront.net/contests/{gid}/`. The scan uses plain requests with six workers and a 15-second timeout. It adds no authentication, cookies, browser tokens or custom request headers. Every completed request receives an HTTP-status, timestamp, byte-count and response-hash receipt. The observed run had no retries: **601 HTTP 200 and 7,039 HTTP 403** responses. A 403 is an access failure and does not establish that the group is absent. Provenance: `catalog_config.json`; `catalog_group_retrievals.jsonl` · `gid/status/attempts`; `catalog_discovery_summary.json` · `group_statuses`.

The scan retained immutable response entity bytes for **272 NBA-relevant lists**, containing **574 NBA contest-header rows**. Of those, **571 rows on 160 distinct displayed dates** fall within the requested **2025-10-21 through 2026-04-12** window. The three outside-window rows remain in their immutable originals and are excluded from candidates. The exact retained in-window date list is recorded in `catalog_discovery_summary.json.exact_retained_header_dates`. This is coverage of a tested ID interval and the public lists returned, not certified coverage of every NBA contest or every season date.

The existing `nba_groups_index.json` was built around owner Showdown dates and was a partial discovery source. This extension preserves that index and all earlier source/standalone/trait artifacts. It saves its new receipts and originals only under the `catalog_*` namespace and `catalog_raw/`.

## Candidate and identity guards

Candidate discovery requires raw `ContestData.SportId=2`, explicit numeric `MultiEntryMax=1`, a valid CID and an in-window date. An SE title alone is insufficient. Obvious Showdown titles and draft groups shared with an obvious Showdown title are excluded. Other NBA cap-one format claims remain unclassified until roster/owner/official guards resolve them. Original group IDs, complete header fields and repeated discovery occurrences remain available.

This produced **11 distinct in-window non-Showdown cap-one CIDs**. Four were already attempted and verified in the earlier owner-paired sample: 183929501, 184483420, 188170143 and 188339631. The seven new CIDs in the table above were requested once each. Deduplication compares full prior paired and standalone retrieval inventories, including failures; it does not retry prior 403s merely because another discovery found the same CID. Conflicting repeated CID dates, titles, fees, caps or draft groups block retrieval. Provenance: `catalog_candidates.parquet` · `already_attempted/already_paired_verified/prior_attempt_records/group_ids/candidate_reasons`.

Catalog/body checks require matching CID, title, date, displayed start time, fee, cap and available contest-size fields. A body's user counts may not contradict the claimed entry cap. Qualification reuses the existing exact owner-ledger guard when an owner context exists. For these seven new CIDs, the full **388,343-row NBA ledger across 20,372 CIDs** has zero rows, and all source bodies omit the owner handle. The six accepted sources therefore reuse the standalone guard: matching official CID/title/date-time/fee/cap/fill/size and NBA Classic type, internal counts, unique source identities and complete selected eight-player blocks. Official UTC start time is converted to America/New_York for the source-header check. Provenance: `peer_se_catalog.qualify`; full-ledger digest; candidate disposition · `owner_ledger_rows/source_owner_entries`; saved official `contestDetail` originals.

Accepted rows carry `lane=standalone_no_owner_ledger_anchor`, `verification_lane=official_header_corroborated`, `headline_verified=true` and `owner_pairing_available=false`. `prelock_timing_verified=false` and `ownership_verified=false` are explicit throughout. Matching official headers corroborate contest identity, not first-party lineup identity or initial-lock timing. The archive does not establish private selection reasons, late-swap history or audited profitability. No owner pairs are manufactured from an owner entry in another contest.

## Arithmetic rechecks and acceptance

The original October 23 BPCologna block in CID183877515 independently sums to eight unique players, one entry, **$49,900 salary and 350 points**. The original March 11 youdacao block in CID188750204 independently sums to eight unique players, one entry, **$49,900 salary and 282.5 points**. Both agree with normalized canonical rosters, salary and score. Realized points are used for arithmetic checks only. Provenance: `catalog_qualification_summary.json.raw_rechecks`; original player `salary/actualPoints` fields and user `lineupCt/totalRosters`.

The validator pins code, full owner-ledger content, earlier deduplication inputs, journals, raw originals and every scientific output. It checks complete bounded ID coverage, permitted retry patterns, exact new-CID attempt coverage, absence of prior-CID refetches, raw discovery recomputation, raw qualification recomputation, eight-slot exposure closure and independent score/salary checks. The acceptance suite passed **34 tests**, including missing/boolean caps, wrong dates, conflicting duplicate CIDs, body/header disagreement, prohibited 403 retry patterns and normalized-output corruption. Rewriting a corrupted output's receipt hash still fails raw qualification recomputation.

The source validator passes with six new qualified contests. Repository strict integration gates, incorporation into the comparison, and manifest wiring remain the orchestrator's responsibility. No models, composite weights or production selections changed in this mechanical recovery.

Artifacts: `peer_se_catalog.py`, `test_peer_se_catalog.py`, `catalog_config.json`, group/data/official retrieval journals, `catalog_raw/`, discovery headers/candidates/summary, `catalog_candidate_{portfolios,lineups,players,exposures,episodes,disposition,quarantine}.parquet`, `catalog_qualification_summary.json`, and `catalog_validation_receipt.json`.
