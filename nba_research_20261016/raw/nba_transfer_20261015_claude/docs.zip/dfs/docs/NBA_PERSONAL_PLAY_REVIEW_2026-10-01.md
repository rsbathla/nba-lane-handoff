# Historical NBA play review

This review covers Ramneik's recorded NBA entries and the saved player selections around the change to usage plus shot-type advantage in **2025–26**, the season he identified. It separates recorded returns, changes in contest allocation, observed selection patterns, and what the available evidence can establish about the method. Monetary results use the full entry ledger; selection results use an explicitly reconciled subset.

## Recorded season results

Winnings include cash plus tickets at their recorded value. Net is winnings minus entry fees, before any unrecorded research or operating costs. NBA-proper excludes WNBA, Summer League, offseason exhibitions and Best Ball. The COVID seasons use the existing repo's season boundaries. The 2019–20 row is only the archived bubble tail. Sources: [season_results.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/season_results.csv), fields `season`, `fees`, `net`, `roi_pct`; read-only `entry_history`.

| Season | Entry fees | Net result | ROI |
|---|---:|---:|---:|
| 2019–20 partial | $41,638 | −$17,296 | −41.5% |
| 2020–21 | $1,312,511 | −$173,594 | −13.2% |
| 2021–22 | $1,086,986 | −$136,069 | −12.5% |
| 2022–23 | $1,646,868 | −$5,455 | −0.3% |
| 2023–24 | $2,014,141 | −$498,748 | −24.8% |
| 2024–25 | $2,120,865 | −$131,702 | −6.2% |
| 2025–26 | $2,291,172 | **+$540,931** | **+23.6%** |

The latest season improved by **$672,633** in recorded net result over 2024–25. Classic and Showdown followed different paths. Sources: the season table above and [format_results.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/format_results.csv), `season`, `game_type`, `fees`, `net`, `roi_pct`.

| Format | 2024–25 net | 2024–25 ROI | 2025–26 net | 2025–26 ROI |
|---|---:|---:|---:|---:|
| Classic | −$21,296 | −1.4% | **+$549,648** | **+26.6%** |
| Showdown Captain | −$110,406 | −19.3% | −$43,717 | −23.9% |
| Other NBA formats | $0 | — | +$35,000 | +87.5% |

The latest other-format result is one Non Late Swap entry with a $40,000 fee. Excluding it leaves **+$505,931** on $2,251,172 of fees, or **+22.5% ROI**. The breakout therefore does not depend on that one exceptional format. Source: `format_results.csv`, `game_type=Non Late Swap`; arithmetic from `season_results.csv`.

## Contest allocation and where results changed

Among Classic and Showdown stakes, the Classic share increased from **73.0% to 91.9%**. An exact symmetric decomposition of their combined ROI change attributes **22.2 percentage points** to changed results within formats and **6.5 points** to changed allocation between formats. This is a description of the observed arithmetic; it does not identify why results changed within Classic. Source: [summary.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/summary.json), `mix_decomposition`.

Within Classic, the improvement appeared in every paid entry-fee band present in both seasons. These are dependent parts of the same portfolio, not six independent confirmations. Source: [fee_results.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/fee_results.csv), `game_type=Classic`, `season`, `fee_tier`, `fees`, `net`, `roi_pct`.

| Entry fee | 2024–25 ROI | 2025–26 ROI | 2025–26 net |
|---|---:|---:|---:|
| $3 to under $10 | −25.3% | +9.5% | +$11,963 |
| $10 to under $33 | −8.3% | +40.5% | +$146,090 |
| $33 to under $150 | −26.9% | +30.9% | +$30,724 |
| $150 to under $600 | +5.6% | +8.4% | +$51,458 |
| $600 to under $2,000 | +20.1% | +39.9% | +$151,941 |
| $2,000 and above | −12.5% | +32.2% | +$157,472 |

Field-size results were less uniform. Classic contests with **21–999 entries** declined from +23.5% to +13.0% ROI, while the **1,000–9,999** group improved from −24.8% to +44.6% and the **10,000–99,999** group improved from −24.6% to +30.9%. Source: [field_results.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/field_results.csv), Classic rows and `field_size`, `roi_pct`. This suggests the improvement was not simply confined to smaller fields; it does not establish a preferred contest size for future play.

Matching the two seasons across **20 common entry-fee-band × field-size cells** covers more than **99.9%** of Classic stakes in each season. Their observed improvement is **27.9 ROI points**: +32.9 within cells and −5.0 from changes in cell allocation. At this coarse resolution, changing the Classic contest mix does not explain the gain. Opponent strength, exact payouts and slate difficulty remain uncontrolled. Source: `summary.json`, `classic_case_mix`; [classic_case_mix.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/classic_case_mix.csv).

## Monthly consistency and large wins

Classic was profitable in **seven of eight played months** in 2025–26. December was −$11,406; January was +$149,331 and February +$176,667. This shows the gain occurred across the calendar, though the months share the same process and contain large tournament payouts. Source: [monthly_results.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/monthly_results.csv), `season=2025-26`, `game_type=Classic`, `month`, `net`.

| Classic sensitivity | Remaining net | Remaining ROI |
|---|---:|---:|
| Full 2025–26 season | +$549,648 | +26.6% |
| Remove largest winning entry | +$402,148 | +19.5% |
| Remove three largest winning entries | +$202,945 | +9.8% |
| Remove five largest winning entries | +$32,013 | +1.6% |
| Remove ten largest winning entries | −$168,987 | −8.2% |
| Remove three most profitable calendar days | +$249,328 | +12.5% |
| Remove five most profitable calendar days | +$53,809 | +2.7% |

These removals subtract each removed entry's or day's fees as well as its net result. They are hindsight stress tests, not estimates of a strategy without winning outcomes. The five largest Classic winning entries contributed **$517,635**, or **94.2% of annual Classic net**. Source: `summary.json`, `classic_concentration`; [largest_wins.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/largest_wins.csv).

A calendar-week bootstrap, keeping each week's entries together, gives a descriptive 95% interval of approximately **−0.2% to +56.6%** for the latest Classic ROI, and **−12.2 to +69.1 percentage points** for its improvement over 2024–25. Those wide intervals include zero. Recorded profit is certain within this ledger; persistent underlying profitability and a season-to-season skill improvement are not statistically established by this bootstrap. It also does not reconstruct alternative lineups or address changes in market competition. Source: `summary.json`, `weekly_classic_uncertainty`, 5,000 reproducible draws.

## Saved selections and source coverage

Historical FantasyLabs sources contain unresolved partial rosters, player-ID gaps and contest-count conflicts. For this review, each retained own contest must have exactly eight unique resolvable players per build, valid salary and ownership fields, legal salary totals, exact personal entry counts, and a complete multiset of lineup scores matching the DK ledger. Field comparisons additionally require filled-entry totals matching DK on both source surfaces and ownership totals conserving eight roster slots. The audit explicitly allows at most 0.005 percentage points per listed player for assumed two-decimal ownership rounding; it allows no unexplained difference in filled-entry counts. The contest's capacity is not treated as its filled count. No missing player is inferred.

| Coverage | 2024–25 | 2025–26 |
|---|---:|---:|
| All ledger Classic contests | 2,144 | 2,308 |
| Saved user-feed contests | 220 | 325 |
| Own rosters and scores reconciled | 168 | 200 |
| Also field counts and ownership reconciled | 40 | 31 |
| Comparable window with usable shot features and at least four opponent teams | 15 | 14 |
| Distinct days in that final comparison | 13 | 14 |

The final comparable subset represents **$162,830** of 2024–25 Classic fees and **$79,870** of 2025–26 fees. It is not representative coverage of the annual portfolio. In particular, the **three largest 2025–26 winning entries do not have whole-contest rosters that pass reconciliation**. We cannot honestly attribute their profits to particular shot-type decisions from these sources. Sources: `summary.json`, `coverage`; [source_inventory.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/source_inventory.csv), [quarantine.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/quarantine.csv), and `largest_wins.csv`, `roster_source_reconciled`.

## Usage and shot matchup patterns

The owner dated the process change but did not specify the exact historical definition of advantage. The measurable **proxy** here uses the player's largest prior-ten-game shot share among catch-and-shoot, pull-up and under-ten-foot attempts. A favorable matchup means the opponent falls in the softest quarter of represented slate opponents for that category's prior allowed attempts per 100 possessions, with ties retained. High usage means prior-ten-game USG of at least 25%. These definitions describe this audit; they are not new production thresholds or a reconstruction of Ramneik's full manual process.

The feature comparison uses December 1 through March 10 in both seasons, requires at least 20 prior appearances and complete prior features, and excludes playoffs. Rookie/short-history players, unavailable frame dates and players with unverified scores or team identity remain outside the covered pool. Both personal and field percentages are normalized over the same covered active player pool. Final field ownership is retrospective.

In the broader set where **own** rosters reconcile, without asserting reliable field ownership, covered selections' favorable-matchup share increased from **32.2% to 39.2%**. Average prior usage changed from **22.2% to 22.5%**, while the share above the 25% usage cut decreased from **32.9% to 30.7%**. The joint high-usage/favorable-matchup share increased only from **7.6% to 8.1%**. Those figures are entry weighted, cover 68 versus 80 contests over 28 versus 40 days, and cover approximately 67% versus 64% of their selected slots. Source: [own_construction_summary.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/own_construction_summary.csv), `covered_his_*`, `feature_*`.

The smaller verified field comparison is consistent with an increased shot-matchup tilt. Each contest receives equal weight here; the saved output also provides entry and fee weighting. Source: [matched_selection_summary.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/matched_selection_summary.csv), `weighting=equal_contest`, `his_*`, `field_*`, `delta_*`.

| Covered selections | 2024–25 owner | 2024–25 field | 2025–26 owner | 2025–26 field |
|---|---:|---:|---:|---:|
| Favorable shot matchup | 35.2% | 32.1% | 39.5% | 33.7% |
| High usage | 34.8% | 31.7% | 29.9% | 32.4% |
| Both conditions | 7.8% | 7.0% | 8.5% | 7.4% |

The favorable-matchup overweight increased from **3.0 to 5.8 percentage points**. This is descriptive evidence of a selection change consistent with part of the stated method. It does not show that buying more high-usage players explained the improvement.

Covered players' actual points exceeded their same-slate, same-$1,000-salary-band field benchmark by **1.03 points per player** in 2024–25 and fell below it by **0.23** in 2025–26. The subset therefore does not demonstrate improved average player value, despite the full ledger's better returns. This comparison misses untracked slots, lineup combinations, tournament placement and many large wins. It should not substitute for the full portfolio result. Source: the same summary, `delta_salary_residual`; feature slot coverage averaged 67% versus 60% in this strict subset.

Exploratory regressions relate selection tilts to the difference in covered actual points between owner and field, controlling for salary difference, prior fantasy production and season. Repeated contests on a date are clustered; each date has equal total weight. Across 29 contests on 27 dates, usage, opponent softness and the joint-condition tilt all have positive estimates but wide intervals crossing zero. Their raw p-values are **0.115, 0.096 and 0.462**; after correcting the three tests they are **0.173, 0.173 and 0.462**. None is statistically significant. These are associations with selected scores, not tests of portfolio returns or causal strategy value. Source: [selection_associations.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/selection_associations.csv).

## Examples from actual selected players

Several frequently selected covered players outperformed their preceding ten-game average in the saved 2025–26 sample. These are descriptive examples, chosen for material sample exposure; they are not independent winners or allocations of profit to players. Counts include the same player used in multiple contest entries on the same date. Sources: [selected_player_review.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/selected_player_review.csv), `season=2025-26`, `selected_entries`, `days`, `usg_l10`, `actual`, `prior_residual`.

| Player | Covered selected entries | Distinct days | Prior usage | Actual DK points | Difference from prior average |
|---|---:|---:|---:|---:|---:|
| Jonas Valanciunas | 691 | 5 | 25.1% | 34.9 | +15.3 |
| Kevin Huerter | 534 | 7 | 18.0% | 32.2 | +12.3 |
| Jaime Jaquez Jr. | 538 | 11 | 21.5% | 36.9 | +8.6 |
| Matas Buzelis | 623 | 11 | 21.5% | 35.2 | +5.6 |
| Donovan Mitchell | 620 | 10 | 33.5% | 42.5 | −5.6 |
| Jaylen Brown | 479 | 12 | 38.0% | 47.8 | −2.0 |

Higher baseline usage did not automatically produce a better result relative to recent production in these examples. Huerter's covered favorable-shot-matchup flag appeared in only **1.1%** of his selected entries, while Jaquez's appeared in **70.8%**. Good selections can arise through different mechanisms. These records cannot tell us whether Ramneik anticipated changed minutes, an absence, a pricing discrepancy, a different play-type matchup, or another factor. No injury explanation is inferred. Source: `selected_player_review.csv`, `advantage` and `prior_residual`.

Broader roster construction changed modestly in reconciled own contests: entry-weighted 4+ players from the same game rose from **66.8% to 68.9%**, 3+ from one team from **72.0% to 73.4%**, and average salary used from **$49,840 to $49,877**. The within-contest ratio of distinct builds to entries stayed around **75%**. These observations cannot identify a causal construction improvement and do not establish optimal thresholds. Source: `own_construction_summary.csv`, `game4`, `team3`, `lineup_salary`, `distinct_build_ratio`.

## What this means for the process

**The earlier research did not establish that usage plus shot-type advantage is incorrect.** It tested whether specific prior features predict a player beating his own recent personal ceiling. That is a different question from whether a player is attractive at a given salary, differs usefully from the field, or helps a lineup finish near the top of a tournament. The earlier tests also used broad shot-attempt categories rather than timestamped daily Synergy play-type interactions or the owner's complete decision process. Sources: [individual ceiling study](/Users/rsbathla/Downloads/dfs/docs/NBA_INDIVIDUAL_CEILING_FACTORS_2026-10-01.md) and [intact rotation usage study](/Users/rsbathla/Downloads/dfs/docs/NBA_INTACT_ROTATION_USAGE_FUNNEL_AUDIT_2026-09-29.md), their stated targets, features and limitations. Any prior wording that treated those null findings as proof against the whole personal strategy was too strong.

The personal record supports three narrower conclusions. First, the 2025–26 improvement is substantial and is mainly a Classic result, with a useful contribution from reduced Showdown allocation. Second, measured shot-matchup emphasis increased in the saved selections, consistent with the stated process change. Third, the archive cannot establish that this change caused the profits: winning outcomes are concentrated, the clean comparative sample is small, and its selected-score tests do not pass statistical significance.

**My review supports keeping usage and shot matchup as research hypotheses and parts of the written analysis, with salary, expected minutes, role and lineup construction considered alongside them.** It does not support calling the process disproved or assigning it an earned production multiplier. A valid test of the actual method needs contemporaneous player-level judgments: the proposed advantage, expected usage/minutes, salary and projection, known availability at decision time, and which candidates were rejected. That would let us compare similar prices and roles in later slates and evaluate lineup results without redefining the strategy after seeing outcomes. This is a research recommendation, not a change to the current scoring rules or bankroll policy.

Reproduction: [personal_play_review.py](/Users/rsbathla/Downloads/dfs/nba/analytics/personal_play_review.py). SQLite is opened with `mode=ro`; the existing identity bridge and repaired historical frame are reused and hashed. Raw feeds and entry history are unchanged. Twelve source and scoring regression tests pass; removing the roster, field or score-attribution guard makes its known-bad test fail, and restoring each guard makes it pass again. The [validation receipt](/Users/rsbathla/Downloads/dfs/nba/analytics/data/personal_review_2026-10-01/audit_validation.json) records these checks. Both NBA and Fantasy strict integration gates pass in their stated scopes. Those gates do not certify the still-blocked full historical construction corpus.
