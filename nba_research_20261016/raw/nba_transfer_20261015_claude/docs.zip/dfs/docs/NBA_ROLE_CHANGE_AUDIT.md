# NBA role-change study audit — 2026-09-22

This is research evidence for the requested third test: whether separating a changed role improves descriptions and later-game forecasts. It changes no production scoring, triggers, weights or current roster claims. Script: `nba/analytics/role_change_study.py`; saved evidence: `nba/analytics/data/research_v2/role_*`.

## Source and event observations

The shared source is `data/research_v2/research_games.parquet`, using stable NBA player IDs and the repaired regular-season game universe. Its source receipt reports 20,582 analytical appearances from 968 games in 2024–25, ending March 10, and 26,457 appearances from all 1,230 regular-season games in 2025–26, ending April 12. These are appearances of at least one minute; subminute appearances and DNPs are outside this outcome sample. Eligible Cup games are included; the Cup final is excluded. The earlier season is partial. Exact inputs, hashes, dates and filters are in `frame_receipt.json` and `role_metadata.json`.

Two examples were independently recalculated from `raw_player_2025.parquet`, including DraftKings points reconstructed from `PTS`, `3P`, `TOT`, `A`, `ST`, `BL`, `TO` and the double/triple-double bonuses. These examples illustrate observed changes, not estimates of causality or recommendations for the coming season.

| Observed detection | Earlier 10 appearances | Following 10 appearances | Exceeding the frozen earlier-role p85 |
|---|---|---|---|
| Gui Santos, February 3, 2026; prior minutes increase | Dec 31–Jan 20: 15.63 minutes, 13.50 DK | Feb 3–28: 30.02 minutes, 32.68 DK | 2/10 → 10/10; bar 20.6375 DK |
| Guerschon Yabusele, February 5, 2026; observed New York → Chicago stint boundary | Jan 7–30: 6.30 minutes, 5.275 DK | Feb 5–Mar 1: 24.91 minutes, 24.60 DK | 1/10 → 9/10; bar 11.80 DK |

Evidence: `role_events.csv` rows `(season=2025,pid=1630611,date=2026-02-03)` and `(2025,1627824,2026-02-05)`, fields `pre_min/post_min`, `pre_fp_dk/post_fp_dk`, `pre_tail_hits/post_tail_hits`, `frozen_pre_p85`. `role_independent_checks.json` records the raw recomputation, exact game IDs and date windows. Gui Santos's five detection games lie between the earlier and following windows; they are not counted as future follow-up outcomes. The team names above are the saved game-feed fields; no transaction date, injury cause, coaching explanation or current role is inferred.

## Fixed research design

Existing layers were inventoried first: `build_season.py` already calculates prior-five starter rate and prior-ten/expanding minutes; `roster_funnel_2026.py` already flags context resets, but neither saves this role-event forecast comparison. The new study consumes the shared repaired source and uses the same stable player IDs. Shot tracking, opponent/environment layers, salary, ownership, construction feeds and full-season Synergy do not enter this bounded test of a player's own history. The separate matchup study evaluates those extra predictors; no NFL environment formula is transplanted into NBA work.

All numeric cutoffs below are declared exploratory choices, not optimized thresholds or deployed weights:

- A **team switch** occurs at the first observed analytical appearance with a different team from the previous appearance. A return to an old team starts a new contiguous stint; earlier stints on that team are not pooled.
- A **prior-game role detection** compares the last five appearances with the preceding ten, within the current team stint. A starter increase requires the older starter rate ≤20% and recent rate ≥80%; a decrease reverses those thresholds. A minutes increase/decrease requires a difference of at least six minutes. Both directions at once are labeled mixed. Actual starter status and minutes from the game being predicted never enter its detection.
- After a detection, ten analytical appearances must pass before another minutes/starter detection. A team switch overrides this cooldown. Follow-up windows end before the next detected event, so they do not overlap. A detection is not backdated for evaluation. For the role-history mean only, the five already-observed detection appearances seed the new history.
- Descriptions require ten earlier and ten following appearances. The earlier window ends just before the five detection games for a minutes/starter event; it ends at the stint boundary for a team event. Pre-event windows and frozen p85 histories cannot cross the relevant contiguous team-stint boundary. Incomplete windows remain in the event inventory but are omitted from the complete-window description.
- The tail bar is the p85 of up to twenty earlier appearances ending before that anchor, with at least ten required. It is frozen for both comparisons. A future exceedance of this old-role bar is **not** membership in the player's highest 15% of the eventual season.

Usage is descriptive only; invalid usage is missing, not capped or imputed. Per-window nonmissing counts are saved. Per-game means weight appearances equally. Role events are detected from played analytical appearances, not calendar time or timestamped injury/starting-lineup feeds.

## Observed changes

| Season and detected change | All events / distinct players | Complete 10-before/10-after events | Mean minutes change | Mean usage change, pp | Mean DK change | Earlier / following frozen-bar hits |
|---|---:|---:|---:|---:|---:|---|
| 2025–26 role increase | 425 / 287 | 342 | +5.14 | +0.54 | +5.16 | 525/3,420 (15.35%) / 1,220/3,420 (35.67%) |
| 2025–26 role decrease | 430 / 306 | 310 | −3.63 | +0.35 | −3.10 | 544/3,100 (17.55%) / 437/3,100 (14.10%) |
| 2025–26 team switch | 79 / 72 | 46 | +2.37 | +0.78 | +3.18 | 58/460 (12.61%) / 129/460 (28.04%) |
| 2024–25 role increase | 312 / 244 | 222 | +4.63 | −0.16 | +4.23 | 346/2,220 (15.59%) / 789/2,220 (35.54%) |
| 2024–25 role decrease | 250 / 201 | 178 | −3.63 | +0.04 | −3.11 | 326/1,780 (18.31%) / 291/1,780 (16.35%) |
| 2024–25 team switch | 71 / 69 | 33 | +1.15 | −0.03 | +1.26 | 52/330 (15.76%) / 89/330 (26.97%) |

Evidence: `role_event_summary.csv`, fields `events`, `players`, `complete_events`, `mean_delta_min/usg/fp_dk`, and tail numerator/denominator fields. One mixed event in 2024–25 has no complete follow-up window and is excluded from this table's substantive comparisons. Repeated events can belong to one player, so event counts are not independent people.

These changes are selected on prior minutes/starter differences, with regression-to-the-mean and availability confounding remaining. The outcome window is later than detection, which avoids describing only the same selected games. It does not establish why the change happened. In 2025–26, 729 of the 855 non-team detections are minutes-only, 91 starter-only and 35 both (`role_events.csv.reasons`): this is mainly a minutes-regime test. Complete-window eligibility also selects players with enough subsequent appearances; forecast comparisons below retain shorter follow-up histories.

## Forecast comparison

Every forecast uses earlier observations from the same player-season only. The common evaluation set starts after fifteen prior analytical appearances. There is no pooled training fit or tuned parameter to leak future dates. All player rows in a game share that game's date; current outcomes cannot enter another player's history.

The seven forecasts are: expanding season mean; means of the prior five, ten and twenty appearances; mean within the current contiguous team stint; mean since the last detected role anchor; and a control that resets history every twenty appearances without inspecting outcomes or roles. Team/role/periodic histories with fewer than three observations fall back to prior-ten. Forecasts are conditional on appearing for at least one minute; they do not estimate DNP risk. The targets are point means, not calibrated ceiling probabilities.

2025–26 common evaluation: **18,615 appearances, 463 players, 1,012 games, 136 dates**. The 8,002 event-proximate rows occur during appearances zero through nine after the most recent event; the remaining 10,613 are controls outside those windows.

| Forecast | All-row MAE, DK | Event-proximate MAE | Outside-window MAE |
|---|---:|---:|---:|
| Expanding season | 8.0726 | 8.2804 | 7.9158 |
| Prior 5 | 8.1350 | 8.2011 | 8.0852 |
| Prior 10 | 7.9658 | 8.0392 | 7.9105 |
| Prior 20 | 7.9663 | 8.1209 | 7.8497 |
| Current team history | 8.0342 | 8.2437 | 7.8763 |
| Detected role history | 7.9672 | 8.0975 | 7.8689 |
| Periodic reset control | 8.0187 | 8.1194 | 7.9428 |

Evidence: `role_forecast_metrics.csv`, `season=2025`, `cohort=all/event_0_9/non_event`, fields `n`, `players`, `games`, `dates`, `mae`. RMSE and signed bias are also saved; MAE is the declared primary loss. Lower MAE is better. The source-level recomputation independently reproduces expanding MAE 8.0725610855 and prior-ten MAE 7.9658178888 on the same 18,615 raw rows (`role_independent_checks.json.full_season_raw_baseline_check`).

Paired differences below are candidate minus control, so negative is better. Intervals aggregate all same-date player rows; parallel game- and calendar-week-cluster intervals are in the saved comparison file. These are unadjusted uncertainty summaries across a declared comparison family, not individual discoveries after selecting the best result.

| 2025–26 comparison | Rows | MAE difference | 95% date-cluster interval |
|---|---:|---:|---|
| Role history − expanding, all | 18,615 | −0.1054 | [−0.1615, −0.0492] |
| Prior 10 − expanding, all | 18,615 | −0.1067 | [−0.1686, −0.0449] |
| Role history − prior 10, all | 18,615 | +0.0014 | [−0.0333, +0.0361] |
| Role history − prior 10, event-proximate | 8,002 | +0.0583 | [+0.0076, +0.1091] |
| Role history − periodic reset, event-proximate | 8,002 | −0.0219 | [−0.0902, +0.0465] |
| Role history − prior 10, after January 15 | 12,167 | +0.0013 | [−0.0452, +0.0478] |

Evidence: `role_forecast_comparisons.csv`, matching `season/cohort/model/control`, fields `mae_delta/date_low/date_high`. For role minus prior-ten in the event window, the game interval is [+0.0072,+0.1095] and the weekly interval [+0.0060,+0.1107]; both preserve the direction. The all-row role improvement versus expanding is approximately 1.31% of expanding MAE, not a large scoring uplift.

The partial 2024–25 comparison does **not** reproduce an overall role-reset improvement over expanding history: 13,185 forecast rows, difference +0.0025 DK MAE, date interval [−0.0573,+0.0623]. Role history versus prior-ten is −0.0233 [−0.0647,+0.0181] overall, and **+0.1021** [+0.0307,+0.1734] near detected events. Thus the event-window comparison against generic recency points in the same unfavorable direction in both seasons. Evidence: the same comparison CSV, `season=2024`, `cohort=all/event_0_9`.

## Verification and self-critique

`test_role_change_study.py` covers current/future-outcome mutation invariance; player-season reset; independent player history; returning to an old team as a new stint; the minimum-history boundary; missing starter data; invalid-usage and duplicate/zero-minute guards; equal evaluation rows; cluster-interval direction; and short intermediate stints excluded from complete old-team windows. Eight tests pass. The guards were exercised with deliberately invalid rows, not only clean examples.

The raw Gui Santos and Yabusele checks re-derived both window means and frozen-bar hits independently of the builder. The full 2025–26 expanding/prior-ten MAEs were recomputed from raw box-score fields with separate vectorized shift/rolling calculations. This is stronger than comparing two outputs of the same history function.

The strongest objection is that role detection merely responds to a short minutes streak and changes the history length. The cheapest falsifying control is already run: recent-five/ten/twenty and an outcome-blind periodic reset on identical dates and rows. Detected role history cannot beat prior-ten overall, and does worse near the events it is meant to help. Therefore the descriptive event patterns do not earn a special role-reset forecasting adjustment. Remaining temporal dependence across weeks, overlapping pre-event windows, missing availability history, low-minute appearances, and the partial earlier season limit inference. No current health, coaching, trade rationale or expected starting role has been verified by this study.

## FINDINGS — evidence tier

**Data shows:** prior-game minutes/starter detections identify materially different later ten-game descriptive averages in both saved seasons (`role_event_summary.csv`). Generic recent history and the tested role-history method both improve on expanding history in 2025–26, but the special role method adds no demonstrated overall gain beyond prior-ten; near detected events it performs worse in both seasons (`role_forecast_comparisons.csv`).

**Inference:** role context is useful for organizing player histories and avoiding misleading season-wide descriptions. These results support further evaluation of recent history as a benchmark; they do not validate the chosen event detector as a production scoring lever.

**Assumptions:** the fixed five-versus-ten, six-minute, 20%/80%, ten-appearance cooldown, fifteen-history and three-observation fallback rules are explicit research choices. Current team identity is taken from the historical game feed, not reconstructed timestamped transaction data. Conditional-on-appearance point forecasts do not answer pre-lock availability or upper-tail probability calibration.

## CONFLICTS

No verified roster/coaching fact is overridden. No production semantics are changed. A claim that these detections raise a player's season-defined top-15% probability would conflict with the frozen earlier-role threshold actually tested. A claim that role segmentation supplies unique forecasting edge would conflict with the generic-recency controls. A claim of two full-season replications would conflict with the March 10 endpoint of the earlier feed.

## DECISION POINTS

Retain this as descriptive/history-comparison research (recommended), or propose a separate production model change after prospective evaluation. If additional testing is wanted, compare calibrated tail forecasts against a strong recency benchmark and timestamped availability/starting-lineup data. Do not optimize the role thresholds on these outcomes and call the same rows validation. The current findings do not justify changing production weights, triggers or roster-reset policy.
