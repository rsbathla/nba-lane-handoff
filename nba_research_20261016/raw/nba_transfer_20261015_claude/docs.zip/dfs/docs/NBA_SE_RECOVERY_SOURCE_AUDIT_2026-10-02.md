# NBA true single-entry recovery source audit — 2026-10-02

This audit documents public source recovery and attribution. It records observed portfolios and source coverage; it does not select a winning cohort, change strategy weights, infer private intentions, or turn source-reported winnings into audited account returns. Neutral inventory and source qualifications come before implications. All years below are NBA season vintages unless a literal ISO date is shown.

## Existing source inventory

Owner NBA Classic contest metadata comes from read-only `dfs_core.db` · `entry_history` · `sport=NBA`, `game_type=Classic`, grouped by `contest_key`; `entry` supplies the exact saved contest name, `contest_date` the date, and `entry_fee` the fee. The complete contest inventory is `nba/analytics/data/research_peer_se/source_ledger_contest_inventory.csv`. Candidate names and one-bullet counts are discovery clues; they do not establish an entry cap.

| Layer / vintage | Inventoried amount | Exact evidence |
| --- | --- | --- |
| Owner NBA Classic ledger · 2019–20 through 2025–26 | 12880 | source_inventory.json · ledger_classic_contests |
| Owner one-bullet Classic contests · all seasons | 9503 | ledger_entries=1; source_inventory.json · ledger_one_bullet_contests |
| Ledger names explicitly indicating single entry · all seasons | 4537 | ledger_named_se; source_inventory.json · ledger_named_single_entry_contests |
| Archived compact NBA user feed headers | 1499 | tools/data/fantasylabs/nba_users/*.json.gz · contest |
| Archived compact headers reporting cap one | 22 | contest.multiEntryMax=1; source_inventory.json · saved_cap_one_headers |
| Existing normalized/full feed headers | 1022 | research_peers/normalized and research_peer_process/raw · contest |
| Saved contest catalog groups / IDs | 596 / 1481 | nba_groups_index.json · groups[].date/titles/ids |
| Catalog titles indicating SE / without owner ledger | 16 / 10 | source_archived_headers.csv · saved_catalog_title; unmatched owner contest_key |
| All-owner bounded candidate IDs | 9503 | source_candidates.csv · cid; owner_one_bullet OR ledger_named_se OR saved_header_cap1 |

The archived-header receipt `source_archived_headers.csv` preserves layer, original metadata path, exact source spelling, CID, date, fee when present, and cap when present. It inventories compact headers, full-feed headers and catalog titles. `tools/data/fantasylabs/nba_lineups` is a trimmed lineup companion whose saved top-level schema has `field_stats` and `lineups`, without a full `contest` header; it cannot replace complete per-user source blocks. The generic NFL cohort archive is not NBA evidence. Existing studies and their raw/cache files were read only.

## Bounded recovery and retrieval qualifications

The initial named/header candidate set contained 4548 IDs. Recovery then included every remaining owner one-bullet Classic contest, including 4955 additional IDs. Neither fee, source winnings nor a peer’s success was used to choose candidates. Every bounded candidate was attempted in 2025–26 first, then 2024–25, then earlier seasons. Sources were fetched with bounded public requests and one retry for transient transport/server errors; no credentials, paid feeds or authenticated dashboard were used. Evidence: `source_inventory.json` · initial_named_or_header_candidates/other_one_bullet_candidates; `source_candidates.csv` · priority/date/cid; `source_retrievals.json` · attempts/url/retrieved_at_utc.

| NBA season | Bounded candidate IDs | Evidence |
| --- | --- | --- |
| 2019-20 | 12 | source_inventory.json · candidate_seasons |
| 2020-21 | 1991 | source_inventory.json · candidate_seasons |
| 2021-22 | 654 | source_inventory.json · candidate_seasons |
| 2022-23 | 1433 | source_inventory.json · candidate_seasons |
| 2023-24 | 2012 | source_inventory.json · candidate_seasons |
| 2024-25 | 1646 | source_inventory.json · candidate_seasons |
| 2025-26 | 1755 | source_inventory.json · candidate_seasons |

All 9503 candidate IDs have a retrieval receipt. 340 returned readable JSON feeds; 9163 public requests returned HTTP 403. The exact HTTP 403 code is preserved in `source_retrievals.json` · attempts[].http_status/error. It does not establish whether an underlying object is missing, access restricted, or available through another archive route. Earlier interim shorthand saying 404 was incorrect; the saved receipts and this audit use the actual 403 responses.

The public endpoint pattern is `https://dh5nxc6yx3kwy.cloudfront.net/contests/nba/YYYYMMDD/CID/data/`. Original successful HTTP bytes are retained under `research_peer_se/raw/`; gzip responses stay as original gzip bytes, and uncompressed responses also retain their original `.response.json` bytes. Receipts preserve URL, retrieval time, response headers, response/compressed/decompressed SHA-256 values, byte counts, source header and raw target handle counts. `source_retrievals.json` covers failures; `source_receipts.json` covers returned sources and acceptance.

## Source acceptance and preserved exclusions

A true-SE source must have actual `contest.multiEntryMax == 1`, exact contest ID/date/fee, no source user with `totalRosters > 1`, internally consistent filled/user totals, and an exact owner ledger entry-count and score-multiset match. Each selected user must have complete eight-distinct-player hashes, positive integer multiplicity totaling its stated count, resolvable source IDs, finite salary/ownership/score fields, legal salary total, available team/event identity and no known NBA identity collision. Existing `peer_play_review.portfolio_identity_issues`, `block_issues`, `canonical_portfolios`, and `peer_process_sources.expand_exposures` are imported without relaxing them. No player is filled in. The raw `uniqueRosters` summary is not used as the number of builds.

Of the returned feeds, 27 reported cap one; 19 passed the owner/source acceptance contract. The remaining cap-one payloads were quarantined. All returned multi-entry feeds remain excluded even when the owner entered only one lineup. Evidence: `source_receipts.json` · header.multiEntryMax/accepted/exclusions; `source_quarantine.csv` · stage/reasons.

| CID / date / source season | Source owner entries / ledger entries | Exact exclusion reasons |
| --- | --- | --- |
| 168368574 / 2024-10-22 / 2024-25 | 141 / 1 | owner_ledger_score_or_count_conflict / source_entry_cap_contradiction / user_entry_cap |
| 159986675 / 2024-03-26 / 2023-24 | 3 / 1 | owner_ledger_score_or_count_conflict / source_entry_cap_contradiction / user_entry_cap |
| 159811861 / 2024-03-21 / 2023-24 | 1 / 1 | source_entry_cap_contradiction |
| 159050465 / 2024-02-27 / 2023-24 | 25 / 1 | owner_ledger_score_or_count_conflict / source_entry_cap_contradiction / user_entry_cap |
| 158138754 / 2024-01-25 / 2023-24 | 5 / 1 | not_eight_slots / owner_ledger_score_or_count_conflict / source_entry_cap_contradiction / user_entry_cap |
| 143093502 / 2023-04-04 / 2022-23 | 15 / 1 | owner_ledger_score_or_count_conflict / source_entry_cap_contradiction / user_entry_cap |
| 140112203 / 2023-01-12 / 2022-23 | 1 / 1 | source_entry_cap_contradiction |
| 125335184 / 2022-04-03 / 2021-22 | 1 / 1 | source_entry_cap_contradiction |

Fresh public recovery did not repair the earlier malformed cap-one payloads. For `168368574` on 2024-10-22, the new source still attributes 141 owner entries while the owner DK ledger contains one; the cap, source totals and owner count/score conflicts remain explicit. A cap-one feed can also fail when the owner has one entry but other users exceed cap one, as `159811861`, `140112203` and `125335184` demonstrate. Full source/owner guards apply to the entire claimed source before any selected peer is extracted. Evidence: each listed CID in `source_receipts.json` and original `raw/*CID.data.json.gz` · contest/users; owner `entry_history.contest_key`.

Source field denominators remain a separate contract. 14 accepted contests exactly match the owner ledger field count; 5 accepted portfolio sources retain `field_verified=false`. They certify complete per-user portfolios and the owner anchor, not full-field rank/ownership denominators. No count tolerance or substituted denominator is adopted.

| Accepted CID / date / season | Source filled / owner ledger field | Field qualification |
| --- | --- | --- |
| 103353915 / 2021-02-14 / 2020-21 | 20 / 20 | exact |
| 105713185 / 2021-04-01 / 2020-21 | 20 / 20 | exact |
| 105831046 / 2021-04-03 / 2020-21 | 20 / 20 | exact |
| 105954214 / 2021-04-05 / 2020-21 | 21 / 21 | exact |
| 106265707 / 2021-04-10 / 2020-21 | 10 / 10 | exact |
| 122582758 / 2022-01-15 / 2021-22 | 10 / 10 | exact |
| 122745679 / 2022-01-17 / 2021-22 | 10 / 10 | exact |
| 134519354 / 2022-10-19 / 2022-23 | 4899 / 4901 | uncertified denominator |
| 134519357 / 2022-10-19 / 2022-23 | 11872 / 11890 | uncertified denominator |
| 142148553 / 2023-03-07 / 2022-23 | 3564 / 3566 | uncertified denominator |
| 152977984 / 2023-10-25 / 2023-24 | 4652 / 4654 | uncertified denominator |
| 152977986 / 2023-10-25 / 2023-24 | 11873 / 11890 | uncertified denominator |
| 168368573 / 2024-10-22 / 2024-25 | 8 / 8 | exact |
| 173744630 / 2025-02-04 / 2024-25 | 18 / 18 | exact |
| 173917580 / 2025-02-11 / 2024-25 | 15 / 15 | exact |
| 183929501 / 2025-10-24 / 2025-26 | 13 / 13 | exact |
| 184483420 / 2025-11-05 / 2025-26 | 25 / 25 | exact |
| 188170143 / 2026-02-19 / 2025-26 | 10 / 10 | exact |
| 188339631 / 2026-02-24 / 2025-26 | 12 / 12 | exact |

One planned peer block was excluded within an otherwise accepted contest: dacoltz in `152977986`, 2023-10-25, has `selected_player_metadata_unusable|unresolved_idmap|unresolved_player_id`. No replacement roster or imputed identity was created. Evidence: `source_quarantine.csv` · portfolio row; original source `users.dacoltz.lineups`.

## Verified portfolios, dates and independent season support

The accepted corpus contains 97 user-contest portfolios and 97 canonical builds, with 5200 valid candidate-player source contexts and 776 selected player-slot rows. Every portfolio has one entry and one complete eight-player build; all selected contexts have existing NBA bridge IDs. The corpus expands from 7 to 19 contests, adding 12 older contests. It contains 17 distinct dates across 6 NBA seasons. The recent 2024–25/2025–26 total remains 7 contests; no additional recent cap-one source was found in the completed public recovery. Evidence: `source_coverage.json` · row_counts/previous_verified_contests/added_verified_contests/verified_distinct_dates/independent_seasons/recent_verified_contests; `source_exposures.parquet` · pid/slot_entries.

| User | Verified contest appearances | Distinct dates | NBA seasons |
| --- | --- | --- | --- |
| bpcologna | 11 | 9 | 4 |
| cheddabisque | 11 | 9 | 5 |
| dacoltz | 4 | 3 | 2 |
| gregr1224 | 5 | 3 | 2 |
| jpm11 | 3 | 2 | 2 |
| mazwa | 3 | 3 | 2 |
| needlunchmoney | 1 | 1 | 1 |
| nerdytenor | 3 | 3 | 2 |
| oxenduck | 6 | 4 | 3 |
| papagates | 14 | 12 | 5 |
| rsbathla | 19 | 17 | 6 |
| youdacao | 14 | 12 | 6 |
| zokin | 3 | 3 | 1 |

| Target / NBA season | Contest appearances | Distinct dates | Observed source fee range |
| --- | --- | --- | --- |
| bpcologna / 2022-23 | 3 | 2 | $5.0–$12.0 |
| bpcologna / 2023-24 | 2 | 1 | $5.0–$12.0 |
| bpcologna / 2024-25 | 2 | 2 | $2120.0–$2120.0 |
| bpcologna / 2025-26 | 4 | 4 | $2120.0–$5300.0 |
| youdacao / 2020-21 | 5 | 5 | $2120.0–$2120.0 |
| youdacao / 2021-22 | 1 | 1 | $2120.0–$2120.0 |
| youdacao / 2022-23 | 3 | 2 | $5.0–$12.0 |
| youdacao / 2023-24 | 2 | 1 | $5.0–$12.0 |
| youdacao / 2024-25 | 1 | 1 | $5300.0–$5300.0 |
| youdacao / 2025-26 | 2 | 2 | $5300.0–$5300.0 |

Amounts and source names in these tables come from `source_portfolios.parquet` · fee/source_user and `source_coverage.json` · by_user/by_user_season. The exact saved target spellings are `bpcologna` and `youdacao`. Fee differences across years remain visible; low-fee and high-fee appearances are not relabeled as equivalent stakes. The same account can repeat one build across separate contests on the same date and pool. Counts above separate contest appearances from dates; they do not claim independence of every entry. Parent analysis owns any further episode collapse or analytical minimum.

## Recent-year shot-window overlap

The existing strictly chronological research frame is `nba/analytics/data/research_v2/research_games.parquet`. Its available windows are {"2024-25": {"max": "2025-03-10", "min": "2024-10-22"}, "2025-26": {"max": "2026-04-12", "min": "2025-10-21"}}. The source audit joins exact NBA ID and date to quantify current frame overlap only; it does not infer that older NBA shot records cannot exist elsewhere, and it does not backfill them. `source_shot_overlap.parquet` preserves current source/player metadata plus `frame_appearance`, `frame_point_agreement`, `joined_shot_complete` and `in_frame_season_window`.

| Target / season | Selected player contexts | In-window portfolios | NBA appearances / point agreements | Complete shot contexts | All eight shot complete portfolios |
| --- | --- | --- | --- | --- | --- |
| bpcologna / 2022-23 | 24 | 0 | 0 / 0 | 0 | 0 |
| bpcologna / 2023-24 | 16 | 0 | 0 / 0 | 0 | 0 |
| bpcologna / 2024-25 | 16 | 2 | 16 / 16 | 15 | 1 |
| bpcologna / 2025-26 | 32 | 4 | 32 / 30 | 13 | 0 |
| youdacao / 2020-21 | 40 | 0 | 0 / 0 | 0 | 0 |
| youdacao / 2021-22 | 8 | 0 | 0 / 0 | 0 | 0 |
| youdacao / 2022-23 | 24 | 0 | 0 / 0 | 0 | 0 |
| youdacao / 2023-24 | 16 | 0 | 0 / 0 | 0 | 0 |
| youdacao / 2024-25 | 8 | 1 | 8 / 8 | 0 | 0 |
| youdacao / 2025-26 | 16 | 2 | 16 / 16 | 8 | 0 |

BP has six recent portfolios/dates and 48 selected player contexts; 28 join complete shot features and one portfolio has all eight shot contexts complete. Youdacao has three recent portfolios/dates and 24 selected contexts; eight join complete shot features and no portfolio has all eight complete. Evidence: `source_coverage.json` · shot_window_overlap rows for the two recent seasons; `source_shot_overlap.parquet` · joined_shot_complete grouped by user/cid. The added older seasons contribute historical source roster construction, not extra current-frame usage/shot observations.

Exact player-level source points can differ from the NBA research box while a source total remains owner anchored. In `183929501` on 2025-10-24, BP’s Stephon Castle source value is 33.0 versus frame 32.25, and Julian Champagnie is 23.5 versus 24.25; the owner also selects Castle. Those discrepancies remain marked, not silently rewritten. Point agreement uses the existing absolute 0.005 boundary. These rows cannot independently certify NBA scoring components from the source values. Evidence: `source_shot_overlap.parquet` · user/player/actual/fp_dk/frame_point_agreement · 2025–26. Archived `currentTeam`, ownership and projection metadata are retained without a certified pre-lock timestamp or a historical team correction in this source layer.

## Original-source rechecks and known-bad tests

Two independent rechecks recomputed the actual selected user’s raw block, resolving its eight FL IDs through the raw player map and existing NBA bridge, preserving multiplicity, recomputing score/salary, comparing canonical build hashes, and reapplying source header/owner ledger guards. They did not use mixed-user global lineup hashes. Evidence: `source_coverage.json` · raw_rechecks; source paths below.

- bpcologna · 2022-10-19 · CID 134519354: 1 entry, 1 canonical build, 8 slots, 286.25 DK source points and $50000.0 salary. Raw source: `nba/analytics/data/research_peer_se/raw/2022-10-19_134519354.data.json.gz` · users.bpcologna.lineups / players / contest.
  Compressed SHA-256: `40ea9e9523c3b65ed822a8ded1e183da2f6352bf0cf6104fd5d58b70aaabe633`; decompressed SHA-256: `d8726585dfa29b5f9df240691fb63c4cd50e1fbd65b46da86aea3dc017e80889`.

- youdacao · 2021-02-14 · CID 103353915: 1 entry, 1 canonical build, 8 slots, 272.25 DK source points and $50000.0 salary. Raw source: `nba/analytics/data/research_peer_se/raw/2021-02-14_103353915.data.json.gz` · users.youdacao.lineups / players / contest.
  Compressed SHA-256: `e36b6d460c0f8b7220f6c1afc23aa939c00df7a09d9a80f598d9ed97d4ca5dd6`; decompressed SHA-256: `5e502e37b08d76953012d9896f723f857a7f94b807a984463b79bc973667c70b`.

The focused regression suite `test_peer_se_sources.py` passes 15 tests. It demonstrates failure for a one-bullet multi-entry contest, another user exceeding cap one, missing cap, wrong contest/date/fee, owner score/count conflict, invalid multiplicity, salary overflow, missing player, duplicate source ID and incomplete peer roster. The positive control preserves exact complete builds while ignoring the raw unique-roster summary. `peer_se_sources.validate()` passes on the real artifacts, verifies recovery/fingerprint coverage and original hashes, reapplies cap/owner guards, rebuilds exact eight-slot exposures and recomputes both raw receipts. Root owns combined NBA/Fantasy integration checks.

## Feasible coverage, inference and unresolved gaps

Confirmed: all known owner one-bullet Classic candidates across the saved historical ledger were examined, every bounded public retrieval has a receipt, and accepted true-SE records are complete under the unchanged source/owner contracts. The exact recent sample did not grow. Earlier seasons added source roster observations and independent dates, with separate stake and field qualifications.

Inference: public object availability and malformed source attribution constrain expansion through this endpoint. HTTP 403 alone cannot separate unavailable keys from restricted objects. This inference is not a claim that the owner lacks more SE history or that these peers played no other SE contests.

Unresolved: broader archive access, independent standings for inaccessible or malformed feeds, unowned catalog contest qualification, and older-season strictly prior shot/usage contexts remain outside this owner-anchored recovery. The catalog’s ten unowned named-SE titles are recorded in `source_archived_headers.csv`; one is explicitly Showdown (`144745590`) and cannot be used as Classic. Other unowned sources need a separately labeled contract rather than an invented owner ledger anchor. An account-access decision was not needed to finish this public recovery and is not treated as a blocker.

Output ownership is limited to the new `peer_se_sources.py`, its focused tests, `research_peer_se/source_*` and `raw/` artifacts, and this audit. The old peer/process/selection source modules, artifacts and originals were not changed. No report rankings, private forecast models, production weights, commits or deletions were introduced.
