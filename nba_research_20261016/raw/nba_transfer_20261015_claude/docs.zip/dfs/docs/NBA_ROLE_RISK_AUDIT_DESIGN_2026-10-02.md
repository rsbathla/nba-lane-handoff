# NBA role risk audit design — 2026-10-02

Scope: technical design for auditing expected minutes/opportunity, exposure concentration and realized selection outcomes. This specifies a descriptive extension of existing sources; it fits no model, adds no scoring weight, assigns no player-level profit and changes no production semantics. The forecast-provenance search is a separate workstream. Its accepted receipts, if any, must pass the contract below before forecast-calibration claims become available.

## Research target and evidence tiers

Keep three questions separate:

1. **Forecast calibration:** did a specifically identified forecast, recoverable before the relevant decision/lock, describe later minutes, participation or opportunity accurately? Calibration is presently unresolved without certified forecast receipts. An accurate provider forecast does not prove the owner used it.
2. **Exposure to role assumptions:** how much of a submitted portfolio depended on the same players, sparse histories or documented role assumptions? Exposure and shared dependencies can be described now. Sparse history is a support limitation, not a calibrated probability of failure.
3. **Realized selection shortfall:** how did a selection perform against explicitly supported comparable source listings, and how did different exposure allocations account for a mean-lineup score difference? This is retrospective accounting, not proof that the original choice was poor.

**Fact** means correspondence to an original source/receipt or a raw historical box. **Inference** means an interpretation of supported observations. **Unresolved** means missing timing, membership, adoption, forecast target or feasible-choice evidence. A generated research forecast belongs to a separate retrospective-model tier even when its features are strictly prior.

Authority: original source plus receipts and raw box feed > verified normalized parents > generated retrospective models. Preserve conflicts rather than silently replacing source scores or mutable archived teams. Prioritize neutral dated case notes before aggregate interpretations.

## Existing inputs and actual support

All data paths in this document are relative to `nba/analytics/data/`; code paths are relative to `nba/analytics/`.

| Reusable input | Contract and limitations |
|---|---|
| `research_peer_process/source_portfolios.parquet` | Complete source portfolios with `cid,user,date,season,entries,cap,entry_class,candidate_pool_signature,fee,canonical_builds`; owner identity is anchored to the contest ledger by the parent pipeline. Source portfolio money is not player-level profit. |
| `research_peer_process/source_lineups.parquet` | Canonical eight-player `hash` and actual multiplicity `ct`; retain repeated submitted builds for portfolio accounting. Never use slot order as roster identity. |
| `research_peer_process/source_exposures.parquet` | `slot_entries,entries,exposure`; exposure is selected entries divided by that user's entries in that contest. Every complete portfolio sums to eight player-equivalents. |
| `research_peer_process/source_players.parquet` and original `source_file` | All accepted source candidate listings: exact source/NBA identities, event, date, salary and source position. `source_projection` is archived metadata without certified pre-lock timing. Actual field ownership and historical candidate membership are separate contracts. |
| `research_peer_process/process_features.parquet` | Existing prior shot strengths, shot shares, opponent exposure ranks, pace, peripherals and prior-season Synergy. These can describe choices; they do not recreate expected minutes or the owner's private calculations. |
| `research_v2/raw_player_2024.parquet`, `raw_player_2025.parquet`, matching `raw_team_*` and `.source.json` | Positive-minute participation including subminute appearances; raw game/team identity and actual minutes/usage/FGA/scoring components. Source reconciliation does not certify exhaustive roster membership or injury cause. |
| `research_peer_participation/*` and `peer_se_participation_helpers.prior_state` | Reuse strictly earlier, latest contiguous same-team histories and explicit unknown states. Existing bracketed nonparticipation and source-listed outside-bracket nonparticipation remain distinct. |
| `research_peer_selection/player_features.parquet`, `named_player_choices.csv`, `model_receipts.json` | Preserve earlier research vintages, named exposure comparisons and retrospective salary-model benchmarks. `price_prediction`, `selected_price_prediction`, `expected_fp_simple` and role-study predictions are not recovered contemporaneous forecasts. |

Directly counted from the process parent on 2026-10-02:

- **266 complete owner portfolios, 146 dates, 26,827 entries, 7,369 player-contest exposure rows.** There are 126 portfolios/66 dates in 2024–25 and 140/80 in 2025–26. Source: `source_portfolios.parquet`, `user=rsbathla`, fields `cid,date,season,entries`.
- Owner classes are **250 multi-bullet MME portfolios**, **nine one-bullet-in-MME portfolios** and **seven true-SE portfolios**. Class-date counts can overlap; do not sum them into independent dates. The 2025–26 classes contain 128, eight and four portfolios respectively. Source: `entry_class,cap,entries`.
- The 7,369 exposure rows represent **5,031 distinct owner player/date outcomes** and 5,031 observed player/date/salary combinations. They are not 7,369 independent games. Source: `source_exposures.parquet.{key,pid,date,salary}`.
- **6,027 owner rows on 116 dates** are within the regular-season raw-feed windows; **6,003** have a positive raw appearance and **24** have no positive row within those windows. **1,342 rows remain outside support.** The 24 require event/team resolution before labeling nonparticipation. Independent join to positive raw boxes used `(season,pid,date)`. All 6,003 matched appearances are at least one minute in this owner sample; the general participation helper still preserves subminute appearances.
- **40 owner source-score-zero rows on 21 dates** exist, including 32 within the raw windows. A zero source score is not a DNP label. Preserve every one. Source: `source_exposures.parquet.actual`.
- All **47,742 process candidate rows** carry `source_projection`. Presence of that field does not certify a pre-lock forecast. Source: `source_players.parquet.source_projection`; original field lineage is `players[*].projPoints` in the archived feed.
- Existing owner process features contain **20 source/box point-conflict rows** and eight mutable-source-team-conflict rows. Preserve their flags and source values. Source: owner exposure join to `process_features.parquet.{source_point_conflict,source_team_conflict}`.
- The SE participation overlay remains **248 resolved of 496 selected slots on 18 supported dates**. It is useful for examples, but the larger source corpus supports the portfolio audit. Source: `research_peer_participation/summary.json.selected_slot_states,supported_dates`.

`research_v2/frame_receipt.json.seasons` establishes a partial 2024–25 feed from October 22 through March 10, with 968 regular-season games, and a 2025–26 feed from October 21 through April 12 with all 1,230 regular-season games. Playoff and outside-window sources must remain present as unsupported observations.

### Same-team history and touches boundaries

Do not label inherited `min_l10/usg_l10/fga_l10` as same-team history: `research_frame.player_prior` groups by `season,pid`, so these rolling fields can cross an observed team switch. Reuse `peer_se_participation_helpers.prior_state` on raw positive boxes for an explicitly separate same-team context: latest contiguous team stint strictly before the date; up to ten earlier appearances; at least three nonmissing observations per statistic; starter fraction over up to five earlier appearances with at least three. Keep history count, per-stat counts and last appearance date/team. No offseason carryover or fabricated starter history.

The inspected role/box/shot inputs expose minutes, usage, FGA, assists and rebounds; they do not establish literal touches. USAGE RATE (%) is not touches; FGA is not touches; Synergy possession share is not a count of all touches. Label these as opportunity measurements. Literal touch forecasts/calibration require a separately reconciled touches source and a declared matching definition/window.

Shot/environment inputs retain their independent support masks: `clean_prior_games,last_player_game,dominant_share,dominant_strength_percentile,dominant_def_rank,dominant_def_percentile,pace_percentile,shot_bundle,usage_shot_bundle,strict_shot_screen`. Opponent allowance means attempted shots per possession, not shooting-efficiency defense. Current actual minutes/usage must never rebuild prior shot metrics. Prior 2024–25 Synergy is descriptive only for 2025–26; same-season full-year profiles would leak future games. Do not transplant NFL environment or ADP formulas into NBA analysis.

## Minimal proposed schema and aggregation units

The following tables/fields are proposals, not implemented claims.

| Table and grain | Minimal fields |
|---|---|
| Source portfolio: one `cid,user` | Original source/receipt hashes, date, exact pool signature, cap, entry class, entries, fee, source scope, owner-ledger correspondence, completeness/rejection reason. |
| Source lineup: one canonical `cid,user,roster` | Eight exact source/NBA identities, `ct`, salary, original source score, and optional timestamped lineup-version receipt. |
| Candidate context: one `cid,source_player` | NBA/source identities, source event/team/position/salary, resolved historical game/team/opponent, independent price/history/participation/shot support states and reasons. Preserve all listings, including source-zero scores and nonparticipants. |
| Exposure: one `cid,user,source_player` | `slot_entries,entries,exposure`; links to context and lineup memberships. No feature filter may remove a selected identity from accounting. |
| Player-game outcome: one `season,NBA_pid,gid` | Raw source hash; actual minutes/starter/usage/FGA/components; positive, resolved nonappearance or unknown status; score discrepancy. Keep source score on the candidate context separately. |
| Forecast version: one `provider,run/version,NBA_pid,gid,target` | Original raw bytes/hash and field path, target/units/conditionality, predicted value or distribution, source-published as-of time, independently evidenced available-at time, retrieval time, cutoff/lock evidence, provider versus owner identity, owner-adoption evidence, certification state/reason. |
| Decision episode: one `user,date,exact_pool,entry_class,decision/version` | Actual portfolio membership; known decision/lock times or unknown; final versus timestamped submitted version; forecast version used only when supported. Retain each contest's actual multiplicities and money separately. |

**SE:** true SE requires cap=1 and one entry. One bullet in a multi-entry contest remains its own class. Collapse the same user/date/pool/canonical roster across repeated rooms for choice summaries, preserving the list of source contests. A complete roster metric requires all eight required fields; a seven-slot covered mean is labeled partial, never a full-lineup metric.

**MME:** preserve each user's own entry denominator and every `ct`, including duplicates. Report continuous max exposure, per-player exposure and the distribution of role-assumption counts across actual lineups. A player at 100% exposes every submitted lineup to the same player outcome; it does not create independent calibration observations. Counts of sparse-history or assumed-role players are descriptive flags, not validated risk probabilities. Save co-exposure/lineup membership so several players depending on one missing contributor or game are not treated as independent risks. No arbitrary concentrated/bad threshold is inferred from this corpus.

For scientific outcome/calibration summaries, deduplicate player-games; retain salary and forecast-version variants as contexts with explicit weights whose total per player-game is one. For actual portfolio impact, retain exposures and contest multiplicities. For process comparisons, first compare supported variants/pools within a date, then give dates equal weight; entry/fee weighting can be a separately labeled consequence view. Overlapping candidate pools and repeated contests still share actual game outcomes. Candidate comparisons and same-contest peer/owner summaries require identical supported observations on both sides.

## Three measurements that must not be fused

### A. Forecast calibration — only after certification

Measure signed error and absolute error for each declared target on the same forecast/outcome rows, with observations, dates, weeks and distinct players reported. Unconditional minutes/FP forecasts retain resolved zero participants. A forecast explicitly conditional on playing is evaluated on that conditional target and accompanied by a separate availability contract; never drop DNPs from an unconditional forecast to improve its score. Actual usage is undefined for a nonparticipant, not reassuring zero. Distribution forecasts require monotone quantiles and probabilities in [0,1], and their coverage claims require the corresponding raw outcome support.

Report provider forecasts and owner forecasts separately; a provider can be tested without proving owner adoption, but cannot explain the owner's choice. A forecast error can arise from genuine uncertainty or later information. It is not itself evidence of a poor decision. Do not subtract the inherited retrospective price or simple-history model and call the difference a pregame forecast miss.

### B. Concentration and role dependence — descriptive now

For each source portfolio, show exposure alongside same-team observation counts, recency, prior starter fraction, recorded role assumptions if any, and named retrospective nonparticipation contexts. Distinguish missing pregame role evidence from an explicitly uncertain forecast. If authenticated scenario forecasts later exist, record exposure to the same scenario and its declared probability; do not infer such probabilities from the realized starter flag.

An exposure-weighted error is portfolio consequence accounting, not additional forecast-validation sample size. Do not translate it into player P&L or a bankroll recommendation. A favorable 100% selection remains as visible as an unfavorable one.

### C. Realized selection shortfall — outcome comparison, not decision quality

Use actual source score for source mean-lineup closure; use reconciled raw DK scoring for component explanations only where source and box scores agree. Compare a selection's outcome with the mean of explicitly defined similar-price/source-position listings on the same exact pool/date, retaining nonparticipants and missing outcomes. Do not choose the highest realized scorer as a hindsight alternative and call its score attainable expected value.

The primary comparison should prefer exact salary and exact source position when supported. If wider inherited salary bands are used (`<=5000`, `>5000 and <8000`, `>=8000`), label the coarser context and retain each player's exact salary. This defines a descriptive comparison, not equivalence in expected value. Report all listings, distinct NBA identities, identities excluded for unresolved linkage, outcome-supported listings, resolved nonparticipants, prior-feature support, focal exclusion and date support. Empty or unsupported groups remain unknown. Do not optimize a salary width on observed outcomes and call it a learned rule.

The existing `peer_se_participation.add_alternatives` is an explicitly **retrospective positive-participant sensitivity baseline**. Keep it as a sensitivity view, never as the pregame candidate set: conditioning on who eventually played removes availability failures using hindsight. A primary source-listed comparison also does not certify a legal or available pregame pool; its unknown eligibility/membership remains explicit. The two populations must not share an unlabeled headline.

Source primary position is not DK roster-slot eligibility. A stronger feasible-replacement claim requires authenticated slate eligibility and the actual eight-player lineup/version, salary left, all unchanged slot constraints, game-lock/late-swap status, and contemporaneous availability. Without those records, say “similar source listing,” not “could have substituted.” Replacing a player can change the optimal surrounding roster; one-slot outcomes do not establish whole-portfolio feasibility or profit.

Repeated player-games and teammate outcomes require calendar-date clustering; calendar-week blocks are a dependence sensitivity. Report dates/weeks rather than counting every contest or entry as an independent trial. Default to descriptive summaries. Any later inference must freeze its target, comparison family and chronology beforehand; sparse named cases remain case reviews, not learned rules.

## Forecast certification contract and required known-bad tests

Status options should distinguish **certified before recorded decision**, **certified before player lock but decision/adoption unknown**, **unverified archived projection**, **retrospective model**, **post-cutoff** and **unresolved**. Certification needs exact original field lineage and an independently credible timestamped/versioned record. File mtime, filename date, a modern retrieval timestamp or an uncorroborated embedded old date cannot certify historical availability. A later retrieval may corroborate a historical immutable/versioned publication only when that historical version/time itself has reliable evidence; do not confuse retrieval time with publication time.

Use a timezone-aware authoritative scheduled lock/tip receipt and the relevant decision/late-swap cutoff. Unknown timezone or decision sequence remains unknown. A final archived submitted roster can establish the final choice; it does not reconstruct initial choices, later edits or which forecast version was seen. An available provider forecast is not evidence of owner adoption. Link owner forecast/rationale to its original saved decision artifact if recovered, rather than assigning a provider's numbers to him.

Future implementation must demonstrate guards on isolated known-bad copies:

| Deliberate failure | Required behavior |
|---|---|
| Archive `players[*].projPoints` has only date/mtime/current retrieval evidence | Retain value as unverified archive; no certified calibration or owner-process explanation. |
| `actualPoints` or same-game MIN/usage supplied as a forecast field | Reject forbidden same-game outcome lineage. Numeric equality alone is not a test: legitimate forecasts can coincidentally equal actuals. |
| Forecast version, publication/capture evidence or timezone moved beyond cutoff | Reject certification or downgrade to explicitly post-cutoff/unresolved. |
| Claimed historical version differs from original bytes/hash, player/event/slate or units | Reject the identity/version join; no name-only fallback or unit guessing. |
| Provider forecast relabeled as owner-adopted without owner decision evidence | Reject adoption claim while retaining any independently certified provider test. |
| Unconditional forecast calibration drops a resolved nonparticipant | Reject changed target/support and show the missing player-game. |
| Outside-window observation or unresolved game supplied with zero actual minutes | Reject reassuring zero; retain unknown. |
| Traded player history crosses the latest same-team stint, or future/current boxes change a prior feature | Reject historical/context mismatch; earlier features must remain invariant. |
| Seven-slot roster treated as complete, source-zero selection removed, or exposure/`ct` fails eight-slot closure | Reject incomplete accounting; preserve selected identities and the actual user denominator. |
| Repeated contest/entry observations inflate forecast-validation N | Reject duplicate player-game target weighting; retain separate portfolio accounting. |
| Positive-participant baseline relabeled a pregame/legal candidate set | Reject scope/certification claim; keep retrospective sensitivity label. |
| Source/box score mismatch assigned to raw scoring components | Mask attribution and retain the visible remainder/conflict. |

These are proposed guards. This design document does not assert they are implemented. Existing participation parsing and inherited-panel reconstruction were separately repaired by the root task; their final receipt is under `research_peer_participation/final_validation_receipt_2026-10-02.json`.

## Dated cases and substantive owner-review questions

Recent owner support in the larger process corpus is Martin **10 contests/five dates**, Small **seven/three**, Jackson **eight/five**, Strawther **three/two**, and Nurkic **16/11**. Counts come from `source_exposures.parquet`, `user=rsbathla,season=2025-26`, exact `player,cid,date`. Strawther additionally has 13 contests/11 owner dates in the earlier season. Repeated rooms are not new role outcomes. Do not describe two recent Strawther owner dates as a broad repeated owner pattern.

| Dated observation | Raw/source evidence and unresolved question |
|---|---|
| Tyrese Martin, 2025-11-07, owner 100/100 entries in contest 184572711, $4,000, 8.75 DK | Original `research_peers/raw/2025-11-07_184572711.data.json.gz.users[rsbathla].lineups,totalRosters` independently reproduces 100 selected/100 submitted; `players[*].salary,actualPoints` reproduces price/score. Raw `raw_player_2025.parquet`, `PLAYER-ID=1631213,GAME-ID=22500031`: 19.3667 MIN, 7 FGA; eight earlier same-team appearances yield 20.875 MIN and 7.5 FGA. Raw scoring independently reconstructs 8.75 DK. The minutes difference is only −1.5083. Which certified forecast/uncertainty justified that exposure? A low score alone does not establish minutes or opportunity forecast failure. Four owner contest listings on this date share this one player outcome. |
| Javon Small, 2025-10-24, full owner exposure at $3,300, 23 source DK | `source_exposures.parquet` rows for 183929496/499/501/503 have `exposure=1`, `actual=23`. `process_features.parquet.prior_games=1`, with missing rolling prior-minutes/usage fields. Source choices and an actual box exist, but an established NBA role baseline does not. What external or saved role estimate supported the choice, and what uncertainty was acknowledged? Retain this favorable result alongside October 29's 2.5 source DK at 16/150 exposure and $4,000; do not interpret either as validating/disproving a missing forecast. |
| Quenton Jackson, 2025-11-01, owner 150/150 entries in contest 184291246, $3,700, 56.5 DK | Original `research_peers/raw/2025-11-01_184291246.data.json.gz` independently reproduces 150 selected/150 submitted and price/score. Raw `PLAYER-ID=1631245,GAME-ID=22500144`: 31.15 MIN, 16 FGA; only three earlier same-team appearances average 16.5667 MIN and 5.6667 FGA. Raw scoring independently reproduces 56.5 DK. Keep this favorable concentrated outcome. November 3's $4,700/15 DK full-exposure result and February 10's $3,400/36.5 DK partial exposure also belong in the review. What role scenario was documented on each date? |
| Julian Strawther, 2026-01-23, owner 24/150 entries, $3,000, 33.25 DK | Original `research_peers/raw/2026-01-23_187567051.data.json.gz` independently reproduces 24 selected/150 submitted. Raw `PLAYER-ID=1631124,GAME-ID=22500640`: 26.6667 MIN, 13 FGA, independently reconstructed 33.25 DK. Twenty-two earlier same-team appearances give prior-ten MIN 12.0167 and FGA 3.4. This favorable owner choice is not a peer-only mechanism. Was the expanded opportunity forecast saved, and why was exposure 16% rather than higher/lower? The question cannot be answered from the result alone. |
| Jusuf Nurkic, 2025-11-03, owner 150/150 entries, $4,800, 32.75 source DK | Original `research_peers/raw/2025-11-03_184402182.data.json.gz` independently reproduces selection multiplicity and price/score. `process_features.parquet`, same player/date: actual MIN 31.25 versus prior MIN 18.0556; actual FGA 12 versus prior 6.8333. Retain this favorable concentrated role expansion; do not assign it individual contest profit. |

The original source and raw-box checks above independently recalculated Martin, Jackson and Strawther; exact field/year/date identity was retained. Nurkic's source exposure was independently checked, while the stated role means come from the verified normalized parent and are labeled accordingly.

Existing named peer comparisons supply contradictions to a one-sided owner-error narrative: `research_peer_selection/named_player_choices.csv`, BPCologna/Tyrese Martin, records `selected_residual_contribution=+3.0207708491` but candidate-price `residual_contribution=-0.4943356326`; the benchmark changes the sign. BP/Quenton Jackson has `selected_residual_contribution=-5.4275653159`, favorable to the owner's greater exposure in that accounting. BP/Cam Thomas has `selected_residual_contribution=-2.3033662175`. These are retrospective benchmark contributions, not decision-quality grades. The audit must preserve the original benchmark definitions and both favorable/unfavorable cases rather than selecting a convenient benchmark after seeing results.

## Final gap and contradiction pass

**FINDINGS — fact:** full source portfolios, prices, exposures and extensive dated owner choices are recoverable. Prior-only role/shot/environment context and actual participation can be attached within stated support. The larger archive offers 146 owner dates, but only 116 have raw-window support; named recent cases offer two to 11 owner dates. The independent raw/source checks include both an unfavorable concentrated result and favorable concentrated/partial results.

**FINDINGS — inference:** a useful audit can now organize exposure to role assumptions and realized outcomes without fitting new weights. Forecast calibration becomes a separate empirical question only for genuinely certified forecast rows. A shortfall in points, a large minutes surprise and high exposure are different observations, not interchangeable diagnoses.

**FINDINGS — unresolved:** pre-decision forecast version/adoption, forecast conditionality, original versus final lineup edits, literal touches, complete pregame candidate eligibility/membership, slate-specific position eligibility and legal replacements remain unestablished by the inspected tables. The separate provenance search may close individual gaps; it must not promote every archived projection at once.

**CONFLICTS:** treating process rolling fields as necessarily same-team histories; treating `source_projection` or a retrospective salary model as a certified owner forecast; dropping unsupported/zero selections; using future participation as the pregame pool; calling usage/FGA touches; multiplying N by contests or entries; attributing player P&L; grading decisions solely from forecast error/outcomes; or narrating only unfavorable owner cases would violate the evidence contract. No verified fact, source artifact or earlier research vintage is overwritten by this design.

**DECISION POINTS:** (a) proceed now with descriptive exposure/role/outcome accounting and keep calibration pending per-row forecast certification — recommended; (b) select exact-price comparisons where supported and explicitly labeled inherited bands as sensitivity, keeping known denominators — recommended; (c) use shared supported owner/peer dates for comparative claims and all supported owner dates for owner-only case review — recommended; (d) if a user wants decision-quality or feasible-substitution judgments, first obtain the required decision/version/eligibility evidence rather than silently changing the research target. Any future numeric risk/loss cutoff is a stated research choice until separately validated, never an earned rule from these named outcomes.
