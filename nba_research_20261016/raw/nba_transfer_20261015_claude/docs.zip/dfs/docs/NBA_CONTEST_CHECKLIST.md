# NBA nightly contest-selection checklist (OVERLAY_PLAN §4)

> **September 22 audit update:** This document is a historical record. Current implementation status, corrected numerical results and source-quality limitations are in [NBA_RECONCILIATION_AUDIT_2026-09-22.md](NBA_RECONCILIATION_AUDIT_2026-09-22.md). Historical construction prescriptions are provisional; prior-season player triggers are not live signals.

*One page, every rule a measured finding — citations in parentheses point
at NBA_AUDIT_2026-07-17.md / NBA_ANALYTICS_NOTES.md. Nothing here is new
research; do not tune these without new measured evidence. 2026-07-19.*

## Before anything: the board

Run `nba/analytics/slate_board.py` with tonight's DK export + injury
report. Board strength = count of players with 2+ live triggers.
**Rank by trigger COUNT, never expected magnitude** (NOTES §4 — magnitudes
invert out-of-sample). A thin board (few multi-trigger players) is a
down-size signal even inside good fee bands.

## Enter (all boxes ticked)

- [ ] **Classic.** The 25-26 profit is 100% classic (F1). Showdown is a
      measured leak with no recoverable edge (S) — stay out; if ever
      re-entered: playoff-marquee SE only, mega-chalk core, popular
      mid-salary CPT, never multi-entry blocks (S2b/S2c; 21-150-bullet
      showdown blocks ran −30.4% in 25-26).
- [ ] **Fee band $600-2K first** (+6.3% pooled, the only green tier
      career-wide; 25-26 +40.4%). $2K+ acceptable in breakout form only —
      career −9.7%, 25-26 +36.8% (F3/C10). $555 is soft: $150-600 SE p1
      0.88%, below baseline (C11 R5).
- [ ] **Micro-stakes are a tax** ($3-10: −12.9% career; $10-33: −2.4%) —
      volume there only as train fodder if at all (F3).
- [ ] **Slate size 3-4 games** best; 1-2-game high-fee slates are the
      bleed shape (C6). Main slate (7-9p) carried 25-26 (+30.7%); the
      off-hours edge of 22-24 did NOT persist into 25-26 (early −9.4%,
      twilight −19.4%, late −23.3%) — don't chase it (I/K6).
- [ ] **SE builds pass `se_precheck.py`** — own-sum 270-285, one 5-15%
      salary-neutral pivot, ≤2 mega-chalk, 4-stack ~every other build,
      dup flag clear (C11).

## Calendar (F2, H/K5)

- October: seed with league priors only; triggers are cold (walk-forward
  0.99x in Dec, matures to 1.26x Apr — NOTES §4).
- December: down-size. Career −$271K hole; even 25-26 was −7.8% (K5).
- February: the hottest measured window (career +27.5%, positive 4
  seasons running incl. +$175K in 25-26 — K2). Full allocation.
- June: exit. Career June −25.8%, negative in every season with volume;
  Finals showdown calendar is the NFL live-finals leak's NBA twin (F1).
- July-September exhibition (Summer League/Olympic): never. −33% career
  (§0 preamble).

## Tilt note (G/K3)

Big-loss days do NOT precede bad play: next-day excess ROI after a p5
loss day is +24% vs season baseline. No cooldown rule needed; the leak
is calendar and lane, not tilt.

## Standing cautions

- DK entry_history export is money truth; FL money fields are not
  (~17pt understatement — HANDOFF §3).
- n<10 suppressed, n<50 flagged, deconfound before any new edge claim.
- These rules are 2025-26-era; re-derive each October (year-ahead
  doctrine: axes persist, player-level identity does not — NOTES §5).
