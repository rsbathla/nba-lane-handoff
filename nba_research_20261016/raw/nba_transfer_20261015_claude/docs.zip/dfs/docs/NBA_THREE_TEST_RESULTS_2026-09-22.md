# NBA follow-up: forecast value, ceiling sources, and role changes

September 22, 2026. These are the three user-authorized studies, run on a repaired research dataset. They extend the existing NBA work. No production weights, p75 triggers, roster assignments, salary rules or lineup decisions were changed.

## Source repair and scope

The 2025–26 sample now contains **all 1,230 regular-season games, 82 for each of 30 teams**, with 26,457 analytical player appearances across 582 players. This restores 66 source-labelled Cup games omitted by the earlier frame and excludes the Cup championship, game 62500001. The 2024–25 source remains partial through March 10: 968 games, 20,582 analytical appearances and 551 players; 61 source-labelled Cup games are restored and final 62400001 excluded. Cup games count toward regular-season statistics except the championship. [NBA rules](https://www.nba.com/news/nba-cup-101).

The outcome sample still requires at least one minute played; these are forecasts conditional on an analytical appearance, not predictions of availability. All raw participant rows, including subminute appearances, are retained for team tracking reconciliation. Three invalid usage values among analytical appearances are missing rather than clipped. Exact scoring components reconcile across all **47,039** analytical rows.

All **165 targeted NBA tracking requests succeeded**, covering 33 dates across the two seasons. Original files are preserved alongside raw response receipts, retrieval times and hashes. Every scheduled research date now has all five category pulls. Of the earlier 53 positive-FGA, zero-shot-diet rows in 2025–26, 48 now have positive tracked attempts and **46 reconcile exactly to box FGA**. Seven positive-FGA rows in the expanded 2025–26 sample still have zero tracked diet; 1,295 total rows have missing or discrepant tracking under the strict reconciliation policy. The corresponding older-season counts are four and 1,014. Discrepancy does not establish its cause; no missing attempts are invented.

For shot features, individual shot counts are retained only where the three shot-type counts reconcile to box FGA and distance counts are within valid bounds. Opponent shot exposure uses at least five fully reconciled games among its prior ten; missing games are omitted, and observed counts are retained. These are **observed-history estimates**, not proof of complete tracking. Current-game tracking quality never determines prediction eligibility: only prior histories do. Some prediction rows therefore have unknown realized tracking but valid prior features.

Source evidence: `nba/analytics/data/research_v2/frame_receipt.json`, `tracking_repair_receipt.json`, `tracking_quarantine_*.csv`, `independent_metric_checks.json`. The original top15 report is a named smaller-sample vintage; its conditional percentages should not be combined with the new full-game-universe profiles.

## 1. What does matchup information add to a basic forecast?

The baseline uses only earlier player history: minutes, production, usage, attempts, starter frequency, variability and recent changes, plus schedule/home context and the prior-20-game p85. Actual game minutes, usage, starter status, final participation and shots never enter its forecast. Added environment information contains both teams' prior pace and offensive/defensive efficiency plus the opponent's prior fantasy points allowed per 100 possessions at the player's coarse G/F/C position.

Shot additions use prior player shot shares multiplied by opponent allowed attempts per 100 possessions for catch-and-shoot, pull-ups and inside-10-foot shots, plus wide-open/tightly contested exposure and coverage counts. These are declared research variables, not new production multipliers. Synergy's season-final aggregates cannot substitute for missing historical daily states. Closing implied totals/spreads form a separate retrospective comparison because lock-time timestamps are unavailable.

The models are fixed, shallow histogram gradient boosting models: 120 iterations, seven leaves, minimum 75 observations per leaf, learning rate .05, L2 regularization 10, no early stopping. They are refit monthly using strictly earlier dates, including the available prior season. December 2025 through April 2026 is replayed. There is no tuning against the reported outcomes; the configuration is an explicit research choice. The saved library version is 1.6.1. [Classifier documentation](https://scikit-learn.org/1.6/modules/generated/sklearn.ensemble.HistGradientBoostingClassifier.html).

Prediction eligibility requires 20 previous appearances in the current season, with no eventual full-season-games requirement. Entire games stay together across date splits. The binary target is exceeding one's **prior-20-game p85**, not the future season's fixed top 15%; its evaluation hit rate is 19.04%. A separate regressor predicts DK points. This is retrospective chronological replay, not an untouched prospective trial, and old NBA research had already examined these seasons.

Lower errors are better. **Brier error** measures probability accuracy; **MAE** is average absolute DK-point error. Read comparisons within the same population.

| All eligible rows: 16,304 appearances, 445 players, 929 games | Brier error | DK MAE |
|---|---:|---:|
| Player-history baseline | .150134 | 7.8533 |
| Baseline + environment | .149332 | 7.8150 |
| Baseline + environment + closing market | .149119 | 7.8069 |

Environment reduces DK MAE by **0.0384 points, about 0.49%**. Its paired weekly-bootstrap 95% interval is [0.0194, 0.0571], with adjusted q=.024. The Brier reduction is .000803; its weekly interval is [.000171,.001573], but q=.068 after the declared twelve-comparison adjustment. Thus the probability improvement does not pass the overall family's 5% gate on this population. Closing-market improvements are small and remain retrospective.

| Identical shot-history-eligible rows: 13,756 appearances, 445 players, 909 games | Brier error | DK MAE |
|---|---:|---:|
| Baseline | .150099 | 7.8356 |
| Baseline + environment | .149112 | 7.7990 |
| Baseline + environment + shots | .149254 | 7.8017 |
| Baseline + environment + closing market | .148941 | 7.7926 |
| Baseline + environment + closing market + shots | .149043 | 7.7926 |

Adding shots to the environment model **worsens Brier by .000142** and MAE by .0027. The Brier improvement interval is [−.000384,+.000134], q=.416; zero lies comfortably inside. Adding shots after closing-market context also produces no demonstrated gain. These results concern this feature definition, model and observed-history subset; they do not prove every finer matchup mechanism is useless.

Uncertainty pairs each prediction on identical player/game rows, resamples 19 calendar-week blocks, and includes a player-cluster sensitivity. Week sign-flip p-values are adjusted across all twelve metric/ablation comparisons, including unattractive results. Weekly dependence beyond the block and overlap between tests remain limitations. Feature-spread checks confirm that the shot variables are nonconstant and populated; the null is not caused by dead features.

Audit trail: `forecast_predictions.parquet`, `forecast_metrics.csv`, `forecast_comparisons.csv`, `forecast_monthly.csv`, `forecast_calibration.csv`, `forecast_summary.json`. An initial version without the existing positional-defense dimension is preserved under `initial_no_dvp/`; the final model consumes that layer after inventory review. The initial version also showed no shot-feature gain. This revision was not chosen to improve a reported result.

## 2. Where do ceiling points come from, and what repeats?

This study uses each player's strict **within-period p85**, explicitly retrospective. Primary descriptions require 50 appearances, ten tail games and thirty ordinary games. There are 197 eligible 2025–26 players. Exact DK scoring is partitioned into two-pointers, three-pointers including the DK bonus, free throws, rebounds, assists, steals, blocks, turnovers and double/triple-double bonuses.

These illustrative players continue the earlier report's examples; they are not selected statistical winners. Values are additional DK points per top-tail game relative to ordinary games.

| Player | Tail / ordinary games | Total DK gap | Allocation to extra minutes | Allocation to production per minute | Selected scoring sources |
|---|---:|---:|---:|---:|---|
| Jalen Brunson | 11 / 63 | +18.80 | +4.91 | +13.89 | Three-pointers +6.36; assists +3.72 |
| Tyrese Maxey | 11 / 59 | +20.46 | +7.51 | +12.95 | Assists +5.11; two-pointers +4.86 |
| Karl-Anthony Towns | 12 / 63 | +20.04 | +2.85 | +17.19 | Two-pointers +6.02; three-pointers +5.88 |
| Donovan Mitchell | 11 / 59 | +19.11 | +2.19 | +16.92 | Two-pointers +5.53; rebounds +3.28 |

Across eligible players, the median exact allocation is **37.3% extra minutes and 62.7% greater production per minute**. Production per minute includes usage, shooting conversion and every other box-score source; it does not mean shooting accuracy alone. The minutes/per-minute decomposition is an alternative view of the same DK gap and must not be added to the scoring categories. Brunson's increased shooting points divide into +7.72 from attempts and +4.36 from conversion; Maxey's into +8.00 and +2.16.

Among 157 players eligible in both calendar halves, the share of the ceiling gap from three-point scoring repeats with correlation **.636**, minutes allocation .491, rebounds .375 and assists .253. Steals are weaker at .117. But after subtracting each player's ordinary scoring mix, the corresponding three-point correlation falls to **.177, q=.051**; rebounds fall to .020 and assists to .061. Much of the raw persistence reflects familiar player style rather than a special ceiling mechanism. Some adjusted sources recur in the equal-calendar year comparison, so the finding is not universal absence of repeatability.

There are 96 planned source comparisons, of which 72 are estimable and adjusted as one family. The older source is too short for its declared second-half gate; the equal-calendar year comparison has 199 pairs. Those are profile-stability tests, not tests of when the next big game will occur. Detailed definitions, uncertainty and independently reconstructed Brunson/Maxey examples: [ceiling-source audit](NBA_CEILING_SOURCES_AUDIT.md). All player profiles: [source_profiles.csv](../nba/analytics/data/research_v2/source_profiles.csv).

## 3. Do role changes justify separate histories?

The fixed detector identifies team-stint changes and prior-game changes in starter frequency/minutes. Minutes detections compare the prior five appearances with the preceding ten and require a six-minute difference; starter changes use 20%/80% thresholds. Detections use no current-game outcomes. Follow-up windows do not overlap, team returns start a new contiguous stint, and thresholds were not tuned to results.

There are 342 complete 2025–26 role-increase windows. Their next ten appearances average **+5.14 minutes and +5.16 DK points** relative to the earlier ten-game window. Exceeding the frozen old-role p85 rises from 15.35% to 35.67%; that old threshold is **not** the new season's top-15% probability. Gui Santos's February 3 minutes-change detection, for example, precedes a next-ten-game average of 30.02 minutes/32.68 DK versus 15.63/13.50 in the earlier window. The five detection games are between those windows and are not counted as future outcomes. No injury or coaching cause is inferred.

The forecasting control is the decisive comparison. All methods predict the same 18,615 later appearances after fifteen prior player-season games:

| Forecast history | Overall DK MAE | MAE during ten appearances after a detected event |
|---|---:|---:|
| Expanding season history | 8.0726 | 8.2804 |
| Prior ten appearances | 7.9658 | 8.0392 |
| Detected-role history | 7.9672 | 8.0975 |

Role history is effectively tied with prior-ten overall and is **0.0583 points worse near events**, with an unadjusted date-cluster interval [+0.0076,+0.1091]. The partial older season points in the same unfavorable direction near events: +0.1021 points. Recent-five, recent-twenty, team-history and outcome-blind periodic resets are also saved controls. These cohorts differ from study1, so their absolute MAEs should not be compared across studies.

Role changes matter for describing a player's history, but this particular detector does not earn a forecasting adjustment beyond ordinary recency. Selection on a minutes streak, incomplete follow-up, repeated players and unknown availability causes remain limits. Details and independent raw-box checks: [role-change audit](NBA_ROLE_CHANGE_AUDIT.md).

## Interpretation and verification

These tests support retaining recent player opportunity and broad environment as research benchmarks. The added shot variables do not improve the tested forecasts, ceiling-source persistence is substantially explained by ordinary style, and explicit role resets fail to outperform a simple recent-history control. None earns a new production weight or automatic lineup rule.

The three analyses are reproducible from `research_frame.py`, `incremental_forecast_study.py`, `ceiling_sources_study.py` and `role_change_study.py`. **96 regression tests passed.** The dedicated research artifact gate verifies source receipts, Cup treatment, exact scoring, prior-only features, prediction pairing, labels and consumed-column hashes. A copied dataset with a Cup semifinal removed and another with missing tracking restored to a false zero are both rejected. Independent calculations reproduce the displayed forecast losses and featured source/role examples. Passing checks certify these calculations and their declared scope, not future profitability or complete injury/market provenance.

Use the verified Python environment described in `nba/analytics/README.md`. Final checks: `python nba/analytics/research_audit.py --strict`, `python nba/analytics/integration_audit.py --strict`, and the shared Fantasy `integration_audit.py --strict`. The historical contest-construction source gate remains separately blocked and is not used in these studies.
