# NBA construction audit — read-only findings, 2026-09-22

Scope: `/Users/rsbathla/Downloads/dfs/core/nba_*.py`, `core/contest_shapes.py`, NBA identity/exposure/precheck tools, historical handoff and audit. SQLite opened with `mode=ro`; imports did not execute writer mains. No source edits, weight changes, commits, or live network claims. Paths below are relative to `/Users/rsbathla/Downloads/dfs/` unless absolute. Quantities were independently recomputed from gzip/SQLite/parquet, not accepted from prose.

## FINDINGS — DATA SHOWS

### P1: Incomplete source rosters silently enter construction analytics

`core/nba_construction_audit.py:63`, `core/nba_winner_lineups_audit.py:74`, `core/nba_se_vs_mme.py:78`, `core/nba_stacks_vs_winners.py:53` check resolvable IDs but never require eight unique players. `core/nba_se_prescription.py:80` compares potentially incomplete sets and subtracts overlap from eight.

Across every current `nba_users/*.json.gz`: 67,525 distinct his hashes, of which **2,033 contain fewer than eight players**. Length distribution: 8:65,492; 7:655; 6:435; 5:252; 4:308; 3:216; 2:129; 1:38. Missing entries are present in both source surfaces, not just a hash parsing error. Known-bad fixture: `tools/data/fantasylabs/nba_users/2024-03-20_159660268.json.gz`, hash `38313:12462:122680:74369:86449:12346:28032`; companion `nba_lineups` file has seven `lineupPlayers` slots, no UTIL, `totalSalary=45100`, yet isCashing=true. Actual cause of source omission is unverified; do not impute missing players.

C11 sensitivity rederived: 235 clean-SE contests have any top-1% candidate; ten have incomplete his builds. Filtering his and candidate rosters to eight leaves225 comparisons. Median swaps remains4; diff-slot low5–15 ownership is19.11% his vs28.00% winner; mega40+ is26.11% vs16.22%. This repairs only roster completeness, not field-source conflicts or outcome bias. The doc's273 overall comparisons also include contests with top5 but no top1 candidate.

### P1: Contest-source identity and denominator consistency lack a gate

Winner output has1,457 contests. Comparing `tools/data/fantasylabs/nba_winner_lineups_audit.csv.n_field_entries` with SQLite `entry_history.MAX(contest_entries)` for the same NBA Classic contest key yields **19 with >5% disagreement, nine with field count >2x DK**,54 with >1% disagreement. These cutoffs describe severity only, not approved acceptance tolerances.

Known-bad fixture: `nba_users/2023-04-18_143613499.json.gz`: `contest.contestSize=5945`, `contest.totalLineupsEntered=23493`; companion `/lineups` `field_stats.n_entries=23493`; DK `entry_history` reports5,928 entries. Its tier1 gameStack counts for sizes4/5/6 are89/29/13, giving `(89+29+13)/(5945*.01)=2.203532380151388`, **220.35%** under `core/nba_stacks_vs_winners.py:tier_rate`; exact provided top1 lineup rate is68.0851%. Do not silently substitute the larger denominator: source identity itself conflicts with the money-truth contest.

For707 contests with both historical histogram and exact winner g4 fields,137 differ by over10 percentage points; the approximation's claimed ±10% fuzz is not a demonstrated bound. Old C4/SE histograms should not silently become trusted rates after a range clamp.

### P1: Attribution guard is inconsistently applied

`core/nba_winner_lineups_audit.py:99–143` never applies the established `FL rosters > 2 * DB bullets` guard from construction and SE audits. Five retained contests credit189 FL rosters for five DB entries: cid143093502(15),158138754(5),159050465(25),159986675(3),168368574(141), each DB bullets1. Last example is2024-10-22. Their presence explains the1,457 winner rows vs1,452 guarded construction rows, but source-count conflicts also exist beyond these five. Propagate shared validation, rather than assuming the existing guard catches every mismatch.

### P1: The precheck implementation cannot support its live claims

- `nba/analytics/se_precheck.py:59–72`: any nonempty out-list fires every eligible absence trigger, without identity/team/key-player/position matching. Real-frame reproduction at2026-04-12: `out_players='NOT AN NBA PLAYER'` adds223 triggers across154 players vs an empty list. Historical flags are also reused from each player's last date without validating tonight's matchup or freshness.
- `:95–99`,`:131–143`: game-stack flag counts teams. In2025-10 through2025-12 raw complete his builds,2,515/6,085 are misclassified:4,401 have a4+ game group, only1,886 a4+ team group. Use source eventId for retrospective game grouping.
- `:191–195` passes enumerate-generated IDs into `pivot_candidates`, which expects FL IDs at`:110–116`. Current bridge minimum FL ID12011; no IDs0–699 match. Consequently ordinary live candidate trigger counts become zero. Salary is also always None here even with a supplied slate.
- `:87` implements at-least-one pivot, not exactly-one; salaries parameter unused; no actual salary-neutral/position eligibility calculation;`:165–168` only notes wrong roster length; duplicate players and out-of-range/nonfinite ownership are not rejected. Claimed DK-entry-row support is absent (reads first column only). `--builds-tonight` is documented but not accepted.

Known-bad duplicate test: players `[('dup',10),('dup',10)] + five distinct players owned39 + one distinct player owned60` sum275 and pass R1/R2/R3/R5 at fee777, despite duplicate roster identity and two pivot slots. Separate 2+2 players in the same event produces a real4-stack that team counting misses.

### P1/P2: Showdown money is counted multiple times

`core/nba_sd_field_analysis.py:235–245` groups his money by date, then joins one row per contest feed. Current `nba_sd_field_analysis.csv` yields45 joined rows but38 unique dates. Totals become **$391,766.89 fees / -$9,203.93**, whereas counting the same dates once yields **$294,478.89 / -$2,520.13**. On2022-06-05, four feeds repeat $22,066 fees/-$7,238.17 each. On dates with multiple games, the same all-day money may be assigned to distinct slate characters. Removing duplicate rows alone does not identify which game's money belongs to which slate.

Library has65 files representing60 distinct `(date,eventId)` combinations;64 feeds usable by existing logic. Optimizer concern was refuted on this sample: all64 returned six unique players, salary<=50000, reconstructed score equals reported score; an independently implemented DP using exact $50 salary units produced identical optimum point totals for all64. This does not establish full generic optimizer correctness or validate strategy from hindsight optimals.

### P2: High-fee cohort winners overcredited on mixed-user duplicate builds

`core/nba_high_fee_audit.py:139–144` credits all `lineupCt` entries whenever any member of COHORT appears in `entryNameList`. Across271 high-fee non-SE contests,12 winning lineups contain both cohort and noncohort users (33 total entries). Example `nba_lineups/2021-11-27_119329956.json.gz`: lineupCt2, lineupUserCt2, entryNameList `[ChipotleAddict, phoenix2019]`, percentile0.46: code credits both entries to cohort. Overall450 entries credited vs430 matching name occurrences, but these are not equivalent units when users can duplicate their own build; do not claim430 is a corrected entry count. Without per-user multiplicities, report a bound/unknown or a clearly labeled lineup-level measure.

### P2/P3: Documentation and counts

SQLite rederivation matches existing money:372,220 NBA-lane entries, fees **$10,514,180.30**, net **-$421,882.56**, with2025-26 fees$2,291,172/net+$540,931.31 over60,727 entries. Full seven season rows match doc amounts (six full seasons plus bubble tail). However filtered NBA-lane scope has**18,498 contests/859 days**, not doc18,672/869. Its current inclusion filter also includes two NBA Best Ball entries, $0 fees/+$50; house sport/format separation says best ball separate, so proper exclusion would produce372,218 entries/net-$421,932.56. Keep this $50 policy correction explicit rather than rewriting history silently.

WNBA separately rederives14,641 entries/$290,199.65 fees/-$32,661.67;2026-to-date3,218 entries/$40,366 fees/+$205.82. No mixed-sport contest-key collisions or duplicate NBA entry_keys found. Missing cash/ticket values:zero.

Actual inventory: nba_users1,499 gzip files (1,452 with rsbathla/lineups), nba_lineups1,457, nba_sd_lib65. All users hashes sum89,223 lineupCt. Bridge1,150 FL IDs matched/58 unmatched,25 person_ids have multiple FL IDs; all360 IDs rostered in>=5 of his2025-26 contest files are matched, unmatched with any his2025-26 appearance=0. Observed duplicated bridge IDs mostly reflect non-overlapping FL-ID eras; no confirmed incorrect identity merge found in bounded review. Exposure lens output exists with30,317 rows, but current output has11 factor columns while current script enumerates13: it needs version/freshness reconciliation.

## Reconciled handoff status

- Identity bridge: implemented (`nba/analytics/build_id_bridge.py` plus id_bridge outputs); active frequent-player acceptance passes above.
- Exposure-vs-edge lens: implemented (`exposure_edges_lens.py` plus30,317-row output); in-sample trigger caveat is present. Output freshness needs reconciliation.
- Pre-lock SE checker: implemented but requires above repairs; do not call ready or rebuild independently.
- Per-season pro-cohort split: historical scripts retain season in some intermediate rows but print pooled named-user fingerprints/ROI; no complete per-season pro-cohort ROI implementation found in this scope.
- Stratum5 train backfill: no stratum5 file in current nba_users archive (strata1:858,2:190,3:157,4:294); not completed. Non-entered flagship backfill not established by this audit.
- 2021 SD reanchor: remains unverified/uncompleted; source library's current dates begin in2022.
- DK showdown exports, FC logged-in state, WNBA source probe, dashboard refresh: not reverified by this bounded source audit; do not repeat historical no-access claims as current facts.

## Compact guard specification and removal fixtures

1. Shared classic lineup validator: require exactly8 unique resolvable player IDs for every lineup used in own-sum/salary/stack/swap metrics. All expected salary, ownership and event fields need explicit finite/type validity; unknown does not become zero. Guard fixture = seven-slot2024-03-20 roster above; fully populated eight-player synthetic control must pass. Log rejected contests, distinct builds and entry-weighted coverage separately; no silent denominator shrinkage.
2. Shared contest-source validator: NBA Classic sport/type and contest key must resolve in read-only DK truth; record source contestSize/totalLineupsEntered/full-field count versus DK count. Reject self-contradictory source counts and surfaces. No implicitly tolerated mismatch; if practical small missing-entry tolerance is wanted, make the explicit acceptance policy visible rather than treating the19 >5% threshold as chosen policy. Fixture cid143613499 must fail before any histogram-derived220.35% can publish. Unit rate guard0<=rate<=1 should additionally fail, never clamp.
3. Shared user-attribution validator: propagate existing FL>2xDB guard to all downstream construction comparisons; additionally record any count discrepancy. Fixture cid168368574(141 vs1) must fail. Passing this loose guard is not proof of exact attribution.
4. Cohort ownership: total duplicate lineupCt cannot all belong to a named cohort from an any-name intersection. Require per-user entry multiplicity for an exact entry count; otherwise label unavailable or bounds. Fixture mixed two-user lineup above: exact credit must not be2.
5. Money conservation: join must preserve unique money grain and totals. Before and after sums and multiplicities asserted; date-level money cannot join many slate rows without explicitly defined allocation. Fixture2022-06-05 four-feed date fails; one input date plus one output money row passes.
6. Precheck adversarial fixtures: bogus unrelated out-name must addzero absence flags;2+2 same-event group must count as4; enumerate-ID candidate must never silently convert unresolved identity to0 triggers; invalid/duplicate roster fails structurally before heuristic PASS output. Thresholds unchanged pending user-owned strategy review.

## INFERENCE

Historical P&L is substantially more reliable than the construction recommendations because it uses DK cash+ticket fields and reproduced independently. C11's ownership direction survives the narrow completeness test, but exact thresholds/fee prescriptions remain retrospective hypotheses; outcome-selected nearest winners and same-season trigger selection do not establish improvement in prospective returns. Strongest objection to abandoning the work: several broad descriptive findings survive; repair source validation and rerun instead of discarding research.

Cheapest falsifying tests: source guards above plus complete-roster/source-consistent replay, followed by genuinely held-out C11 evaluation. Do not spend money or tune ownership thresholds from this audit.

## ASSUMPTIONS / LIMITS

DK entry_history is the authorized monetary truth; cash+ticket sum remains existing semantics. The audit did not authenticate FC, retrieve missing external exports, refresh rosters, modify thresholds or run writer mains. The independent sensitivity filter changed only roster completeness and is not a final clean report. `contest_shapes.py` archetype keys and enrichment do not encode sport; current contests table is134 NFL-only rows and NBA tools here import only norm, so this is a latent reuse hazard, not confirmed NBA contamination. Preserve explicit sport separation if reusing it for NBA.

## CONFLICTS

Incomplete rosters/source identity conflicts contradict reports' exact-lineup and same-room claims; unbounded histogram rates contradict probability semantics; duplicate money violates monetary conservation; precheck absent-player flags and ID joins contradict player-specific live evidence; binary C11 pass/fail policy is stronger than what retrospective descriptive evidence establishes. No verified current roster layer was overruled.

## DECISION POINTS

Recommendation: quarantine affected historical construction recommendations as provisional, add shared blocking guards with known-bad tests, then regenerate affected outputs under declared coverage. Preserve reproduced money totals with explicit small best-ball separation correction. Reconcile handoff to implemented-but-unvalidated precheck rather than unbuilt. Any C11 threshold/fee-policy tuning and any daily-to-game money allocation require owner choice; default recommendation is no strategy tuning and no invented allocation. No user approval needed for read-only probes or mechanical guard repairs already requested.

## Reproducible raw probe completion

`/tmp/nba_construction_raw_probe.py` completed successfully; full JSON is `/tmp/nba_construction_raw_probe.json` (470,943 bytes). It reproduces both bad fixtures and has a positive-control eight-player fixture. Additional coverage from the same requested scan: 263 user-feed contests contain at least one partial or unresolved-ID build; 6,297 distinct builds / 9,535 lineupCt fail the combined completeness+identity test (the earlier2,033 figure is partial length alone).188 kept-lineup source files contain at least one invalid roster.999/1,457 full-field totals differ from DK by any amount; most differences are small, so an exact-count gate and a severe-conflict gate have very different practical scope. The >1%/>5%/>2x numbers above are severity summaries, not implicitly approved tolerance policies.
