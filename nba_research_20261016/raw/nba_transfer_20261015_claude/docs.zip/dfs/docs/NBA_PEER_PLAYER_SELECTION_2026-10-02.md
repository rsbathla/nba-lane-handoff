# NBA peer player choices and backtests — 2026-10-02

BPCologna, youdacao, the original comparison peers and the additional peers identified by the corrected older-season screen are reviewed below. These are observed selections on shared contests, with historical player roles and later results. Their private forecasts and reasons for each pick are unavailable.

The selection study contains **1,677 complete user-contest portfolios and 200,555 attributed entries** across 2024–25 and 2025–26. Its later same-contest comparisons span **114 contests and 72 dates**. Entries on the same slate are dependent observations; the uncertainty calculations use dates and calendar weeks. [summary.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/summary.json) and [cohort.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/cohort.json).

## Observed player preferences

The table lists the largest overweights and underweights versus your entries in 2025–26. Names are ranked by exposure difference before inspecting outcomes, with at least three observed dates per name. Percentages average contests within each date, then dates **where either portfolio selected that player**. They are conditional preferences, not exposure over every possible slate; both-zero dates are outside this named-case denominator. A player appearing on three dates remains a three-date example even when thousands of entries contain him. [named_player_choices.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/named_player_choices.csv) · fields `peer,player,dates,delta_exposure`; [selection_tests.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/selection_tests.csv) · `contests,days`.

| Peer | Why included | Shared contests/dates | More than you | Less than you |
| --- | --- | --- | --- | --- |
| 3rd_and_schlong | corrected older screen | 42/37 | Ryan Kalkbrenner +34.4 pp (3d); Ben Sheppard +22.4 pp (3d); Jimmy Butler +16.6 pp (4d) | Shaedon Sharpe -35.7 pp (5d); Javon Small -33.8 pp (3d) |
| bpcologna | requested | 92/59 | Julian Strawther +18.4 pp (3d); Cam Thomas +18.1 pp (6d); Ja Morant +16.9 pp (6d) | Tyrese Martin -63.8 pp (3d); Anthony Davis -39.9 pp (5d) |
| cheddabisque | corrected older screen | 38/28 | Cam Thomas +33.5 pp (4d); Scottie Barnes +20.0 pp (7d); Tre Jones +19.6 pp (10d) | Anthony Davis -31.7 pp (5d); Shaedon Sharpe -30.0 pp (4d) |
| dacoltz | original comparison | 43/29 | Noah Clowney +28.4 pp (6d); Aaron Wiggins +18.9 pp (5d); Brice Sensabaugh +17.0 pp (3d) | Shaedon Sharpe -58.4 pp (3d); Tyrese Martin -46.7 pp (3d) |
| gregr1224 | original comparison | 28/25 | Jusuf Nurkic +18.2 pp (5d); Keyonte George +14.5 pp (6d); P.J. Washington +13.2 pp (8d) | Jalen Smith -19.9 pp (4d); Andrew Wiggins -17.1 pp (3d) |
| hixx | original comparison | 68/45 | Julian Strawther +27.4 pp (3d); Ziaire Williams +14.4 pp (5d); Brandon Ingram +13.4 pp (14d) | Javon Small -35.7 pp (3d); Anthony Davis -29.4 pp (5d) |
| jpm11 | original comparison | 37/28 | Jalen Green +26.0 pp (3d); Cam Thomas +25.7 pp (4d); Franz Wagner +21.0 pp (7d) | Tyrese Martin -50.7 pp (3d); Anthony Davis -38.4 pp (4d) |
| jsn77 | corrected older screen | 19/15 | Cam Thomas +25.6 pp (3d); Jaylen Brown +22.7 pp (7d); Dyson Daniels +21.8 pp (6d) | Anthony Davis -56.4 pp (3d); Shaedon Sharpe -50.7 pp (3d) |
| magneto999 | corrected older screen | 11/11 | Jaylon Tyson +20.3 pp (4d); Sandro Mamukelashvili +19.0 pp (3d); Aaron Gordon +18.3 pp (4d) | Pascal Siakam -36.4 pp (3d); Shaedon Sharpe -35.9 pp (3d) |
| mazwa | original comparison | 53/34 | Bobby Portis +30.2 pp (3d); Devin Booker +28.8 pp (8d); Nikola Jokic +28.6 pp (13d) | Quenton Jackson -37.0 pp (4d); Javon Small -35.1 pp (3d) |
| needlunchmoney | corrected older screen | 8/5 | Anthony Edwards +13.8 pp (3d); P.J. Washington +12.6 pp (4d); Daniel Gafford +11.6 pp (3d) | Kon Knueppel -5.7 pp (3d); Matas Buzelis -5.0 pp (3d) |
| nerdytenor | original comparison | 17/16 | Jusuf Nurkic +21.6 pp (5d); Desmond Bane +17.6 pp (6d); Saddiq Bey +15.4 pp (6d) | Matas Buzelis -37.2 pp (4d); Daniel Gafford -33.8 pp (3d) |
| oxenduck | original comparison | 91/58 | Julian Strawther +23.2 pp (3d); Justin Champagnie +18.2 pp (5d); Bub Carrington +17.8 pp (5d) | Javon Small -37.6 pp (3d); Anthony Davis -23.5 pp (6d) |
| papagates | corrected older screen | 41/25 | Cam Thomas +30.3 pp (4d); Dillon Brooks +26.7 pp (4d); Noah Clowney +25.5 pp (5d) | Tyrese Martin -94.2 pp (3d); Quenton Jackson -64.8 pp (3d) |
| youdacao | requested | 26/18 | Herbert Jones +33.9 pp (6d); Kel'el Ware +30.2 pp (3d); Mike Conley +28.5 pp (3d) | Kawhi Leonard -35.8 pp (3d); Andre Drummond -33.8 pp (3d) |
| zokin | corrected older screen | 14/11 | Ryan Rollins +22.2 pp (3d); Ryan Kalkbrenner +21.2 pp (3d); Franz Wagner +18.6 pp (4d) | Quenton Jackson -50.2 pp (3d); Trey Murphy -47.2 pp (4d) |


## What those players represent

Player types use the eleven archived Synergy play types from **2024–25**, consumed only for the 2025–26 review. The dominant type is the player’s largest prior-season possession category across all team stints; it is not his exclusive scoring method. Each matchup description retains the category share, offensive efficiency and opponent’s prior-season efficiency/rank. It does not assume the opponent’s defense or the player’s role stayed unchanged. [player_features.parquet](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/player_features.parquet) · `syn_type,syn_vintage,syn_poss_pct,syn_off_ppp,def_rank`; [prior-season inputs](/Users/rsbathla/Downloads/dfs/nba/analytics/data/synergy).

BPCologna’s largest repeated positive differences include a cheap prior spot-up player (Julian Strawther), a high-usage prior pick-and-roll ball handler (Cam Thomas), and another prior pick-and-roll ball handler (Ja Morant). Youdacao’s list includes a lower-usage prior spot-up player with peripheral production (Herbert Jones), a prior pick-and-roll roll man (Kel’el Ware), and another prior spot-up player (Mike Conley). The precise classifications, shares and possession counts are in the player-feature file; these lists describe several different routes to points.

- bpcologna / Ja Morant: prior dominant type **PRBallHandler**, prior-category share 28.7%, prior usage 33.4% on covered example dates.
- youdacao / Kel'el Ware: prior dominant type **PRRollMan**, prior-category share 24.5%, prior usage 18.6% on covered example dates.
- youdacao / Mike Conley: prior dominant type **Spotup**, prior-category share 31.4%, prior usage 13.1% on covered example dates.

The full-slot prior-role mix below shows each peer’s two largest known categories and the category most overweighted relative to you on that peer’s shared dates. Unknown roles retain their own share; no observed categories are renormalized. These category differences are descriptive. [player_types.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/player_types.csv) · `dimension,player_type,peer_slot_share,owner_slot_share` (2025–26 selections, 2024–25 role vintage).

| Peer | Largest prior role categories, % of all slots | Largest positive role difference versus you | Unknown prior-role slots % |
| --- | --- | --- | --- |
| 3rd_and_schlong | Spot-up 39.5%; Pick-and-roll handler 22.5% | Transition +0.6 pp | 10.2 |
| bpcologna | Spot-up 40.7%; Pick-and-roll handler 22.4% | Spot-up +1.7 pp | 9.4 |
| cheddabisque | Spot-up 37.3%; Pick-and-roll handler 21.9% | Pick-and-roll handler +1.4 pp | 11.7 |
| dacoltz | Spot-up 35.5%; Pick-and-roll handler 22.7% | Cut +1.5 pp | 11.1 |
| gregr1224 | Spot-up 43.3%; Pick-and-roll handler 23.7% | Spot-up +2.7 pp | 9.3 |
| hixx | Spot-up 40.7%; Pick-and-roll handler 23.7% | Spot-up +1.4 pp | 9.3 |
| jpm11 | Spot-up 36.5%; Pick-and-roll handler 23.1% | Pick-and-roll handler +1.7 pp | 11.7 |
| jsn77 | Spot-up 34.9%; Pick-and-roll handler 19.2% | Transition +2.1 pp | 10.9 |
| magneto999 | Spot-up 37.8%; Pick-and-roll handler 19.4% | Spot-up +6.7 pp | 13.0 |
| mazwa | Spot-up 39.3%; Pick-and-roll handler 19.5% | Cut +1.4 pp | 11.1 |
| needlunchmoney | Spot-up 40.9%; Pick-and-roll handler 17.2% | Cut +2.5 pp | 9.7 |
| nerdytenor | Spot-up 39.8%; Pick-and-roll handler 23.8% | Pick-and-roll handler +1.4 pp | 8.7 |
| oxenduck | Spot-up 38.9%; Pick-and-roll handler 21.6% | Cut +0.5 pp | 9.9 |
| papagates | Spot-up 38.6%; Pick-and-roll handler 23.2% | Spot-up +2.2 pp | 10.8 |
| youdacao | Spot-up 40.7%; Pick-and-roll handler 21.6% | Spot-up +3.5 pp | 10.5 |
| zokin | Spot-up 40.1%; Pick-and-roll handler 19.5% | Pick-and-roll handler +4.0 pp | 10.4 |

The comparable prior-history summaries below use a separate coverage mask for each trait. Minutes and usage use prior-ten-game averages; “cheap minutes” means salary at most $5,000 and prior minutes at least 25. Values are conditional means per covered slot, with each peer and your value computed on the same contests. Shot coverage does not remove otherwise usable minutes or usage. [player_traits.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/player_traits.csv) · `trait,days,peer_value,owner_value,peer_slots,owner_slots`.

| Peer | Prior usage %, peer/you | Prior minutes, peer/you | Cheap-minutes slots %, peer/you | Usage-covered dates | Usage-covered slots of8, peer/you |
| --- | --- | --- | --- | --- | --- |
| 3rd_and_schlong | 21.9/22.1 | 27.7/27.1 | 7.5/6.6 | 29 | 7.81/7.82 |
| bpcologna | 22.1/22.1 | 27.1/26.8 | 6.8/6.5 | 44 | 7.91/7.91 |
| cheddabisque | 22.5/22.6 | 27.1/26.8 | 6.8/7.0 | 25 | 7.78/7.75 |
| dacoltz | 22.2/22.4 | 27.6/27.1 | 9.2/7.6 | 25 | 7.64/7.74 |
| gregr1224 | 22.0/22.1 | 27.0/26.5 | 9.0/7.8 | 16 | 7.97/7.95 |
| hixx | 22.0/22.2 | 27.3/27.2 | 7.4/7.1 | 31 | 7.84/7.80 |
| jpm11 | 22.8/22.5 | 26.8/26.8 | 6.0/7.0 | 25 | 7.90/7.88 |
| jsn77 | 22.4/22.4 | 27.8/27.4 | 8.9/9.1 | 12 | 7.44/7.48 |
| magneto999 | 22.0/22.5 | 27.3/26.9 | 7.2/5.7 | 9 | 7.90/7.80 |
| mazwa | 22.2/22.3 | 27.2/26.8 | 7.6/6.8 | 31 | 7.80/7.81 |
| needlunchmoney | 21.9/22.4 | 26.5/25.8 | 2.6/4.3 | 5 | 8.00/8.00 |
| nerdytenor | 22.2/22.2 | 27.5/27.1 | 6.0/5.8 | 14 | 7.65/7.64 |
| oxenduck | 22.3/22.2 | 27.1/26.9 | 6.9/6.4 | 54 | 7.85/7.87 |
| papagates | 22.1/22.3 | 28.3/27.3 | 7.8/6.5 | 23 | 7.75/7.72 |
| youdacao | 21.9/22.5 | 27.6/27.3 | 9.6/8.0 | 17 | 7.72/7.67 |
| zokin | 21.9/22.2 | 28.1/27.8 | 8.3/6.7 | 9 | 7.55/7.56 |


Full player-type shares, including an explicit unknown category and zero shares for categories absent on a slate, are saved in [player_types.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/player_types.csv) and [player_types_by_contest.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/player_types_by_contest.csv). Every portfolio’s shares sum to 100%. These describe historical roles and source salary tiers, not a fitted preferred-player rule.

## Named selections: why the observed scores differed

The following cases were selected from large exposure differences, not from a search for winners. “Selected-price residual” subtracts a salary-only model trained on earlier selected player contexts, while “contribution” averages exposure difference multiplied by that residual. Multiplying separate averages will not reproduce the contribution because exposure changes from slate to slate. Each contribution is a piece of the full eight-player comparison; it is not money earned by that player. [named_player_choices.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/named_player_choices.csv) · `selected_residual,selected_residual_contribution,actual_minutes,actual_usage,gap_*`; [model_receipts.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/model_receipts.json).

| Peer | Player | Dates | Exposure %, peer/you | Mean salary | Prior → actual minutes | Prior → actual usage % | Mean source points | Mean selected-price residual | Exposure-weighted residual contribution |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| bpcologna | Julian Strawther | 3 | 27.1/8.7 | $3,633 | 16.4 → 29.7 | 15.8 → 26.1 | 30.3 | 12.6 | +3.67 |
| bpcologna | Cam Thomas | 6 | 25.1/6.9 | $6,317 | 27.1 → 24.1 | 30.4 → 27.1 | 20.0 | -11.1 | -2.30 |
| youdacao | Herbert Jones | 6 | 41.3/7.4 | $4,850 | 28.7 → 31.3 | 16.3 → 15.0 | 22.3 | -1.8 | +0.21 |
| youdacao | Jusuf Nurkic | 5 | 14.7/47.7 | $4,800 | 19.3 → 25.7 | 23.2 → 22.6 | 31.6 | 7.7 | -2.34 |
| cheddabisque | Cam Thomas | 4 | 36.2/2.7 | $7,075 | 30.5 → 24.9 | 32.2 → 26.0 | 21.4 | -13.2 | -4.23 |


**Strawther / BPCologna.** Prior minutes were 16.4, realized minutes 29.7; prior usage was 15.8%, realized usage 26.1%. His prior dominant category was spot-up, covering 29.3% of his prior possessions. On these three dates his mean salary was $3,633 and source score 30.3. The extra exposure contributed +3.67 points against the selected-price benchmark. The raw +6.21-point contribution includes +1.72 from two-point scoring, +1.32 free throws, +1.12 rebounds and +0.87 assists. These observed changes support a minutes-and-opportunity explanation of this example; the archive does not show whether injury news, a starting assignment or another forecast led BPCologna to select him.

**Jones / youdacao.** Prior usage was only 16.3%, with 28.7 prior minutes; realized minutes were 31.3 and realized usage 15.0%. Prior spot-up share was 46.8%, and the example opponents averaged rank 23.3/30 in that prior-season category, where a higher rank allows greater efficiency. Extra exposure added +8.71 raw points: +2.45 from threes, +2.20 two-point scoring, +1.58 rebounds, +1.18 assists and +1.21 steals. The selected-price residual contribution was only +0.21, and his unweighted mean residual was −1.83. This is a concrete low-usage selection with several scoring sources; the large raw contribution alone overstates a price-adjusted advantage.

**Nurkic / youdacao.** You had 47.7% exposure versus his 14.7% on five union-selected dates. Realized minutes were 25.7 versus a prior 19.3, and mean points were 31.6 at a mean $4,800 salary. His prior dominant category was post-up. Youdacao’s lower exposure contributed −2.34 points against the selected-price benchmark. The raw −11.05-point difference included −4.87 rebounds and −1.99 assists. Your selection was favorable in this particular comparison.

**Thomas / BPCologna and cheddabisque.** The peers overweighted this prior pick-and-roll ball handler. On cheddabisque’s four example dates, prior minutes/usage were 30.5/32.2%, falling to realized 24.9/26.0%; points averaged 21.4 at a $7,075 salary. His extra exposure contributed −4.23 selected-price residual points. BPCologna’s six-date example also had a negative contribution, −2.30. High prior usage can identify opportunity while still producing a bad pick when realized minutes, production or price disappoint.

Component arithmetic is used only where the historical NBA event is unique and the source player score exactly agrees with the complete NBA scoring box. All examples above have reconciled component dates; unresolved entries remain in full source-score accounting with a separately displayed unexplained remainder. Actual minutes, usage and scoring components are outcomes, never model predictors.

## Heldout portfolio selection comparisons

For each same-contest pair, player exposures sum to eight, peer-minus-your exposure differences sum to zero, and their weighted source scores reproduce the mean lineup score difference. The primary residual subtracts a frozen 2024–25 salary model trained on source-player listings, including source zero scores. That candidate archive is not a timestamped list of active players, so a second frozen benchmark trains on the earlier selected union. Both comparisons are price-aware research measures; neither certifies tournament skill or recreates a private projection system. [paired_contests.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/paired_contests.csv) · `raw_gap,residual_gap,selected_residual_gap,unmodeled_raw_contribution`; [selection_tests.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/selection_tests.csv).

| Peer | All shared contests/dates | Fee≥$150 contests/dates | Raw points gap | Primary residual gap | Date-bootstrap95% interval | Holm16 p | Selected-price sensitivity gap | Supported residual dates |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 3rd_and_schlong | 42/37 | 1/1 | -6.03 | -6.29 | [-12.00, -0.95] | 0.550 | -5.65 | 36 |
| bpcologna | 92/59 | 4/4 | +1.07 | +1.14 | [-2.53, +4.70] | 1.000 | +1.38 | 56 |
| cheddabisque | 38/28 | 2/2 | -3.62 | -2.95 | [-10.59, +4.56] | 1.000 | -2.60 | 27 |
| dacoltz | 43/29 | 3/3 | -1.56 | -1.22 | [-8.95, +6.70] | 1.000 | -1.38 | 28 |
| gregr1224 | 28/25 | 0/0 | -2.01 | -1.47 | [-6.01, +2.98] | 1.000 | -1.12 | 22 |
| hixx | 68/45 | 3/3 | -6.15 | -4.08 | [-8.76, +0.31] | 1.000 | -4.41 | 44 |
| jpm11 | 37/28 | 2/2 | -2.71 | -1.77 | [-8.75, +4.39] | 1.000 | -1.29 | 27 |
| jsn77 | 19/15 | 0/0 | -11.83 | -10.72 | [-22.68, +1.18] | 1.000 | -11.25 | 13 |
| magneto999 | 11/11 | 0/0 | -13.26 | -12.67 | [-26.29, -0.49] | 1.000 | -11.77 | 11 |
| mazwa | 53/34 | 3/3 | -1.12 | -0.57 | [-8.03, +7.20] | 1.000 | -1.03 | 29 |
| needlunchmoney | 8/5 | 1/1 | -8.15 | -9.16 | [-17.79, +0.95] | 1.000 | -8.12 | 5 |
| nerdytenor | 17/16 | 1/1 | -7.21 | -7.19 | [-18.06, +2.41] | 1.000 | -5.91 | 15 |
| oxenduck | 91/58 | 5/5 | +3.45 | +4.15 | [+0.33, +7.95] | 0.550 | +4.08 | 53 |
| papagates | 41/25 | 3/3 | -7.48 | -6.82 | [-16.66, +2.80] | 1.000 | -6.16 | 23 |
| youdacao | 26/18 | 3/3 | +5.40 | +7.42 | [-2.72, +20.13] | 1.000 | +7.02 | 17 |
| zokin | 14/11 | 2/2 | -9.84 | -9.89 | [-25.13, +3.90] | 1.000 | -9.53 | 10 |


These tests combine fee lanes. They cannot establish a high-stakes-only selection edge with just zero to five high-stakes contexts per peer. A positive mean with a wide interval is an observed result, not a replicated advantage. Every planned peer is retained in the correction family, including unsupported or sparse cells. The selected-price sensitivity also has no Holm-corrected significant peer result. Calendar-week sensitivity remains null after its own complete correction family. Mean points are distinct from tournament tail outcomes and ROI.

## Six reasons tested as prior information

The models were fixed research specifications trained on 2024–25, then evaluated in 2025–26. Each candidate is compared with a salary-only model trained and tested on exactly the same feature-qualified rows. Results below use unique player-games selected by the corrected older-season cohort; repeated contest listings and entries do not multiply the sample. Positive improvement means lower absolute prediction error. Each block has its own data mask. [factor_backtests.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/factor_backtests.csv) · `n,days,improvement,holm_p,verified_improvement,verified_holm_p`; [factor_predictions.parquet](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/factor_predictions.parquet) and [model_receipts.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/model_receipts.json).

| Block | Player-games/dates | MAE improvement, points | Holm6 p | Score-reconciled sensitivity improvement | Sensitivity Holm6 p |
| --- | --- | --- | --- | --- | --- |
| Prior minutes, usage, attempts and points/minute | 3,252/55 | +0.001 | 1.000 | +0.001 | 1.000 |
| Prior shot mix × opponent attempt allowances | 2,108/49 | -0.025 | 1.000 | -0.023 | 1.000 |
| Prior pace, efficiency and positional allowances | 2,952/50 | +0.005 | 1.000 | +0.005 | 1.000 |
| Prior rebounds, assists, steals, blocks, turnovers | 3,252/55 | +0.025 | 1.000 | +0.025 | 1.000 |
| Salary relative to prior production/opportunity | 3,252/55 | +0.017 | 1.000 | +0.018 | 1.000 |
| Prior minutes, usage and starter-rate changes | 3,252/55 | +0.019 | 1.000 | +0.020 | 1.000 |


These are incremental prediction tests on the peers’ selected population. They do not establish that a peer used a block, nor that the block distinguishes his choices from yours. The shot block tests the archived attempt-allowance fit and diet features; it does not reproduce your exact usage-plus-advantage screen, play-type judgment, injury interpretation or live minutes forecast. None of the six tested blocks establishes an incremental gain in this specification. Small null effects do not prove that individual players lack useful factors.

## Gaps worth addressing in the NBA process

The observed gaps are specific enough to track, but they do not justify importing a peer’s whole player pool or changing production weights.

- **Separate baseline usage from the forecast of tonight’s role.** Strawther’s successful example involved a large realized minutes/usage change despite modest prior usage. Archive the pre-lock minutes, starter and role forecast with its timestamp so that success can be credited to a forecast rather than discovered after the game.
- **Keep lower-usage paths to ceiling in the candidate review.** Jones’s example combined minutes, shooting, rebounds, assists and steals. A usage filter alone can miss that profile. His price-adjusted gain here was small, so the example supports a candidate category rather than a proven added weight.
- **Review concentrated value selections by date and uncertainty.** Your substantial exposures to Martin, Small and Jackson explain several peer differences. Some of your value selections were favorable, including the Nurkic comparison, and peers’ Thomas preferences sometimes lost. The useful review is whether your pre-lock minutes and opportunity estimates justified each concentrated exposure.
- **Retain your usage-plus-shot thesis as a testable process.** The peers span ball handlers, spot-up players, cutters and rebound/assist centers, and their average usage often resembles yours. The present comparison does not establish that your changed 2025–26 process was incorrect. Record the exact advantage calculation, opponent exposure, forecast minutes, price, availability assumptions and late changes; evaluate those saved decisions prospectively.

Frozen older-season top-five overweighted player names and their later readback are also saved, including missing later opportunities, in [frozen_older_player_preferences.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/frozen_older_player_preferences.csv) and [older_player_preference_readback.csv](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/older_player_preference_readback.csv). They were chosen from older exposure alone, not later winners; they are descriptive continuity checks, not an independent sixteen-player significance screen.

## Source audit and reproducibility

The shared team map omitted OKC. Correcting it expanded accepted source portfolios and changed the 2024–25 success screen. Original peers remain labeled as original comparisons; the corrected screen adds 3rd_and_schlong, cheddabisque, jsn77, magneto999, needlunchmoney and zokin. BPCologna and youdacao are requested benchmarks. The earlier construction report is preserved as a pre-correction vintage with links into its archived data. [Corrected screen](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peers/corrected_success_screen.json); [older report](/Users/rsbathla/Downloads/dfs/docs/NBA_PEER_PLAY_REVIEW_2026-10-02.md).

The player audit joined 23,378 source contexts to historical NBA appearances. It flagged 21 source team discrepancies and 67 source/box point discrepancies. Historical identities require a unique NBA game for the source event. Opponent-dependent features remain missing for unresolved events. Flags preserve source facts; they do not rewrite archived scores or infer injury news. [player_source_reconciliation.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/player_source_reconciliation.json).

The primary price model uses 12,355 unique earlier price contexts through 2025-05-14, with salary support $3,000–$12,900. Its heldout source-pool MAE is 8.45 points and bias -0.56; these describe the broad listed-player pool, not calibration for active selected players. History-enhanced training is limited by the separate NBA frame, whose older year stops on 2025-03-10; later features stop on 2026-04-12. Raw source-score accounting extends beyond that feature window. Unsupported salaries remain unmodeled, with full raw contributions retained. [price_calibration.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/price_calibration.json); [model_receipts.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/model_receipts.json).

Source identity and owner counts/score multisets are anchored to the actual personal contest ledger. Competitor outcomes remain reported source player/portfolio points, not independently certified individual DK scores or audited account profit. Disputed field sizes do not certify ownership or ranks. Injury news, active-player lists, pre-lock projections and private reasoning are not recovered. No whole-career claim is made. [Accepted opening-night source](https://dh5nxc6yx3kwy.cloudfront.net/contests/nba/20251021/183157061/data/) independently reproduces 22 entries/176 slots for you, BPCologna and youdacao. [source_receipts.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/source_receipts.json); [method audit](/Users/rsbathla/Downloads/dfs/docs/NBA_PEER_SELECTION_METHOD_AUDIT_2026-10-02.md); [youdacao source audit](/Users/rsbathla/Downloads/dfs/docs/NBA_YOUDACAO_SOURCE_AUDIT_2026-10-02.md).

Reproduce with `peer_player_selection.py` or use `--from-artifacts` only when its saved input fingerprint still matches. The NBA integration gate checks raw source hashes, eight-slot conservation, score/salary closure, source-discrepancy indicators, component remainders, prior-year play-type vintage, strictly earlier model training and complete correction families. Known-bad tests cover each failure class. [Study code](/Users/rsbathla/Downloads/dfs/nba/analytics/peer_player_selection.py); [tests](/Users/rsbathla/Downloads/dfs/nba/analytics/test_peer_player_selection.py).

Validation: **55 targeted tests passed**, including known-bad omission, identity, chronology, scoring, missingness and family controls. Three isolated guard-removal experiments reject their bad fixtures with the guard present and pass after removing only that guard; production code remains intact. [Removal evidence](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_selection/guard_removal_evidence.json).

Both the NBA integration audit and the Fantasy repository’s required `integration_audit.py --strict` completed with exit0. Passing these scoped research checks does not certify the separately blocked full construction corpus.
