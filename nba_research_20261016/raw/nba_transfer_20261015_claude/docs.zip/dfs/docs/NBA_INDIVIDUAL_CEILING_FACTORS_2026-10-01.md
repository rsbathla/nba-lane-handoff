# Individual NBA ceiling factors — October 1, 2026

## Player observations

Each comparison below uses only the named player's games. A condition means the feature is above that player's own earlier-sample median; the threshold is then frozen for later games. A ceiling game exceeds the player's strictly prior-20-game DraftKings p85, with at least 20 earlier current-season appearances. This is a recent personal ceiling, not a fixed 15% full-season label.

| Player and factor | Availability sample | Earlier ceiling games: condition on / off | Later ceiling games: condition on / off | Evidence |
|---|---|---|---|---|
| Kyle Filipowski — pull-up fit | All availability states | 8/22 (36.4%) / 1/23 (4.3%) | 7/15 (46.7%) / 3/15 (20.0%) | Positive direction persisted. Earlier p=.0135; later directional p=.1225. A candidate, not a statistically confirmed effect. |
| Keldon Johnson — faster prior pace | Intact rotation | 5/14 (35.7%) / 0/14 | 2/11 (18.2%) / 0/6 | Positive direction persisted. Earlier p=.0407; later directional p=.4044. Small event counts leave substantial uncertainty. |
| Jalen Brunson — opponent under-10-foot attempt allowance | All availability states | 0/24 / 8/25 (32.0%) | 4/15 (26.7%) / 2/17 (11.8%) | Earlier negative association passed correction over his 11 factors (q=.0443), then reversed direction. |
| Jaren Jackson Jr. — higher prior minutes | All availability states | 0/23 / 11/23 (47.8%) | 0/4 / no observations | Earlier negative association passed correction over his 11 factors (q=.0034). No later comparison group; unresolved rather than disproven. |

These examples were selected for illustration after examining the complete table. They are marginal associations, not causal explanations or current roster/health claims. Zero observed ceiling games does not imply zero underlying probability. In particular, Filipowski's fit threshold is 1.3505 in the saved fit units: an above-own-median matchup, not a claim that he is a high-volume pull-up specialist.

All players' support counts are in [player_coverage.csv](../nba/analytics/data/research_individual/player_coverage.csv); all 3,850 player-factor rows, including negative and unsupported tests, are in [player_factors.csv](../nba/analytics/data/research_individual/player_factors.csv). No player was selected using later performance.

## What was tested separately for each player

The repaired research frame and preceding intact-rotation study were extended. The earlier top15 study already contained individual tests, but its game universe and shot data were explicitly qualified; this run uses the repaired all-regular-season research path.

The development sample ends January 15, 2026 and includes the available 2024–25 history. Validation starts January 16 and ends April 12, 2026. Each eligible player has separate thresholds and effects for 11 factors: catch-and-shoot, pull-up and under-10-foot fit; each corresponding opponent attempt allowance per 100; prior usage; prior minutes; both-team prior pace; positional fantasy allowance; and defensive points allowance.

Fit combines the player's prior shot share and the opponent's prior attempt allowance. Testing opponent allowance separately helps distinguish a matchup response from a change in the player's own shot mix. Current-game shots, usage and minutes never become model predictors.

The intact-rotation condition is exactly the preceding pooled study's retrospective definition: at least four other established teammates, each averaging at least 20 minutes over prior appearances, are represented in the same-team participation panel and none is absent. The larger all-availability sample is a separate sensitivity, not a replacement for the intact question.

## Individual inference and support

| Stage | Intact rotation | All availability states |
|---|---:|---:|
| Players with any eligible history | 512 | 527 |
| Total eligible appearances | 6,673 | 22,894 |
| Median appearances per player across both periods | 10 | 45 |
| Players with at least 20 development games | 41 | 309 |
| Declared player-factor rows | 451 | 3,399 |
| Rows meeting development comparison support | 450 | 3,387 |
| Initial p<.05 associations, either direction | 8 | 96 |
| Initial positive p<.05 associations | 2 | 53 |
| Associations passing correction over that player's 11 factors | 0 | 2 |
| Associations passing correction over the complete search | 0 | 0 |
| Initial candidates with adequate later support | 2 | 58 |
| Adequately supported candidates retaining their direction | 1 | 32 |
| Candidates passing later directional p<.05 | 0 | 0 |

Development requires at least 8 games on each side; validation requires at least 5 on each side and 6 calendar weeks for dependence-aware inference. These are minimum support rules, not assurances of adequate statistical power. Unsupported tests stay in the declared family with p=1, and their support flag remains false.

Each comparison's primary p-value is the larger of the Fisher exact p-value and a calendar-week clustered difference-of-means p-value. Intervals preserve zero-cell uncertainty by taking the envelope of the clustered interval and a Wilson/Newcombe difference interval. Significance requires agreement between the count-based and dependence checks.

Multiplicity is shown both within each individual player and across the complete search. This does not average players' effects together. It accounts for the number of opportunities to select an apparently significant result. Replication evaluates all 104 initial p<.05 candidates in their earlier-selected direction, retains unsupported candidates with p=1, and corrects over that candidate family. None passes even the unadjusted later directional screen under the stated inference rule. The same zero-replication result holds using the simpler one-sided Fisher test alone among the 60 candidates with adequate later support, before any replication correction.

## Models that allow different player responses

The forecast comparison uses shared prior player-history, environment and shot predictors plus player intercepts as its reference. Personal models then add distinct coefficients for each player's three shot fits or all 11 factors. Positive effects for one player and negative effects for another are allowed. Fixed ridge penalties shrink noisy individual slopes; scaling choices .5 and 1 are research specifications, not learned production weights. No later-game tuning selected the penalties.

The evaluation includes only players with at least 20 earlier games: 421 later intact-rotation appearances across 37 players, and 6,671 later all-availability appearances across 275 players. Every model predicts identical rows within each cohort.

| Comparison, stronger of the two shrinkage settings | Reference Brier | Personal Brier | Change |
|---|---:|---:|---|
| Three personal shot-fit slopes, intact rotation | .129698 | .137877 | Worse |
| Three personal shot-fit slopes, all availability | .156982 | .168470 | Worse |
| All 11 personal slopes, intact rotation | .129698 | .154681 | Worse |
| All 11 personal slopes, all availability | .156982 | .189122 | Worse |

All eight cohort/model comparisons worsened held-out Brier under the tested settings; their week-clustered comparisons pass the eight-test correction in the negative direction. Per-player forecast comparisons are also exported: 10 nominal positive improvements in the larger sample, zero surviving the full player/model correction; none in the intact subset. These results indicate overfitting in these specifications, not that every possible personalized model must fail.

A synthetic positive control creates equal and opposite player-specific effects that cancel in the pool. The same personal-slope machinery recovers both effects and beats the shared model. This verifies that the implementation can detect the user's proposed heterogeneity when the data supports it.

## Interpretation and limits

The user's concern is valid: a pooled null cannot establish that individual effects are zero. The earlier pooled conclusion applies to a common multiplier. The new individual tests reveal specific candidates, but do not yet validate a repeatable personal factor under the stated criteria. Filipowski's pull-up fit and Johnson's pace association retain a positive direction and remain candidates; small, selected samples do not justify automatic scoring rules.

There is especially little intact-rotation history per person. Most players are unresolved, and the lack of significance cannot be used to dismiss their basketball mechanisms. The next useful evidence is additional dated games evaluated against frozen candidate definitions, not a guarantee that every player must yield significance after searching enough factors.

The participation cohort remains retrospective: later reappearance may establish stint brackets, and terminal absences can be missed. This does not establish who was known available before lock. Different seasons, roles and teams can confound a marginal within-player split; the adjusted forecast comparison is a separate check. Weekly clustering does not remove every longer-range dependency. The median splits and linear personal deviations do not exhaust nonlinear combinations, individual defender assignments or unavailable injury timing. Prior studies have examined this historical season, so chronological validation here is not a pristine new-season confirmatory experiment.

No production score, weight, injury model or lineup rule changed. Salary, ownership, closing markets, daily Synergy and NFL layers are excluded with reasons in the NBA deliverable manifest.

## Reproduction and audit

Run `python nba/analytics/individual_ceiling_study.py`; audit saved results with `python nba/analytics/individual_ceiling_study.py --audit`. Use the runtime documented in the NBA analytics README. The new gate is included in `next_research_audit.py` and therefore the NBA integration gate.

`data/research_individual/summary.json` records source hashes, method, chronology, support and model specifications. `forecast_comparisons.csv` gives the full eight-comparison family; `player_forecast_comparisons.csv` retains individual forecast checks. Source frame SHA256: `a57949a4efcc5cc930a3a6bfe0114631ba4f6c3488109f439802ec83f99f71ad`.

Regression checks cover future-score/feature mutations, fixed personal thresholds, missing comparison groups, zero-cell uncertainty, an opposite-effects positive control, complete correction families, paired-error signs and rejection of a fabricated replication claim. Saved numerical thresholds use round-trip CSV parsing so floating-point rounding cannot move tied observations across a split. The artifact audit independently reconstructs each saved player's condition counts and inference, verifies support labels, cohort pairing, source hashes, target identity and Brier accounting.
