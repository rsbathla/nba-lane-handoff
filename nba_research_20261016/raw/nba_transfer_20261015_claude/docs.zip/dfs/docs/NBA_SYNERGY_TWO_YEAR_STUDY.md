# NBA Synergy play-type study — honest two-year test

> **September 22 audit update:** This document is a historical record. Current implementation status, corrected numerical results and source-quality limitations are in [NBA_RECONCILIATION_AUDIT_2026-09-22.md](NBA_RECONCILIATION_AUDIT_2026-09-22.md). Historical construction prescriptions are provisional; prior-season player triggers are not live signals.

*Built 2026-08-06 from the official NBA Stats Synergy endpoint. Seasons:
2024-25 and 2025-26 regular season. Player offense + team defense, all 11
public play types. DK outcome truth: committed as-of 2025-26 lever frame.*

## Question

Does matching a player's primary Synergy play type to an opponent that is
weak against that play type predict personal DK ceiling games?

Play types pulled: isolation, transition, pick-and-roll ball handler,
pick-and-roll roll man, post-up, spot-up, handoff, cut, off-screen,
offensive rebound/putback, and miscellaneous.

## The honest design

The NBA endpoint exposes season aggregates; it does not expose historical
daily snapshots or honor date-bounded filters. Applying a final-season rank
back to earlier games is lookahead.

The primary test therefore freezes information available before 2025-26:

1. Player primary play type = highest-possession 2024-25 category, minimum
   50 possessions.
2. Opponent weakness = 2024-25 defensive PPP allowed rank 23-30 in that
   category.
3. Join those frozen features to 2025-26 game-level DK ceiling outcomes.
4. Compare on/off ceiling rates; then adjust for existing as-of opportunity,
   DvP, defense, pace, Vegas, rest and home factors.

House guardrails apply: n<10 suppressed, n<50 flagged, multiple play-type
tests corrected with Benjamini-Hochberg. Player-specific conclusions are not
carried year-ahead at strength.

## Headline verdict

**The broad Synergy matchup thesis fails year-ahead.**

| test | on | off | lift | significance |
|---|---:|---:|---:|---:|
| Honest 2024-25 profile/defense → 2025-26 outcomes | 28.2% (n=4,074) | 28.7% (n=11,200) | **0.982×** | Fisher p=.544 |
| Adjusted logistic model | — | — | OR **0.973** | p=.501 |
| 2025-26 final snapshot applied to same season | 32.3% | 28.6% | **1.127×** | p=1.4e-6; LOOKAHEAD |

The same-season snapshot recreates the attractive historical signal, while
the preseason-knowable version does not. This explains why the earlier
Cowork result looked like 1.18×: season-end opponent ranks contain information
from after each game.

## Honest year-ahead results by primary play type

| play type | on n | off n | on | off | lift | raw p | BH p | verdict |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| Offensive rebound | 81 | 242 | 42.0% | 27.7% | **1.516×** | .019 | .076 | candidate, not armed |
| Isolation | 33 | 76 | 30.3% | 22.4% | 1.355× | .469 | .537 | flagged n<50 |
| P&R roll man | 271 | 660 | 33.9% | 26.8% | **1.266×** | .032 | .085 | candidate, not armed |
| Cut | 228 | 639 | 29.8% | 26.9% | 1.108× | .438 | .537 | neutral |
| Transition | 346 | 952 | 30.1% | 27.8% | 1.080× | .444 | .537 | neutral |
| Spot-up | 2,282 | 6,286 | 28.2% | 29.5% | 0.955× | .237 | .474 | no edge |
| Post-up | 59 | 174 | 28.8% | 32.8% | 0.880× | .630 | .630 | no edge |
| P&R ball handler | 770 | 2,145 | 23.5% | 28.1% | **0.836×** | .014 | .076 | fade candidate, not armed |
| Off-screen | 4 | 26 | — | — | — | — | — | suppressed n<10 |

None passes the predeclared 5% multiple-testing gate. The three directional
tails survive player fixed-effect checks:

- Offensive rebound: adjusted player-FE OR 1.98, p=.016; leave-one-player-out
  lift range 1.41-1.59 (7 usable players).
- Roll man: adjusted player-FE OR 1.40, p=.036; leave-one-player-out lift
  range 1.22-1.31 (22 players).
- Ball handler: adjusted player-FE OR 0.78, p=.012; leave-one-player-out lift
  range 0.82-0.85 (71 players).

These are exploratory confirmations, not new independent tests, so they do
not override the BH verdict.

## What actually persists

- **Player archetype:** 72.8% of 301 players with ≥50 possessions in both
  seasons retained the same primary Synergy category.
- **Opponent weakness:** unstable. Defensive-rank y/y correlations include
  transition .464, offensive rebound .462, cut .463, handoff .337,
  ball-handler .191, post-up .215, isolation .050, roll-man .041,
  spot-up .035 and off-screen -.078.

That decomposition matters: the player trait is reasonably portable, but
last year's opponent rank usually is not. A live edge must use **current,
strictly as-of opponent defense**, not prior-season or final-season ranks.

## 2026-27 protocol

1. Preserve returning players' primary play-type profile as a weak October
   prior; reset team movers and major role changes.
2. Snapshot all 11 Synergy player/team tables daily. Each snapshot is
   cumulative through the prior day and must be stored by date—never overwrite.
3. Build opponent ranks from the latest pre-lock snapshot; shift-1 by design.
4. Initially monitor only the three directional candidates: offensive
   rebound, roll man, and ball handler. Spot-up and transition are not armed.
5. Suppress n<10, flag n<50. Re-grade monthly and require walk-forward
   replication plus multiple-testing control before changing exposures.
6. Use the result as one count-based board flag alongside opportunity and
   construction—not as a projection replacement.

Daily snapshot example:

```powershell
python nba/analytics/pull_synergy.py --seasons 2026-27 `
  --out-dir nba/analytics/data/synergy/snapshots/2026-10-20 --refresh
```

## Artifacts

- Puller: `nba/analytics/pull_synergy.py`
- Test: `nba/analytics/synergy_yearahead.py`
- Raw aggregates: `nba/analytics/data/synergy/` (44 CSVs)
- Honest joined game frame: `nba/analytics/data/synergy_yearahead_games_2526.csv`
- Per-type results: `nba/analytics/data/synergy_yearahead_by_type.csv`

Source pages identify the tables as provided by Synergy; the pull uses the
same official NBA Stats `synergyplaytypes` endpoint behind those pages.
