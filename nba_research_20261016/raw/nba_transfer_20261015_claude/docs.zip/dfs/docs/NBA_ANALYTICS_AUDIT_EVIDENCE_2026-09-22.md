# NBA analytics read-only audit — 2026-09-22

Scope: `/Users/rsbathla/Downloads/dfs/nba/analytics/{build_season,trigger_analysis,merge_tracking,slate_board,synergy_yearahead,run_yearahead}.py`, persisted frames/triggers/ledger and `core/lever_tests.py`, compared with `docs/NBA_ANALYTICS_NOTES.md` and `docs/NBA_SYNERGY_TWO_YEAR_STUDY.md`. No canonical files edited. All line references below refer to pre-repair sources. Runtime `/Users/rsbathla/Downloads/Fantasy/.venv/bin/python` contains numpy/pandas/scipy/pyarrow/openpyxl; statsmodels absent.

## FINDINGS — data/code establishes

### P1 — Full-season player shot diet leaks into the as-of flags and walk-forward

`nba/analytics/merge_tracking.py:55-58` fills missing categories with zero and computes `groupby('pid')[c].transform('mean')`, then uses that FULL-season mean to determine `fav_cat` for every game. Opponent ranks are shifted, player category is not. This contradicts merge_tracking docstring lines 4-8, analytics notes lines 117, 141, 167-181, and ledger descriptions claiming clean pre-lock flags. A tomorrow-data mutation can change yesterday's favorite category.

Nonmutating probe: read each committed frame; for `cats=['cs','pu','lt10']` calculate `groupby('pid')[c].transform(lambda s:s.shift().expanding(min_periods=1).mean())`, choose max in the same category order, and select the existing `strank_<category>` column. Count changes only where hit and historical diet exist.

* 2024-25: 975/15,177 labeled rows have a different category (115 players); 405 flags change.
* 2025-26: 1,389/20,638 labeled rows differ (120 players); 575 flags change.
* Whole-frame league lift happens to remain similar: 2024-25 existing on 1,126/3,466 vs off 3,371/11,711 = 1.1286x; as-of on 1,128/3,463 vs off 3,369/11,714 = 1.1326x. 2025-26 existing 1,559/4,792 vs 4,585/15,846 = 1.1244x; as-of 1,560/4,783 vs 4,584/15,855 = 1.1281x.
* Running existing `trigger_analysis.walk_forward` on labeled 25-26 rows, all 14 DEFAULT_AXES, eval_from=min(labeled.date)+8 weeks=2025-12-31 reproduces notes exactly: 28.2/33.4/36.7/38.1% for 0/1/2/3+ (n=15,191). Replacing ONLY diet flag yields 28.1/33.5/36.7/37.5%.

Recommended fix/test: chronologically sorted shift-1 player diet; explicit no-history/unknown; guard missing tracking dates instead of zero-fill; compare features on a prefix vs same prefix after future rows are added. Preserve legacy evidence before rebuilding. This numerical sensitivity does not prove deployability: other inputs lack lock timestamps.

### P1 — Slate board falsely activates every absence trigger from any nonempty out list

`slate_board.py:53-54`: `(active if outs else pending).append(ax)` for any of f_key_out, f_2key_out, f_samepos, f_new_starter. A single unrelated out-player arms every qualifying player's two-key-out and same-position triggers. No teammate, count, rotation status, or position matching occurs. A pure synthetic fixture with Player A/B on separate teams and one unrelated out name reproduces the false activation.

Recommended test: unrelated player's absence activates no trigger; one qualifying teammate cannot activate f_2key_out; same-position vacancy needs evidence; unknown context stays pending. Live use should consume dated pid-based factors and enforce trigger training vintage, rather than derive current conditions from old games.

### P1/P2 — Board does not implement the documented trigger battery

`build_season.py:136-140` excludes dvp_rank/wd_rank from saved frame; both committed frames lack those columns. `slate_board.py:37-41` consequently sets both state maps empty; lookups at lines 18-19 default zero, silently declaring these axes inactive. Six further axes have no evaluation branch: f_fav_shot_type, f_opp_wo_soft, f_pace_up, f_itt118, f_b2b, f_rest3. `--itt` is parsed but unused. Eight of 14 stored axes / 183 of 454 stored trigger rows are ineffective. Remaining hot/min flags read previous game's PREgame state, missing that game's result. Opponent keys also use BDB full names vs common DK tricodes without normalization.

Tests: exhaustive axis disposition (every trained axis either evaluated with evidence or explicitly pending); missing raw ranks must not be silently false; dated current states; no old-season player triggers; empty rows must not crash `sort_values('n_active')` at line 69. Root/worker owns board repair.

### P1 qualification — Absence factors are retrospective participation proxies, not demonstrated pre-lock data

`build_season.py:33` removes MIN<1 before `rosters` at line 61, then declares out when prior rotation candidate does not occur in current game's filtered participant set (lines 68-75). This is not an injury-report snapshot, can treat DNP/CD, trades, or short appearances as out, and ceases remembering long absences after 3 team games. No reporting timestamp exists. CLOSING SPREAD/TOTAL at lines 129-133 may also occur after DFS slate lock for later games; there is no timestamp to establish knowledge at entry lock. Therefore module line 3 'All features as-of — zero lookahead' and notes' 'deployment-grade' are stronger than evidence.

Raw probe `/Users/rsbathla/Downloads/04-12-2026-nba-season-player-feed.xlsx`, Regular rows: 25,217 rows, 178 MIN<1, 3 MIN==0; dates 2025-10-21 through 2026-04-12. Recreating exact key-candidate loop produces 2,022 absence records, FIVE of which were recorded as actual sub-minute participants in the raw feed:

| player | date | game id | min | prior min_l10 |
|---|---|---:|---:|---:|
| Dean Wade | 2025-11-05 | 22500171 | .633333 | 23.1000 |
| Ethan Thompson | 2026-01-02 | 22500476 | .616667 | 23.9133 |
| Mikal Bridges | 2026-04-12 | 22501190 | .383333 | 32.4317 |
| Justin Edwards | 2026-03-30 | 22501091 | .600000 | 24.2233 |
| Deni Avdija | 2026-02-22 | 22500826 | .983333 | 30.4067 |

Fix participation set independently of outcome minimum; label historical factors as proxies; archive dated injury/market inputs prospectively. Do not rebrand this as verified pre-lock backtesting. Changing research absence definition is a semantic decision for root/user, not resolved here.

### P2 — Synergy profiles silently choose one team stint and tie-breaking depends on file order

`synergy_yearahead.py:33-37` uses unsorted glob; `profiles:41-48` filters individual rows POSS>=50, sorts PLAYER_ID/POSS, drops duplicate PLAYER_ID. Raw 2024-25 has 100 duplicate (PLAYER_ID,PLAY_TYPE) pairs; 2025-26 has 82, representing team stints. The documented highest-possession season category instead selects maximum individual stint. No aggregation, deterministic secondary category, or tie policy exists.

Quantitative sensitivity (not proposed new weights): sum POSS and PTS by PLAYER_ID/PLAYER_NAME/PLAY_TYPE, then choose max. For 24-25, five already-eligible players change category: Jonas Valanciunas roll man129 -> post-up183, Caris LeVert spot-up102 -> ball-handler135, Kyle Kuzma transition143 -> ball-handler172, Shake Milton spot-up59 -> ball-handler81, Quentin Grimes spot-up156 -> ball-handler190; two players become eligible (pids1628971/1630200). These seven affect 344 labeled 25-26 rows, change 103 soft flags. Overall honest result becomes on n=4,103/off n=11,294, lift .980x, p=.493. Negative broad verdict survives.

Pure file-order probe: reverse the list returned by glob, concatenate the SAME raw rows, use unchanged profiles sorting. Adem Bona (OffRebound63/PRRollMan63) and Lauri Markkanen (OffScreen150/Spotup150) change primary type. Honest broad lift .982 -> .979 (n_on4,081/off11,193, p=.4664). OffRebound q .075523 -> .119090; rollman .084651 -> .119090; ballhandler .075523 -> .110008. No candidates become armed.

2025-26 has additional exact ties: Jaime Jaquez Jr Transition319/Spotup319, Craig Porter Jr Spotup88/PRBallHandler88. Existing local profiles return 217/301=72.093% same category, versus documented 72.8% (notes:197; Synergy study:80-81; ledger final row). Reversing only 24-25 order gives215/301. Treat persistence claim as implementation/tie sensitivity, not merely arithmetic typo.

Tests: shuffled input file/row order yields same categories/results; multiple team stints sum before threshold/top selection; either predeclared deterministic ties or explicit tied-category policy. Recommendation aggregate season possessions, deterministic tie policy recorded, then rebuild report; no new scoring weights.

### P2 — Statistical helper returns false perfect significance on degenerate inputs

`core/lever_tests.py:118-135`: hi/lo defined by inclusive terciles can overlap, while permutation tests high vs ALL remaining games, not high vs low; continuous middle tercile incorrectly appears only in perm null. Constant exposure example returns BOTH hi and lo=20, delta=0, p=0 after empty-slice warnings:

```
x=pd.DataFrame({'player_id':[1]*20,'date':range(20),'cond_exposure':[0]*20,'value':range(20)})
own_log(x,1,n_perm=200)
# {'delta_hi_lo':0.,'p_perm':0.,'n':20,'n_hi':20,'n_lo':20}
```

`year_ahead_did:64-85` allows threshold ties to assign every player to lever. Example 30 identical zero-split players in each season returns n_lever30/n_control0, NaN effect/interval, p=0, grade WEAK instead of unpowered:

```
x=pd.DataFrame([dict(player_id=p,season=y,cond_value=1.,base_value=1.,n_cond=10)
                for y in [2024,2025] for p in range(30)])
year_ahead_did(x,2024,2025,n_perm=200)
```

Recommendations: require disjoint nonempty high/low/control groups, finite arrays, unique player-season keys, adequate sample each side; permutation pool should contain exactly actual comparison groups; `p=(extreme+1)/(B+1)` to avoid claiming exact zero from finite random samples. Null/constant/near-tie/continuous-middle/outlier tests. The current helper selftest PASSES despite these known-bad cases; it does not test them. Did not demonstrate that current NBA yearahead verdicts are invalid from this bug; canonical run reproduces all displayed values.

### P2 — Tracking identity guarantees stronger than implementation

`merge_tracking.py:10-12,40-49` promises team/date co-occurrence verification and refusal of silent merge. Actual implementation name-normalizes, drop_duplicates(nname), and prints aggregate match rate, then left joins on pid/date; no team evidence, no ambiguity failure, no merge cardinality validation. Missing categories become zero at55. However measured CURRENT artifacts are clean on major identity concern: no mismapped resolved nba_pid->pid; no duplicate (date,tag,nba_pid); 605/605 expected date/config pairs in24-25,770/770 in25-26. Exactly one unmatched tracking record in24-25 pid1642389; none in25-26. Both frame identity systems already match NBA person_id for all resolved ids. Prefer direct verified ID, explicit unresolved report/coverage gate, fail collision fixtures; do not imply actual current misjoins found.

### P3 — Reproducibility claims/paths

`nba/analytics/README.md` says run_yearahead has /home/claude paths; current run_yearahead lines19-20 are repo-relative and work. `build_season.py:143-145` still hardcodes unavailable /home/claude sample inputs/output. CLI defaults in pull_tracking/trigger_analysis and doc examples use old nba/data or tools/data. Synergy player-FE and leave-one-out claims (study:68-73) have no reproducible implementation in synergy_yearahead.py, and rg found no alternate persisted code for those checks. Report these as unsupported-by-saved-runner, not disproven. No original lost screener metrics revalidated.

## VERIFIED RESULTS TO PRESERVE

* Frames: 19,310 rows/15,177 labeled/551 pids for24-25 (through2025-03-10);25,039 rows/20,638 labeled/582 pids for25-26 (through2026-04-12). Zero duplicate(pid,gid) in either.
* Independently recomputed shift-1 rolling20/min8 p75 and hit from each frame: ZERO mismatch in both seasons.
* Independently calculated DK scores from raw04-12-2026 player XLSX formula PTS+.5*3P+1.25*TOT+1.5*A+2*ST+2*BL-.5*TO+1.5DD+3TD: ALL25,039 matched persisted rows exactly, max difference0.
* Re-ran readout from44 raw Synergy CSVs/current profile semantics: n_on4,074/n_off11,200, lift .982x Fisher p=.5437; subtype rates/q match report; saved game frame15,274 rows equals fresh join, zero missing defense among profiled rows. Broad negative result is robust to tested profile fixes.
* Current run_yearahead: f_fav_shot_type DiD .010,p .597,r-.046,nlev50; wide-open .009,p.665,r.112,nlev49; rest3 .093,p.013,nlev21; all displayed 14-axis results reproduce. Statistical selftest passes but inadequate for known-bad edge cases.

## INFERENCES

Existing pipeline is useful retrospective research, but broad claims of fully deployable pre-lock validation exceed input provenance. Diet leak's correction leaves simple league lift almost unchanged; do not claim it eliminates the historical edge. Board's actual behavior cannot substantiate ranking by the tested 14-axis battery. Synergy broad failure remains the stable conclusion; numerical tails/persistence depend on profile construction.

## ASSUMPTIONS / LIMITS

Nonmutating correction uses expanding prior-shot means with min1 solely to demonstrate leakage sensitivity; root should explicitly decide/record production cold-start rule. No fresh NBA roster facts used here. No corrected absence-based weight estimates, no ownership/salary rules, no new weights proposed. Current statsmodels model/FE numbers not executed (dependency absent). Historical injury/line timestamps absent; cannot retroactively prove knowledge at lock.

## CONFLICTS

All-as-of/deployment-grade claims conflict with full-season diet, realized participation flags, and timestamp-free closing lines. 'No silent joins' claim conflicts with actual merge checks. Stable documented72.8% conflicts with217/301 locally and lacks deterministic tie policy. Current broad Synergy FAILED verdict is corroborated, not contradicted. NFL-specific ADP/environment logic was not applied.

## DECISION POINTS

1. Evidence status: preserve researched factors but label provisional/retrospective until timestamped inputs; recommendation yes. Do not erase historical evidence or pretend corrected source makes old trials prospective.
2. Synergy season profile semantics/ties: aggregate season stints and deterministic tie rule (recommended), or explicitly retain stint-based question and relabel report. No positive weight earned either way.
3. Historical participant proxy: retain clearly qualified for research or rebuild from dated injury snapshots when available (recommended prospective path); do not silently equate participation with availability.
