# Youdacao and player-level NBA source audit — 2026-10-02

## Evidence vintage and scope

This audit inventories exact youdacao coverage and existing player-level sources. It does not define a new analytical threshold, select winners using later outcomes, infer anyone's private process, or alter code. The reported-return and complete-block counts below are the **initial peer-artifact vintage before the independently authorized OKC mapping repair and combined rebuild**. Preserve them as that vintage; the rebuilt parent receipt is authoritative for final post-repair coverage.

Inputs: `nba/analytics/data/research_peers/{raw,normalized}/`, `fetch_receipt.json`, `reported_returns.csv`, `user_season_returns.csv`, the repaired prior-feature frame, the identity bridge, raw official-source archives and local projection/workbook snapshots. This audit uses exact full personal user blocks and their own `lineupCt`; it never attributes mixed-user global build counts to a person or fills an absent player.

All initial table names below refer to the preserved [pre-OKC artifact vintage](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peers/archive/pre_okc_2026-10-02), not the rebuilt root tables. Final coverage and player comparisons are in [the completed selection study](/Users/rsbathla/Downloads/dfs/docs/NBA_PEER_PLAYER_SELECTION_2026-10-02.md).

## Exact accepted reported-return coverage

The initial `reported_returns.csv` has **388 youdacao user-contest rows**, **388 distinct cid values**, **239 distinct date values**, and **41,235 entries**. The exact case-insensitive match returns only lowercase `youdacao`; rereading all corresponding normalized full feeds finds that same exact source spelling. **45** of those accepted rows have `field_verified=True`. These are portfolio-qualified reported source returns; they are not a complete audited account ledger or a claim that all source field denominators are certified. Sources: `reported_returns.csv`, `user`, `cid`, `date`, `entries`, `field_verified`; years shown below.

Every row below was recomputed from `reported_returns.csv` and matched against `user_season_returns.csv` for `contests`, `days`, `entries`, `cost`, `reported_won`, and `reported_net`. The lane definition is the existing runner's fee classification, not a new audit threshold. Distinct dates are counted separately within each lane and cannot be added across lanes.

| Season | Existing fee lane | Contests | Dates | Entries | Reported cost | Reported winnings | Reported net |
|---|---|---:|---:|---:|---:|---:|---:|
| 2019-20 | high_stakes | 3 | 3 | 61 | $33,855.00 | $30,983.00 | $-2,872.00 |
| 2019-20 | lower_fee_MME | 1 | 1 | 150 | $3,000.00 | $1,180.00 | $-1,820.00 |
| 2020-21 | high_stakes | 19 | 19 | 459 | $336,880.00 | $359,112.00 | $22,232.00 |
| 2020-21 | lower_fee_MME | 81 | 60 | 9,647 | $146,825.00 | $449,364.00 | $302,539.00 |
| 2021-22 | high_stakes | 11 | 11 | 279 | $179,655.00 | $177,570.00 | $-2,085.00 |
| 2021-22 | lower_fee_MME | 52 | 42 | 7,105 | $105,175.00 | $90,529.00 | $-14,646.00 |
| 2022-23 | high_stakes | 9 | 9 | 250 | $216,942.00 | $1,258,050.00 | $1,041,108.00 |
| 2022-23 | lower_fee_MME | 60 | 35 | 6,310 | $84,280.00 | $157,819.00 | $73,539.00 |
| 2023-24 | high_stakes | 6 | 6 | 195 | $261,888.00 | $51,200.00 | $-210,688.00 |
| 2023-24 | lower_fee_MME | 83 | 55 | 9,787 | $143,833.00 | $79,494.00 | $-64,339.00 |
| 2024-25 | high_stakes | 4 | 4 | 98 | $103,290.00 | $66,400.00 | $-36,890.00 |
| 2024-25 | lower_fee_MME | 37 | 23 | 4,483 | $66,211.00 | $62,786.00 | $-3,425.00 |
| 2025-26 | high_stakes | 2 | 2 | 61 | $46,176.00 | $25,400.00 | $-20,776.00 |
| 2025-26 | lower_fee_MME | 20 | 14 | 2,350 | $28,750.00 | $12,170.00 | $-16,580.00 |

For the requested current-season comparison, the accepted 2025–26 high-stakes lane is only **two dates**, while the lower-fee lane has **20 contests on 14 dates**. This is a coverage limit, not a determination of whole-season skill. `quarantine.csv` additionally records a youdacao reported-return rejection at **2023-01-12 / cid 140112203**, reason `cap_cost_or_missing_money`; the audit does not reinterpret that combined reason. Contest-level quarantines have `user=all` and must be consulted in addition to that single username-specific row. Sources: the initial return tables above and `quarantine.csv`, `date`, `cid`, `stage`, `user`, `reasons`.

The initial `frozen_cohort.json` includes the eight development-selected peers and requested BP benchmark, but does not include youdacao. Accordingly the initial `portfolios.parquet` and `lineups.parquet` contain no youdacao rows. Those files retain exact user hashes and personal counts for the other peers; a named player-level exposure table has not yet been materialized there. Source: `frozen_cohort.json`, `successful_peers`, `requested_benchmark`; `portfolios.parquet`/`lineups.parquet`, `user`, `hash`, `ct`.

## Full-block completeness and exclusions before the map repair

Using the existing `peer_play_review.block_issues` and canonical `roster_issue`, **278 of the 388** accepted reported-return user blocks pass the complete construction checks; **110** do not. Passing blocks account for **29,573 source entries**. These counts include the original map defect below and are intentionally pre-repair. Reason counts overlap: `missing_team_game` **86**, `not_eight_slots` **8**, `unresolved_idmap` **31**, `unresolved_player_id` **31**, and `duplicate_player_id` **6**. Source: all initial accepted cids' `normalized/*.data.json.gz`, `users.youdacao.lineups`; existing guard functions; receipt `block_coverage[].block_issues`, `entries`.

The explicit hash counts contain **329,604 observed slot occurrences**, compared with **329,880 nominal slots** from entries times the Classic roster length. The mismatch is preserved and reflects the existing invalid hashes; no absent slot was fabricated. Source: initial full user `lineups` hashes and personal `lineupCt`, receipt `block_coverage[].weighted_slots` and `entries`.

| Season | Fee lane | Initial accepted contests | Existing complete-block passes |
|---|---|---:|---:|
| 2019-20 | high_stakes | 3 | 0 |
| 2019-20 | lower_fee_MME | 1 | 0 |
| 2020-21 | high_stakes | 19 | 15 |
| 2020-21 | lower_fee_MME | 81 | 62 |
| 2021-22 | high_stakes | 11 | 9 |
| 2021-22 | lower_fee_MME | 52 | 46 |
| 2022-23 | high_stakes | 9 | 5 |
| 2022-23 | lower_fee_MME | 60 | 41 |
| 2023-24 | high_stakes | 6 | 4 |
| 2023-24 | lower_fee_MME | 83 | 50 |
| 2024-25 | high_stakes | 4 | 3 |
| 2024-25 | lower_fee_MME | 37 | 29 |
| 2025-26 | high_stakes | 2 | 1 |
| 2025-26 | lower_fee_MME | 20 | 13 |

These are not final coverage numbers after repair. The exact fee/cap, eight unique resolvable IDs, finite source values, team/event availability, salary cap, NBA identity collisions, multiplicity conservation and tail-count checks are reused unchanged from the existing guard. A reported-return row can pass its monetary-header checks without passing the stronger complete-player-block checks.

## Independently reread raw examples

All raw examples below had their decompressed SHA256 recomputed against `fetch_receipt.json.sha256`. Personal count sums and source fee arithmetic were reproduced directly from `users.youdacao`, without a global `entryNameList` join. Source field values were not repaired.

### Complete high-fee example — 2025-10-29 / 184164892

Raw path: `nba/analytics/data/research_peers/raw/2025-10-29_184164892.data.json.gz`.

Source header `contest`: date `2025-10-29T19:00:00`, fee **$555**, entry cap **24**, actual source field **800**. `users.youdacao`: **24** totalRosters, **24** actual eight-player hash records, exact personal multiplicity sum **24**, cost **$13,320**, reported winnings **$2,900**. Existing complete-block guard has no issues. The `uniqueRosters` header says **23**, whereas both stored hash count and unordered canonical build count are **24**. This discrepancy remains flagged; it is not corrected by assuming a different definition. Sources: the raw file, `contest`, `users.youdacao.{totalRosters,uniqueRosters,totalEntryCost,totalWinning,lineups}`; all values refer to 2025–26.

One actual submitted hash is `38294:38277:12240:27998:12188:245149:245017:28062`, with personal `lineupCt=1`. Its player names and IDs come directly from raw `players` and the existing bridge:

| FL ID | Raw fullName | Raw team | Bridge NBA ID | Dated BDB team |
|---|---|---|---|---|
| 38294 | Tony Bradley | IND | 1628396 | Indiana |
| 38277 | Lauri Markkanen | UTA | 1628374 | Utah |
| 12240 | Jrue Holiday | POR | 201950 | Portland |
| 27998 | Pascal Siakam | IND | 1627783 | Indiana |
| 12188 | Russell Westbrook | SAC | 201566 | Sacramento |
| 245149 | Jarace Walker | IND | 1641716 | Indiana |
| 245017 | Keyonte George | UTA | 1641718 | Utah |
| 28062 | Jamal Murray | DEN | 1627750 | Denver |

The date-specific player-game lookup comes from `research_v2/research_games.parquet`, `pid,date,team`, for 2025–26. Within-season `prior_games` is only **3 or 4** for these eight players, so the existing prior20 feature gate does not describe this opening-week portfolio. Those are missing eligible histories, not evidence of absent usage or shot-type reasoning. Source: the same exact dated frame rows, `prior_games`.

### Complete lower-fee example — 2025-11-05 / 184483423

Raw path: `nba/analytics/data/research_peers/raw/2025-11-05_184483423.data.json.gz`.

Source header `contest`: date `2025-11-05T19:00:00`, fee **$15**, entry cap **150**, actual source field **9,192**. `users.youdacao`: **150** totalRosters, **141** actual eight-player hash records, exact personal multiplicity sum **150**, cost **$2,250**, reported winnings **$2,425**. Existing complete-block guard has no issues. The `uniqueRosters` header says **131**, whereas stored and canonical build counts are **141**. Personal counts conserve totalRosters, while distinct-count semantics conflict. Sources: the raw file, fields as in the preceding example, 2025–26.

One submitted hash is `71699:12559:73382:455397:75309:90421:90375:12576`, with personal `lineupCt=1`:

| FL ID | Raw fullName | Raw team | Bridge NBA ID | Dated BDB team |
|---|---|---|---|---|
| 71699 | Daniel Gafford | DAL | 1629655 | Dallas |
| 12559 | Andrew Wiggins | MIA | 203952 | Miami |
| 73382 | Jose Alvarado | NOP | 1630631 | New Orleans |
| 455397 | Derik Queen | NOP | 1642852 | New Orleans |
| 75309 | Jalen Brunson | NYK | 1628973 | New York |
| 90421 | Saddiq Bey | NOP | 1630180 | New Orleans |
| 90375 | Trey Murphy | NOP | 1630530 | New Orleans |
| 12576 | Nikola Jokic | DEN | 203999 | Denver |

The exact identities, dates and player teams support named exposure comparisons. The existing feature gate still lacks sufficient within-season history for these displayed players: `prior_games` ranges from **2 to 7**. Source: `research_v2/research_games.parquet`, dated 2025–26 `pid,date,prior_games` rows.

### Known source gap — 2025-10-22 / 183502407

Raw path: `nba/analytics/data/research_peers/raw/2025-10-22_183502407.data.json.gz`. Personal `totalRosters` and multiplicity sum are both **37**, with **37** eight-slot hashes, cost **$32,856**, reported winnings **$22,500** and fee **$888**. However one selected ID is literal **`-1`**, absent from the source idmap. Existing reasons are `unresolved_player_id` and `unresolved_idmap`. Raw `uniqueRosters=36` also differs from the **37** actual canonical builds. Eight slots alone do not establish eight resolved people. No ID was invented for the missing player. Source: the raw `users.youdacao` block, `players`, and `contest`, 2025–26.

## Identity and dated-team conflict pass

The existing bridge is `nba/analytics/data/id_bridge.csv`, columns `fl_pid,person_id,fl_name,nba_name,team_last,first_seen,last_seen,match_method`. It has **1,150 mapped rows**. Raw FL player keys and NBA `pid`/Synergy `PLAYER_ID` are different namespaces. For example FL **12576** maps to NBA **203999** for Nikola Jokic, and FL **75309** maps to NBA **1628973** for Jalen Brunson. Source: bridge rows plus the raw 2025–26 player objects above. A raw name can be displayed without manufacturing a bridge match; richer NBA features require that exact bridge.

The initial shared `build_id_bridge.TEAM_MAP` omitted **OKC**, even though official/current source layers and dated BDB rows use OKC/Oklahoma City. The initial selected-player check found **282 weighted slot exclusions** from that omission, rather than an actual changed-team discrepancy: **142** in the 2024–25 lower-fee lane and **140** in the 2025–26 lower-fee lane. Example: 2024-10-24 / 169154387 Aaron Wiggins, FL **70247** → NBA **1630598**, raw `currentTeam=OKC`, dated frame `team=Oklahoma City`, and both sources' actual DK points **28.0**. Source: raw/normalized contest players, bridge row, dated research frame `team,fp_dk`; receipt `team_conflict_examples`. The current official roster receipt is `nba/analytics/data/roster_snapshot_2026.json`, `meta.season=2026-27`, `meta.source_url=https://www.nba.com/players`, `meta.retrieved_at=2026-09-22`, and `roster[].team_current_tri=OKC`. It supports the tricode mapping while its stated scope does not certify historical or opening-night eligibility. The parent has separately authorized a verified mapping repair and artifact rebuild; this audit makes no module change.

No additional old-team mismatch was established among this bounded youdacao selected-player/date overlap after distinguishing that map omission. This is not global certification of all FL player objects. `bridge.team_last` is an era/disambiguation aid, not a historical contest-date roster. A name such as Mikal Bridges can have an old tricode there; historical comparisons must use the raw contest team and the dated player-game team rather than overwrite either from the bridge or a current roster snapshot. Score conflicts are separately retained in `block_coverage[].slot_stage_counts`, and must not be relabeled as teammate or injury facts.

## Existing prior-only research frame

Path: `nba/analytics/data/research_v2/research_games.parquet`. It has **47,039 player appearances and 103 columns**. The source receipt identifies BDB raw player/team workbooks and corrected official NBA tracking files. The 2024–25 vintage is partial: **20,582 appearances, 551 players, 968 games, 2024-10-22 through 2025-03-10**. The 2025–26 vintage has **26,457 appearances, 582 players, 1,230 games, 2025-10-21 through 2026-04-12**. Sources: `research_games.parquet`, `season,pid,gid,date`; `frame_receipt.json`, `seasons[].rows,players,regular_games,from,through`. Appearance eligibility excludes subminute outcomes; it is not every rostered player-game.

Prior fields already available, with their exact source column names:

- Role/opportunity: `prior_games`, `min_l5,min_l10,min_l20,min_szn`, `usg_l5,usg_l10,usg_l20,usg_szn`, `fga_l5,fga_l10,fga_l20,fga_szn`, `starter_l5,starter_l10,starter_l20,starter_szn`, `min_sd10`, `min_change`, `usg_change`.
- Prior production: `fp_dk_l5,fp_dk_l10,fp_dk_l20,fp_dk_szn`, `fp_dk_sd10`, `fpm_l10`, `expected_fp_simple`, `p85_prior20`, `days_since_played`.
- Prior tracked shot diet: `cs_prior10,pu_prior10,lt10_prior10,wo_prior10,vtight_prior10`, `cs_prior_share,pu_prior_share,lt10_prior_share`, `tracking_prior10_n`, `fit_cs,fit_pu,fit_lt10`.
- Prior opponent/team environment: `own_pace_l10,opp_pace_l10`, `own_oeff_l10,opp_oeff_l10`, `own_deff_l10,opp_deff_l10`, `game_pace`, `opp_cs_allowed100,opp_pu_allowed100,opp_lt10_allowed100,opp_wo_allowed100,opp_vtight_allowed100`, `opp_shot_clean_n`, `opp_dvp_G,opp_dvp_F,opp_dvp_C`, `opp_dvp100`.
- Schedule/player metadata: `pid,gid,date,player,team,opp,position,home,rest`.

Source semantics: `research_frame.player_prior` and `team_features` compute historical states before appending the present date; shot/role windows reset by season. The opponent tracking policy uses only fully reconciled earlier games with its existing minimum-count gate. These fields are prior-game reconstructions, not independently timestamped forecasts from before DK lock.

Present-game columns such as `min,usg,fp_dk,fga,fgm,fg3a,fg3m,fta,ftm,reb,ast,stl,blk,tov,pts,starter,cs,pu,lt10,wo,vtight` are outcomes and cannot be called pregame predictors. `season_p85,season_top15,rolling_p85` are labels; `p85_prior20` is the prior threshold. `opening_total,opening_spread,closing_total,closing_spread,itt` have no source timestamp receipt and are explicitly retrospective markets. Sources: same frame fields, `research_frame.py`, and `frame_receipt.json.market_policy`.

The initial youdacao feature join uses the runner's already declared prior20 plus complete tracking/source-team/source-score requirements. Before repairing the map, complete existing feature-gate slot occurrences are **106** in 2024–25 high stakes and **1,563** in 2024–25 lower fees; **zero** in 2025–26 high stakes and **4,288** in 2025–26 lower fees. These are observed slots across all accepted user blocks, including blocks later rejected for construction, not certified full portfolios or independent observations. All earlier seasons have no overlap with the repaired frame. Source: receipt `pre_repair_block_coverage_summary[].slot_counts.complete_existing_feature_gate`; existing `peer_play_review.FEATURES`/`feature_pool`; years and lanes as stated. This separation prevents interpreting absent feature coverage as an absent strategy.

## Detailed shot and play-type layers already present

### Official daily tracking, reconstructed as of earlier games

Corrected sources: `research_v2/tracking_corrected_2024-25.csv` and `tracking_corrected_2025-26.csv`, with `date,tag,nba_pid,fgm,fga,fg3m,fg3a`. They have **69,273** and **88,977** tag-player-date rows respectively; they are not distinct games. Tags are `cs,pu,lt10,wo,vtight`: catch-and-shoot, pull-up, less than ten feet, wide-open, very-tight. Date bounds are **2024-10-22 through 2025-03-10** and **2025-10-21 through 2026-04-12**. Sources: those exact CSVs, `date,tag,nba_pid`, season vintages as named.

`tracking_repair_receipt.json` records **165 official NBA endpoint requests across 33 date/season pairs**, retrieved **2026-09-22**, with `url,source_file,sha256,retrieved_at,status`. Original response bytes live in `research_v2/tracking_receipts/`. These prove the historical statistics and request date filters; they do not certify historical pre-lock injury forecasts. The untouched older `tracking_2024-25.csv` and `tracking_2025-26.csv` exist, but the corrected files are the consumed research source. Sources: receipt `requests[]` and `frame_receipt.json.seasons[].tracking_source`.

### Richer prior-season Synergy archetypes

Directory: `nba/analytics/data/synergy/`. For each of **2024–25 and 2025–26**, there are **11 player-offense** and **11 team-defense** CSVs, one for each `Cut,Handoff,Isolation,Misc,OffRebound,OffScreen,PRBallHandler,PRRollMan,Postup,Spotup,Transition`. The 2024–25 player files together have **3,380 rows and 438 NBA PLAYER_IDs**. Source: `2024-25_P_offensive_*.csv` and `2024-25_T_defensive_*.csv`, with the corresponding 2025–26 files; counts from the actual file inventory and `PLAYER_ID`.

Fields include `SEASON_ID,PLAYER_ID,PLAYER_NAME,TEAM_ID,TEAM_ABBREVIATION,PLAY_TYPE,POSS,POSS_PCT,PPP,PTS,FGA,FG_PCT,FT_POSS_PCT,TOV_POSS_PCT`. Team defense has corresponding `TEAM_ID,PLAY_TYPE,POSS,PPP` and scoring/shot fields. `pull_synergy.py` identifies the official `stats.nba.com/stats/synergyplaytypes` season-aggregate source. These CSVs have no historical daily snapshot timestamps. `synergy_yearahead.py` already handles traded players by summing all team-stint possession/point rows before deriving a profile, with all loaded categories in the denominator.

The prior **2024–25** profiles are chronologically suitable as preseason archetypes for **2025–26** selections, including October games without a prior20 within-season window. This does not guarantee that last year's role or efficiency persisted. The **2025–26** full-season aggregate cannot supply an honest pregame type for an earlier 2025–26 game; the existing same-season read is explicitly LOOKAHEAD. No new minimum-possession cutoff is chosen by this audit.

Among youdacao's accepted 2025–26 selected slots, **275 unique FL IDs** occur; **274** map to NBA IDs, while literal `-1` is unresolved. Of those mapped IDs, **233** have any 2024–25 player-offense profile and **41** do not. Profiles cover **16,908 of 19,280 mapped slot occurrences** before whole-block construction exclusions. This is an unthresholded presence inventory, not eligibility or predictive success. Source: exact personal user hashes/lineupCt in the 2025–26 raw/normalized feeds, existing bridge, `2024-25_P_offensive_*.csv`, receipt `prior_season_playtype_coverage`.

Exact prior-season examples, summing every team stint and dividing by all loaded play-type possessions:

| Player / NBA ID | Prior 2024–25 largest-volume play type | Type possessions | All loaded type possessions | Share |
|---|---|---:|---:|---:|
| Nikola Jokic / 203999 | Postup | 409 | 1,782 | 22.95% |
| Jalen Brunson / 1628973 | PRBallHandler | 610 | 1,548 | 39.41% |
| Daniel Gafford / 1629655 | Cut | 138 | 549 | 25.14% |
| Jamal Murray / 1627750 | PRBallHandler | 463 | 1,360 | 34.04% |

Sources: `2024-25_P_offensive_{postup,prballhandler,cut}.csv` for numerators and all **11** player-offense CSVs for denominators; `PLAYER_ID,PLAY_TYPE,POSS`, 2024–25. Tony Bradley / NBA **1628396** has no loaded 2024–25 profile; that is an explicit unknown, not a fabricated archetype. Prior profiles also are absent for other selected players; absence alone does not establish why.

### Other detailed snapshot layers

`/Users/rsbathla/Downloads/nba_play_type_analysis_2026-03-04.xlsx` exists with sheets `Player Play Type Profile`, `Team Defensive Rankings`, `Matchup Funnels`, `Player vs Opp Breakdown`, and `Expected FGM`. Player fields include category frequency, PPP, FGA and `Dominant_PlayType_1/2`, plus catch-and-shoot/pull-up/less-than-ten-feet values. This is an actual richer saved workbook, but its filename does not certify the underlying statistic cutoffs or pre-lock provenance; derived funnel/expected fields are not primary outcomes.

`/Users/rsbathla/Downloads/dfs/nba-dashboard/data.json` and the neighboring Downloads copy contain `players,defenses,player_splits,player_shot_zones,defense_shot_zones,defense_pos_vulnerability,daily_matchup,team_environment`. Their metadata mixes a March 15 display date, March 10 daily slate and March 26 last-update/data-window labels. `meta.data_source` says NBA.com L7 plus season cross-reference. These are a snapshot, not a certified daily historical archive. A zone field exists but cannot silently supply an earlier game's pregame zone matchup. Source: those exact JSON `meta` and layer keys, 2026 snapshot vintage.

## Injury, minutes and projections: inventory probes and limits

A bounded `rg --files` probe across Downloads and the NBA estate, excluding WNBA/NFL/vendor/runtime/credential paths, found **275 NBA-named projection CSVs**, **184 non-temporary NBA season-feed workbooks**, and **five NBA Main projection exports** under the searched filename patterns. They include re-downloads and do not represent that many unique slates. No dedicated NBA injury-report filename was found under `*injur*`, `*Injur*`, `*INJUR*`, NBA injury-name variants, or standard injury-report filename patterns. This is a bounded discovery result, not proof that no injury information exists anywhere. Sources: receipt `layer_filename_probe`, exact path lists; searched filename categories.

Actual archived schemas read:

- `/Users/rsbathla/Downloads/NBA DFS Projections - 2026-03-20T191412.768.csv`: `Player,Team,Opp,Minutes,FPTS,Ceiling,ProjOwn,Site,Slate,Scenario`. The sampled row is **FD**, so an NBA filename cannot be treated as DK automatically. A filename time does not supply timezone, lock validation or provider timing.
- `/Users/rsbathla/Downloads/NBA DFS Projections (3).csv`: `Player,Pos,Team,Opp,Minutes,FPTS,Ceiling,Own,Site,Slate,Scenario`; numbered filename does not identify a slate date. Its sampled row also declares FD.
- `/Users/rsbathla/Downloads/DK NBA Projections (16).csv`: `Player Name,Projection,Opp,Minutes,DK Position,DK Salary,DK Points,DK Ceiling,DK Own,DK Slate`. Minutes and forecast columns exist, but the numbered filename does not certify date/timing.
- `/Users/rsbathla/Downloads/NBA_2026-04-15-730pm_DK_Main.csv`: `DFS ID,Name,Pos,Team,Opp,Status,Salary,Actual,SS Proj,Live Proj,My Proj,My Own,Adj Own`, scoring percentile distributions, and component `Min`. This supplies saved status and projected-minute/forecast information on the labeled slate; it needs a source/lock timestamp and dated ID join before a prospective claim. It is outside the repaired frame's April 12 endpoint.
- `/Users/rsbathla/Downloads/04-12-2026-nba-season-dfs-feed.xlsx`: source metadata and daily cumulative data include player/game IDs, starter, minutes, usage, rest, positions, salaries and **fantasy points scored**. These are realized fields, not a certified injury or projected-minute feed.

The read-only core database `projections` table has no rows; its schema includes `locked_at` but there is no NBA forecast history there. `slate_players` and `player_results` have NFL rows only. Source: SQLite `sqlite_master`, `PRAGMA table_info`, and sport-grain count queries as of this audit. This was probed directly rather than inferred from table names.

The recovered raw FL player schema has `fullName,playerId,currentTeam,currentTeamId,eventId,eventTeamId,homeVisitor,favDog,salary,position,rosterPosition,projPoints,ownership,actualPoints,statDetails,madeCut`. The inspected raw examples have **no injury-status or projected-minutes field and no forecast timestamp**. Public `projPoints` exists and can be compared retrospectively; it cannot be called a certified pre-lock model without separate evidence. Normalized source caches retain only consumed player fields and drop per-user exposures; richer source inspection must use `raw/`. Sources: the three actual raw examples, `players`; `peer_play_review.load_source` cache schema.

A retrospective teammate participation panel exists at `research_next/teammate_participation_panel.parquet`, with `season,gid,date,team,teammate_pid,present,teammate_prior_min` and companion creator/scorer/big context for source seasons 2024 and 2025, consumed by `available_usage_funnel_study.attach_availability`. Actual participation is useful for a sensitivity but is not certified injury status or knowable lock availability. The audit does not infer an injury diagnosis from a missed appearance.

## Feasible player-level metadata and final gap pass

**Facts.** Actual named selections and exact personal exposure counts can be recovered from complete full user blocks: user hash → raw FL playerId/fullName/salary/event/team → bridge NBA person_id → date-specific BDB player-game and prior fields. Richer prior-season type can then join through Synergy PLAYER_ID and SEASON_ID. This chain exists for both youdacao and the existing peer accounts; no guessed names or source-global multiplicities are necessary.

**Inference.** A named exposure comparison using those complete source blocks and an explicitly qualified prior-season archetype layer is feasible. Opening-week missing prior20 histories suggest the already-built preseason Synergy profiles are relevant to descriptive type comparison. Neither source proves the manual reason anyone selected a player or the cause of profit.

**Unresolved.** Final post-OKC-repair accepted counts; distinct-roster header semantics; source ID `-1` and other unresolved players; independent verification of disputed filled fields; account-wide peer returns; forecast/ownership/injury timestamps; old-team continuity across seasons; no-profile players; and accurate daily play-type/zone snapshot provenance. All must stay visible. Archived projection/status files require their own slate/site/source/lock audit before use.

**Acceptance.** All **14 season/lane aggregate pairs** were reproduced from the initial accepted returns; **three** actual raw source hashes and personal cost/count sums were verified; **two** of those full portfolios pass the existing complete block guard and the third reproduces a genuine unresolved-player failure. No analytics module, threshold, weight, source gzip or database row was modified. The parent's final combined gate covers the ensuing repair/rebuild; this source audit does not rerun broad repository gates independently.

Receipt: `/tmp/nba_youdacao_inventory_2026-10-02.json`. This Markdown file is the only repository file authored by this audit.
