# NBA player shot profiles and top-15% game study

**Later same-day follow-up:** [the three-test study](NBA_THREE_TEST_RESULTS_2026-09-22.md) restores regular-season-eligible Cup games and repulls missing tracking dates in a separate research dataset. Its player source profiles use the expanded sample and replace this report's smaller-sample descriptive counts for subsequent research. The conditional tests below remain the explicitly qualified original subset vintage; they were not silently rerun or transferred to the expanded universe.

As of September 22, 2026. This is a reproducible study of the existing historical sample, not a new-season projection. The existing frames omit source-labelled NBA Cup games, so “top 15%” below means each player's top tail **within the available sample**, not the complete official regular season. No production weights or p75 trigger rules were changed.

## What player data exists

| Layer | Available detail | Coverage |
|---|---|---|
| Daily shot type | Catch-and-shoot (`cs`), pull-ups (`pu`), less than 10 feet (`lt10`); raw tracking also contains makes and three-point attempts/makes | 2025–26: all 582 historical frame players have some tracked attempts. 2024–25: 543 of 551. Individual games can be missing. |
| Defender distance | Wide open, defender 6+ feet (`wo`); very tight, 0–2 feet (`vtight`) | These overlap shot types. The five fields are **not** five mutually exclusive bins. |
| Synergy play type | Isolation, transition, pick-and-roll ball handler/roll man, post-up, spot-up, handoff, cut, off-screen, offensive rebound, miscellaneous | Eleven season aggregate tables; 439 player IDs in 2025–26 and 438 in 2024–25. No daily historical Synergy snapshots. |
| Opportunity and box score | Minutes, usage, attempts, assists, rebounds, steals, blocks, DK points | Per player/game in the BDB feeds. |
| Matchup/environment | Prior opponent shot-attempt ranks, positional DK points allowed, points allowed, pace; closing implied total/spread; schedule | Opponent shot funnels are attempt allowance, not shooting efficiency. Closing lines lack a saved lock-time receipt. |
| Teammate availability | Key rotation, two key rotation, same-position starter absence proxies | Inferred from final participation and a short prior roster window; no named, timestamped injury history. |

The September 22 official roster snapshot has 573 players. **463 have 2025–26 shot history, 403 have a Synergy profile, and 274 have at least 50 appearances in the current frame.** The other 110 have no local 2025–26 frame history; this does not establish why. See [current roster profiles](../nba/analytics/data/top15_current_roster_profiles.csv), one row per current player with explicit coverage flags, and [both-season historical profiles](../nba/analytics/data/top15_profiles.csv).

## Sample and definition

The primary outcome is DK fantasy points strictly greater than each player's own sample 85th percentile. Ties and small samples mean the realized fraction is not exactly 15%. The 2025–26 frame has 25,039 player-games, 582 players and 3,862 top-tail games (15.42%), dated October 21–April 12. The 2024–25 comparison has 19,310 player-games, 551 players and 3,018 top-tail games (15.63%), dated October 22–March 10. Both require at least one minute played and use the existing source-labelled `Regular` subset.

Individual condition tests require at least 50 appearances and 10 available games with the condition on and 10 off. This produces 3,109 player/condition tests across 281 eligible players in 2025–26 and 1,446 across 163 in 2024–25. Missing underlying ranks and histories are omitted rather than classified as false. Fisher tests are two-sided. Benjamini–Hochberg adjustment includes all tested player/condition pairs, separately by season and outcome; it does not adjust only the attractive results. `q` below is the adjusted value, with a 0.05 discovery threshold. The statistical assumptions do not remove serial dependence, correlated teammates, role changes or confounding.

A second outcome uses a prior-20-game p85, minimum eight previous appearances, to remove future scores from the threshold. Its 2025–26 hit rate is 4,181/20,638 = 20.26%; it answers a different question from the fixed sample tail. January 15 splits discovery and later replication, with separate whole-family adjustments in each half. The cohort still requires 50 appearances over the entire sample, so this is retrospective replication, not a deployable player-selection process.

## What individual big games looked like

These are **realized same-game descriptions**, comparing top-tail games with the player's other games. They cannot be used as pregame inputs. Descriptive tail comparisons require at least 10 observed top-tail games; smaller tails remain flagged in the profile export.

| Player | Top-tail / other games | Shot pattern: top tail vs other games | Opportunity and other production |
|---|---:|---|---|
| Jalen Brunson | 11 / 58 | Pull-up attempts **14.0 vs 10.1**; pull-ups account for **59.5% vs 53.6%** of box-score FGA | Minutes 38.2 vs 34.2; usage 33.9% vs 29.8%; assists 9.4 vs 6.4 |
| Tyrese Maxey | 10 / 56 | Attempts inside 10 feet **11.5 vs 7.9**; their share **44.1% vs 38.0%** | Minutes 42.4 vs 37.1; usage 32.1% vs 29.4%; assists 9.0 vs 6.1 |
| Karl-Anthony Towns | 11 / 58 | Catch-and-shoot attempts **5.4 vs 3.3**; their share **29.4% vs 25.8%**. Inside-10-foot share is almost unchanged, 63.7% vs 63.2% | Usage 32.1% vs 25.2%; total FGA 18.3 vs 12.9; rebounds 13.8 vs 11.6 |
| Donovan Mitchell | 10 / 57 | Pull-ups **11.2 vs 8.6**, but nearly identical pull-up share, **45.0% vs 45.4%** | Total FGA 24.9 vs 19.0; usage 37.4% vs 31.4%; rebounds 7.3 vs 4.0 |

For Mitchell the shot profile is principally more volume within a similar mix. Brunson and Maxey also show shifts in the mix. These are descriptions of this sample, not proof that a particular defense caused the big games. Attempt shares use summed tracked attempts divided by summed box FGA on observed tracking rows; source reconciliation limitations below still apply.

Across the 151 players with at least 10 top-tail games, the equal-player median top-tail-minus-other-game difference is **+6.27 minutes, +4.61 FGA and +3.67 usage percentage points**. All 151 have higher mean minutes and FGA; 146 have higher usage. Selecting high fantasy-point outcomes naturally selects greater opportunity and production, so these differences measure how the ceiling occurred, not independent predictive edge.

## Conditions associated with the top tail

These examples span availability, prior opportunity, shot funnel and environment. Each rate is “top-tail games / all available games under that condition.” They are exploratory candidates selected after viewing the full results; **none passes q ≤ 0.05**.

| Player and condition | Condition on | Condition off | q | Interpretation limit |
|---|---:|---:|---:|---|
| Javonte Green — two key rotation players absent | 8/14 = 57.1% | 4/64 = 6.3% | .057 | Near the statistical threshold, but the absence variable is retrospective participation, not injury confirmation. |
| Nique Clifford — prior-10 minutes at least 3 above prior sample mean | 11/31 = 35.5% | 0/37 = 0% | .057 | Prior opportunity expansion; maturation and season timing can confound the split. |
| Gui Santos — prior-10 usage at least 3 percentage points above prior sample mean | 9/21 = 42.9% | 1/42 = 2.4% | .075 | Prior usage expansion; not his eventual same-game usage. |
| Bobby Portis — two key rotation players absent | 7/12 = 58.3% | 3/51 = 5.9% | .075 | Named absent teammates and injury timing remain unverified. |
| Andrew Nembhard — opponent allows high volume of his prior favorite shot category | 7/15 = 46.7% | 2/39 = 5.1% | .184 | Prior dominant category is usually pull-ups; rank-based, source-limited funnel, not shot efficiency. |
| Karl-Anthony Towns — closing team implied total at least 118 | 9/28 = 32.1% | 2/41 = 4.9% | .457 | Closing market association, not proof the line was available at lock. |
| Tyrese Maxey — fast game environment | 6/23 = 26.1% | 2/39 = 5.1% | .726 | Prior pace in that day's upper quartile; early games without pace history omitted. |

All 16 conditions and all tested players are saved in [player factor results](../nba/analytics/data/top15_player_factors.csv). Favorite-shot funnels require prior opponent allowed-attempt rank at least 24; high rank means more attempts allowed. That is volume exposure, not an efficiency-adjusted defensive weakness, and the saved ranks are not pace adjusted.

For context, raw pooled 2025–26 rates among the 281 eligible players are 22.7% vs 13.3% with/without the same-position absence proxy; 21.2% vs 14.6% with/without recent minutes expansion; 17.2% vs 14.7% in the fast-pace condition; and 16.0% vs 14.7% at team implied totals of at least 118. Pooled populations differ, conditions overlap, and shared games are correlated. These are descriptive associations, **not independent effect estimates or a combined score**. [Full pooled results](../nba/analytics/data/top15_league_factors.csv).

## Repeatability and source audit

No individual 2025–26 season-top-tail condition passes the whole-family 5% adjustment. Neither season produces a positive H1 discovery passing its family gate, so there is no qualifying H1 discovery to advance as validated by H2. Smaller half-season on/off samples also limit power; this is not evidence that every basketball mechanism is absent.

The sole 2024–25 sample-tail positive is Kyle Filipowski's recent-FPPM increase: 8/16 vs 0/34, q=.035. In 2025–26 the analogous descriptive split is 8/28 vs 3/42: the positive direction recurs and nominal p=.021, although q=.631 in the broad 2025–26 family. A separately locked single-candidate replication would treat that nominal result differently; the association has not simply disappeared. With the prior-20-game p85 target it is 10/28 vs 11/37, p=.789. The adaptive-target evidence does not establish a repeatable hot-form edge. [Replication results](../nba/analytics/data/top15_chronological_validation.csv).

The additional audit found four limits that the earlier broad audit did not fully resolve:

1. **Game universe:** `build_season.py` filters labels containing `Regular`, omitting tournament-labelled rows. The 2025–26 team feed contains 67 such games. The NBA says Cup games count toward regular-season statistics except the championship, so most of this omission is a real completeness defect, not a legitimate full-season exclusion. The current study preserves and names the existing subset. A complete-season rebuild must include eligible Cup games, exclude the championship, reconcile the 2024–25 feed's smaller tournament universe, and rebuild all dependent rolling features. [NBA Cup rules](https://api-hub.nba.com/news/nba-cup-101).
2. **Player/game tracking:** Complete date/category pulls do not establish complete player coverage. The 2025–26 frame has 53 positive-FGA games with zero tracked shot-diet attempts; 2024–25 has 38. These are masked as missing in the new profiles. Total tracked diet differs from box FGA on 1,239/25,039 and 859/19,310 rows respectively, including nonzero differences that are not silently imputed. There is an entirely blank tracking game on February 28, 2025. Legacy opponent ranks inherit these gaps; **every shot-funnel test is explicitly source-limited**, even when its raw p-value looks attractive.
3. **Invalid usage:** Two 2025–26 source values and one 2024–25 value exceed 100%. They match the raw feed, so this is not a join error. They are excluded from usage measures while preserving the player's score and outcome row.
4. **Availability and market timing:** Participation proxies do not distinguish injuries from rest, trades, DNPs or other rotation changes. Closing lines are not a timestamped pre-lock series. No specific injured-teammate narrative is inferred from these flags.

The independent review and raw-source checks are recorded in [method audit](NBA_TOP15_METHOD_AUDIT.md). The earlier p75 Synergy year-ahead study found no broad edge after aggregation repairs, but that result is not substituted for a p85 test here. Daily Synergy funnel research still requires historical snapshots.

## Implication for upcoming-season work

We have enough data to build player-specific shot and opportunity dossiers. The clearest observed distinctions are **opportunity expansion, which shot category supplies extra volume, and whether the shot mix actually changes**. Availability and shot-funnel candidates belong in a verification queue. They do not yet justify player multipliers or automatic lineup decisions.

Before promoting these candidates: repair the game universe and tracking gaps; collect named teammate availability and market lines with timestamps; refresh player role and team context; then rerun the fixed tests on later data. Do not multiply overlapping absence, minutes and usage effects. The roster snapshot establishes membership, not opening-night role or health.

Reproduce with `python nba/analytics/top15_study.py` from the `dfs` root using an environment with pandas, scipy, pyarrow and openpyxl. `top15_summary.json` contains definitions/counts, `top15_games_2526.parquet` contains inspectable labels and source flags, and `test_top15_study.py` includes future-score, false-zero tracking, invalid-usage, missing-rank and full-family adjustment checks. This report is exploratory research; artifact checks do not certify a profitable strategy.

Validation: 68 regression tests passed, including six new top15 tests; the NBA roster/research strict gate passed. Independent review recomputed the Portis, Nembhard and Brunson examples and all saved player-family p/q values. The historical construction-source gate remains separately blocked, and source completeness limitations above remain open.
