# NBA peer saved-source audit — 2026-10-01

## Scope and source grain

This is a mechanical inventory of saved historical NBA sources for BPCologna and high-stakes MME peer comparisons. It does not classify skill, backtest a strategy, or certify peer account returns. The requested filter is source-reported entry fee at least $150 and personal `totalRosters` at least 20. `season_of` is reused from `core/nba_construction_audit.py`, including COVID schedule adjustments. SQLite was opened with `mode=ro`; there were no network calls or original-source mutations.

Primary saved sources were examined first, followed by the existing construction audit. There is no `graphify-out/graph.json` in this NBA repository; this bounded inventory does not build a new graph.

## NBA compact user summaries

There are **1,499 gzip user-feed files**, plus one non-gzip directory child. Every summary row checked has 11 elements. The archive was collected from contests the owner entered and stratified by the owner's volume and fee. It is not an independent random sample of peers' NBA activity and does not backfill all contests a peer entered.

| Season | Saved NBA user-feed gzip files |
|---|---:|
| 2019-20 | 14 |
| 2020-21 | 214 |
| 2021-22 | 203 |
| 2022-23 | 226 |
| 2023-24 | 282 |
| 2024-25 | 227 |
| 2025-26 | 333 |

The only exact saved handle containing `cologna` is **`bpcologna`**, appearing in **936 summary rows**. BPCologna is the owner's search label here; no separate mixed-case source handle or account alias was found. This does not establish ownership of any alias outside the archive.

`tools/fl_nba_harvest.py` passes these fields through from the raw `users` object without validating them or calculating peer return:

| Index | Source field | Meaning retained by harvester |
|---:|---|---|
| 0 | user-object key | Exact handle. |
| 1 | totalRosters | Source-reported personal roster count. |
| 2 | uniqueRosters | Source-reported distinct personal roster count. |
| 3 | totalEntryCost | Source-reported personal cost. |
| 4 | totalWinning | Source-reported winnings; no DK cash/ticket breakdown. |
| 5 | lineupsCashing | Source-reported cashing lineup count. |
| 6 | lineupsInPercentile1 | Source-reported first-percentile bucket count. |
| 7 | lineupsInPercentile5 | Source-reported first-five-percent bucket count. |
| 8 | lineupsInPercentile10 | Source-reported first-ten-percent bucket count. |
| 9 | lineupsInPercentile20 | Source-reported first-twenty-percent bucket count. |
| 10 | maxExposure | Source-reported maximum player exposure. |

The compact row omits per-user exposures and the lineup hash/count map for every account except `rsbathla`. The harvester retains the owner's full block and a common idmap; it does **not** save full BP user blocks. `totalWinning` is not an authoritative ledger of peer cash, tickets, all contests, or all-account returns.

## BP high-fee MME appearances and consistency

The raw fee/roster filter finds **31** appearances. It includes visibly misattributed contest feeds. A secondary exact source-count comparison keeps **19**: source `totalLineupsEntered` and companion `field_stats.n_entries` equal DK actual `entry_history.contest_entries`; fee matches DK; personal rosters do not exceed source entry cap/capacity; cost equals rosters times fee; DK format is Classic. Capacity can exceed filled entries. This is a quality comparison, not an adopted tolerance policy.

| Season | Raw contests | Raw rosters | Raw source cost | Raw source winnings | Count-consistent contests | Count-consistent rosters | Count-consistent cost | Count-consistent winnings |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 2022-23 | 1 | 150 | $159,000.00 | $0.00 | 0 | 0 | $0.00 | $0.00 |
| 2023-24 | 3 | 62 | $72,703.00 | $4,400.00 | 1 | 21 | $11,655.00 | $4,400.00 |
| 2024-25 | 16 | 488 | $625,592.00 | $309,250.00 | 11 | 260 | $299,320.00 | $159,300.00 |
| 2025-26 | 11 | 430 | $384,159.00 | $655,100.00 | 7 | 180 | $282,039.00 | $178,050.00 |

There is no qualifying saved row for 2019–20 through 2021–22 under this specific fee/volume filter. That does not show BP did not play those seasons. All 31 have a saved lineup companion. Twelve fail exact filled-field consistency; three additionally exceed source entry cap/capacity. No qualifying row has a cost-arithmetic or fee mismatch.

Severe fixtures:

- `nba_users/2023-04-04_143093502.json.gz`: named $1,060 All-Star Single Entry, cap 1, capacity 8, DK actual field 6, but BP has 150 rosters/$159,000 cost and source/companion actual field 16,035.
- `nba_users/2024-01-25_158138754.json.gz`: cap 1, DK actual field 15, but BP has 20 rosters and source/companion field 23,628.
- `nba_users/2024-10-22_168368574.json.gz`: cap 1, DK actual field 15, but BP has 125 rosters and source/companion field 4,695.

The raw 2025–26 sample reports $655,100 winnings on $384,159 cost; the exact source-count subset reports $178,050 winnings on $282,039 cost. This reversal shows that sampling and attribution checks materially affect apparent success. Neither subtotal is a complete audited peer season. No return or skill judgment is made from them.

The 19 source-count-consistent appearances also are **not** all construction-clean. The existing canonical `roster_issue` validator, applied to saved `lineupPlayers` and idmap, finds:

| Date / contest | Invalid BP distinct builds | Exact reason |
|---|---:|---|
| 2025-01-27 / 173566402 | 5 | not_eight_slots: 5 |
| 2025-02-21 / 174148127 | 10 | unresolved_player_id: 10 |
| 2026-02-04 / 187879251 | 3 | unresolved_player_id: 3 |
| 2026-03-23 / 188943225 | 3 | unresolved_player_id: 3 |

Counts are distinct builds. Field `lineupCt` is not an exact peer entry weight if other handles share the build. The receipt retains a bad hash and exact reason for each affected contest. No missing slot or identity was filled in.

## Complete peer builds versus trimmed fields

| Directory | Saved children | Relevant contents |
|---|---:|---|
| tools/data/fantasylabs/nba_users | 1,500 | 1,499 gzip files: compact all-user summaries, owner's full block, common idmap. |
| tools/data/fantasylabs/nba_lineups | 1,457 | Pre-trim field statistics; trimmed saved roster/score/payout/name records. |
| tools/data/fantasylabs/nba_sd_lib | 65 | Showdown player library; no NBA full peer user blocks established. |
| tools/data/fantasylabs/cohort | 1,955 | Harvester explicitly uses NFL endpoint; zero NBA entry-history contest ID matches. |
| tools/data/fantasylabs/se_top_users | 45 | Zero NBA entry-history contest ID matches in bounded inventory. |
| tools/data/fantasylabs/users | 3,421 | Generic/NFL archive; zero NBA entry-history contest ID matches. |

No separately named NBA cohort/full-peer-user directory was found by narrow filename discovery. The generic NFL cohort archive cannot be relabeled NBA.

`tools/fl_nba_lineups_harvest.py` retains builds with `lineupPercentile <= 5`, owner name, any fixed cohort name, or `lineupCt >= 5`. Declared trim: `pct<=5|rsbathla|cohort|ct>=5`. The fixed cohort is:

`papagates`, `youdacao`, `moklovin`, `oxenduck`, `mazwa`, `cheddabisque`, `ChipotleAddict`, `theWhistlesGoWooo`, `ragingphilip`, `hishboo`, `petteytheft89`, **`bpcologna`**, `bgreseth`, `Kobe4MVP`, `jpm11`, `dacoltz`, `hixx`, `fjbourne`, `giantsquid`, `sullybrochill`, `Awesemo`, `beaker913`, `ehafner`, `bric75`.

Recognized builds for an exact member of that cohort are retained unconditionally by the script, including losing builds. This is broader than winner-only coverage. It does not make the overall field complete or identify each account's personal multiplicity inside shared builds. Newly selected peers outside this cohort can have outcome-biased saved build coverage.

Saved records include slot IDs in `lineupPlayers`, `points`, `totalSalary`, `totalOwn`, `lineupCt`, `lineupUserCt`, `entryNameList`, `lineupRank`, `lineupPercentile`, and `payout`. `entryNameList` identifies users of a build, while `lineupCt` is all field entries on it. Crediting its full count to each listed peer overattributes entries. The [2026-09-22 construction audit](NBA_CONSTRUCTION_AUDIT_EVIDENCE_2026-09-22.md) documents this exact prior failure.

## Two independently reproduced raw examples

The original gzip sources below were reread independently of the season subtotal; cost arithmetic, entry counts, and summary winnings versus solo-named companion payouts were recomputed.

### 2025-10-22 / 183502407

[NBA user feed](../tools/data/fantasylabs/nba_users/2025-10-22_183502407.json.gz), [lineup companion](../tools/data/fantasylabs/nba_lineups/2025-10-22_183502407.json.gz).

Raw row: `['bpcologna', 37, 37, 32856.0, 59000.0, 17, 2, 7, 9, 17, 100.0]`.

Fee $888, cap 37, capacity 1,251, actual field 1,131. DK, source totalLineupsEntered, and companion n_entries agree at 1,131. All 37 BP builds are solo-named and account for 37 entries. Cost recomputes as `37 × 888 = 32,856`; companion entry-weighted payout sums to **59,000**, matching the summary. One saved build has 339 DK points, payout 15,000, reported percentile 0.71.

### 2026-02-11 / 187917270

[NBA user feed](../tools/data/fantasylabs/nba_users/2026-02-11_187917270.json.gz), [lineup companion](../tools/data/fantasylabs/nba_lineups/2026-02-11_187917270.json.gz).

Raw row: `['bpcologna', 30, 30, 75000.0, 12000.0, 3, 0, 0, 1, 3, 100.0]`.

Fee $2,500, cap 30, capacity 1,000, actual field 931. DK, source totalLineupsEntered, and companion n_entries agree at 931. All 30 BP builds are solo-named and account for 30 entries. Cost recomputes as `30 × 2500 = 75,000`; companion entry-weighted payout sums to **12,000**, matching the summary. One saved build has 318.75 DK points, payout 4,000, reported percentile 9.88.

This pair includes a source-reported winning and losing contest. It does not establish a prospective profitable strategy.

## Authoritative local DK standings

Narrow `rg --files` search for `*standings*.zip` and `*standings*.csv`, excluding runtime/vendor/credential paths, found 153 files across sports. Headers and first ten lineups identified **nine NBA Classic ZIPs**: six exact NBA entry-history contest matches, and three PG/SG slot schemas without owner contest metadata. Full ranked-entry scans counted BP and owner entries. No CSV was extracted or mutated.

All nine have this header:

`Rank, EntryId, EntryName, TimeRemaining, Points, Lineup, [blank], Player, Roster Position, %Drafted, FPTS`

They provide exact entry-level Rank, EntryId, EntryName, Points, and Lineup, plus a separate player ownership/points block. **None has entry winnings/payout/prize columns.** Exact entry multiplicity is recoverable; dollars require an independently verified payout schedule.

| Exact ZIP path | DK date if available | DK fee if available | Ranked rows | BP entries | Owner entries |
|---|---|---:|---:|---:|---:|
| /Users/rsbathla/Downloads/contest-standings-189728510.zip | Not in owner entry history | Unknown | 17,319 | 150 | 0 |
| /Users/rsbathla/Downloads/contest-standings-189754326.zip | Not in owner entry history | Unknown | 13,071 | 150 | 0 |
| /Users/rsbathla/Downloads/contest-standings-189781418.zip | 2026-04-20 19:00:00 | $20 | 20,588 | 150 | 150 |
| /Users/rsbathla/Downloads/contest-standings-189813860.zip | 2026-04-21 19:00:00 | $20 | 20,588 | 150 | 150 |
| /Users/rsbathla/Downloads/contest-standings-189841917.zip | 2026-04-22 19:00:00 | $20 | 19,791 | 150 | 150 |
| /Users/rsbathla/Downloads/contest-standings-189870220.zip | 2026-04-23 19:00:00 | $20 | 19,588 | 150 | 150 |
| /Users/rsbathla/Downloads/contest-standings-189902192.zip | 2026-04-24 19:00:00 | $20 | 19,588 | 150 | 150 |
| /Users/rsbathla/Downloads/contest-standings-189924679.zip | 2026-04-25 13:00:00 | $20 | 11,764 | 150 | 150 |
| /Users/rsbathla/Downloads/contest-standings-189942018.zip | Not in owner entry history | Unknown | 11,764 | 150 | 0 |

BP has 150 rows in each ZIP, totaling **1,350** BP entries. The owner has 150 in each of the six metadata-matched ZIPs, totaling **900** entries. Known files are $20 Classic April 2026 contests; they are not a high-stakes season return sample. The three metadata-unknown ZIPs retain unresolved dates and fees. Empty/nonstandard lineup strings occur in some fields and are counted in the receipt; construction comparisons still require complete-roster validation.

## Unresolved gaps and appropriate use

- A complete audited BP or peer account ledger is absent from these saved sources. Compact source winnings and selected contests cannot certify full-account ROI.
- Contest/source conflicts, missing slots, and unresolved IDs need explicit quarantine or fresh verified recovery. Raw values were left intact.
- Mixed-user shared builds lack exact personal multiplicities. DK entry rows or full per-user blocks are required for an exact weighted portfolio.
- A successful peer cohort selected on the entire evaluation season is retrospective and outcome-selected. A backtest must freeze it on earlier data or label that bias.
- Prior usage/shot-fit features alone do not reveal peer intent. Their pre-lock projections and the owner's exact manual definition of advantage are absent.
- No scoring weight, threshold, credential, original gzip, or database row was changed. No commit was made.

## Checks and receipt

Mechanical receipt acceptance passed: 1,499 source files, 936 BP handle appearances, 31 raw high-fee MME appearances, 19 exact source-count-consistent appearances, two independent cost/entry/payout reproductions, and nine DK Classic ZIPs with 150 BP entries each. Existing canonical roster validation was reused; no new guard was added. Repository integration verification is the parent's combined change gate.

Receipt: `/tmp/nba_peer_inventory_2026-10-01.json`. Existing source logic reused: `tools/fl_nba_harvest.py`, `tools/fl_nba_lineups_harvest.py`, `tools/cohort_harvest.py`, `core/nba_construction_audit.py`, and `nba/analytics/source_quality_audit.py`.

This estate supports qualified construction comparison and direct April entry replay. Saved-source inventory alone cannot establish a peer's full return or a transferable profitable strategy.
