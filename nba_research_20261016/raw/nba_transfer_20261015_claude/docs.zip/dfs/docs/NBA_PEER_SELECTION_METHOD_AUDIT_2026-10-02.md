# NBA peer player-selection audit

Research-method audit, 2026-10-02. Scope: observable player selections by the eight previously frozen older-profitable peers, BPCologna, and the newly requested youdacao. The question is whether their player preferences identify a useful gap in the owner's process. Lineup construction, player-selection quality, and causal knowledge of another user's private process are different estimands. This audit does not change production weights, thresholds, bankroll or optimizer settings.

## FINDINGS — confirmed data and contracts

### Reuse and preserve the existing cohort

`nba/analytics/data/research_peers/frozen_cohort.json.successful_peers` names dacoltz, gregr1224, hixx, jpm11, mazwa, nerdytenor, oxenduck and papagates. Its `requested_benchmark` is bpcologna. The success screen used 2024–25 reported returns, with reported winnings capped at ten times cost per contest; 2025–26 is the evaluation season. Keep these identities fixed when source validation improves. Add youdacao by user request regardless of his older success screen, and identify him as a requested benchmark. Do not rerank the cohort using later player outcomes or replace a later loser with a more successful peer.

`peer_play_review.py` already supplies recovered full user blocks, source/portfolio guards, canonical unordered rosters, owner count/score reconciliation, independent date/week uncertainty and prior-feature joins. Extend those validated grains. `personal_play_review.py:compare_pool` supplies the documented prior shot-allowance proxy, `incremental_forecast_study.py` supplies prior-only model feature discipline, and `ceiling_sources_study.py:scoring_components` supplies an exact descriptive DK scoring decomposition. Existing rolling-model predictions were trained on progressively earlier dates that can include 2025–26; they are not a fixed 2024–25-trained price benchmark and must not be relabeled as one.

The inspected pre-correction `portfolios.parquet` contains 2,325 user-contest portfolios and `lineups.parquet` 244,667 canonical builds, covering ten usernames including the owner. Youdacao has zero rows in this materialization; his recovered blocks need to pass the same guards and be materialized explicitly. This is a data-pipeline fact, not evidence that he did not play.

### Snapshot qualification: pending OKC identity repair

The orchestrator has reported an omitted OKC mapping in the identity validator and is preserving the previous artifact vintage before repairing it. The feasibility numbers in this audit refer to the **pre-OKC-repair, pre-youdacao-extension snapshot**, not final achievable coverage. Its fingerprints are:

- `research_peers/portfolios.parquet`: `bc471251789a991c9674bb5b444f40b53fb5f5a3b64d51318dc1c6857f517e5e`.
- `research_peers/lineups.parquet`: `742a9efb8d44c33868ffd8c665f776dc9a01e4b89d37fb4a2f185938165f3896`.
- `research_v2/research_games.parquet`: `a57949a4efcc5cc930a3a6bfe0114631ba4f6c3488109f439802ec83f99f71ad`.

Corrected source receipts and rebuilt materializations supersede these counts. A missing mapping can reject otherwise valid complete portfolios; it must not be interpreted as a competitor's omission or a genuine absence of usable source data.

### Player features: what exists and what does not

The inspected `research_v2/research_games.parquet` has 47,039 unique `(pid,date)` appearances. `season=2024` has 20,582 rows spanning 2024-10-22 through 2025-03-10; `season=2025` has 26,457 rows spanning 2025-10-21 through 2026-04-12. There are no duplicate player/date keys in this snapshot.

For 2024 and 2025 respectively, `prior_games >= 20` and finite `min_l10/usg_l10` cover 11,025 and 16,339 appearances; adding `shot_features_complete` leaves 9,108 and 13,786. These are player appearances across the feature archive, not selected entries, independently sampled events or accepted peer-contest counts. Observed `tracking_prior10_n` ranges from five to ten among shot-complete rows.

The frame contains prior minutes, usage, FP, attempts, starter rates, own/opponent pace and efficiencies, shot shares/attempt-allowance fit, personal prior-20 ceiling thresholds and role-change proxies. It contains raw `reb`, `ast`, `stl`, `blk`, `tov`, `fg3m` and `fta`, but no lagged rebound/assist/stock features. It contains no contest salary, projected ownership, timestamped injury news, potential assists or rebound chances. Salary must come from validated contest sources; peripherals must be shifted and rolled from existing raw history, rather than taking same-game box-score numbers as predictive inputs.

`peer_play_review.py:feature_pool` currently requires the complete joint minutes/usage/shot feature set and a current-date appearance before any feature is used. This is appropriate for its explicitly qualified joint proxy, but it is too restrictive as a universal selection mask. A minutes-only test should not lose a valid player's history because his shot feed is missing. Reusing current-date appearance eligibility also conditions on realized participation: a selected player who did not appear can disappear from the feature comparison. Keep full source selections and scores, and report this participation conditioning; do not silently call the resulting pool every player who could have been selected.

### Pre-correction feasibility only

Joining peer portfolios to the owner's same contest and restricting `season='2025-26'` gives:

| Inspected pre-correction scope | Unique contests | Dates |
|---|---:|---:|
| High-stakes paired portfolios | 3 | 3 |
| Lower-fee MME paired portfolios | 77 | 50 |
| Lower-fee pairs inside the feature archive's date window | 63 | 41 |
| Lower-fee pairs with any joint-feature-covered slots for both users | 32 | 24 |
| Lower-fee pairs with every slot joint-feature-covered for both users | 1 | 1 |

Only one peer-contest in that last row has complete joint-feature coverage for both sides, and no high-stakes pair does. Distinct peer-contest rows exceed unique contests because several users can share a contest. Counts come from `portfolios.parquet.{cid,date,season,lane,user,feature_slot_coverage}` and the exact same-contest owner join. They are not a final limit after the identity repair or after adding family-specific history masks.

The joint-mask covered dates by existing peer are BPCologna 20, dacoltz 7, gregr1224 8, hixx 14, jpm11 9, mazwa 10, nerdytenor 1, oxenduck 22 and papagates 7. Consequently, a per-peer factor conclusion from this vintage could be supported very unevenly. Do not imply that all peers received equally powerful tests.

### Independent raw rechecks

**Raw eight-slot and zero-sum contract.** `research_peers/raw/2025-02-24_174238080.data.json.gz` reports `contest.entryCost=555`, `multiEntryMax=24`, and 800 source field entries. `users.rsbathla`, `users.bpcologna` and `users.youdacao` each report 24 entries. Independently summing their `lineups.*.lineupCt` reproduces 24 each; expanding every colon-delimited hash reproduces **192 player slots each**. Every supplied hash has eight IDs. Each user selects Zach Collins in all 24 entries.

Exposure differences on that raw fixture, selected by exposure rather than player score, include:

| Player | Peer | Peer exposure | Owner exposure | Difference |
|---|---|---:|---:|---:|
| Quentin Grimes | BPCologna | 45.83% | 8.33% | +37.50 pp |
| Tyrese Maxey | BPCologna | 37.50% | 95.83% | −58.33 pp |
| Trae Young | youdacao | 87.50% | 0.00% | +87.50 pp |
| Tyrese Maxey | youdacao | 33.33% | 95.83% | −62.50 pp |

Summing all player exposure differences gives zero up to floating-point rounding for both peers. This checks the proposed player-gap arithmetic; it does not establish that these players are a general advantage or that the fixture satisfies every accepted-source guard. Neither fixture contest is represented in the inspected accepted portfolio table.

**Raw point conservation and a losing benchmark.** On the same 2025-02-24 fixture, summing `players.*.actualPoints` over each user's hashes, weighted by exact `lineupCt`, gives mean lineup points of 219.8958 for the owner, 235.2292 for BPCologna and 214.5521 for youdacao. Thus a real difference in selections can coincide with either higher or lower observed scores. These are raw-source arithmetic fixtures, not a selected validation success. No tournament profit is allocated to their players.

A second raw fixture, `2026-02-03_187856745.data.json.gz`, has owner and BPCologna 135 entries and exactly 1,080 expanded player slots each. Youdacao is absent from that source user block. Absence means unavailable for that same-contest pair, not zero performance or zero skill. This $111 fixture is outside the $150+ primary high-stakes lane.

## INFERENCES — useful player-selection tests

### 1. Conserve the full player-exposure ledger

For user `u`, player `i`, and contest `c`, define `e[u,i,c] = attributed entries containing i / total user entries`. Every complete Classic portfolio must satisfy `sum_i e[u,i,c] = 8`. The slot-share version `e/8` sums to one. Keep these meanings distinct; 50% exposure means a player occupies one slot in half the entries, not half the portfolio's eight slots.

For peer versus owner, define `delta_e[i,c] = e[peer,i,c] - e[owner,i,c]` on the **union of both full selected-player sets**, retaining zeros on either side. Require `sum_i delta_e[i,c] = 0`. Identify overweights and underweights from these exposure differences before looking at later player points, ceiling hits or payouts. For trait summaries over a complete portfolio, use `sum_i e[i,c]*trait[i,c]/8`.

The exact score identity is `sum_i delta_e[i,c]*actual_DK_points[i,c] = peer_mean_lineup_points[c] - owner_mean_lineup_points[c]`. Reproduce it on every accepted pair. The corresponding salary sum equals the difference in average lineup salary. These are accounting identities, not independent betting observations and not player P&L.

To answer how selected players produced the observed difference, consume `ceiling_sources_study.py:scoring_components`: its guarded components include two-point scoring, three-point scoring plus DK bonus, free throws, rebounds, assists, steals, blocks, turnovers and double/triple-double bonuses. Compute `sum_i delta_e[i,c]*component[i,c]` for each component and reconcile their sum to the covered DK score difference. Carry a separately visible unjoined-player remainder. This can establish that an observed advantage came through assists, rebounds or shooting in the covered games. It does not establish that the peer forecast that source or that the environment caused it. Current-game components are outcomes; they must not assign pregame player types or enter the predictive feature blocks. The existing scorer refuses incomplete boxes and appearances under one minute; retain its guard and do not fabricate components for missing/DNP rows.

Use canonical player IDs with contest/event/team checks; preserve the raw FL ID and full source name for provenance. Never merge distinct players by name alone. One raw user may have several hashes containing the same eight players in different slot orders; consume the canonicalized multiplicities already supplied by `canonical_portfolios`.

For peer-specific results, pair only contests both users actually entered. For a pooled eight-peer benchmark, average eligible peers' portfolios within the same contest, compare the owner once, and then give dates equal weight. Publish the number and identity of peers contributing to each date; a varying available cohort is not the same as all eight peers playing every slate. BPCologna and youdacao remain separately identifiable requested benchmarks.

### 2. Use a frozen price-aware forecast and distinct outcomes

Train a price benchmark only on available **2024–25** records with validated source salary and outcome. A simple salary curve with position controls is a defensible baseline; use a fixed low-complexity or regularized specification and tune any model choices solely by chronological folds within that development archive. The repaired feature archive stops on 2025-03-10, so any history-enhanced model using it is trained on the available partial development season, not an invented complete 2024–25 feature year.

Join candidate players and salaries from validated full contest sources. Multiple contests on a date can repeat the same player-game, salary and outcome; deduplicate training contexts or weight each player-game equally across its observed slate/price contexts. A player's score must not become 20 independent target observations because he was in 20 contests or 150 entries. Different salaries on different slate definitions are separate priced contexts, not automatic source errors; they still share one game outcome.

Freeze the fitted model, training maxima, transformations, hyperparameters and salary support before evaluating 2025–26. Report heldout calibration and error on a source-defined player pool, then on the selected pool. Flag salary or history regions outside development support. Do not describe a source's final `projPoints` as a timestamped pre-lock forecast. It may be a separately labeled retrospective sensitivity, never the primary price benchmark.

Define the player residual `r[i,c] = actual_DK_points[i,c] - expected_2024_points[i,c]`. The paired selection residual gap `sum_i delta_e[i,c]*r[i,c]` measures whether one portfolio scored better than this frozen price baseline expected, given its choices. A higher expected-points portfolio and a positive unexpected residual are different findings; publish both. Also publish raw points and salary gap so forecast error cannot hide the actual result.

The secondary personal-ceiling endpoint is existing `rolling_p85`, defined against `p85_prior20`, with at least 20 prior appearances and strictly prior thresholds. Its exposure-weighted rate is `sum_i e[i,c]*rolling_p85[i,c]/8` on a fully eligible pool. A personal ceiling is not salary value, a top-1% lineup, or tournament profit. Never substitute `season_top15` or `season_p85` as a prospective label.

Players with short history must remain in full exposure and raw-score accounting. A salary-only model can provide a separately labeled fallback where valid training support exists; history-enhanced models require their explicit minimum history. Do not fabricate a personal ceiling for a rookie or impute short-history usage from the current game. Show fallback and unmodeled slot fractions by user.

### 3. Separate full-slot accounting from feature-qualified comparisons

Use a distinct eligibility mask for each factor family, shared by both users on that contest. Missing shot fields do not disqualify price-only, prior-minute or peripheral analysis. No missing value becomes zero, median usage or an absence flag.

For feature-covered player set `K`, partition any additive quantity into `sum_K delta_e*x` plus the uncovered contribution; covered exposure differences generally **do not** sum to zero. Report each user's covered slot mass and their mass difference. Renormalizing each user's covered weights to sum to eight invents a redistributed portfolio. If normalized means are useful, call them conditional means per covered slot, not full-lineup gains.

The strongest full-slot residual comparison requires supported forecasts for every selected player on both sides. When this is unavailable, report full raw-score difference plus the modeled contribution and unknown remainder, or a clearly labeled conditional selection test. Do not generalize a tiny fully covered shot subset to the annual process.

If feasible, construct prior-history features as of the slate date for all source-selected players, including a player with no current appearance, using only games strictly before that date. Current opponent must come from validated slate event/team identity, and rolling history must include the latest prior game rather than reusing its already-shifted row. This repairs participation conditioning; it does not recover private injury news. If only current-date feature rows are used, explicitly label the analysis appearance-conditioned and report selected non-appearance/missing-date slots separately.

### 4. A bounded prior-only factor family

Use six predefined blocks, with model choices frozen on development data. Preserve all-block and matched-mask baseline comparisons; a block must not receive a better baseline simply because it excluded difficult rows.

| Block | Feasible prior inputs | Main qualification |
|---|---|---|
| Opportunity | `min_l10`, `usg_l10`, `fga_l10`, `fpm_l10` | Prior averages only; current minutes and usage are outcomes |
| Shot fit | `fit_cs`, `fit_pu`, `fit_lt10`, prior shares, opponent prior attempt allowances, `tracking_prior10_n` | Attempt-allowance proxy; no shot-quality or private play-type inference |
| Environment | `own_pace_l10`, `opp_pace_l10`, own/opponent prior efficiencies, `opp_dvp100` | No closing or opening market fields as pre-lock facts without timestamp receipts |
| Peripherals | Lagged prior rebound/assist/steal/block/turnover rates derived from existing raw history | Box-score rates, not rebound chances or potential assists; denominator/minute guards |
| Price relative to prior opportunity | Prior `expected_fp_simple/(salary/1000)` or a frozen salary-by-prior-production interaction; comparable prior saved-slate price change only if supported | Research price-to-history proxy, not assumed underpricing; the salary-only baseline already includes raw salary |
| Role change | `min_l5-min_l20`, `usg_l5-usg_l20`, prior starter-rate change, `days_since_played` | Role proxy; no diagnosis of injury, private news timing or current starter assumption |

Shift each peripheral component before rolling, across chronological player history and explicitly handled team stints. Rebuild on the same existing history rather than joining current rebounds or assists as predictors. Do not count a zero-minute denominator as a valid per-minute rate. Label the proxy's observation count.

For shot fit, use continuous prior exposure-times-softness features where feasible. The older dominant-category/softest-slate-quartile flag remains a descriptive proxy: guard at least four represented opponents before calling its cutoff a slate quartile, show ties, and never interpret a restricted slate percentile as an absolute league defense tier. Verify that prior share and opponent data meet the existing shot-completeness contract. An opponent allowing many attempts is not proof that a selected player enjoyed better shot accuracy or more scoring opportunities in that game.

First test whether each nonredundant block improves heldout prediction over the frozen price baseline on the **same rows**, using a prespecified mean-absolute-error difference averaged by unique player-game and then date. Ceiling-model Brier loss can remain a labeled secondary outcome. Raw salary cannot be credited as an incremental factor when the baseline already contains it; the price-relative-to-history block must add a prespecified supported interaction/proxy or remain descriptive with its inferential test unperformed. Then describe whether peers overweight players scoring highly on that prior block, and whether the associated residual gap persists in 2025–26. A block can explain an expected-points difference without proving unexpected skill. A statistical coefficient cannot establish that the competitor used that factor or caused the eventual outcome.

For primary inference, use one prespecified residual-gap endpoint for each of the ten named peers and correct that ten-test family, and six prespecified block-loss comparisons for the fixed older-profitable cohort, corrected as their own six-test family. Keep personal-ceiling, type-by-peer interactions and detailed named-player tests descriptive unless their expanded family is declared and corrected. Sixty peer-by-factor searches cannot inherit a six-test correction.

Repeated contests, the same game across users, and every entry containing a player remain jointly dependent. Aggregate or resample whole dates, carrying all user/player/pair/model rows together. Use full calendar-week blocks as a persistence sensitivity. Report distinct dates and weeks, not only slot counts. With small date counts, exact tests or broad intervals may be more honest than asymptotic significance. No extra positive evidence is earned by duplicating the owner's same selected player across all peer comparisons.

### 5. Show names and player types without winner selection

For every named peer, publish the complete paired player-exposure ledger or its accompanying data file. The written cases should select the largest positive and negative exposure differences, with a minimum exposure/date count declared before observing outcomes. Also select repeated names by absolute exposure difference across equally weighted paired dates. Sorting first by positive realized residual or by winning-lineup membership creates a winner story; it is allowed only as explicitly secondary illustration with the failures also shown.

For each selected case, show source name, player ID, date, salary, peer/owner exposures, prior minutes/usage and role change, available prior shot/environment/peripheral fields, frozen expected points, actual points, residual and personal ceiling eligibility. Include both favorable and unfavorable outcomes and at least one high-exposure peer loss. Describe observed facts, for example "higher prior assist rate and a positive price-adjusted residual," not "he knew the injury would open assists" or "he targeted the exact ceiling."

Define player types from prior data or development-season cuts: high-minute/high-usage scorers, low-price rising-minute players, rebound/assist-oriented players, catch-and-shoot or pull-up-heavy profiles, and high-prior-volatility profiles are feasible descriptions when fields support them. Keep overlapping type memberships rather than forcing every player into one exclusive label. Missing fields produce an unclassified type. Current points, current starter status, winning percentile and eventual game usage must not assign a type.

## ASSUMPTIONS / UNRESOLVED GAPS

- The primary high-stakes and lower-fee lanes remain separately labeled; $150 fee and 20 personal entries are declared research definitions. Official $20 validation can corroborate final selection and rank distributions, not peer financial return without prize records.
- The OKC mechanical repair can change accepted coverage, not the frozen peer identities or the old cohort's historical selection rule. Rebuilt receipts must replace the pre-repair feasibility table before final evidence is generalized.
- Current source `players.actualPoints` is an observed score, not a pregame predictor. A missing feature-game join is not automatically a zero or a DNP; a source-recorded zero is still a score whose reason remains unknown.
- Existing raw rosters, source-internal counts and owner DK score/payout checks support different validation tiers. The owner's DK validation does not independently certify every competitor's raw source score or financial return.
- No source inspected here reconstructs private forecasts, projected ownership, injury timing, real-time swap intent, optimizer constraints, bankroll or unobserved contests. Selection patterns can support a measured hypothesis, not an attribution of private reasoning.
- All proposed fitted coefficients are research forecast parameters. No production composite weight or live threshold is added by this audit.

## CONFLICTS

Using the current joint shot mask for every analysis would discard valid non-shot evidence. Renormalizing missing selected slots into a complete portfolio would violate the eight-slot accounting contract. Using current appearance to define a full pregame candidate pool would condition on an outcome. Training a supposedly 2024–25-only baseline on existing rolling predictions that include 2025–26 would violate the chronological holdout. Winner-selected names or outcome-defined player types would violate the exposure-first comparison. Assigning P&L to player exposures would invent a monetary allocation. Source rejection from the omitted OKC mapping must not be treated as genuine source scarcity or a player's strategic omission.

## DECISION POINTS

Recommendation: preserve the original eight identities, add both requested benchmarks, rebuild source eligibility after the mapping repair, publish full-slot player exposure differences and price-aware outcomes first, and then run the bounded prior-factor tests on explicitly covered scopes. If feature coverage remains limited, return player names and measured score contributions with unknown reasons instead of forcing a statistically significant explanation. A process gap needs repeated prior-defined selection differences, later salary-aware performance evidence and enough independent dates; another user's large win alone is insufficient. Any later decision to change forecasts, player exposure caps, lineup constraints or bankroll allocation belongs to the owner after reviewing those results.

## Self-critique and final gap pass

The audit preserves losing peers and underweights, treats missing exposure as unknown rather than a signal, and separates portfolio score arithmetic from tournament finance. It explicitly addresses salary support, partial-year training, final projection timestamps, short player history, missing shot feeds, realized-participation conditioning, team identity, canonical duplicate builds, repeated player-game targets, different slate prices, and multiple testing. Two raw source fixtures independently verified the numerical eight-slot contract; one additionally verified zero-sum exposure differences and source point conservation. Proposed guards still require known-bad tests: seven-player roster, same-player bridge collision, future/current peripheral feature, out-of-period forecast receipt, missing shot field with valid minutes, non-appearance selected player, fractional/negative multiplicity, zero-minute rate denominator, and a same-day outcome duplicated into train and test. Include valid controls for every guard. None of this constitutes evidence that a tested factor already worked; outcomes require the orchestrator's completed replay and rebuilt source receipts.
