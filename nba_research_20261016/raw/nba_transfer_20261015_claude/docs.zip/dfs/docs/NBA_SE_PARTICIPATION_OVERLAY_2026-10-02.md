# NBA single entry participation and role review

This review overlays the verified BPCologna, youdacao and Ramneik selections with actual NBA participation, earlier role history and named nonparticipating contributors. It preserves all 496 submitted slots. Box-score coverage resolves 248 slots across 18 dates: 247 positive-minute appearances and one listed player with no positive appearance. The other 248 slots remain unknown, including the March 12, 2025 contests beyond the older feed's March 10 endpoint. These counts come from [summary.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_participation/summary.json), `selected_slot_states` and `supported_dates`.

Actual participation describes what happened. It does not establish what either peer knew before lock. Neutral observations for each user appear first; comparisons and proposed tracking follow.

## BPCologna observations

The recovered 2025–26 sample contains ten dates and 80 selected slots. All 80 have positive raw minutes; 69 were actual starters. Fifty-nine selections had at least one other bracketed key contributor with no positive appearance. A key contributor means at least 20 minutes per appearance over up to ten earlier same-team appearances, with at least three required. Sixty selections had a key nonparticipant listed in that source contest; 17 had at least one such listing outside the existing participation bracket. These categories overlap and must not be added. Source: [selected_slots.parquet](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_participation/selected_slots.parquet), `user`, `season`, `played`, `actual_starter`, `bracket_key_absence`, `listed_key_nonparticipant`, `listed_outside_bracket_key`.

Nine selected players actually started after starting at most 20% of their up-to-five earlier same-team appearances. These nine selections occurred on five dates and all had a bracketed key nonparticipant. Earlier starter history is known for 63 of the 80 slots. Seven selected actual starters had prior minutes below 20, also with bracketed key nonparticipation. These are observations of opportunity, not evidence of an unexpected promotion or a correct minutes forecast. Source: `starter_after_bench_history`, `prior_starter_fraction`, `prior_low_minutes_starter`, `prior_min`, `date` in the selected-slot table.

## youdacao observations

The recovered 2025–26 sample contains four dates and 32 slots. Thirty-one players have positive raw minutes; 26 were actual starters. Twenty-seven selections had bracketed key nonparticipation, 29 had a source-listed key nonparticipant, and 14 had a key listing outside the bracket. Seven actual starters had mostly bench history, across all four dates; all seven had bracketed key nonparticipation. Starter history is known for all 32 slots. Four actual starters had prior minutes below 20. Source: the same selected-slot fields, filtered to `user=youdacao`, `season=2025-26`.

Patrick Baldwin is the one selected nonparticipant, on March 11. Other listed players resolve his archived Sacramento event to the Charlotte–Sacramento game, but the raw feed contains no positive-minute appearance for him. His $3,000 listed salary and prior 10.90 minutes do not establish why he was selected, whether a swap occurred, or what was known before lock. Source: `cid=188750204`, `pid=1631116`, `participation_state=listed_no_positive_minutes`, `salary`, `prior_min`; independently checked in `summary.json.raw_rechecks`.

## Ramneik observations

Your recovered 2025–26 sample contains four dates and 32 slots. All selected players have positive raw minutes; 26 were actual starters. Twenty-two selections had bracketed key nonparticipation, 22 had source-listed key nonparticipation and eight had a key listing outside the bracket. Four actual starters had mostly bench history on two dates; all four had bracketed key nonparticipation. Starter history is known for 23 of 32 slots. Two actual starters had prior minutes below 20. Source: selected-slot fields filtered to `user=rsbathla`, `season=2025-26`.

## Observed participation contexts

These are counts of selected slots in the recent sample. They are not independent player observations: the same NBA player can be selected by multiple users. The history denominator is shown separately because an early-season player can have a known box score and insufficient prior history.

| Observed context in 2025–26 | BPCologna | youdacao | Ramneik |
|---|---:|---:|---:|
| Dates with resolved selections | 10 | 4 | 4 |
| Selected slots with positive minutes | 80/80 | 31/32 | 32/32 |
| Actual starters | 69/80 | 26/32 | 26/32 |
| At least one bracketed key nonparticipant | 59/80 | 27/32 | 22/32 |
| Actual starter after mostly bench history | 9/63 known | 7/32 known | 4/23 known |
| Actual starter with prior minutes below 20 | 7/63 known | 4/32 known | 2/23 known |

Source: canonical slot deduplication by `user,date,candidate_pool_signature,roster,flpid` in `selected_slots.parquet`. These recent supported rosters do not repeat across rooms; older duplicated rooms remain collapsed in the episode tables.

Across both covered seasons, the mostly-bench-history starter counts are 13/110 known slots for BPCologna on eight dates, 10/55 for youdacao on seven dates, and 5/39 for you on three dates. Every one of those selections has a source-listed key nonparticipant context. Bracketed nonparticipation covers 12/13, 8/10 and 5/5 respectively. These remain partial-history slot counts, not complete-roster averages. Source: the same canonical selected-slot rows, both supported seasons, `starter_after_bench_history`, `listed_key_nonparticipant`, `bracket_key_absence`.

## Shared contest comparisons

A direct comparison uses an actual owner-shared contest and identical complete coverage on both eight-player rosters. The unmatched counts above cannot establish a difference in user process.

| 2025–26 roster measure | BPCologna versus you | youdacao versus you |
|---|---|---|
| Actual starter fraction | 81.25% versus 81.25%, four dates | 75.00% versus 81.25%, two dates |
| Bracketed key nonparticipant fraction | 65.63% versus 68.75%, four dates | 87.50% versus 87.50%, two dates |
| Starter after mostly bench history | 6.25% versus 12.50%, two dates | 12.50% versus 12.50%, two dates |
| Actual starter with prior minutes below 20 | 12.50% versus 12.50%, two dates | 6.25% versus 12.50%, two dates |

Source: [paired_profiles.parquet](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_participation/paired_profiles.parquet), `complete_dates`, `peer_value`, `owner_value`, metrics `actual_starter`, `bracket_key_absence`, `starter_after_bench_history`, `prior_low_minutes_starter`. Means weight roster variants equally within a pool, pools equally within a date, and dates equally within the season. Unpaired standalone contests add no owner comparison.

On the two shared dates with complete prior minutes, BPCologna's actual minutes exceeded earlier minutes by 3.00 per selection versus your −1.83; youdacao's excess was 3.33 versus the same −1.83. That is a realized opportunity difference worth reviewing, but two dates and retrospective minutes do not prove better projections or identify a decision rule. Source: paired profile metric `realized_min_change`. Current minutes and usage are excluded from inherited prior shot metrics and are never called pregame predictors here.

## Other players on the same slate

For each positive-minute selection, the overlay also describes other source-listed players who actually played in that contest, with the same listed primary position and inherited salary band: at most $5,000, above $5,000 and below $8,000, or at least $8,000. The focal NBA identity is excluded. This is a retrospective comparison group; it does not certify a legal DraftKings replacement, roster feasibility or pre-lock availability.

On complete recent rosters, selected actual starters exceeded those comparison-group means by 26.45 percentage points for BPCologna over nine dates, 22.55 for youdacao over three, and 16.43 for you over four. The mostly-bench-history starter measure also exceeded its corresponding means: 13.61 points over seven dates, 17.12 over three and 7.91 over two. Coverage differs by metric, and Baldwin's nonappearance contributes no fabricated active-player alternative baseline. Source: [profiles.parquet](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_participation/profiles.parquet), `complete_dates`, `complete_date_mean`, metrics `alternative_difference_actual_starter` and `alternative_difference_starter_after_bench_history`.

The same-contest comparison still does not establish a peer-only pattern. The difference between BPCologna and your bench-history baseline excess is −4.79 percentage points on two complete dates; youdacao's is +0.69 points on two. No significance test or selection model was fitted. Source: paired profile metric `alternative_difference_starter_after_bench_history`, `difference`, `complete_dates`.

## Examples of what the overlay adds

On February 24, both peers selected Gui Santos and you did not; all three selected Brandin Podziemski. Santos was an actual starter, played 39.33 minutes, and had already averaged 28.13 minutes with starts in all five earlier appearances. This is an established recent role by that date, not a new-starter example. The raw source contains no positive appearance for Stephen Curry or Al Horford, both bracketed key contributors. Jimmy Butler is separately recorded as a source-listed key nonparticipant outside the bracket because he never returned later in the covered season. A zero bracket count would therefore be an unsafe substitute for full availability. Source: selected slots `cid=188339631`, `pid=1630611`, named absence columns; original `raw_player_2025.parquet`; `summary.json.raw_rechecks`. Existing role data names Santos's February 3 detection a minutes increase; no same-day starter promotion is inferred.

On March 11, both peers selected Killian Hayes at $3,100. He had eight earlier contiguous Sacramento appearances, averaged 14.36 minutes, and started none of the earlier five; he actually started and played 30.78 minutes. His prior usage was 15.91%, versus actual 16.79%. The raw feed has no positive appearance for the four bracketed key names—Devin Carter, Dylan Cardwell, Malik Monk and Russell Westbrook—or the three source-listed key names outside the bracket—Domantas Sabonis, Keegan Murray and Zach LaVine. This illustrates how a selection with modest earlier usage can acquire substantial minutes in a different participation context. It does not establish injury causes, membership for the source-only names, or the peers' private reasoning. Source: selected slots `cid=188750204`, `pid=1630165`; original catalog user roster and `raw_player_2025.parquet`, independently rechecked.

The independent audit also checked an older example: BPCologna's February 21, 2025 Ryan Rollins selection at $3,600. Rollins actually started and played 33.67 minutes after 12.96 earlier minutes and an earlier-five start fraction of 20%. The raw feed has no positive appearance for Damian Lillard or Taurean Prince; Bobby Portis is a separate source-listed key nonparticipant outside the bracket. Source: selected slots `cid=174148129`, `pid=1631157`; original standalone user roster and `raw_player_2024.parquet`.

## What this suggests tracking

The observable common pattern is **role opportunity in the day's participation context**, alongside established starters. Both peers repeatedly selected that pattern, and you did too. The small shared sample does not show that you omitted it more often. The observed minute differences raise a narrower question: how accurately did each process forecast the size of the opportunity?

For future slates, the useful record would keep your usage and shot-type advantage together with the expected minutes and role **after** availability news. Specifically, record projected minutes versus recent same-team minutes, announced starters, which creators/scorers/bigs are unavailable, the expected redistribution of attempts and assists, and the timestamp of each assumption. Record your passed-over same-price choices too, so a later review compares the decision's alternatives. These are proposed logging fields, not new scoring weights or a verified peer method.

Your usage-plus-shot-type approach is not contradicted by this overlay. Participation can change who receives the shots and how many minutes a favorable shot mix can be used. The unchanged inherited shot fields remain present with their own missingness; this review does not retest their upside significance or pretend that dated Synergy/injury/projection histories have been recovered.

## Evidence and validation

The output separates actual participants, existing bracketed absences, source-only nonparticipant listings, earlier same-team role history and inherited role detections. Source-only listings do not establish current teammate membership. Absence causes and pre-lock timing remain unknown. Actual boxes also have some team-minute reconciliation discrepancies, preserved in normalization rather than repaired; the overlay never certifies exhaustive roster or availability coverage.

Earlier windows use strictly earlier positive-minute appearances, including subminute appearances, and reset at observed team changes. At least three nonmissing values are required per selected-player statistic. Existing panel windows retain their original definitions unchanged. Existing role events retain their earlier-ten versus later-five rule, minimum history and cooldown. `role_up_regime` means the latest inherited event was a role increase, not a new starter, a current increase or necessarily a recent event.

The builder verifies original raw cache receipts, the exact current core used by the saved role study, and independently reconstructs every inherited participation-bracket/prior-role row. It pins all source and output hashes and then recomputes every saved overlay table. Known-bad tests cover malformed minutes/starters, false nonparticipation, unsupported dates, future/cross-team history, terminal bracket omissions, self-counting, corrupted prior roles, duplicate source identities, fabricated standalone owner pairs, partial rosters and rewritten output hashes. Focused test and both strict-gate results are recorded in [final_validation_receipt_2026-10-02.json](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_peer_participation/final_validation_receipt_2026-10-02.json).

Verification completed: 171 focused SE tests passed. The NBA strict integration gate and the Fantasy strict integration gate both exited 0. No production scoring, lineup optimizer or fitted preference rule changed.
