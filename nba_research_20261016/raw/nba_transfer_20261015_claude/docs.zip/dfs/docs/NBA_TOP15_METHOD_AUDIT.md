# NBA top-15% study: independent method and source audit

Audit date: 2026-09-22. Scope: the repaired historical player frames, daily tracking extracts, saved season Synergy tables, and the separate `top15_study.py` research build. This audit changes no production percentile, scoring weight, trigger threshold, or roster fact. All season labels below are NBA season start years. Source code references describe the version read during this audit.

## Source facts

The daily shot data supports player-game descriptions of catch-and-shoot (`cs`), pull-ups (`pu`), attempts from less than 10 feet (`lt10`), defender distance of 6+ feet (`wo`), and defender distance of 0–2 feet (`vtight`). These are the literal query mappings in `nba/analytics/pull_tracking.py:21-26`; `DateFrom=DateTo` and `PerMode=Totals` appear at lines 34–40. The CSVs retain `date`, `nba_pid`, `tag`, `fgm`, `fga`, `fg3m`, and `fg3a`. The repaired frames retain the corresponding attempt counts, prior-game player averages, and prior opponent attempt-allowed ranks; they do not retain makes by category.

| Source / fields | 2024–25 | 2025–26 |
|---|---:|---:|
| `frame_2425.parquet` / `frame_2526.parquet`: rows, `pid`, `gid` | 19,310 rows; 551 players; 907 games | 25,039 rows; 582 players; 1,164 games |
| Frame `date` range | 2024-10-22 through 2025-03-10 | 2025-10-21 through 2026-04-12 |
| Frame distinct `date` | 121 | 154 |
| `tracking_2024-25.csv` / `tracking_2025-26.csv`: rows | 64,442 | 83,687 |
| Tracking distinct `nba_pid` | 544 | 582 |
| Observed `date × tag` / expected from frame dates × five tags | 605 / 605 | 770 / 770 |
| Duplicate tracking `date × tag × nba_pid` | 0 | 0 |
| Synergy player-offense source rows / distinct `PLAYER_ID` | 3,380 / 438 | 3,364 / 439 |
| Synergy team-defense source rows / distinct `TEAM_ID` | 330 / 30 | 330 / 30 |

Sources: `nba/analytics/data/frame_{2425,2526}.parquet`, `tracking_{2024-25,2025-26}.csv`, and the matching `data/synergy/<season>_{P_offensive,T_defensive}_*.csv`. Counts above were recalculated directly from these files.

Each season has 11 saved player-offense and 11 team-defense Synergy tables. They are season aggregates, not player-game play-type observations: the puller sends season, entity, group and play type (`pull_synergy.py:32-37`) and the saved tables have season/team/player/play-type fields, without game dates. They can describe a season's archetype; they cannot establish that a particular top-tail game contained more rolls, cuts, isolation possessions, or putbacks. The repaired `synergy_yearahead.profiles` sums team stints before ranking possessions and uses an explicit alphabetical tie rule (`synergy_yearahead.py:62-75`). Full-season Synergy summaries remain descriptive when attached to games from the same season.

### Coverage of the saved current-roster snapshot

`data/roster_snapshot_2026.json` records 573 distinct `pid` values across 30 teams, retrieved at `2026-09-22T04:01:21.014608+00:00` from the official players page. Its metadata limits the snapshot to a current roster listing, not opening-night eligibility or contract status. Exact-ID intersections give:

| Among 573 snapshot players | 2024–25 source sample | 2025–26 source sample |
|---|---:|---:|
| Has historical frame games and some positive tracked diet attempts | 389 | 463 |
| Has at least 50 historical frame games | 147 | 274 |
| Appears in at least one saved Synergy player table | 343 | 403 |
| No historical frame rows | 184 | 110 |

All 582 historical 2025–26 frame players have some positive tracked diet attempts; 543 of 551 historical 2024–25 players do. These season-level coverage counts do not undo missing individual appearances. The 110 current-list players without a 2025–26 frame cannot receive a local 2025–26 top-tail profile; their absence from this sample does not establish that all are rookies.

### The frame is a source-labelled subset, not every game in the raw feed

`build_season.py:30` keeps player rows whose `BIGDATABALL DATASET` contains `Regular`. The raw 2024–25 team workbook contains 1,814 such rows, representing 907 games, plus 124 rows labelled `NBA 2024 In-Season Tournament`, representing 62 games. The raw 2025–26 team workbook contains 2,328 regular-labelled rows, representing 1,164 games, plus 134 tournament-labelled rows, representing 67 games. Every regular-labelled game is present in its frame; the extra source-labelled tournament games are excluded. The companion report subsequently cites the official NBA Cup rule, verified by the orchestrator, that all Cup games except the championship count toward regular-season statistics. This audit independently established the raw label exclusion but did not repeat that web verification. Accordingly, the omitted regular-season-eligible Cup games are a completeness defect. The remaining local task is to map the raw tournament rows to eligible games, exclude the final, and reconcile the earlier partial feed. The report identifies the current universe and shorter 2024–25 window explicitly. Repair changes rolling histories and outcome quantiles and needs a deliberate rebuild, not a prose correction alone.

Sources: `/Users/rsbathla/Downloads/03-10-2025-nba-season-{player,team}-feed.xlsx` and `/Users/rsbathla/Downloads/04-12-2026-nba-season-{player,team}-feed.xlsx`, fields `BIGDATABALL DATASET` and `GAME-ID`. Input fingerprints are preserved in `data/rebuild_input_provenance_2026-09-22.json`.

### Shot categories overlap and coverage is not established by date-level success

The defender-distance tags classify a different dimension from the shot-diet tags. Adding all five counts is invalid. Raw box-score comparisons establish this directly:

| Frame joined to the same raw player workbook, by `pid/gid` | 2024–25, n=19,310 | 2025–26, n=25,039 |
|---|---:|---:|
| `cs + pu + lt10 == FGA` | 18,451 | 23,800 |
| Three-category sum below box `FGA` | 857 | 1,206 |
| Three-category sum above box `FGA` | 2 | 33 |
| All five category counts summed exceed box `FGA` | 15,746 | 20,590 |
| Three-category sum zero despite box `FGA > 0` | 38 | 53 |
| No tracking row in any category despite box `FGA > 0` | 38 | 51 |
| Box attempts on those entirely missing tracking rows | 299 | 285 |

Total three-category attempts versus box attempts are 160,807 / 162,093 in 2024–25 and 205,448 / 207,383 in 2025–26. Therefore a sum of the three categories should be labelled **tracked diet attempts**, not an exact box-score total. Shares using that denominator are within the measured shot diet, not automatically shares of all official attempts. No shot-level identifiers are saved, so exact intersections between the two classification dimensions cannot be reconstructed.

The missing-player evidence includes large-minute, high-attempt appearances, not just one-attempt edge cases. On 2025-02-28, game `22400856` has 189 box attempts from frame players but zero tracked attempts in all three diet categories. On 2025-01-07, 13 player appearances in Boston–Denver have no tracking row despite 104 combined box attempts. On 2026-03-05, missing positive-attempt appearances occur in six games; examples include Rudy Gobert (8 box FGA), Julius Randle (11), and Draymond Green (6). A date/category response existing elsewhere on the slate does not make an absent player/category row a proven zero.

Bounded handling: keep these game labels and non-shot evidence; mark the affected player's shot observation unavailable for shot summaries rather than zero. Maintain a distinct missingness count and do not convert an unknown share into zero. Player-game shot quality does not repair saved opponent histories: affected team-game totals can contaminate later `strank_*` values. Those funnel observations require a sensitivity check or explicit exclusion flag covering the lookback windows, or must remain provisional. Small differences between tracking and box counts alone do not identify which source is wrong and should not be silently “corrected.”

## Label and statistical design

**Descriptive target.** For each player within one source-labelled season sample, compute the empirical 85th percentile of `fp_dk` and select scores strictly greater than it. This is a valid retrospective question. It intentionally uses the season's eventual outcome distribution and must not be described as a pregame label available at the time. Strict thresholding and finite samples mean the selected fraction need not be exactly 15%.

Independent raw-frame calculation, without player eligibility restrictions:

| Label / fields | 2024–25 | 2025–26 |
|---|---:|---:|
| `fp_dk > groupby(pid).fp_dk.quantile(.85)` | 3,018 / 19,310 = 15.629% | 3,862 / 25,039 = 15.424% |
| Games exactly equal to the season p85 threshold | 152 / 19,310 | 204 / 25,039 |
| `fp_dk > prior-20-games p85`, minimum eight prior games | 3,190 / 15,177 = 21.019% | 4,181 / 20,638 = 20.259% |

**Validation target.** The rolling p85 uses only earlier results and avoids leaking the threshold. It answers a related adaptive-ceiling question, not precisely the same question as final-season top-tail membership. Report its observed base rate and evaluation n; calling its rate “15% by definition” would be false in these samples.

**Chronological validation.** H1 features and outcomes may identify a direction; H2 evaluates that locked direction. Each player–axis condition needs at least ten observed on games and ten observed off games in each half under the stated design. Missing source state is neither on nor off. Exposure eligibility should be based on sample counts, not whether a significant result appears. Every eligible tested player–axis pair belongs in the reported multiplicity family; apply global Benjamini–Hochberg before selecting favorable examples. If H1 supplies a screening gate, disclose that gate and the precise H2 family rather than describing an uncorrected attractive subset as validated. Specify whether the hypothesis family spans one season or both, whether tests are one- or two-sided, and whether negative associations are investigated.

Benjamini–Hochberg addresses the declared family of tests; it does not establish causality, eliminate role-change confounding, or make repeated games independent. Same-game minutes, USG and shot attempts are realized mechanisms. A higher value during games selected for high fantasy points does not establish a usable predictor or an exposure adjustment. Opponent `strank_*` measures prior per-game category attempts conceded, not opponent shooting efficiency or a causal scheme advantage; it is not pace-adjusted.

## Usage, absence and environment source checks

The repaired frames' `usg` and `min` match the corresponding raw `USAGE RATE (%)` and `MIN` values on all 19,310 joined 2024–25 rows and all 25,039 joined 2025–26 rows. The following upstream values exceed 100:

| Season | Player / pid | Date | MIN | USG |
|---|---|---|---:|---:|
| 2024–25 | Antonio Reeves / 1641810 | 2024-10-23 | 1.0000 | 163.7666 |
| 2025–26 | Dalen Terry / 1631207 | 2025-11-02 | 1.2000 | 107.2961 |
| 2025–26 | Kobe Sanders / 1642920 | 2026-03-31 | 1.3667 | 105.2396 |

No USG nulls or negative values occur in either frame. Exclude these out-of-range values from usage summaries, not from the outcome/game sample. Do not cap them to 100 silently. Short appearances remain common: fewer than five minutes occur in 1,579 / 19,310 rows in 2024–25 and 1,874 / 25,039 rows in 2025–26; fewer than ten minutes occur in 3,000 and 3,602 rows respectively. A mean of per-game USG gives each appearance equal weight. Any alternative minute-weighted summary or minimum-duration sample must be named explicitly; do not select whichever produces a stronger trend. Player-season sample size, minutes and team/role changes should accompany narratives.

`f_key_out`, `f_2key_out`, and `f_samepos` are retrospective participation proxies. The source code now preserves positive sub-minute appearances in its participant set (`build_season.played_rosters`), repairing the previously confirmed false outs. It still infers absence from a candidate last seen in the prior three team games, with prior expected minutes at least 22. It does not know an injury diagnosis, the time an absence became public, whether a player was traded, or long absences that aged out of this candidate window. The study may call these **missing recent rotation players** or **participation proxies**, not verified injuries. Current `n_key_out` summed once per team/game is 1,376 over 1,814 team-games in 2024–25 and 2,017 over 2,328 team-games in 2025–26.

| Unavailable continuous source state | 2024–25, n=19,310 | 2025–26, n=25,039 |
|---|---:|---:|
| `game_pace` | 1,738 | 1,633 |
| `dvp_rank` | 2,694 | 2,708 |
| `wd_rank` | 1,669 | 1,585 |
| Each `strank_cs/pu/lt10/wo/vtight` | 1,669 | 1,671 |
| `itt` | 0 | 0 |

Many stored boolean comparisons encode unavailable early-season state as `False`. The study should restore missingness using the corresponding continuous source column before computing on/off rates. Pace measures prior ten-game team pace with a minimum five-game history; its flag is relative to that day's game distribution, not a permanent league threshold. `itt` is derived from source closing spread/total; the files do not supply a DFS-lock timestamp. These are market-context associations, not proof that the quoted line was available at slate lock. Saved nonnull ranges are pace 94.218–104.699 and ITT 94.75–129.75 in 2024–25; pace 93.184–104.910 and ITT 96.0–135.5 in 2025–26. No extreme-range anomaly was established by this probe.

## Two-round audit and remaining gaps

The first round inventoried repaired frames, taxonomy, source granularity, invalid USG, unavailable warmup states, and p85 definitions. Gaps identified before the second round were: whether invalid usage came from the raw feed, whether shot categories matched official attempts, whether date-level pull coverage concealed missing players, and whether frame games covered every raw source game.

The second round joined both raw player workbooks on exact `PLAYER-ID/GAME-ID`, inspected raw team dataset labels, and matched the tracking identity/date universe. It closed the USG provenance and frame-join questions, proved shot overlap, located missing positive-attempt players, and exposed the tournament-labelled exclusion. Remaining gaps that local saved fields cannot close are: exact source failure causes for missing tracking, timestamped injury/market availability, the exact mapping of raw tournament rows to the subsequently verified league inclusion rule, shot-level intersections, and causal adjustment for changing roles or opponents.

## Standalone runner and artifact review

The completed `nba/analytics/top15_study.py` and the generated `data/top15_{profiles,player_factors,league_factors,chronological_validation}.csv`, `top15_games_2526.parquet`, and `top15_summary.json` were inspected read-only. The runner preserves production `hit`/p75 and adds separate `season_top15`, `season_p85`, `rolling_p85`, and `p85_prior20` research fields. Its inferential player cohort requires at least 50 appearances in the season source sample: 163 historical players in 2024–25 and 281 in 2025–26. This is a retrospective cohort criterion, not a requirement knowable early that same season.

The runner now masks the 38 / 53 suspect positive-box-FGA, zero-diet observations in 2024–25 / 2025–26, records `tracking_missing_suspect` and mismatch counts, and uses available-game FGA denominators for per-category season shares. Descriptive per-field tail means require at least ten nonnull tail observations. Both shot-funnel axes are marked `source_limited_shot_funnel=True`, because masking realized shot summaries cannot repair the previously derived defensive lookbacks. No shot trigger is certified by this research build.

The actual chronological split is through January 15 for H1 and after January 15 for H2 in each season. These are chronological segments, not necessarily equal halves of a player's sample. All H1 comparisons have at least ten on and ten off observations; all reported H2 comparisons do as well. H2 eligibility failure leaves its result unavailable. BH families cover all eligible hypotheses within each season and outcome; H1 is independently adjusted and H2 is adjusted across the available H2 comparisons from H1-eligible pairs. They are not adjustments restricted to attractive H1 discoveries.

| Hypothesis family | 2024–25 tests | 2025–26 tests |
|---|---:|---:|
| All player × axis, descriptive season p85 | 1,446 | 3,109 |
| All player × axis, rolling p85 | 1,355 | 2,925 |
| H1 rolling-p85 player × axis comparisons | 420 | 567 |
| Corresponding H2 comparisons with sufficient observations | 170 | 407 |
| Positive H1 discoveries at q ≤ .05 | 0 | 0 |

There are zero positive season-p85 player × axis results at q ≤ .05 among the 3,109 2025–26 tests. The 2024–25 descriptive family has one positive result, discussed separately below. This says the broad screen did not establish individual associations at its specified family-wide gate; it does not prove that every underlying effect is zero.

Independent arithmetic checks used `scipy.stats.fisher_exact` and `false_discovery_control`, not the study's `bh` helper. All stored player-factor p-values and q-values in the four outcome/season families agree with recomputation from their saved contingency counts within 3e-16. A direct synthetic future-outcome perturbation left every existing rolling-p85 threshold unchanged; it changed the final-season threshold as expected. A nine-on/nine-off comparison was suppressed and a ten-on/ten-off comparison was tested. These establish the inspected numerical behavior, not the missing pre-lock source provenance.

### Independent raw-row verification of featured candidates

The following two checks began with `frame_2526.parquet`, independently recomputed each player's own-season strict p85 label, and then counted the source condition. BH values were independently recalculated over the entire 3,109-test 2025–26 descriptive family.

| 2025–26 player and source condition | Own p85 | On / off top-tail counts | Fisher p | Global q |
|---|---:|---|---:|---:|
| Bobby Portis, pid 1626171, `f_2key_out` | 38.35 DK | 7 / 12 versus 3 / 51 | .0001340772 | .0745611350 |
| Andrew Nembhard, pid 1629614, `f_fav_shot_type` | 43.075 DK | 7 / 15 versus 2 / 39 | .0009447847 | .1835834838 |

Portis has 63 games in the source sample; all are eligible for the participation-proxy split. His seven on-condition top-tail dates are 2025-12-11, 2026-01-21, 2026-01-27, 2026-02-12, 2026-03-08, 2026-03-15 and 2026-03-17. The condition is inferred missing recent rotation players, not verified named injuries.

Nembhard has 55 source-sample games, with one omitted from this factor comparison because the underlying favorite-category/opponent rank state is unavailable. His seven on-condition top-tail dates are 2025-12-27, 2026-01-10, 2026-01-31, 2026-02-10, 2026-02-22, 2026-03-23 and 2026-03-25. His result also carries the shot-source limitation and cannot certify a funnel edge. Both candidates fail the declared q ≤ .05 family gate.

A third independent descriptive check joined Jalen Brunson's exact `pid/gid` frame rows to raw `FGA` in `04-12-2026-nba-season-player-feed.xlsx`. His 2025–26 threshold is 50.45 DK, with 11 top-tail games and 58 ordinary games; none of his rows has the suspect positive-FGA/zero-diet condition. Direct means reproduce the profile output:

| Brunson field | Top-tail, n=11 | Ordinary, n=58 |
|---|---:|---:|
| Frame `pu`, pull-up attempts | 14.00000 | 10.12069 |
| Frame `min` | 38.20909 | 34.19885 |
| Raw box `FGA` | 23.54545 | 18.89655 |
| Frame `usg` / raw `USAGE RATE (%)` | 33.91387 | 29.77181 |

These are contemporaneous differences in realized opportunity, not validated predictors. They also do not establish that his pull-up share, efficiency, or any one component caused the fantasy tail.

### The sole 2024–25 positive result requires precise replication wording

Kyle Filipowski, pid 1642271, is the only positive 2024–25 descriptive result passing that season's 1,446-test BH family: `f_hot`, 8 / 16 on versus 0 / 34 off, own-season p85 30.45 DK, Fisher p=.0000239719, q=.0346633639. Source rows with unavailable `min_l10` are omitted from this factor comparison.

In 2025–26 the same descriptive condition remains positive: 8 / 28 on versus 3 / 42 off, p85 42.3 DK, p=.0214808078, q=.6306476463 in the broader 3,109-test family. It is inaccurate to say the association vanished or simply “failed year-ahead” without specifying the test family. A genuinely predeclared single-candidate replication would have a different multiplicity family from the broad repeat screen; this audit does not retrofit that design after inspecting the result.

The 2025–26 adaptive rolling-p85 comparison is much weaker: 10 / 28 versus 11 / 37, p=.789307, q=1.0 among 2,925 rolling-outcome tests. Thus this build does not establish an adaptive-ceiling predictor. Distinguish failure of the declared broad-family gate, absence of rolling-p85 evidence, and persistence of a positive descriptive direction.

A terminology review also identified that `f_hot`, `f_min_exp`, and `f_usg_exp` compare the recent window to **prior-game season-to-date** baselines, not the previous season. Narrative descriptions must retain that distinction.


## Final companion-report review

The final `docs/NBA_TOP15_TRENDS_2026-09-22.md` was reviewed against the generated tables and the independent source checks above. Its displayed Portis, Nembhard, Brunson and Filipowski claims agree with the independently recomputed rows. The four-player descriptive shot table was also checked from `top15_games_2526.parquet`: Brunson's pull-up shares are 59.459% / 53.558%, Maxey's less-than-ten-foot shares 44.061% / 38.038%, Towns' catch-and-shoot shares 29.353% / 25.802%, and Mitchell's pull-up shares 44.980% / 45.387%, matching the printed rounding. None of these four displayed players has masked shot observations in its top-tail or ordinary comparison group.

The report's equal-player medians reproduce across 151 players with at least ten top-tail games: +6.27155 minutes, +4.60714 box FGA, and +3.67358 USG percentage points. All 151 differences are positive for minutes and FGA; 146 are positive for usage. Its four displayed pooled rates reproduce their exported denominators: same-position proxy 798/3,521 versus 1,919/14,385; minutes expansion 453/2,139 versus 2,175/14,924; pace 862/5,002 versus 1,730/11,788; ITT 1,017/6,345 versus 1,700/11,561. These checks confirm arithmetic and transcription, not causal interpretation.

`top15_current_roster_profiles.csv` has 573 rows and 573 distinct pids, consistent with the saved roster snapshot. The report identifies missing history and does not infer rookie status, current health, or opening-night roles. Its sample, tracking, availability, market timing, multiplicity and Filipowski qualifications address the specific concerns raised during this audit. The standalone regression file `nba/analytics/test_top15_study.py` was executed: six tests passed. No remaining blocker was identified to delivering this as a clearly limited descriptive/exploratory study; the game-universe and tracking defects remain blockers to a complete-season or certified predictive claim.

## INFERENCES

The existing sources can support useful individual historical descriptions, with precise coverage and uncertainty labels. Broadly higher volume in selected high-DK games is consistent with opportunity contributing to the outcome, but does not isolate a causal driver or establish pregame prediction. Failure of the broad adjusted tests supports keeping these player associations exploratory; it does not support a claim that all basketball mechanisms are absent.

## ASSUMPTIONS AND UNRESOLVED ITEMS

This review accepts the study's declared 50-appearance, ten-per-side, strict-p85 and January-15 specifications for evaluation; it has not optimized them or claimed they are uniquely correct. The raw workbook is used as the cross-check for box FGA and USG without assuming every discrepancy proves that source is right. The audit does not resolve missing tracking retrievals, historical injury/market timestamps, a repaired complete game universe, or the robustness of any player association to role segmentation and dependent observations. The orchestrator's separately verified Cup rule is attributed to the companion report; no current basketball facts were independently researched here.

## FINDINGS

Daily player shot-attempt data and historical participation/environment context exist, with the denominators and limitations above. Same-season top-tail descriptions are supportable. Per-game Synergy mechanisms, proven injury levers, and deployment-grade causal claims are not established by these files. Date-level tracking coverage overstates completeness; unknown shot observations and warmup ranks need explicit treatment.

## CONFLICTS

“Full season” would conceal the shorter 2024–25 endpoint and tournament-labelled exclusions. “Total shots” would overstate the three-category sum or double-count all five tags. “Injury” would overstate a participant-set proxy. “Top 15% validation base rate” would misstate the observed rolling-p85 target. No current roster or player-role fact has been inferred from historical priors.

## DECISION POINTS

Keep production p75 and weights unchanged. For this research output, prefer exact source-labelled universe descriptions, per-feature missingness, and global multiplicity over the declared eligible family. Treat all surviving associations as candidates until prospective tests exist. Map the raw tournament games to the verified regular-season inclusion rule before claiming complete regular-season coverage; repair/re-pull missing tracking before promoting funnel candidates, and consider role-specific histories only under a declared new research design.
