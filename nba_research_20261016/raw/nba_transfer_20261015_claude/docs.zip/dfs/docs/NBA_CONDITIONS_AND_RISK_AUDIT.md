# NBA combined conditions and downside — September 22, 2026

These are tests 5 and 7 from the follow-up list. They use the repaired research frame and a common held-out cohort of 13,756 player appearances in December 2025–April 2026. Each has at least twenty earlier appearances in the same season and complete prior shot-matchup features. These are conditional-on-playing results: a player must have played at least one minute to enter the source outcome sample. Missing daily shot information is not filled with zero. The earlier 2024–25 feed ends March 10; it supplies historical training data, not a complete comparison season.

## Observations before conclusions

### Combined conditions

Four combinations were specified: rising recent minutes with faster pace; rising recent usage with a high pull-up fit; rising minutes with a high near-basket fit; and rising minutes with a high catch-and-shoot fit. Minutes/usage growth means the prior-five mean is at least three minutes/percentage points above the prior-twenty mean. Pace is the mean of the two teams’ trailing-ten pace. Each shot-fit field is the player’s prior share of that shot type multiplied by the opponent’s prior allowance per 100 possessions. It is an attempt compatibility measure, not shooting efficiency, a causal funnel or a DFS value score.

The pace/fit thresholds are the training sample’s 75th percentiles. Every monthly fold fits its thresholds, median imputer, missing-value indicators, scaler and models on strictly earlier dates. The main-effects logistic model includes all existing player history, environment and shot features, the lower-tail threshold, and the six condition flags. Five candidate models add each of the four products separately or all four together. The same rows enter every model. A fixed boosted-tree model provides a nonlinear reference. Research specifications are not production weights.

| Held-out target | Main effects Brier | All four products Brier | Improvement | Week 95% interval | Adjusted q |
|---|---:|---:|---:|---:|---:|
| Above prior20 p85 | .147159 | .147218 | −.000059 | −.000142 to +.000019 | .550 |
| Below prior20 p15 | .145425 | .145400 | +.000025 | −.000046 to +.000099 | .664 |

Lower Brier is better. None of the ten predeclared target-by-interaction comparisons passes the 5% whole-family false-discovery threshold. All confidence intervals include zero. Calendar-week paired resampling retains same-game/date dependence; player-cluster intervals are also exported. The main-effects model’s ceiling Brier is lower than the fixed boosted-tree reference’s .149224, but this comparison does not isolate a shot effect, and model-family selection was not separately validated.

Some raw cells look attractive: rising minutes plus faster pace produced an adaptive-ceiling rate of 32.2% in 701 appearances. That alone does not establish a special interaction. The held-out comparison asks whether the product adds information beyond minutes and pace themselves, including the other available layers. See `conditions_four_cells.csv` for every cell and `conditions_comparisons.csv` for every positive and negative result.

### Ceiling and downside together

The predictive targets use strict comparisons with each player’s previous twenty games: above p85 and below p15. Their realized frequencies are 19.0% and 18.6%, respectively; they are not mathematically fixed at 15% after the player’s role or performance distribution changes. Neither target uses a future threshold. Separately, retrospective season-tail columns use each player’s full source season, before filtering study rows.

The following descriptions use thresholds fixed from the older season and the same 13,756 recent-season appearances. They are unadjusted associations, not causal effects or formal discovery selections.

| Prior condition | Games with / without | Adaptive ceiling with / without | Adaptive downside with / without |
|---|---:|---:|---:|
| Minutes up ≥3 | 2,235 / 11,521 | 26.9% / 17.4% | 9.9% / 20.2% |
| Minutes down ≥3 | 2,171 / 11,585 | 14.2% / 19.9% | 23.5% / 17.6% |
| Usage up ≥3 points | 1,745 / 12,011 | 20.5% / 18.8% | 16.4% / 18.9% |
| Faster pace | 4,169 / 9,587 | 21.3% / 18.0% | 17.4% / 19.1% |

The minutes-growth association also appears against the fixed full-season p85: 23.8% with growth versus 14.8% without. Across 73 players with at least ten appearances in each minutes-growth state, the median within-player adaptive-ceiling difference is +8.3 percentage points, downside difference −14.9 points, and DK difference +3.73. This addresses some between-player composition, but simultaneous availability changes, schedule, and evolving roles remain confounders. Individual rows are descriptive and have not earned player-specific multipliers.

In the nonlinear reference model’s highest predicted-ceiling quintile, later observed ceiling/downside rates were 30.6%/12.5%, versus 11.7%/22.3% in the lowest quintile. Higher personal ceiling probability need not mean more absolute fantasy points: the highest quintile averaged 20.96 DK versus 23.65 in the lowest. The target measures exceeding a player’s own recent history, so this is not a ranking for lineup construction.

## Interpretation and limits

Recent opportunity is useful context for both tails. These four explicit interaction terms provide no demonstrated extra forecasting benefit in this design. This does not establish that all interactions fail; it limits the claim to the declared conditions, thresholds, models and sample. Shot completeness selects the cohort, repeated-player and longer-range dependence remain, and there is only one held-out season. No current injury, opening-night role, salary, ownership or profit conclusion follows. No production score, trigger, multiplier or lineup rule changed.

## Evidence and falsification

- Runner: `nba/analytics/condition_tail_study.py`; all outputs begin `nba/analytics/data/research_next/conditions_`.
- Source: `research_v2/research_games.parquet`, SHA256 `a57949a4efcc5cc930a3a6bfe0114631ba4f6c3488109f439802ec83f99f71ad`. Consumed columns, exact model settings, fold dates, training-only cutoffs and family definition are in `conditions_summary.json`.
- Raw scoring reconstruction independently matches all 47,039 appearances exactly. A separate loop computes 27,364 available prior20 tail thresholds from raw box scores and matches all 192,584 exported model/target labels. Brier scores and the displayed condition rates are independently rederived by `next_research_audit.py`; results are saved in `conditions_independent_checks.json`.
- Eight falsifying tests cover future/current outcome mutation, new-season resets, strict ties, overlapping tails, duplicate identity, missing-condition preservation, product identity, fixed training cutoffs, unpaired predictions, changed labels and invalid probabilities. The dedicated gate rejects altered cutoffs and recomputes the full ten-test BH family.
- The first numerical implementation encountered spurious runtime matrix-multiplication warnings also reproduced on bounded Gaussian data, with finite results agreeing with elementwise multiplication to approximately 1e−14. Final logistic fits use Liblinear with explicit elementwise prediction, finite checks and convergence assertions; this was a numerical repair, not selection based on a favorable result.

Exact provenance for the rates is `conditions_risk.csv` (`n_on`, `n_off`, `ceiling_*`, `downside_*`, `season_top15_*`); for within-player contrasts, `conditions_within_player.csv`; for prediction quintiles, `conditions_tail_tradeoff.csv`. NFL environment/coverage/ADP layers do not apply to this NBA study. Daily Synergy, timestamped injury availability and the blocked historical contest corpus were excluded because they cannot establish these dated player outcomes or a live edge.
