# NBA 2026–27 roster and continuity funnel

Refreshed September 22, 2026 from the [official NBA roster listing](https://www.nba.com/players). This is the current published listing, not opening-night eligibility, a contract audit, or a projection. Raw source, hash and retrieval time: `nba/analytics/data/roster_snapshot_2026.json` and its `.source.html` file. The Stats endpoint timed out; the official web page supplied the fallback. All joins use NBA person IDs.

## Listing and historical context

573 current listed players, 30 teams, no duplicate IDs. Compared with August 5: 26 team changes among continuing IDs, 43 additions and 55 no longer listed. See `nba/analytics/data/roster_changes_since_2026-08-05.csv`; disappearance alone does not prove retirement or release.

The historical identity pool now includes all 582 players in the 2025–26 frame, rather than only those with ceiling labels. Players with fewer than eight appearances retain identity/history even though no ceiling-rate estimate is available. `n_frame_games` counts analytical appearances; `n_games` counts games with a prior-eight-game ceiling label. The historical frame filters appearances under one minute for outcome analysis; current roster membership does not.

| Current context | Players |
|---|---:|
| SAME_TEAM_SAME_COACH | 270 |
| SAME_TEAM_NEW_COACH | 68 |
| MOVED_TEAM | 125 |
| NEW_NO_2526_FRAME | 110 |

There are 119 additional historical IDs absent from the current listing. Within stable team/coaching context, 130 have at least 50 labeled games; 14 have prior shot triggers after the September corrections. Roster/team/coaching changes reset context; no old player conditional lift is armed for the new season. The existing six-team coaching reset map was rechecked against the [official coaching tracker](https://www.nba.com/news/2026-coaching-tracker).

## Stable historical shot-trigger queue

Alphabetical order; no ranking or recommendation. Every row below has n≥50 labeled games. Smaller samples remain visible with evidence flags in the CSV, but are omitted here. These triggers use corrected historical features and must be re-earned in 2026–27.

| Player | Team | Labeled games | Historical shot axes |
|---|---|---:|---|
| Cam Spencer | MEM | 60 | f_opp_wo_soft |
| Carter Bryant | SAS | 61 | f_fav_shot_type |
| Evan Mobley | CLE | 53 | f_fav_shot_type|f_opp_wo_soft |
| Gui Santos | GSW | 58 | f_fav_shot_type |
| Jordan Clarkson | NYK | 58 | f_fav_shot_type |
| Jordan Goodwin | PHX | 57 | f_fav_shot_type |
| Karl-Anthony Towns | NYK | 61 | f_fav_shot_type |
| Keldon Johnson | SAS | 68 | f_opp_wo_soft |
| Mohamed Diawara | NYK | 56 | f_fav_shot_type |
| Neemias Queta | BOS | 65 | f_opp_wo_soft |
| Oso Ighodaro | PHX | 69 | f_fav_shot_type |
| Pelle Larsson | MIA | 57 | f_opp_wo_soft |
| Ryan Kalkbrenner | CHA | 58 | f_opp_wo_soft |
| Sion James | CHA | 70 | f_fav_shot_type|f_opp_wo_soft |

## Audit qualification

The shot diet now uses only prior games, and sub-minute participants are no longer counted as absent. Historical absence indicators remain final-participation proxies; closing lines lack lock timestamps. These are research profiles, not certified pre-lock effects. The complete findings and remaining work are in [the September audit](NBA_RECONCILIATION_AUDIT_2026-09-22.md). August's report is preserved under `docs/archive/nba_pre_audit_2026-09-22/`.
