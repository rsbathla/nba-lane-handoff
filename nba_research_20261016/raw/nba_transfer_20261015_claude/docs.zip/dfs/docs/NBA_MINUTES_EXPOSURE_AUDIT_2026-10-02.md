# NBA 2025–26 minutes and exposure audit

This reviews recorded selections against archived ETR minutes and fantasy-point forecasts, with FantasyCruncher kept as a separate proxy as you authorized. Your stated primary provider was ETR. The archives do not link a forecast revision to a submitted lineup or late swap. “Forecast” below therefore means the recorded reference, not a certified estimate you adopted.

## Recorded cases

These are diagnostic examples of concentrated selections, with favorable and unfavorable results retained. They are not a random sample or a player-level profit attribution. Minutes histories use at most ten strictly earlier appearances in the latest contiguous same-team stint. Fantasy points are independently recomputed from the raw boxes.

| Date | Player | Reference | Entries using player | Prior minutes | Forecast → played minutes | Forecast → raw DK points |
|---|---|---|---:|---:|---:|---:|
| 2025-11-07 | Tyrese Martin | FantasyCruncher | 100/100 | 20.88 | 26.75 → 19.37 | 23.13 → 8.75 |
| 2025-11-23 | Goga Bitadze | FantasyCruncher | 147/150 | 15.83 | 28.50 → 0.00 | 29.87 → 0.00 |
| 2025-11-25 | Trendon Watford | FantasyCruncher | 150/150 | 22.00 | 25.25 → 10.70 | 24.29 → 9.75 |
| 2026-01-09 | Branden Carlson | ETR | 78/150 | 12.38 | 24.00 → 15.83 | 25.20 → 10.75 |
| 2026-01-09 | Ajay Mitchell | ETR | 150/150 | 24.99 | 33.00 → 38.02 | 36.80 → 37.75 |
| 2026-01-14 | Precious Achiuwa | FantasyCruncher | 85/150 | 21.37 | 27.25 → 38.58 | 23.17 → 50.00 |
| 2026-01-24 | Jusuf Nurkic | FantasyCruncher | 13/20 | 31.19 | 29.25 → 31.35 | 39.80 → 55.00 |
| 2026-01-26 | Pat Spencer | FantasyCruncher | 150/150 | 8.89 | 12.75 → 33.55 | 12.28 → 26.25 |
| 2026-03-14 | Isaiah Jackson | FantasyCruncher | 16/16 | 13.59 | 13.25 → 22.90 | 13.94 → 29.50 |

Source: [bound cases](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_role_forecasts/report_cases.parquet) · `pid`, `cid`, `provider`, `slot_entries`, `entries`, `prior_min`, `forecast_minutes`, `actual_min`, `provider_fp`, `actual_fp_raw`. Each row retains its original forecast path, logical CSV row and original contest-feed path.

Tyrese Martin missed the saved minutes forecast as well as the point forecast. His actual minutes were close to his prior average, which explains why a history-only comparison missed the forecast shortfall. Branden Carlson also fell short of an ETR role increase. Ajay Mitchell exceeded the ETR minutes estimate on the same slate. Precious Achiuwa, Jusuf Nurkic, Pat Spencer and Isaiah Jackson retain favorable comparisons. Goga Bitadze has no positive raw appearance; the archive does not establish when or why nonparticipation became knowable. None of these results alone proves a bad pregame decision.

The earlier progress message incorrectly called the Martin case Kenyon Martin Jr. The source person is Tyrese Martin, ID1631213. Published cases now require the full name/person/date/contest binding and a known-bad guard test.

## Alternatives in the recorded pool

The comparison uses original FantasyLabs `rosterPosition`, shared recorded eligibility and salary within $500, without filtering on actual participation. FantasyLabs primary `position` is retained separately and cannot substitute for roster eligibility. The table names the highest recovered reference within that comparison group; it does not certify DraftKings historical eligibility, availability, a feasible full lineup replacement or the owner’s rejected candidates. Missing forecasts remain in the source denominator.

| Player/date | Own forecast FP | Best recovered comparison | Comparison salary / FP | Known forecasts / source alternatives |
|---|---:|---|---:|---:|
| Tyrese Martin · 2025-11-07 | 23.13 | Anfernee Simons | 4500.00 / 22.47 | 29/29 |
| Goga Bitadze · 2025-11-23 | 29.87 | Sandro Mamukelashvili | 3400.00 / 23.31 | 17/17 |
| Trendon Watford · 2025-11-25 | 24.29 | Tristan da Silva | 5000.00 / 23.34 | 6/6 |
| Branden Carlson · 2026-01-09 | 25.20 | Kenrich Williams | 3400.00 / 21.10 | 16/35 |
| Ajay Mitchell · 2026-01-09 | 36.80 | Jeremiah Fears | 5200.00 / 28.20 | 9/9 |
| Precious Achiuwa · 2026-01-14 | 23.17 | Brook Lopez | 3700.00 / 23.44 | 7/7 |
| Jusuf Nurkic · 2026-01-24 | 39.80 | Bam Adebayo | 7800.00 / 42.66 | 2/2 |
| Pat Spencer · 2026-01-26 | 12.28 | Bones Hyland | 3100.00 / 12.74 | 22/23 |
| Isaiah Jackson · 2026-03-14 | 13.94 | Jonas Valanciunas | 3300.00 / 11.07 | 15/15 |

Source: [candidate forecasts](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_role_forecasts/candidate_forecasts.parquet) · `source_eligibility`, `salary`, `provider_fp`, `alternatives_source_n`, `alternatives_forecast_n`, `alternative_best_player`, `alternative_best_salary`.

The unfavorable Martin, Goga, Watford and Carlson cases had stronger recorded point forecasts than the recovered comparable alternatives. Their bad results therefore cannot be described as simply ignoring an obviously better mean projection. Carlson’s ETR comparison is incomplete, so that statement applies only to its known forecasts.

## Broader observations

The FantasyCruncher proxy covers **77 distinct owner MME player-dates on 35 dates** with mean exposure across rooms of at least50% and a projected minutes increase of at least3 over the earlier same-team average. These are stated descriptive cutoffs, not learned exposure rules. **14 missed the forecast by at least5 minutes**, while 11 exceeded it by at least5. The average minutes error, weighting dates equally, was -0.27; the point error was +0.54 DK points. This shows both downside and upside in concentrated role bets; it does not establish that taking the role increases was systematically wrong.

On February19, the one fully forecast-covered owner SE lineup had **4 Indiana players**, totaling 123.75 proxy projected minutes versus 86.68 played, and 136.68 projected DK points versus 99.25 raw points. This illustrates a shared team-level dependency inside a single lineup. The same archive cannot certify your expectations, identify the cause of the rotation changes, or show that the combination was inferior before lock.

Complete same-contest MME comparisons are small in magnitude: BPCologna selected an average of0.14 more proxy projected minutes per slot across14 dates; youdacao selected 0.35 more across5 dates. Their corresponding point-projection differences were−0.18 and+0.03 per slot. The averages weight dates equally, after contests within each date. ETR has only one complete BP pairing. True SE has one complete proxy pairing per peer, so this audit cannot establish a superior repeatable SE selection rule. These are descriptive comparisons with no significance claim.

Sources: [audit descriptors](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_role_forecasts/report_descriptors.json), [matched pairings](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_role_forecasts/paired_comparisons.parquet), [summary](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_role_forecasts/summary.json) · `paired`, `coverage`, `calibration`.

## What this means for your process

The clearest review target is **how much exposure depends on a role increase actually materializing**. Carlson, Martin, Goga and Watford supply concrete unfavorable examples; Mitchell and the favorable cases prevent turning that into a blanket rule against role changes. Several concentrated unfavorable selections were supported by the archived mean projection. We cannot call the exposure irrational without your adopted estimates, uncertainty and news timing.

A useful decision record would distinguish baseline minutes/value from any matchup override: expected minutes and a plausible lower role, expected usage, shot/play-type volume, opponent allowance/exposure, pace, the best rejected alternative and the reason for the exposure. For SE, record which selections share the same rotation or game-condition assumption. This audit proposes no new weights or exposure limits.

Your usage-plus-shot-type method is **not disproved**. Existing strictly prior shot mix, shot strength, opponent category ranks, pace, prior Synergy and participation contexts are retained. Those research proxies are not your exact contemporaneous inputs, and the ETR files contain no projected usage, attempts or touches. The FP/minute residual in the data is only arithmetic; it cannot identify shooting, touches, effort or efficiency as a causal explanation.

## Coverage and evidence limits

The combined source corpus has284 owner/BP/youdacao portfolios on85 dates and retains all8,960 source player-contest exposures in each of two provider lanes. Owner MME support is128 portfolios on79 dates; owner true SE support is4 on4. One bullet in an MME contest remains a separate format.

| Owner reference | Unique forecast-supported player-dates | Dates | Mean absolute minutes error | Fully covered MME portfolios/dates | Fully covered true SE portfolios/dates |
|---|---:|---:|---:|---:|---:|
| ETR | 90 | 3 | 4.21 | 1/1 | 0/0 |
| FantasyCruncher | 1497 | 42 | 4.49 | 30/21 | 1/1 |

Calibration collapses repeated contests to one player/date/provider outcome per user. Mean errors first average players within a date, then dates. The different selected populations cannot establish provider superiority.

Source time is interpreted as Eastern when the FL contest clock lacks a timezone. Both local download time and saved-content modification time must precede the initial contest clock; this is a declared assumption and local consistency check, not an immutable lock receipt. Post-start files are excluded even if later-game swaps might have legitimately used them. Date, NBA person, salary and historical team/opponent must match. FD values, ambiguous edited headers and live/actual columns are excluded.

Four FC files assigned every player6 minutes and5 points. They and matching values elsewhere remain visible but unqualified: 1460 parsed rows. No numerical user-facing minutes changes were found in the inspected2025–26 DK FC files. Imported point projections are preserved separately; equality with ETR in some rows does not certify private adoption.

All22 owner source-score-zero selections remain. There are 35 source exposures across 12 player-dates where source FP differs from raw recomputation; the two values remain separate. No contest-profit attribution is derived from the raw-point differences.

Validation pins original inputs, code and outputs, then re-extracts every forecast, historical context, alternative group and selected exposure. Known-bad cases cover postlock revisions, site/game/person/salary mismatch, constant arrays, wrong eligibility, missing forecasts, repeated outcomes, corrupted case labels and exposure closure. Independent original CSV/FL/Excel checks corroborate Martin, Nurkic and Mitchell. [Provenance audit](/Users/rsbathla/Downloads/dfs/docs/NBA_FORECAST_PROVENANCE_AUDIT_2026-10-02.md) · [design audit](/Users/rsbathla/Downloads/dfs/docs/NBA_ROLE_RISK_AUDIT_DESIGN_2026-10-02.md) · [final validation receipt](/Users/rsbathla/Downloads/dfs/nba/analytics/data/research_role_forecasts/final_validation_receipt_2026-10-02.json).
