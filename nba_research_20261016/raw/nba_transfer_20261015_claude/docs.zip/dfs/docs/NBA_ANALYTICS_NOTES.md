# NBA Ceiling-Game Analytics — Settled Conclusions & Doctrine

> **September 22 audit update:** This document is a historical record. Current implementation status, corrected numerical results and source-quality limitations are in [NBA_RECONCILIATION_AUDIT_2026-09-22.md](NBA_RECONCILIATION_AUDIT_2026-09-22.md). Historical construction prescriptions are provisional; prior-season player triggers are not live signals.

*Distilled 2026-07-19 from the July 2026 cloud workstream (full-season 2025-26
study + 2024-25 year-ahead validation). Verdicts also live as rows in
`nba/analytics/levers_ledger.csv` — read that first, don't re-derive dead axes.*

**Provenance:** every claim in this document comes from the Cowork export
`dfs_nba_workstream.zip` (2026-07-19). `dfs_nba_workstream_with_git.zip` was
hash-verified byte-identical on all 12 content files; its only addition is the
session's 6-commit git history (8e5d056 doctrine → 449ef9d season frames), so
the two zips are a single source — no claim differs between them. Merged into
this repo 2026-07-19 on the Windows side: code + ledger → `nba/analytics/`,
small data (trigger table + both season lever frames, all <1MB) →
`nba/analytics/data/` (gitignore exceptions added — repo otherwise ignores
`*.parquet`). Nothing in the export exceeded 5MB, so no release-asset upload
was needed; the big NBA data (`nba_entry_history.db` 84MB, FL feed corpora
~273MB) is the separate nba_lane handoff bundle and stays out of git per
`.gitignore` and HANDOFF_NBA_LANE §2. Section 8's paths below are the export's
original layout — see `nba/analytics/README.md` for the in-repo mapping.

## 1 · Definitions (settled)

- **Ceiling game** = DK score above the player's OWN 75th percentile.
  Retrospective analysis: season p75. Production/backtest: AS-OF rolling p75
  (prior 20 games, min 8, shift-1) — season quantiles leak the bar.
  League base rate ≈ 25% (season bar) / ≈ 30% (rolling bar). p85 was the
  original definition; relaxed 2026-07 because stars' bars sat near their max
  (Jalen Johnson p85 = 64.4 DK) — p75 gave better-powered, MORE stable results
  (split-half trigger persistence 56% → 68%).
- **Pre-lock factor** = knowable before lineups lock. **Realized mechanism** =
  measured in-game. Never sell a realized mechanism as a predictor.

## 2 · League factor hierarchy (replicates across seasons)

Lifts on P(ceiling), pre-March windows; 24-25 column is an INDEPENDENT rebuild:

| axis | 2025-26 | 2024-25 | verdict |
|---|---|---|---|
| any key rotation out | 1.71x* | 1.44x | ARMED — the backbone |
| same-pos starter out (exact 5-pos) | 1.49x | 1.44x (coarse) | ARMED; 5-pos beats G/F/C (33.9% vs 30.8% on-rate) |
| opp concedes wide-open (as-of rank>=24) | 1.25x* | 1.14x | ARMED-tail; replicates y/y (24-25 cell filled by the 2026-07-19 PC rebuild, §10; local 25-26 rebuild reads 1.08x — see §10 magnitude note) |
| soft DvP (rank 24-30) | 1.29x | 1.10x | ARMED small; weak league-wide, real player residuals |
| weak opp D (pts allowed) | 1.31x | 1.13x | ARMED small |
| pace-up game (both teams, slate q75) | 1.16x | 1.05x | environment channel, bounded |
| back-to-back | 1.17x | 1.05x | mild POSITIVE (contra-consensus) |
| Vegas ITT 118+ | 1.07x | 0.99x | DID NOT replicate — context, not signal |
| running hot (fp/min L10>>szn) | 1.30x | 0.96x | DID NOT replicate |
| 3+ days rest | 0.79x | — | DEAD (league fade), lone y/y-persistent player lever |
| home court | 1.01x | — | DEAD |
| tough-DvP fade | 0.90x | — | too weak to arm |

*25-26 number from the original full pipeline; feed-only rebuild gives 1.4-1.5x.

Sub-findings: Synergy play-type matchup (user dashboard data) = 1.18x overall,
**1.15x additive** where no other matchup factor fires — but source was a
season-end snapshot; arm only after an as-of daily-refresh rebuild. Per-shot-type
as-of matchup (rim/C&S/PU/drives) ≈ 1.13-1.21x; strongest for roll-men.

## 3 · Realized-mechanism doctrine (the volume confound)

Ceiling rate by total-shot surge: -2 shots 3.6% | normal 17.5% | +2..5 49.7% |
+5 75.8%. Ceiling games ARE volume explosions. Holding volume fixed, the shot
MIX barely matters: quick-touch tilt 0.94x, 0-dribble 0.97x — the "3.11x
quick-touch mechanism" was volume in a costume (VETOED in ledger). Survivors at
fixed volume: early-clock tilt 1.16x, 7+-dribble tilt 1.13x. Use clock/dribble/
touch data for PROFILING (fed vs self-created), never as mechanisms.
Same confound applies to all realized surge stats (3PT/rim/C&S/WO surges).

## 4 · Per-player triggers (within-season instrument)

Per (player, axis): n_on>=8 both sides, raw>=0.38, binomial p<0.05 vs own
off-rate; EXPECTED = EB-shrink toward base x league-lift (K=12).
- Split-half (p75, pre-March): 1.23-1.37x OOS, 62-68% of triggers held.
- **Walk-forward (daily re-derived, as-of label — deployment-grade):**
  0/1/2/3+ active = 27.9/30.9/35.6/39.2% (p=5e-12); any-vs-none 1.18x;
  matures 0.99x (Dec) → 1.26x (Apr). Repo rebuild reproduces: 28.1/33.5/38.3/38.5.
- **Rank boards by COUNT of active triggers, never expected magnitude** —
  in-sample magnitudes INVERT out-of-sample (low-exp tertile 36.8% observed vs
  high-exp 21.5%).
- Stud archetype flips with salary: cheap = Opportunity-driven, $8.5K+ =
  Matchup-driven. Case law: LeBron 25-26 — 39% ceiling rate w/ same-pos starter
  out vs 2% full lineup, 88% of his ceilings covered (role fact, not trait).

## 5 · Year-ahead verdict (THE negative result)

`lever_tests.year_ahead_did`, 456 shared PLAYER-IDs, 24-25 (thru 3/10) → 25-26:
- **Axis level replicates** (table above). Player-level lever identity does
  NOT: all 12 axes WEAK/UNPOWERED except rest3 (+0.093, p=0.013, dies in
  window-matched sensitivity). Whispers under threshold: 2key-out (r=0.152),
  b2b (+0.053, p=0.031).
- **October seeding doctrine: league factor priors + in-season walk-forward
  trigger discovery. Do NOT carry player conditional rates across seasons at
  strength** (heavily-decayed weak priors at most). Shot-type levers were the one
  candidate left, since shot diet is a trait while situations are not —
  RESOLVED 2026-07-19: tested and FAILED like the rest (§10). No player-level
  lever identity of any kind survives a season boundary; the October doctrine
  is now closed on all measured axes.

## 6 · Model layer (production screener, lost repo — rebuild notes)

The `ceiling_screener` package (ingest → leakage-guarded features → calibrated
tiers → daily screen) was lost in a container recycle; its validated numbers:
Brier skill +0.028 vs base, AUC 0.595, ECE 0.029 at p75 (similar at p85);
situational multipliers new-starter 1.90x, samepos-out 1.21x, soft-DvP 1.13x;
walk-forward top-10 precision ~2x random. Rebuild from BDB feeds using
`nba/build_season.py` as the feature core; keep the shift(1) leakage rule and
the calib_key single-source pattern.

## 7 · Identity & data case law

- Join seasons on BDB PLAYER-ID; NBA person_id via name bridge with explicit
  alias table (alex sarr→alexandre sarr) — audit unmatched, never drop silently.
- BDB team codes are full names ("Golden State"); NBA/dashboards use tricodes —
  keep the TEAM_MAP in one place.
- stats.nba.com blocks datacenter IPs (403) — pull from residential
  (nba/pull_tracking.py) or via in-browser fetch. ~1.15s/request is safe;
  observed ~0.5% transient failures — retry then mark missing, never zero-fill.
- DK FP from box: PTS + 0.5·3PM + 1.25·REB + 1.5·AST + 2·STL + 2·BLK − 0.5·TO
  + 1.5 DD + 3 TD.
- BDB DFS feed is NOT needed for the lever stack — closing spread/total live in
  the team feed; ITT = (TOTAL − SPREAD)/2.

## 8 · What exists where

- `nba/build_season.py` — feeds → as-of lever frame (both seasons committed
  under `tools/data/frame_*.parquet`).
- `nba/run_yearahead.py` — the §5 test; add shot axes after merge_tracking.
- `nba/pull_tracking.py` + `nba/merge_tracking.py` — tracking pulls + shot-type
  flags (run on PC).
- `nba/trigger_analysis.py` — triggers + walk-forward (self-validating).
- `nba/slate_board.py` — DK-CSV slate board (count-ranked).
- `nba/levers_ledger.csv` — all 24+ settled verdicts incl. dead axes.
- Delivered-in-chat only (regenerable by the above + session HTML builders):
  ceiling_games_dashboard.html, player_ceiling_triggers.html, slate demo.

## 9 · Overlay lens results (2026-07-19, PC side — NOT from the Cowork zips)

First run of `nba/analytics/exposure_edges_lens.py` (OVERLAY_PLAN §2): his
2025-26 classic exposure vs field own across 324 FL-covered contests
(30,317 contest×player rows; MME ≥20-roster subset; trigger counts from the
season-derived table — in-sample caveat; factor flags are as-of and clean).

- **He already expresses the edges, monotonically:** leverage (his − field)
  by trigger count = +0.48 (0) / +1.47 (1) / +2.71 (2) / +2.84 (3+).
  Over the field on every league factor; largest on 2key-out (+3.31pp).
- **C11-chalk hypothesis REFUTED:** the mega-chalk (40%+) over-index is NOT
  concentrated in zero-trigger chalk — triggered mega-chalk leverage +18.5
  (n=161) vs untriggered +15.0 (n=332). The chalk leak is a general
  over-buy, not edge-blindness; the C11 pivot rule stands on its own
  (construction discipline), don't expect the trigger board to fix it.
- SE-included and full row-level data: `nba/analytics/data/exposure_edges_2526.csv`.

## 10 · Shot-type axes: full-season rebuild + year-ahead verdict (2026-07-19, PC side — NOT from the Cowork zips)

Both-season tracking pulls completed locally (`pull_tracking.py`, residential
IP, 770+605 date×config pairs, 100% coverage after transient-failure backfill;
id bridge 100% after alias rows Alexandre Sarr / Carlton Carrington / Cui
Yongxi — retired-name collisions audited inert, only Zyon Pullin (1 FGA)
unmatched). Frames re-merged with the canonical `merge_tracking.py`; committed.

- **League-level: both axes replicate year-over-year.** fav-shot-type 1.12x
  (25-26) / 1.13x (24-25); wide-open funnel 1.08x (25-26) / 1.14x (24-25).
  The 24-25 column was the missing independent cell — now filled.
- **Magnitude re-grade:** the local full-season rebuild reads SOFTER than the
  cloud session's numbers (fav-type 1.19x→1.12x, wo 1.25x→1.08x for 25-26).
  Same merge code, full-season pull; the cloud pipeline used partial
  in-browser pulls. Treat the local numbers as canonical (reproducible from
  committed code + committed tracking CSVs); armed-tail status stands
  (count-based@board), no revert triggered, but wo is no longer "strongest
  matchup factor."
- **Year-ahead: FAILED, same as every other axis.** `run_yearahead.py` with
  shot axes: f_fav_shot_type DiD 0.010 p=0.597 r=−0.046 (n_lev 50);
  f_opp_wo_soft DiD 0.009 p=0.665 r=0.112 (n_lev 49) — both WEAK. The §5
  "trait" hypothesis decomposes cleanly: the DIET is a trait (81% of 330
  shared ≥20-game players keep the same top category y/y) but the ceiling
  LEVER on it is not portable. Carry the diet profile, never the conditional
  rate.
- **Within-season, the axes pay:** 49 shot-axis triggers across 44 players in
  the refreshed `triggers_2526.csv` (454 rows total, 14 axes); walk-forward
  with shot axes live: 28.2/33.4/36.7/38.1% by 0/1/2/3+ active (n=15,191).
  Use on boards via count-ranking, rebuild each October.

## 11 · Synergy play types: honest two-year test (2026-08-06, PC side)

Official NBA/Synergy aggregates were pulled for all 11 play types, player
offense and team defense, for 2024-25 and 2025-26. Full report:
`docs/NBA_SYNERGY_TWO_YEAR_STUDY.md`.

- Broad primary-type × soft-defense fit **FAILED year-ahead**: frozen 2024-25
  profile/ranks applied to 2025-26 outcomes = 28.2% vs 28.7%, 0.982x,
  n=4,074/11,200, p=.544; adjusted OR .973, p=.501.
- Same-season final snapshot = 1.127x, p=1.4e-6, explicitly LOOKAHEAD. This
  recreates the attractive cloud result but cannot be used pre-lock.
- Exploratory tails: offensive rebound 1.516x, roll man 1.266x, ball handler
  0.836x. All survive player-FE/leave-one-out checks but none passes 5% BH
  correction (q=.076/.085/.076): monitor only, not armed.
- Player primary type is reasonably stable (72.8% y/y); opponent defensive
  ranks mostly are not (spot-up r=.035, roll-man .041). The 2026-27 unlock is
  stored daily as-of snapshots, not prior-season defense.
