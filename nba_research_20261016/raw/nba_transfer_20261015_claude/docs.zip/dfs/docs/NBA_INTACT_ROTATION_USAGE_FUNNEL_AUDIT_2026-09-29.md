# NBA intact-rotation usage × shot-funnel audit — 2026-09-29

October 1 follow-up: [individual player factors](NBA_INDIVIDUAL_CEILING_FACTORS_2026-10-01.md) tests each player's own thresholds and later-game effects, plus separate player coefficients. The pooled null below concerns a common interaction and does not establish that every individual effect is zero. The follow-up distinguishes sparse samples, persistent candidates and failed replication.

## Question and design

This test asks whether an established high-usage player has a greater chance of exceeding his own prior-20-game DraftKings p85 when the opponent allows his shots, even when his normal rotation is available. The condition uses prior-10 usage level rather than a usage-increase flag; current-game usage never enters a predictor.

The primary cohort contains 3,367 held-out player-games from December 2025 through April 2026. A game qualifies when at least four other established same-team rotation players are represented and none is absent. “Established” means prior-10 minutes of at least 20 inside the stable team-stint participation panel. A stricter five-teammate sensitivity contains 3,277 held-out player-games.

High usage is prior-10-game usage at or above the earlier training sample's 75th percentile. The cutoff ranged from 22.86% to 22.96% in the primary monthly folds. Shot fit is the player's prior shot-type share multiplied by the opponent's prior allowed attempts per 100 for catch-and-shoot, pull-up, or shots under 10 feet. Every monthly model was trained only on earlier dates. The additive comparison already includes usage, shot fit, prior player performance, minutes, pace, efficiency, rest and positional fantasy allowance.

## Observed high-usage cells

These are held-out rates within the high-usage group. The interval resamples calendar weeks. They are descriptive associations; the matched forecast ablation below is the incremental test.

| Shot fit | High-fit games | Lower-fit games | High-fit ceiling rate | Lower-fit ceiling rate | Difference (95% week interval) |
|---|---:|---:|---:|---:|---:|
| Pull-up | 440 | 422 | 14.09% | 12.32% | +1.77 pp (-2.08, +7.53) |
| Catch-and-shoot | 38 | 824 | 5.26% | 13.59% | -8.33 pp (-14.24, -3.06) |
| Under 10 feet | 100 | 762 | 7.00% | 14.04% | -7.04 pp (-12.77, -1.30) |

The pull-up pattern is the only positive raw contrast. It weakens to +0.90 percentage points in the stricter five-teammate cohort, with a -3.24 to +7.12 interval. Catch-and-shoot has only 38 high-usage/high-fit observations, so its negative raw rate is too thin to treat as a stable player rule. The under-10-foot negative association also does not establish a causal penalty; player archetype and opponent selection remain possible explanations.

## Held-out interaction test

Eight predeclared interaction models were tested in each of the two intact-rotation cohorts: binary high-usage × high-fit and continuous usage × fit for each shot type and all three jointly. Positive Brier improvement means the interaction predicted personal-p85 games better than the additive model.

No positive interaction survived uncertainty or the 16-test Benjamini-Hochberg family correction.

| Primary interaction | Brier improvement | 95% week interval | Adjusted q |
|---|---:|---:|---:|
| High usage × pull-up fit | +0.000027 | -0.000057 to +0.000129 | .883 |
| High usage × catch-and-shoot fit | -0.000131 | -0.000250 to -0.000022 | .381 |
| High usage × under-10-foot fit | +0.000162 | -0.000073 to +0.000366 | .801 |
| All three binary interactions | +0.000020 | -0.000266 to +0.000250 | .977 |
| All three continuous interactions | -0.000092 | -0.000269 to +0.000079 | .801 |

The additive model's primary-cohort Brier score was 0.114615 and AUC was 0.6474. The best displayed interaction changes Brier by about 1.6 Brier basis points and its interval crosses zero. Player-cluster interval sensitivity reaches the same decision.

## Decision

The proposed mechanism is reasonable, but this sample does not support a general high-usage shot-funnel multiplier when the established rotation is intact. Pull-up fit remains the only directionally positive candidate, and its observed lift is small, imprecise and weaker under the stricter availability definition. It should remain a contextual note until another season supplies an independent replication sample. No production trigger or weight changed.

The availability definition is retrospective. It is based on who eventually appeared within a stable team stint rather than timestamped injury reports at DFS lock, and it can miss terminal injuries after a player's last appearance. The result therefore answers the historical mechanism question under the best available participation proxy; it does not certify that every player was known available before lock.

Reproducible sources: `nba/analytics/available_usage_funnel_study.py`, `nba/analytics/data/research_next/available_usage_funnel_summary.json`, `available_usage_funnel_comparisons.csv`, `available_usage_funnel_high_usage_contrasts.csv`, and `available_usage_funnel_predictions.parquet`. The source frame SHA256 is recorded in the summary receipt.
