# NBA work reconciliation and audit — September 22, 2026

**Later same-day completion:** [Three follow-up studies](NBA_THREE_TEST_RESULTS_2026-09-22.md) now run on a separate repaired research frame: all 1,230 2025–26 regular-season games, eligible Cup games restored,165 targeted tracking pulls saved, unresolved tracking differences quarantined. This resolves the game-universe defect for that research path; legacy frames/triggers remain qualified historical vintages. The new forecast/source/role results do not authorize production weighting changes.

**Additional source findings from the top-15% follow-up:** date/category coverage did not prove player/game tracking completeness, and the historical frame excludes tournament-labelled games, including games that count toward the regular season. Prior shot ranks therefore remain source-limited. The detailed counts, qualified player study and remaining repair work are in [NBA_TOP15_TRENDS_2026-09-22.md](NBA_TOP15_TRENDS_2026-09-22.md) and [NBA_TOP15_METHOD_AUDIT.md](NBA_TOP15_METHOD_AUDIT.md). The invariant passes below establish reproducibility, not complete source coverage.

This review inventories the existing NBA work, refreshes current rosters, and tests historical calculations against raw inputs. The canonical NBA project is `~/Downloads/dfs`; its `nba-dashboard/` is the consolidated dashboard. The separate `~/Downloads/nba-dashboard/` copy carries the same stale March data metadata. No scoring weights, ownership bands, fee thresholds, entries, or external accounts were changed. Nothing was committed.

## Current roster and continuity

The official [NBA roster listing](https://www.nba.com/players) was retrieved September 22 at 04:01 UTC. Its 573 active listed players cover all 30 teams with unique NBA person IDs. The Stats `commonallplayers` request timed out; the official page's structured player records supplied the fallback. The raw page, hash, retrieval timestamp, source URL and normalized IDs are saved in `nba/analytics/data/roster_snapshot_2026*`.

Relative to the August 5 listing, 26 continuing IDs have a different team, 43 IDs have been added, and 55 are no longer listed: 585 + 43 − 55 = 573. These are listing differences, not individually verified transaction announcements or opening-night eligibility. The [official coaching tracker](https://www.nba.com/news/2026-coaching-tracker), checked September 22, still lists six changed teams; the existing reset map agrees. No coaching correction was needed.

The refreshed funnel includes **all 582 historical player IDs**, including players without eight games needed for a ceiling label. Previously, aggregating only labeled rows silently dropped those short histories. Current players split into 270 same-team/same-coach, 68 same-team/new-coach, 125 moved-team, and 110 without a prior frame. Another 119 historical IDs are absent from the current listing. This larger historical population is a methodological inventory correction, not evidence of 119 new departures since August.

Among same-team/same-coach players, 130 have at least 50 labeled historical games and 14 have a corrected prior shot trigger. They remain a revalidation queue; no 2025–26 individual conditional rate is promoted to a 2026–27 live signal. Details: `docs/NBA_2026_ROSTER_FUNNEL.md`; ID-level differences: `nba/analytics/data/roster_changes_since_2026-08-05.csv`.

## Research calculations and repairs

| Area | Evidence and disposition |
|---|---|
| Fantasy points and ceiling labels | All 25,039 2025–26 DK scores agree with the raw player feed. Both seasons' prior-20-game/minimum-eight p75 and hit labels reproduce exactly. Rebuilt frames retain every score and label. |
| Shot diet | The old builder used each player's full-season shot mean to select their favorite category, leaking future games. It now uses sorted, shifted prior-game expanding means. First appearances have no prior category; deterministic category order resolves ties. Future-data mutation tests show later shots cannot alter earlier profiles. |
| Tracking identity and coverage | NBA and BDB use the same person IDs in the audited inputs. The merge now joins IDs directly, rejects duplicate keys and incomplete date/category pulls, and reports IDs outside the filtered frame. No actual incorrect old identity mapping was found. One 2024–25 tracking ID lies outside that frame. |
| Apparent absences | Players with sub-minute appearances were filtered out before forming participation sets. Five concrete 2025–26 examples were falsely considered absent. Participation sets now include every positive-minute appearance independently of the analytical one-minute outcome filter. |
| Pre-lock claims | Absence flags still come from final participation, not timestamped injury reports. Closing Vegas lines also lack proof of availability at DFS lock. The corrected backtests remain retrospective research; “deployment-grade” and blanket “zero lookahead” claims are not supported. Exact-five-position absence claims are not reproduced by the saved coarse G/F/C builder. |
| Synergy season profiles | Traded-player team stints are now summed before eligibility and top-category selection. Exact possession ties use an explicit alphabetical category fallback. Duplicate input rows and missing defense are checked. The broad negative result survives. |
| Statistical helpers | Constant exposure, overlapping terciles, missing/undersized controls, nonfinite data and duplicate player-season records no longer produce misleading significance. Own-log permutations now compare the same high/low groups as the observed statistic. Thresholds are unchanged; finite random permutations use add-one p-values. |

The rebuilt 2025–26 frame contains 20,638 labeled player-games. The unchanged trigger-selection rules yield 455 historical trigger rows across 259 players, including 50 shot-axis rows. Walk-forward ceiling rates for 0/1/2/3+ active triggers are **28.1% / 33.5% / 36.8% / 37.8%**, over 15,191 games from December 31 onward. These replace the previous 28.2/33.4/36.7/38.1 figures for this exact window. They are associations using the qualified historical inputs above, not proof of a deployable injury advantage.

Corrected Synergy season aggregation gives **0.980×** broad year-ahead lift, on/off n=4,103/11,294, Fisher p=.493. The historical-control adjusted OR is .970, p=.463. No subtype passes the 5% multiple-testing gate: the three previously highlighted tails each have q≈.0895. Category persistence is 222/304 = **73.03%** under the corrected aggregation and deterministic tie rule. The old 72.8% and old subtype q-values are superseded. Player-fixed-effect/leave-one-out numbers in the August report lack a saved reproducible implementation; they were not certified in this audit.

Both seasons and the trigger table were rebuilt from the existing BDB feeds and tracking CSVs. The 2024–25 window ends March 10; the 2025–26 window ends April 12. They are not equal full-season windows. Before-repair datasets and narrative vintages were preserved under `nba/analytics/data/archive/pre_audit_2026-09-22/` and `docs/archive/nba_pre_audit_2026-09-22/`.

## Live tools

The July handoff's “unbuilt” descriptions were stale. `se_precheck.py`, `build_id_bridge.py`, `exposure_edges_lens.py` and the contest checklist already existed. The identity bridge resolves all 360 FL IDs rostered in at least five of the user's 2025–26 contest files; no incorrect identity mapping was confirmed in the bounded review.

The precheck and slate board did contain serious implementation errors. Any nonempty out-list activated unrelated players' absence triggers; the board silently omitted eight axes; the precheck counted team stacks as game stacks; live candidate enumeration IDs did not match FL IDs; invalid or duplicated builds could receive heuristic passes. Those defects are repaired, with regression tests.

Live axes now require explicit same-date `pid,date,f_*` factor rows and trigger provenance (`trained_through` before the slate, in the same season). Missing facts remain pending, rather than being treated as active or false. Previous-opponent frame rows and a free-text out-list cannot certify tonight's factors. September smoke checks activate no prior-season triggers. Standard DK salaries, the existing user slate format, names lists and single DK entry rows are supported.

The checker now separates game and team stacks, rejects invalid/duplicate eight-player builds and invalid ownership, and labels missing game mappings or fees unknown. A real 150-build feed has 93 game-four stacks but only 23 team-four stacks; the repaired checker agrees with direct source calculations. “At least one low-owned slot” is a shape screen. Exact-one swap, salary/position legality, outgoing-player match and portfolio stack frequency are explicitly unevaluated. Numeric C11 thresholds remain historical hypotheses, not newly validated recommendations.

## Historical construction and money

The source audit found 2,033 incomplete hashes among 67,525 distinct personal builds. Including unresolved player IDs, 6,297 builds / 9,535 entry counts across 263 contests fail structural validation. Do not impute their missing players. Companion winner feeds also contain partial rosters.

Of 1,457 winner-contest rows, 999 field counts differ from DK by some amount, 54 differ by more than 1%, 19 by more than 5%, and nine exceed twice the DK field. These are diagnostic bins, not approved tolerance thresholds. One preserved histogram fixture produces a **220.35% stack rate** because source denominators disagree. Replacing its denominator or clamping the rate would conceal the source conflict.

Five winner-analysis contests also bypass the existing attribution guard, crediting 189 rosters against five DK entries. Mixed-user duplicated winning builds overcredit named-cohort entries. These flaws remain reasons to withhold the affected construction claims until source-consistent rebuilding; they were not silently “fixed” by discarding a convenient subset.

The showdown date join repeats daily money across multiple feeds: 45 joined rows represent 38 dates. Its old $391,766.89 fee sum becomes $294,478.89 when those same dates are counted once; net changes from −$9,203.93 to −$2,520.13. **Neither number allocates money correctly to game-level slate character.** The runner now refuses a many-slate-to-one-day money join. No allocation rule was invented.

The independent DK money calculation reproduces $10,514,180.30 fees and −$421,882.56 net for the old NBA-lane scope. That scope contains two free NBA best-ball entries with $50 winnings; excluding them yields 372,218 entries and −$421,932.56 net, with fees unchanged. The old report also overstated NBA-lane contest/day counts: the reproduced old scope is 18,498 contests and 859 days. WNBA was checked separately. No duplicate NBA entry keys or missing cash/ticket fields were found.

All 64 usable historical showdown optimizer outputs were legal and matched an independent exact-score solver. C11's low-owned-slot direction also survives a narrow completeness-only sensitivity test (225 comparisons, median four swaps). These passes do not repair source-count conflicts, hindsight selection, or establish forward ROI.

## Open-item reconciliation

| Existing item | Current status / remaining work |
|---|---|
| Current roster funnel | Refreshed with official source receipt and ID-level changes; preseason listing still needs later opening-night refresh. |
| Identity bridge | Built; frequent historical-player acceptance passes. Extend with new-season FL identities when available, do not rebuild from scratch. |
| Pre-lock SE checker | Built and mechanically repaired. Current factor builder, legal swap checks, and portfolio frequency check remain open. |
| Exposure-versus-edge lens | Built; 30,317 saved rows. Full-season trigger selection is in-sample, saved factor columns lag the script, and corrected upstream features invalidate freshness. Preserve as historical; regenerate after source validation, with explicit training vintage. |
| Contest-selection checklist | Exists; historical construction/fee prescriptions need source-consistent and held-out revalidation. |
| NBA dashboard refresh | Still open. Both copies report March 26 data with older slate/environment windows. No saved refresh generator was found. No dashboard was commissioned or rebuilt here. |
| Daily Synergy snapshots | Puller exists; 44 historical aggregate files are present. A dated, routinely maintained 2026–27 snapshot collection and daily-factor path remain open. |
| NBA Cup game universe | Repaired in `research_v2`: all 1,230 recent-season games, 66 source-labelled Cup games included, championship excluded. Older feed still ends March 10. Legacy frames and original top15 report remain explicitly subset-only. |
| Player/game tracking gaps | 165 targeted requests succeeded in `research_v2`; 46 of 53 original recent-season blank shot rows now exactly reconcile. All date/category pulls present; 1,295 expanded-sample recent-season rows still fail strict shot reconciliation and remain missing. Prior opponent features use only observed valid history; legacy rank tables are not promoted. |
| Pro-cohort season analysis | Partial historical season fields exist; complete per-season cohort ROI not established. Exact entry multiplicity matters. |
| Train / non-entered flagship backfill | No stratum-5 files in current personal-contest archive; no completed non-entered flagship backfill established. |
| WNBA source probe | Separate sport; not performed in this NBA audit. The old open item is explicitly out of scope. |
| 2021 showdown reanchor | Open; current library starts in 2022. |
| DK showdown lineups / FantasyCruncher session | Prior request for exports/login remains unresolved; current login state was not checked. No new authentication or export request was made. |
| Field-calibrated lineup simulations | Not built; data calibration depends on resolving the source conflicts. |

## Validation and operational conclusion

Raw findings with original line references and reproductions are saved in `NBA_ANALYTICS_AUDIT_EVIDENCE_2026-09-22.md` and `NBA_CONSTRUCTION_AUDIT_EVIDENCE_2026-09-22.md`. Rebuilt numerical receipts are under `nba/analytics/data/`. The source-quality scanner is repeatable and fails its strict gate on the real corrupt fixtures; it does not pretend those data are clean.

Run the roster/research invariant gate with `python nba/analytics/integration_audit.py --strict`, regressions with `python -m pytest nba/analytics/test_data_integrity.py nba/analytics/test_live_tools.py nba/analytics/test_statistical_core.py -q`, and the separate historical-source gate with `python nba/analytics/source_quality_audit.py --strict`. The latter is expected to remain nonzero while the documented source conflicts remain. The existing Fantasy integration audit also completed with zero P0 violations; that NFL gate is not certification of NBA sources. Final verification: **62 regression tests passed**, the NBA roster/research strict gate exited 0, and a copied fixture with the old full-season shot mean was rejected as `noncausal shot diet`. `git diff --check` passed. The separate source-quality strict gate exited 1 as expected on unresolved real data conflicts.

**Continue from the repaired roster and research foundation. Historical construction recommendations are provisional, and the NBA live workflow is not yet ready for autonomous use.** The next substantive step is an explicit source-reconciliation policy followed by clean replay, then timestamped current-season factor collection. Any tolerance rule, new weight, C11 strategy tuning or allocation of daily money to games requires a stated decision before implementation.
