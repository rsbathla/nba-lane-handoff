# NBA forecast provenance audit — October 2, 2026

Internal evidence for the selection and exposure audit. Source notes precede conclusions. Provider estimates, saved custom/import estimates and reconstructed research forecasts are separate vintages. No score or winning outcome filtered this inventory.

## Confirmed source notes

### Original ETR downloads

Original local download metadata identifies **214 files with 2025–26 context and ETR origin**, containing **206 distinct content hashes**, across **78 filename/download-context dates**. Their `com.apple.metadata:kMDItemWhereFroms` hostname is `establishtherun.com`; identification does not rely on guessed filenames. All 214 are generic NBA DFS Projections CSVs. Older DK/FD NBA Projections files also have ETR download origins. The manifest pins content and origin-metadata hashes while retaining only safe hostnames.

These counts describe export context, not verified slate coverage. Explicit filenames identify 113 files over 40 dates. Other files need their local capture date and player/team/opponent/salary/DFS-ID rows reconciled to a historical slate. There are 82 DK files over 51 context dates and 132 FD files over 64 context dates. Within the existing box-score endpoint of April 12, there are 177 ETR files over 66 dates, including 60 DK files over 39 dates. FD fantasy points and salary cannot stand in for DK fantasy points and salary; FD minutes can be a separately declared role proxy after exact player/game matching.

Raw columns include `Minutes`, `Salary`, `FPTS`, `Ceiling`, `ProjOwn`/`Own`, `Site`, `Slate`, `Scenario`, `DKSlateID` or `FDSlateID`, and provider player names. They do **not** contain projected usage rate, FGA or assists. `DKSlateID=42086564` is a DraftKings slate-player ID. `FDSlateID=127814-171779` includes a FanDuel slate prefix and player ID. Blank IDs remain unsupported.

Header order matters. The original-looking provider FPTS field immediately follows Salary in 213 of 214 recent direct-origin files. NBA DFS Projections (16).csv has a blank header and blank values there; its early Projection field stays separately qualified. A leading FPTS/Projection before Salary is often added or replaces Pos. Across all 222 generic NBA CSVs, 16 have differing early/custom and retained FPTS values: nine have direct ETR origin and seven arrived through mail attachment origin. Those differences do not establish who edited them or when the owner used them.

Two primary ETR rechecks:

- NBA DFS Projections - 2026-02-24T195707.884.csv, SHA256 `22e3d4155a72f3661b0dcad9791f760d3f4b231990473be12f2a3d8a3ba5d3ec`: Gui Santos has DK ID 42086564, 30.0 projected minutes, $5,600 salary, 31.7 FPTS, DK/MAIN/Default. Brandin Podziemski has 30 minutes/33.0 FPTS, and Pat Spencer has 26 minutes/27.1 FPTS. Filename, quarantine epoch, birth and modified time agree on 19:57:07 EST. The Thunderdome CID 188339631 begins at 19:00. This export is later than initial contest lock, even though some western games remained unstarted.
- NBA DFS Projections (93).csv, SHA256 `47247ff8df97c0eb19ae6e97e8c9edcfef35b6e87fd6d3ed646dd62cdedaa62b`: Tyrese Maxey has DK ID 41574433, 39 minutes, custom FPTS 53 and retained FPTS 49.5. Joel Embiid, ID 41574436, has custom 1 versus retained 46.7. Birth is January 19, but last modification is January 21. The saved custom values are not proved to have existed before January 19 lock.

### FantasyCruncher exports

The dated DK family has 179 files across all seasons, including 127 files over 96 dates in 2025–26 context. The FD family has 103 files across all seasons, including 75 files over 65 recent dates. DK has 114 files over 85 dates within the existing April 12 box-score endpoint.

Draftkings_NBA_2026-03-11_players.csv has 212 player rows, grouped headings on row 1 and true headers on row 2. Its SHA256 is `33748c1acd5b88803248516058206a8203d3365e273ff7edc9ae40525a5831e3`, and origin is `www.fantasycruncher.com`. Quarantine capture is 15:00:13 EDT, while the listed games start at 19:30. That is strong local evidence of a pregame export, subject to local metadata and exact pool limitations.

The grouped header separates provider Proj Mins/FC Proj from custom/import Mins/My Proj. FPPM occurs separately in historical, provider and custom groups. USG/FGA/Ast/Min under Player Averages - Season are historical averages, not tonight's projected touches. This family contains no stable NBA or DFS player ID.

None of the 127 recent DK files has a numerical Mins versus Proj Mins difference among comparable numeric rows. Six files have differing My Proj versus FC Proj values: January 27 (1), February 7 (1), February 24, March 5, March 20 and April 15 (1). This identifies saved differences, not manual owner decisions. On February 24, Luka Doncic has FC 55.09 versus My 58.7; the latter matches ETR 58.7 later that evening. One matching example does not establish that all custom columns are ETR imports.

The February 24 DK file, SHA256 `be18571c8a6548786d7c217c3220071018e367f0aca9bc374b9429af824f84fe`, contains 68 late-game rows at 10:00/10:30 pm and was captured at 20:31. It cannot provide full alternatives for the 19:00 Thunderdome. The FD export that day covers earlier games instead. March 12 (1) DK/FD exports contain an Actual Data group and were captured March 13; they must remain separate from the March 12 unscored exports.

### SaberSim and owner adjustment leads

Nine NBA_20*.csv files span five dates: April 15, April 17, May 11, May 15 and May 19. Their origin is `app.sabersim.com`. They retain filename slate/date/time, DFS ID, SS Proj, My Proj, Live Proj, Actual, Min, PTS, AST, RB, 2PT, 3PT, exposure fields and simulated point quantiles. Seven files have differing saved My Proj and SS Proj values. The definition of 2PT/3PT as makes versus attempts is not established by these headers; projected FGA must not be invented.

April 15 has three distinct DK snapshots captured at 08:47, 16:54 and 19:20 for a filename 19:30 slate. April 17 DK was captured at 19:26 for a filename 19:30 slate. Actual fields are zero and live fields empty, supporting local pregame context. May 15 DK was captured at 20:44 for a 19:00 slate and contains 18 nonzero actual scores and 21 live forecasts. It is a live/postlock artifact. Every version survives in the manifest.

2026-05-09_NBA_playoff_DFS_projections.xlsx contains DK Proj Min, Adj Min, delta minutes, Logic, Adj FPPM, Adj FPs and DK Proj FPs. Its XML created/modified timestamps are 2026-05-09T17:52:40Z, before its listed 15:00 ET game. Input revision, author and whether these assumptions were used are unresolved. The existing actual boxes stop April 12, so evaluating this later playoff artifact requires later boxes. Owner matchup workbooks also contain Proj Minutes and historical usage/shot/pace fields, but headers alone do not establish generation rules or historical windows.

### FL original JSON and database

Original FL raw rechecks used CID 188339631 on February 24 and CID 184483420 on November 5. Both player objects contain: actualPoints, currentTeam, currentTeamId, eventId, eventTeamId, favDog, firstName, fullName, homeVisitor, lastName, madeCut, ownership, playerId, position, projPoints, rosterPosition, salary and statDetails. ProjPoints is their only projection field. Checked player statDetails are empty. There is no projected minutes/usage/attempts/assists or projection revision/capture timestamp. ContestDate describes the contest, not the projection vintage. Finished-field ownership, actual points and winnings establish post-contest archives.

February 24 raw SHA256 `5f2bdcc5fcc74eca21b2ff50447393dcb49710603c0ab7cb5fac90155866d024`: Gui Santos FL ID 195274 has projPoints 31.4, versus ETR 31.7 later that day. Curry and Butler have zero source projections but no cause or prelock timestamp. November 5 SHA256 `8a1931f22c7d1c5a863475ebe84599d97ba0de50278fc0454275ee1608e31f23` independently corroborates the schema and its 19:00 contestDate. Zero source projection is not a certificate of nonparticipation.

The read-only database has zero projections rows, including zero NBA rows. Its schema contains sport, slate_date, player_name, projection, ownership_proj, source and locked_at, with no minutes or touches. NBA contests, slate_players and player_results each have zero rows. NBA entry_history has 388,343 entry/contest result records, not forecasts. Frozen research forecast and role parquet files are generated retrospective models, not owner estimates.

## Inference and unresolved limits

ETR is now an identifiable primary source. A qualified provider-based audit need not rely entirely on another provider. Timing remains uneven: 108 of 214 direct-origin recent ETR files were modified on a date later than their context date. Quarantine/birth timestamps corroborate acquisition but do not freeze currently saved content. No inspected source has an immutable contemporaneous receipt proving which provider/custom revision drove an initial roster or later swap. Immutable prelock-certified owner forecast dates therefore remain zero. This limits attribution; it does not prevent explicitly qualified archived diagnostics.

Custom/import fields establish saved differences and sometimes corroborate ETR values. They do not identify the estimate driving each entered roster. Owner-used minutes could equal the provider baseline without an edit. Neither these headers nor generated research forecasts reconstruct the owner's full expected touch allocation or manual usage/shot/pace judgment.

## Exact recent SE retrieval contexts

These are inventory date/site matches before exact player, game and pool closure. They do not count as certified full-roster forecasts.

| Contest ID | Date | ETR DK files | ETR FD files | FC DK files | Qualification |
|---|---|---:|---:|---:|---|
| 183877515 | 2025-10-23 | 0 | 0 | 0 | No same-context export identified |
| 183929501 | 2025-10-24 | 1 | 1 | 0 | Generic exports (4) DK/(5) FD; date, pool and timing closure required |
| 184483420 | 2025-11-05 | 0 | 0 | 0 | FL point projection only |
| 187351358 | 2026-01-16 | 0 | 4 | 1 | FD minutes proxy separate from DK points/salary |
| 187549820 | 2026-01-22 | 0 | 1 | 1 | FD minutes proxy separate from DK points/salary |
| 187572958 | 2026-01-23 | 0 | 0 | 3 | Preserve FC variants and pool coverage |
| 188170143 | 2026-02-19 | 0 | 0 | 1 | FC provider archive proxy |
| 188339631 | 2026-02-24 | 1 | 0 | 1 | ETR after main lock; FC late-game pool only |
| 188750204 | 2026-03-11 | 0 | 0 | 1 | FC 212 rows at 15:00 local |
| 188927072 | 2026-03-17 | 0 | 0 | 0 | No same-context export identified |

## Reusable loaders, retrieval leads and gap search

Reuse peer_process_sources.source_players for exact FL source IDs and preserved projection/event/salary fields, verified SE source lanes from peer_se_traits.source_tables, and the participation overlay for actual/prior role. Core ingest_fc_rewind.py recognizes FC grouped headers, but it is NFL-only, requires actual Score and uses INSERT OR REPLACE. It is unsuitable for preserving NBA historical snapshot revisions and must not be run against these exports.

The final gap search inspected download-origin metadata on 4,001 safe top-level CSV/XLSX files. Sixty-eight additional direct ETR exports were other sports or WNBA, not another NBA family. Inventory also covered named Downloads forecasts, dated FC players, SaberSim players, projection templates, owner matchup workbooks, repository NBA folders and read-only SQLite analytics tables. No credentials, auth or cookies were opened. No graphify-out was available in the existing workspace inventory.

Useful retrieval leads are platform-ID joins to original entry/upload/late-swap files, provider revision histories, owner cloud object versions and daily minutes exports. Preserve current checksums and local metadata before editing. Historical provider date/game context should take precedence over filesystem date alone. Later playoff boxes are needed for May owner adjustments. Generated later research remains a separate vintage.

## FINDINGS

- Confirmed data: ETR origin is established, and Minutes/FPTS fields exist at usable volume. FC supplies a larger dated role-proxy archive, and SaberSim supplies a smaller later box-forecast archive. Every candidate version is retained.
- Inference: local context and baseline/custom differences permit qualified archived diagnostics. They cannot alone assign an error to an owner prelock forecast or private reasoning.
- Assumption for mechanical matching: local dates use America/New_York, original group/index semantics survive, and exact player/game/pool matching precedes comparisons.

## CONFLICTS

- Treating all source projections as owner forecasts violates the source/time boundary. Treating historical USG/FGA/Ast as projected touches crosses a metric boundary.
- FD points/salary do not establish DK points/salary. A same-date late pool does not establish main-slate alternative coverage.
- Edited columns, overwritten headers, live postlock data and reconstructed forecasts cannot silently become initial forecast features.

## DECISION POINTS

- Recommended: continue the authorized qualified archived ETR-primary/FC-proxy audit, separating baseline/custom values and testing timing/version sensitivity. Keep source gaps distinct from confirmed decision errors.
- Owner attribution needs an initial saved projection/import revision or contemporaneous note linking an estimate to entered rosters. Additional collection should not block qualified diagnostics now.

## Machine-readable inventory

[archive_manifest.json](../nba/analytics/data/research_role_forecasts/archive_manifest.json) contains absolute paths, full SHA256 hashes, safe provider hostnames, context dates, sites, UTC birth/modified/quarantine times, ordered headers and semantic indices. All 743 candidates survive, regardless of outcome. No URLs, query strings or bearer/auth values appear.

## Direct ETR recent archive index

Dates below are filename/download-context dates, not independently verified contest dates. `F` means explicitfilename date; `Q` means quarantine download date.

| File | Context date / method | Site | SHA256 |
|---|---|---|---|
|NBA DFS Projections (1).csv|2025-10-21/Q|FD|2db135a3022ee27c15cec0dab5804e0e5d16df0f737fe6706a495604937b95a0|
|NBA DFS Projections (10).csv|2025-10-31/Q|FD|1314eb1d74bb675336290ed5d5f54c8a8de50d22f9f644934d4f2e6271fae010|
|NBA DFS Projections (100).csv|2026-01-21/Q|FD|af5bba6da37630c040b26e49b57b5c728e658e6e8b6cc996558d66a04dbb4792|
|NBA DFS Projections (11).csv|2025-10-31/Q|DK|abf549393b94f2b5427d00bf4cc66b816f94e0b10f980369b95ad3ca0901f83a|
|NBA DFS Projections (12).csv|2025-10-31/Q|FD|cec76c52afb3fe46645cb18947e4cb61955ad2f1e31d1cf44ac87e68efd42112|
|NBA DFS Projections (13).csv|2025-11-03/Q|DK|afe1d2c984a4ccae5ac9b23fc85a37dead547e33698bb088913e88a7d9f03512|
|NBA DFS Projections (14).csv|2025-11-03/Q|FD|a2b61a72e897072ca8f8de92a3c2faa18df69b0ec3e6c823c973c85e64ceca4f|
|NBA DFS Projections (15).csv|2025-11-07/Q|DK|53e0d339d1c367123dec6c8c86ade25d4776f729c8aae03059ee13cbd4314b6f|
|NBA DFS Projections (16).csv|2025-11-10/Q|DK|1f5901955fdb0ed8ef56273ea5cc654e823298d7d741b9306b75fe9542a953d9|
|NBA DFS Projections (17).csv|2025-11-20/Q|FD|58132d5fed4e5723adb65aaa2ebe96edb8523a5cddd108a25c1dee3ecc8cddcd|
|NBA DFS Projections (18).csv|2025-11-23/Q|FD|fc2ba691cc17b03554af4db626b8260c96bea1927a430706ad96198ed7615759|
|NBA DFS Projections (19).csv|2025-11-23/Q|FD|6f110bd11eb84b579a2eb4bf864310371b3c45bd6a5ce023397c45f11fb0a6fb|
|NBA DFS Projections (2).csv|2025-10-22/Q|FD|21937f9748480b7335e160c73a6261908772ad89b780bc0b482a9fe452e592af|
|NBA DFS Projections (20).csv|2025-11-23/Q|DK|7dc2b366095ecff4715b606847fe1d38f881b9fd50d30f3de07568af19fa182d|
|NBA DFS Projections (21).csv|2025-11-24/Q|DK|aa71d910a7b263f0cf47e4c1d9f4d3b285c018a269cc8c2ca7fcc0f9816ea325|
|NBA DFS Projections (22).csv|2025-11-24/Q|FD|2def72b18d9f1dee98b914c6425d8f84c9240f0eaf7879b7b2a5b30f5a72b0d1|
|NBA DFS Projections (23).csv|2025-11-28/Q|FD|362a386a85a781524902d17c7d9e9e6c5149317795b1a8264ad89713490504c7|
|NBA DFS Projections (24).csv|2025-11-28/Q|DK|163c5fa2e537e5857d4c8daad44954eafc14c00300b4cec8d83dc15de38d8c7a|
|NBA DFS Projections (25).csv|2025-12-01/Q|DK|c4845fbf2924be0bbd35d90d0801bf4eaac3d2402e463ea1274a31487a531462|
|NBA DFS Projections (26).csv|2025-12-01/Q|FD|15d389fcfe3c9273fa0fe779e0f06784f1345cbacb9ba986c9723f972f378694|
|NBA DFS Projections (27).csv|2025-12-07/Q|DK|26dbd5219460af947a68edf8bc70b83bd22ac9257fc9cd8864df185837259eb6|
|NBA DFS Projections (28).csv|2025-12-08/Q|DK|f1d103e247509986cf0a2a0c5703dd407a791e334e2ec74113d8f10e8efdaaff|
|NBA DFS Projections (29).csv|2025-12-08/Q|FD|eff1684186f6a23dcbf4b5b963c2f9da8f5c5fc4805848200da546bf883c43c3|
|NBA DFS Projections (3).csv|2025-10-22/Q|FD|3ef8dfd62697ac46266d80553903d17cd35fb19ae1fc6d2e1435efecd92c5281|
|NBA DFS Projections (30).csv|2025-12-09/Q|FD|2bef57e563db27fa2e5a54aaf7d0d9cd08f4cbf872ae2d1e2aebfa0d7c9e2056|
|NBA DFS Projections (31).csv|2025-12-09/Q|FD|8a2aae6d31db98897887de917cf07e768e5f3cd0405c90ab2e0d04f4840ba253|
|NBA DFS Projections (32).csv|2025-12-09/Q|DK|3fab01874d715a8a87e6e625aabaa15afb62ea8575626d58feff72f613d3d271|
|NBA DFS Projections (33).csv|2025-12-10/Q|DK|49c6ee53ced4ec6f675a626b897e468daa4404a28adb744e640600d3fa128eea|
|NBA DFS Projections (34).csv|2025-12-11/Q|DK|f28de00caf3c37eebcf62998c963e4ecf53a8ce404f608fe26243bddca36950b|
|NBA DFS Projections (35).csv|2025-12-11/Q|FD|ad265b74327cf3d7cbae8d1fe49f7ca96a7586730eb5a09a30867bcd782e8d9b|
|NBA DFS Projections (36).csv|2025-12-11/Q|FD|cbc102ac362c38f4e6efbc998c1f24178fa2792b0ac62f73241f3d4ef0255128|
|NBA DFS Projections (37).csv|2025-12-11/Q|FD|13952f16f3426879af4702fe5b37dc5c4575c8358708718f049b46ae8b68291c|
|NBA DFS Projections (38).csv|2025-12-11/Q|FD|8e0fa98c4dc847536b62398e9c531b7cbff9d2c8c8c5811742b072f36b426860|
|NBA DFS Projections (39).csv|2025-12-11/Q|DK|d03b9b4cecfaccb550eb0531bde6036c096d84ea079ab4cff9a6a31b5ac214e9|
|NBA DFS Projections (4).csv|2025-10-24/Q|DK|fe5134e00a8806a16db2ea1761d378dc66cc0dfcaaa3c7d4b493d6be88b31823|
|NBA DFS Projections (40).csv|2025-12-12/Q|DK|da6c3b141da7e09f74f21dc4b7fc1e2ab606ea35799f20293f80c053b2946ebe|
|NBA DFS Projections (41).csv|2025-12-15/Q|FD|54b835137af37a2d661364e769118aa4b9b105c9c8b72130b7ec56200917e5ac|
|NBA DFS Projections (42).csv|2025-12-15/Q|FD|df9fa28d3b88afdbfec426dc34e594535902ada48f53de2f568974628564fb69|
|NBA DFS Projections (43).csv|2025-12-15/Q|FD|9f03561e15bb5e24cbd310ded66eaae10d5ba5ec45a2f893966460c15c60aa13|
|NBA DFS Projections (44).csv|2025-12-19/Q|DK|cc739795e1170ab03984dc335446579cb8c380f47924e6a4f219a1f3d0a86c06|
|NBA DFS Projections (45).csv|2025-12-19/Q|FD|39680c8cbf01a00dac642db6be474b364a2caf5f7c707c89d41279a75517278f|
|NBA DFS Projections (46).csv|2025-12-19/Q|FD|e0e95e60a0ff41a07567b0c861ecd10cdeff32d4006cd34698b6509164bcc1c3|
|NBA DFS Projections (47).csv|2025-12-19/Q|FD|d2742fad718a36b63025e23d2b916be04f58b6d7efb171db7f9370f2a54311ac|
|NBA DFS Projections (48).csv|2025-12-19/Q|FD|725d961e23a7e170a103e8b3b5b2b7667525b0649084256ca5d5d37fc8db1bc0|
|NBA DFS Projections (49).csv|2025-12-20/Q|FD|241b34719485c8b9273e1729ec098201b9ff77ff31b386b368d4ebbd533756e6|
|NBA DFS Projections (5).csv|2025-10-24/Q|FD|5b4da449485f0a9ffc15cff068718d316b79a688e1da1291741332ea17452803|
|NBA DFS Projections (50).csv|2025-12-20/Q|FD|9bbbb74a1084fb62af0fd42c85cb50b8ac68ce81e74ef45034ea00d5af3d6aaa|
|NBA DFS Projections (51).csv|2025-12-20/Q|FD|991c9e83b5afbf081e046236ec654fedbc4a1094d5be63cc83883347b1b25091|
|NBA DFS Projections (52).csv|2025-12-21/Q|FD|4e6fed7a56de50bced33a93af4b7f5a8c085a8beb73685303206d3a12433b27b|
|NBA DFS Projections (53).csv|2025-12-22/Q|FD|7c765b47aae19dee1349d35c5dfd8ed0146b0661e7640a441f0e29c0bb5cb4ba|
|NBA DFS Projections (54).csv|2025-12-22/Q|FD|7737e835e59724d0ac186069106ef4021306ac7ea4093113c6d496905b216290|
|NBA DFS Projections (55).csv|2025-12-22/Q|FD|0dd1b8da6fccce70d0388c63cdb9733753230c7a0c3acfeccdcdf8a3fea8b0f0|
|NBA DFS Projections (56).csv|2025-12-26/Q|FD|51c06da05f80b069837c18f757f36c55ed25d6f197cda0e2ffb1c9a6de2de88d|
|NBA DFS Projections (57).csv|2025-12-26/Q|DK|f88f8719b29f2f6b58c5a3ad5629bcc0be6863f2a1872c5f3919781395865118|
|NBA DFS Projections (58).csv|2025-12-30/Q|FD|7d6dd393a01cd0c1177fab1e4087b0ce2e964bc08e92488635e9e575dab43cbe|
|NBA DFS Projections (59).csv|2025-12-30/Q|DK|07f217c424d21e274d7c8476c9fc4257b7861cd45274a7d8fea4499618dad1ac|
|NBA DFS Projections (6).csv|2025-10-29/Q|DK|1b4b67d4bffe8286ae815ea777f52aa5afb5a09466b5b0c884c3a2e51941a7f5|
|NBA DFS Projections (60).csv|2025-12-30/Q|FD|f1e55295e6426088e9f9c42c2b75ec09e3e86b236c414c5a9dd37ca830e84fa5|
|NBA DFS Projections (61).csv|2025-12-30/Q|FD|25d54966af0d4d60799455524db97620ddd2dc77e534661480d6554d2d32c47c|
|NBA DFS Projections (62).csv|2025-12-30/Q|DK|5bd63b848a14257a18abbd0802e694191e106dc8f3a72d7a72f768dc4e2cc0d2|
|NBA DFS Projections (63).csv|2025-12-30/Q|FD|71f2b3705f97cdb8b2effcfd3d08f3717014006c394826bddec1d71fe1bbd8a5|
|NBA DFS Projections (64).csv|2026-01-01/Q|FD|d474ed57400d32e2957499068b02c5004b53176338a118433509ab426ff383cd|
|NBA DFS Projections (65).csv|2026-01-01/Q|FD|d474ed57400d32e2957499068b02c5004b53176338a118433509ab426ff383cd|
|NBA DFS Projections (66).csv|2026-01-05/Q|FD|d203a9bb93cbd2d553ad9e8f598fab54d0a0e7b7101f4bd10b14fb9af712a0f7|
|NBA DFS Projections (67).csv|2026-01-06/Q|DK|e675353bf9c9cdda44b115ea938a9c1bbe89b0c9c5e31a53cb7a397f2155f242|
|NBA DFS Projections (68).csv|2026-01-07/Q|FD|9dc1b31b24b8b139f24d275e059ac09b0b589d8734292390bcd56977be9b60cc|
|NBA DFS Projections (69).csv|2026-01-08/Q|FD|377c09a9e52ad3c6e47c52a97c8651947e6a62fa3f74b65d574fa19d24390b05|
|NBA DFS Projections (7).csv|2025-10-29/Q|FD|34ba1b1dec33417a001d53e255999b7b66cd2b1d0f44bdf80b06f32d68d00673|
|NBA DFS Projections (70).csv|2026-01-08/Q|FD|7d711c85d36bcd95bdfadc114e785bb87fe93ffcd35e3b4af8afa454388b676e|
|NBA DFS Projections (71).csv|2026-01-08/Q|FD|be3f27e32ad2a2fe510147779ff4b45421743e08d0deaf0cd4cdfd8776ca4f03|
|NBA DFS Projections (72).csv|2026-01-08/Q|FD|d046a6a8fcaab81ac298857765457fefb5e5590aa4013f10dd3ebe38e55a54bd|
|NBA DFS Projections (73).csv|2026-01-08/Q|FD|d046a6a8fcaab81ac298857765457fefb5e5590aa4013f10dd3ebe38e55a54bd|
|NBA DFS Projections (74).csv|2026-01-08/Q|DK|40addcfce710c324efebfa64aab8e54dc57d0257bd23a00b93f76b336d1da55c|
|NBA DFS Projections (75).csv|2026-01-09/Q|DK|96895e269e75fa6d09e823b4896c790ecb3274abbd4e44508f38b00125749d8b|
|NBA DFS Projections (76).csv|2026-01-09/Q|DK|21c39add75a7483a337eaa8377eb27b5563d98bed2066437372262ece5aee7ef|
|NBA DFS Projections (77).csv|2026-01-09/Q|DK|24ef3d8e75c9e33d43a593de67eee7e54e4a72426d72b020b8e6c964f100e9c1|
|NBA DFS Projections (78).csv|2026-01-09/Q|FD|3f95183b989161a3da74332e69a950bb8355006e782c8db49e3b27b763b15aff|
|NBA DFS Projections (79).csv|2026-01-09/Q|FD|b925d86a5b356ebf64bba96e18955ba7acadd6d071b3341c981946d05a796780|
|NBA DFS Projections (8).csv|2025-10-30/Q|FD|018c6718db52ab6d4fcaf666a726f4b7a4b2725061d30b662225e96743cf2e0c|
|NBA DFS Projections (80).csv|2026-01-09/Q|DK|0ddb98d5426a28ff8237a3f00d5e6282760bd984e8b08198986106a57186e980|
|NBA DFS Projections (81).csv|2026-01-09/Q|FD|4fd9914cf8bc87c3fd982a41573061936298a2675fc2d6e4a141eb4d5193856d|
|NBA DFS Projections (82).csv|2026-01-09/Q|FD|d03feea33b5888573e8fb5570334414514a5182a738ca1c6d17ae986e92b7429|
|NBA DFS Projections (83).csv|2026-01-13/Q|FD|d2f33b4442cd0cecf393233b0291f2124c5dbcf99c0d98458738d3eb469d560a|
|NBA DFS Projections (84).csv|2026-01-15/Q|FD|c81130feaa187c8b194d616bc2571d4f60411f60d8d9108cd6b2c65597b45b71|
|NBA DFS Projections (85).csv|2026-01-15/Q|FD|746088042cd606b8d5d00d8c8853e3db6955033cc9ef25809db86eeb9a4fc839|
|NBA DFS Projections (86).csv|2026-01-15/Q|FD|c81130feaa187c8b194d616bc2571d4f60411f60d8d9108cd6b2c65597b45b71|
|NBA DFS Projections (87).csv|2026-01-15/Q|FD|5613650afe3be84837cd810fb856655d6df0e5dd9d5110ea23b6c902989a445a|
|NBA DFS Projections (88).csv|2026-01-15/Q|FD|8270a5a8d533514d00ec3772b175bf55f717899cd492e1a23c89859dcc07a9c8|
|NBA DFS Projections (89).csv|2026-01-16/Q|FD|d56fa430ff56761f6d5fb28a58ef3be36247096b88b74f31114dc7caa6d08745|
|NBA DFS Projections (9).csv|2025-10-31/Q|DK|92b5f684d872b8b8b744d66ded8ec1ceaf09828d679cc6ffb80c4a02fb420f69|
|NBA DFS Projections (90).csv|2026-01-16/Q|FD|9ab9f5180ebc9e21318e476a2897f611974abb5594c1755c2ebd68d377436f72|
|NBA DFS Projections (91).csv|2026-01-16/Q|FD|7c55e181b2fd35efba3eaa8c1cb835b9cf8cba8a0531df3cbf2b83617ee03213|
|NBA DFS Projections (92).csv|2026-01-16/Q|FD|e300beada748b7c2f9ec1f0e7f36e7b333292af91365739742d5a7e344c80df1|
|NBA DFS Projections (93).csv|2026-01-19/Q|DK|47247ff8df97c0eb19ae6e97e8c9edcfef35b6e87fd6d3ed646dd62cdedaa62b|
|NBA DFS Projections (94).csv|2026-01-19/Q|FD|0aa79111a67f8d23a1554520259ea12d4694335ce3775d300add0ac5856a9796|
|NBA DFS Projections (95).csv|2026-01-19/Q|DK|d7c460720d879186d5aeb5197a20ccebb1c49cdf3c5d7dd3240b4ed0b427fb96|
|NBA DFS Projections (96).csv|2026-01-20/Q|FD|4c884e4ef80c0d2ee452bf4154156fcfdb7a6ff4fa9e75437f04069c410d0a45|
|NBA DFS Projections (97).csv|2026-01-20/Q|FD|a586ac26152d50ff34ca665304a35034d4a6f684c5d0def0ebf66bcbb66d260d|
|NBA DFS Projections (98).csv|2026-01-20/Q|FD|9e6441ddc03fb3f18937e7acf4d2b75fa80a5377989b2b2f0ae7ce39a4b9a39a|
|NBA DFS Projections (99).csv|2026-01-20/Q|FD|92f011eb5c8febd5cf967a36df3d92bb30b40f31d0b3ca23859bfbef1894553b|
|NBA DFS Projections - 2026-01-21T184440.990.csv|2026-01-21/F|DK|d2a6a508fc16593d55620f35b923f99b126e13872af846046ae14c0bcfa03016|
|NBA DFS Projections - 2026-01-21T195643.284.csv|2026-01-21/F|FD|0ac2bf75a8ea09445ef022babfed1c86ed710a9403e71484a1491599c6c265af|
|NBA DFS Projections - 2026-01-22T184151.222.csv|2026-01-22/F|FD|84d25d309a6cd9a89e135f6e8d4d2f5e04970c86d83a2cac3c307136e7dcc416|
|NBA DFS Projections - 2026-01-24T195805.101.csv|2026-01-24/F|FD|1e6cb913c9bf80df78815ab8963f85ab0b81482204469a507095b25b6c3e2639|
|NBA DFS Projections - 2026-01-24T202451.512.csv|2026-01-24/F|FD|1e6cb913c9bf80df78815ab8963f85ab0b81482204469a507095b25b6c3e2639|
|NBA DFS Projections - 2026-01-26T194008.063.csv|2026-01-26/F|FD|b022ccd2f4cfad8efcb75933bb35a2410520e53e873d6d738b4d0689b23926b1|
|NBA DFS Projections - 2026-01-26T204020.885.csv|2026-01-26/F|FD|04c21e7a2e650ba04be30d0160d30d4bf7e524820aeb331e35457bbe59b6c5fd|
|NBA DFS Projections - 2026-01-27T204044.527.csv|2026-01-27/F|DK|019d9cec451bc480e141a984dd5cb8ea57bd9ae3226ddc37e4d0f4a0b6904d7a|
|NBA DFS Projections - 2026-01-31T180355.600.csv|2026-01-31/F|DK|80ef1293f417660940bb64b2614e706a13528f26a92682f98937b76b3836a907|
|NBA DFS Projections - 2026-01-31T183955.166.csv|2026-01-31/F|FD|8066586df493990b67c756cff6ca641f2445b86419bbb43920018a5a450d588f|
|NBA DFS Projections - 2026-02-03T192433.924.csv|2026-02-03/F|FD|57fafd7b216edde59ee57c7f8110dc33267f27d9016379d88603cf16772b3b0f|
|NBA DFS Projections - 2026-02-03T195346.822.csv|2026-02-03/F|FD|b2a6089da28141efb976a57204ed13d555ac810621eae90e650d10bf38b85660|
|NBA DFS Projections - 2026-02-07T144218.164.csv|2026-02-07/F|DK|bfdad24e0184de6b1a4a0da4813a7246e7cbd8cc5f7d738f4292b38d57c5b52e|
|NBA DFS Projections - 2026-02-07T152705.072.csv|2026-02-07/F|FD|ee6fa09ee682d92f728aed9d6cb82350f6d2f3ceafb7cd53060ba5b88eba1522|
|NBA DFS Projections - 2026-02-07T195900.971.csv|2026-02-07/F|DK|b65b032908bafb4c786da6f7968c5abe7b9f52b437e138d3dbb567d7670d481e|
|NBA DFS Projections - 2026-02-07T202902.985.csv|2026-02-07/F|FD|aaa6f9bf6e985f98be68f7a34a1ae8b247f78a1a233889e3ab6be8d1098a44ab|
|NBA DFS Projections - 2026-02-10T195841.758.csv|2026-02-10/F|FD|5b42ebf96b8c58535264dfc2568c5c416b8ea5317d0ac280bc08f809bc85ce0f|
|NBA DFS Projections - 2026-02-10T205212.330.csv|2026-02-10/F|FD|5f4aa83839ff853c66f1d58d06e0a0b64c98438aa6ef81050f916d80b2ede50d|
|NBA DFS Projections - 2026-02-10T205257.391.csv|2026-02-10/F|FD|8564629ff37d553c15ebdd4f1bdc62b9014eeef413622e033430cb9015012170|
|NBA DFS Projections - 2026-02-10T220941.703.csv|2026-02-10/F|FD|4d39e6bd2aecbc11a22f65062f437ef75de45af6b376971bad2709e7005e7407|
|NBA DFS Projections - 2026-02-11T192156.123.csv|2026-02-11/F|DK|f88f80675e39a38a067c24453d54078112632c4016864419dd5e989daabd937c|
|NBA DFS Projections - 2026-02-11T192203.651.csv|2026-02-11/F|FD|765232b0415439cc68485823ac7151c2efb12a84efdb2176ef832acd303abd3d|
|NBA DFS Projections - 2026-02-12T191420.075.csv|2026-02-12/F|DK|078c3a75f3a297031b2a89a89bbb62e3a224cba5e185b190e6371dc56641ef3e|
|NBA DFS Projections - 2026-02-12T191530.086.csv|2026-02-12/F|DK|637e17684095bb1502679765bcb3592233a27f831393f474f83f797e5ea8f723|
|NBA DFS Projections - 2026-02-12T192000.331.csv|2026-02-12/F|FD|be3a6dcdd56996e5690c5797cff6626ea032ddfe8de852df3fd5cf4f897e0777|
|NBA DFS Projections - 2026-02-12T204617.485.csv|2026-02-12/F|DK|c837d20f6113b4a7ab491aa9952179603dbbb5dd0bcae00629e3ee770faa3428|
|NBA DFS Projections - 2026-02-12T204900.131.csv|2026-02-12/F|FD|186bf32d69b70a19f0834ccbbfc0cde0edf2be89e5e6bddeba1e32e894f60489|
|NBA DFS Projections - 2026-02-20T221108.472.csv|2026-02-20/F|DK|c47038d51a05ba75a88567a7bcbb3f5c3fa5ede6bc59dc3d1243547646b73051|
|NBA DFS Projections - 2026-02-20T221512.729.csv|2026-02-20/F|FD|fad6b443a3e42b487497fa759019adfe2925c88f67ab7a34007abffcd2fc9f2c|
|NBA DFS Projections - 2026-02-23T194945.290.csv|2026-02-23/F|DK|63be2fe3dbca4692fbfab01985b6078798e4aad1cb15940ca34fe9fe913738b1|
|NBA DFS Projections - 2026-02-23T195216.753.csv|2026-02-23/F|FD|8c9d626a5d158b0545d3bd2fce37bcb4607f3f6983448602d0ec7aec1e33978f|
|NBA DFS Projections - 2026-02-24T195707.884.csv|2026-02-24/F|DK|22e3d4155a72f3661b0dcad9791f760d3f4b231990473be12f2a3d8a3ba5d3ec|
|NBA DFS Projections - 2026-03-01T202643.550.csv|2026-03-01/F|DK|a5a7cd58e66c90c015be60a5e8990cb2d60bd6fa08c192436617f4e43b541491|
|NBA DFS Projections - 2026-03-01T202912.861.csv|2026-03-01/F|DK|6aef417bc9020857606ca0537526b2081ded3164023b2a11c0ffa06a8bfb9272|
|NBA DFS Projections - 2026-03-01T204830.537.csv|2026-03-01/F|DK|ced4ca4c9d887e7bfcd0a4ce5a52e2d5e244a54830f9f4fbd7bbb0e356bd54fa|
|NBA DFS Projections - 2026-03-02T205501.300.csv|2026-03-02/F|FD|c33a28420ad0478760288be0e684316ee410cda7d8b36aff013228469d232f2b|
|NBA DFS Projections - 2026-03-04T183809.704.csv|2026-03-04/F|DK|3afeabe9dbb832b5d44ba9fa907a6e1efd096eacd70c241d1c3f3d154d78fcf2|
|NBA DFS Projections - 2026-03-04T184523.444.csv|2026-03-04/F|FD|cc285fcecff88a3f1846a426f4ecb9617011009a4d11e99cdfa93b1a48638e3d|
|NBA DFS Projections - 2026-03-04T192105.773.csv|2026-03-04/F|FD|28274ea4bd5ee28f8135b1c41eb27d952564b98371213172ed4e80d3b4f3bccd|
|NBA DFS Projections - 2026-03-04T192632.527.csv|2026-03-04/F|DK|c863180b7a618b16a5c0188594659304465638a3b65226ee46e8679fffd49f38|
|NBA DFS Projections - 2026-03-04T195020.874.csv|2026-03-04/F|DK|f701543184ccac79b64bacf0b8f2ad38d82f4c2ccf48c740faadedbfc4acac50|
|NBA DFS Projections - 2026-03-04T195902.890.csv|2026-03-04/F|FD|65aa073ad459de9a9af09b42bc45a00935d58d77f0914a2eed3c4d93bd2c9a1d|
|NBA DFS Projections - 2026-03-05T183715.366.csv|2026-03-05/F|DK|8b64672f73ccd9b07bce48e20a4cd12ba9dbcf8b09f599a5cd4441e7a90a0b66|
|NBA DFS Projections - 2026-03-05T184831.255.csv|2026-03-05/F|FD|ad89fbc87d5f3ee39945aa5869b6f86ee267892010b6af518d263ba2225e3fc1|
|NBA DFS Projections - 2026-03-05T185102.536.csv|2026-03-05/F|DK|d955f69485a544b4efe87e5892476941ba7b4d2b27e6c337cd22766ed49cc06a|
|NBA DFS Projections - 2026-03-06T195705.387.csv|2026-03-06/F|FD|2861a0967f23f392ea434eb4716dadadc53d2f00d55555a6c7f41cfe760fc234|
|NBA DFS Projections - 2026-03-07T195822.408.csv|2026-03-07/F|FD|4c606361bb6f809d39dba442a34a759c0f576c9837209e4aa7ca7be322606d90|
|NBA DFS Projections - 2026-03-09T204250.694.csv|2026-03-09/F|FD|8ac5eca8cd4e2e21db4f78a3ea3108b83ac580cfd6b545efc02944550bef6d7f|
|NBA DFS Projections - 2026-03-10T192807.457.csv|2026-03-10/F|FD|4cffcbb0997cba68be2d53364c5cc604c487cfb1488d4f2f7ffab3a7c2a508df|
|NBA DFS Projections - 2026-03-12T192511.353.csv|2026-03-12/F|FD|21a47af7c9d7ed065f85c032dfb1b5e897c1580dcffa7dab31694b7b70a6550c|
|NBA DFS Projections - 2026-03-12T192618.138.csv|2026-03-12/F|FD|d0168893fb28ef775c868f6e49e2cf1424e334d63db53cd27b4be88081cf8ac3|
|NBA DFS Projections - 2026-03-12T215349.701.csv|2026-03-12/F|FD|540ee71cc07126db159621b6b27d0dc241a64247309a01eabf35fac8f90e3108|
|NBA DFS Projections - 2026-03-16T195628.072.csv|2026-03-16/F|FD|4d81cd1e35f7538b82301b5f01c0835fb1690b0fc8731f408aa07b250d692a20|
|NBA DFS Projections - 2026-03-16T195729.120.csv|2026-03-16/F|DK|b333c9390f9001528da6917271929782853a47ec7e62f9880a76b5849efc80ef|
|NBA DFS Projections - 2026-03-18T180646.523.csv|2026-03-18/F|FD|dec81765d837c517b5847e6e843a64381bfbe898734c3bf064cf39e345392f1d|
|NBA DFS Projections - 2026-03-18T184727.021.csv|2026-03-18/F|FD|692cb66ab5617240444ab40d72e9e5b6a32e75fa59d0cbe5f8928a33c64232a9|
|NBA DFS Projections - 2026-03-18T184832.792.csv|2026-03-18/F|FD|acf6cbfc2b2ff0584097e5e85b310c2b4b3f354c944f0b50c5c2569e456e9165|
|NBA DFS Projections - 2026-03-18T185012.214.csv|2026-03-18/F|FD|991a66a7aa585dc38f2de0f387291fa62fd5f59084ec8174db2d86c07e4672b9|
|NBA DFS Projections - 2026-03-18T191656.852.csv|2026-03-18/F|FD|9bedbf8316b90d026d78e257551f445b5a0f2aaaba040a2f59d07e4e6fb0101c|
|NBA DFS Projections - 2026-03-18T191723.350.csv|2026-03-18/F|FD|9bedbf8316b90d026d78e257551f445b5a0f2aaaba040a2f59d07e4e6fb0101c|
|NBA DFS Projections - 2026-03-18T194843.638.csv|2026-03-18/F|FD|1c2f10366c70fb36b4dd11387850e025e6909b59257b990e93218472ba87726d|
|NBA DFS Projections - 2026-03-20T171410.559.csv|2026-03-20/F|DK|20c9fbaeb6b0f92bacc739f49c45a5190b4a418d70937d84004d74ca5a24c67b|
|NBA DFS Projections - 2026-03-20T180059.927.csv|2026-03-20/F|DK|77ef815a160f9fad8ca20fbdb3c099003abe595a28374292336bad8969a84654|
|NBA DFS Projections - 2026-03-20T183829.263.csv|2026-03-20/F|DK|772b03337aaf0ea3f9db96626171646ff3a439a352f052c3e3c78ac3cd3ec8d4|
|NBA DFS Projections - 2026-03-20T185459.230.csv|2026-03-20/F|FD|74f9d176895e2044c764e342104c42ab565ec1ef09877a3a520b3ac778c70bf7|
|NBA DFS Projections - 2026-03-20T185515.756.csv|2026-03-20/F|FD|d24e811d3870ca296ad5505653b208386960ccce70141ac19d7b790bf72f2d61|
|NBA DFS Projections - 2026-03-20T190600.845.csv|2026-03-20/F|DK|b305944cdb62d7cef2fb7152127c90f14cfb756a7971891e0761b0e81ce9e78b|
|NBA DFS Projections - 2026-03-20T191402.967.csv|2026-03-20/F|FD|7294a12cd8dd5f042474913b518d1b6d8a9438298b7d334dfb023fa3b3a47dd8|
|NBA DFS Projections - 2026-03-20T191412.768.csv|2026-03-20/F|FD|b42089180c858345f0b1e8cd73c4045450b7dac2c8d8376de21a9efdc136addf|
|NBA DFS Projections - 2026-03-20T192032.101.csv|2026-03-20/F|DK|812e99caf9810e46b2c35a005aa59ccbecea45d7f750015761953f214c63c2b9|
|NBA DFS Projections - 2026-03-20T192149.897.csv|2026-03-20/F|FD|a2b8e3ed15ae9de9b627f8c9d09f236770cbb00dcc585883d440f995f14e9be6|
|NBA DFS Projections - 2026-03-20T192450.305.csv|2026-03-20/F|DK|567a93ea0c7f470f77f70ad27bd39dfa08bc8d08e2a2f6ed802b5ac40f6fb833|
|NBA DFS Projections - 2026-03-20T192900.861.csv|2026-03-20/F|FD|72fa12dd9363a3c173085db4c565dcf070c5ab9b1e6c8e312ca6d475a20d9408|
|NBA DFS Projections - 2026-03-20T194524.897.csv|2026-03-20/F|DK|141c7368b06deee7a14d5ada4153e9c240bba124119f2f3286069c239f5b1750|
|NBA DFS Projections - 2026-03-23T185703.584.csv|2026-03-23/F|DK|3073e91435e9b71d67b3c44014cba830969bed46e91a379d02b066368b747cd1|
|NBA DFS Projections - 2026-03-25T205229.711.csv|2026-03-25/F|DK|5f9cec76c9246d283f22bbb338d0833a66e2654f38e321c1577e0e6c77472159|
|NBA DFS Projections - 2026-04-14T183231.750.csv|2026-04-14/F|DK|8dbda213b983df9f83e7f74345563c824145f1ac066e48cc0b478e88a33dba8b|
|NBA DFS Projections - 2026-04-14T192542.664.csv|2026-04-14/F|FD|73ba792d2e62bf180f2bf76d4a0e87e93fa67a149c37fbae83da5649a35f84f2|
|NBA DFS Projections - 2026-04-14T193007.247.csv|2026-04-14/F|DK|641cbe27f6e52e0a22bcbd455f134bffb3e87ea00038e7963621a3f4e96a2fb6|
|NBA DFS Projections - 2026-04-15T170426.429.csv|2026-04-15/F|DK|8b12f6ae0159be176c1efd7d2390626cbb026c37cb6f0f25c1272e418607af88|
|NBA DFS Projections - 2026-04-15T192203.431.csv|2026-04-15/F|DK|0b0a086def4e7241779621ad949fc883d097f1ea89a61d08c73b5224b439e780|
|NBA DFS Projections - 2026-04-15T192256.031.csv|2026-04-15/F|DK|ba77b9e727d56871351329f58fe225e5589fc05b84461e0ffac26d01c1c61668|
|NBA DFS Projections - 2026-04-15T192735.734.csv|2026-04-15/F|FD|86381a8c618c5bb68f204f34266d667068b881d008e19bbb300d94ba25d57112|
|NBA DFS Projections - 2026-04-17T191040.320.csv|2026-04-17/F|DK|57b3cb65825e04d505fde98df6047d9ef33c80a7b1c59d1a5a1a3e1a7e6e8401|
|NBA DFS Projections - 2026-04-17T192842.850.csv|2026-04-17/F|FD|ebd53e783dad8d2281dc511f4d5ae960336a97bfbbd312e0677dfeebeb475afd|
|NBA DFS Projections - 2026-04-22T172750.304.csv|2026-04-22/F|DK|18e49694ccdfd53699bb239638484a96081ec253e829b6884f05ae611b1ac202|
|NBA DFS Projections - 2026-04-22T183331.983.csv|2026-04-22/F|FD|42a7c3a7a0b171191a399972301628015f466aeae8eb472784ed5940558f5e29|
|NBA DFS Projections - 2026-04-22T184128.547.csv|2026-04-22/F|FD|ed9c2cc4f6966e46ca42271086dd558b6bd82dfad33ce50549941b4ab143e2ca|
|NBA DFS Projections - 2026-04-22T212250.154.csv|2026-04-22/F|DK|192b62cde6436fc45b4aa9ef2f109e1591ca1b75f4f031fc8f3b52fadbf0c8e8|
|NBA DFS Projections - 2026-04-23T173642.519.csv|2026-04-23/F|DK|21a866841083ac2ad5cf0227445ef98d27cc4eb05cb56a41cb66912e4f8deebb|
|NBA DFS Projections - 2026-04-23T182040.039.csv|2026-04-23/F|DK|e3fbdb7d58a0dc89cd9aa35e8e6170102d126209e122f69fc0c42e5e9aab079e|
|NBA DFS Projections - 2026-04-23T184343.873.csv|2026-04-23/F|FD|57ca8ca1b066f8036dbaa68ca46b3786b550a3dc1efaa3fb7b33d9ec97591de6|
|NBA DFS Projections - 2026-04-23T195029.494.csv|2026-04-23/F|DK|c443f273043ca60e9d52f8d2812de2a58f88dc53f015f2c897ede775cfc1fee5|
|NBA DFS Projections - 2026-04-24T184638.442.csv|2026-04-24/F|DK|6c86cd13a25295c5d00ae0c5bca6b8c396ddcd67dc35fbc31161a095e5b54531|
|NBA DFS Projections - 2026-04-24T185905.827.csv|2026-04-24/F|FD|f81f32816194bd338fbcffdf4eddbf46fa8affc4f352557bc438db91fc13853a|
|NBA DFS Projections - 2026-04-24T214743.661.csv|2026-04-24/F|DK|18a35a82a8f293b31d874a8291564d586ac2b8e4b62688512639813b4f90044e|
|NBA DFS Projections - 2026-04-24T215410.197.csv|2026-04-24/F|FD|90550f2c12c46e5e92700dd62640071596159cebf138d460c6b1dd88fc5129c3|
|NBA DFS Projections - 2026-04-24T215559.671.csv|2026-04-24/F|FD|90550f2c12c46e5e92700dd62640071596159cebf138d460c6b1dd88fc5129c3|
|NBA DFS Projections - 2026-04-24T221021.241.csv|2026-04-24/F|FD|90550f2c12c46e5e92700dd62640071596159cebf138d460c6b1dd88fc5129c3|
|NBA DFS Projections - 2026-04-25T114547.142.csv|2026-04-25/F|DK|7626984665db1cfd1784d483f3e775960364b3cb3f8d96d531fb23a15d113ade|
|NBA DFS Projections - 2026-04-25T120733.290.csv|2026-04-25/F|FD|82a4ad0b9ca2588b287dab0d59d029319b4645f334c465813e42c27a9a9bac96|
|NBA DFS Projections - 2026-04-27T193921.246.csv|2026-04-27/F|DK|29307643b618004a7c297344136bbb42e2a9605311a7f30891ab90baf10c6a9c|
|NBA DFS Projections - 2026-04-27T194525.222.csv|2026-04-27/F|DK|7184b45db30fae79fae9a6281eeb89ed6a9109b57d948f8ce32f7ed85d01f5cd|
|NBA DFS Projections - 2026-04-27T194536.620.csv|2026-04-27/F|DK|510475cb22f14f6c5a7ceae4a93ae82a490483317b582a794201f17fb065d714|
|NBA DFS Projections - 2026-04-27T195352.644.csv|2026-04-27/F|FD|0c59482fb1771bf9f12e36d0995f66d2abb7ffa452b1646fa8ffa311c5ae6eb4|
|NBA DFS Projections - 2026-04-27T211934.144.csv|2026-04-27/F|DK|2d5418109db4f55a3173138d88bcfff4c8a7d0610e1e60b492c36c30754f6547|
|NBA DFS Projections - 2026-04-27T212400.339.csv|2026-04-27/F|FD|79097de072020c03969df34a28bcaa0892972624065951eef07c1fd2555981d9|
|NBA DFS Projections - 2026-04-27T212617.135.csv|2026-04-27/F|FD|79097de072020c03969df34a28bcaa0892972624065951eef07c1fd2555981d9|
|NBA DFS Projections - 2026-04-28T173956.354.csv|2026-04-28/F|DK|c5d3d46da89c42e43f04a64447f9ec6dccffb2717df415c3d883c6081ca90798|
|NBA DFS Projections - 2026-04-29T173840.473.csv|2026-04-29/F|DK|53a24bbba1319745374db856f3b14b04838fec8de4e7303d5725bfe417e51bcb|
|NBA DFS Projections - 2026-05-08T185746.973.csv|2026-05-08/F|DK|34e24746217892095b20b368bb030998aa1b13dab54c261258938e014f6a62b6|
|NBA DFS Projections - 2026-05-08T185818.913.csv|2026-05-08/F|FD|2780a7ba6b94b41d39ff53aea96c3795298fdfd99f798d8112d81f8283da85e6|
|NBA DFS Projections - 2026-05-09T144628.962.csv|2026-05-09/F|DK|0ec78c26b5b948beabb0a20ca15481c916d998443b548f93a5c2f55abac83d0d|
|NBA DFS Projections.csv|2025-10-21/Q|FD|1225b4d29b82d5bb153d581dc72d36416148bc61654e4863fe14c7b583e0b54a|
