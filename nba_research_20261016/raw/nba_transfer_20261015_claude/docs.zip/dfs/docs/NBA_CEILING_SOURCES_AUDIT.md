# NBA ceiling production: decomposition and repeatability audit

As of September 22, 2026. Study 2 of the authorized follow-up. This artifact contains research evidence, not production weights, lineup instructions, or a pregame scoring model.

## Evidence and definitions

The consumed source is `nba/analytics/data/research_v2/research_games.parquet`, built from the normalized BDB player feeds. `source_summary.json` records both the input-file hash and a hash of only the consumed columns, so a later refresh of unrelated tracking fields does not obscure which box-score data was tested. Player identity is `pid`; a scoring row is `(season, pid, gid)`. Scoring components reuse the formula in `build_season.dk_points`, including cumulative double-double and triple-double bonuses. This study does not consume the unreliable contest-construction corpus.

| Source season | Scoring rows / players | Dates | Primary eligible profiles | Eligible early / late halves |
|---|---:|---|---:|---:|
| 2024–25 | 20,582 / 551 | October 22–March 10 | 44 | 223 / 0 |
| 2025–26 | 26,457 / 582 | October 21–April 12 | 197 | 244 / 224 |

Source: `source_summary.json → season.{2024,2025}.{rows,players,first_date,last_date,eligible_by_period}`. These repaired samples include eligible Cup games, changing some counts and contrasts from the earlier top-15% report. The older source remains a partial season. At least one minute played is required; this describes appearances, not every rostered game.

The tail is strictly above each player's own period p85. Primary descriptions require at least 50 appearances, 10 tail games and 30 ordinary games. Early and late periods split at January 15 and **independently recompute p85 inside each half**, with at least 30 appearances, five tail games and 20 ordinary games in each half. This yields 157 common eligible players in 2025–26. The 2024–25 source ends too early to support the declared late-half gate: its comparison is explicitly unpowered, and the minimum was not lowered after inspection.

The strict primary year-to-year comparison has only 25 common players because of the older source's short length. A declared equal-calendar comparison, both seasons ending March 10 with at least 40 games, six tail games and 30 ordinary games in each period, yields 199 common players. All qualifying players enter each comparison; eligibility uses both periods and is retrospective.

## Exact accounting

Every one of the 47,039 scoring rows reconciles exactly: maximum absolute difference from stored DK points is **0**. The additive categories are two-point makes ×2; three-point makes ×3.5, including the DK bonus; made free throws; rebounds ×1.25; assists ×1.5; steals ×2; blocks ×2; turnovers ×−0.5; double-double bonus; and triple-double bonus. The source field for each is retained in `research_games.parquet`; the exported `source_profiles.csv` uses `delta_{component}` for tail mean minus ordinary mean.

Two alternative decompositions explain the same contrast; they must not be added as extra categories to the DK partition:

- Minutes versus production per minute: for group mean minutes `M` and **minute-weighted** FPPM `R = total FP / total minutes`, `mean FP = M × R`. The exact symmetric split is `ΔM × mean(R)` plus `ΔR × mean(M)`. An unweighted average of game-level FPPM would not guarantee closure.
- Shot attempts versus conversion: separately for 2PT, 3PT and FT, group mean makes equal mean attempts × aggregate conversion. The same symmetric product identity divides the scoring contrast between volume and conversion. If either group has zero attempts, conversion on that side is unobserved; the explicit convention uses the observed side's rate and allocates the contrast to volume. `*_zero_attempt_convention` preserves this distinction. No conversion skill is inferred from an unobserved rate.

All eligible player-period rows also pass component, minutes and shooting contrast closure checks to within 1e−9. Selecting the highest fantasy-point outcomes naturally selects production; this is accounting, not causal attribution or proof of a pregame advantage.

## Individual examples, independently checked

These four players continue the earlier report's examples; they were not selected as statistical winners. All rows below are 2025–26 primary descriptions. Values are additional DK points per tail game relative to the player's ordinary-game mean.

| Player | Tail / ordinary games | FP gap | Minutes allocation | Per-minute allocation | 2PT | 3PT | FT | Rebounds | Assists |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Jalen Brunson | 11 / 63 | 18.80 | 4.91 | 13.89 | 3.75 | 6.36 | 1.96 | 1.77 | 3.72 |
| Tyrese Maxey | 11 / 59 | 20.46 | 7.51 | 12.95 | 4.86 | 2.43 | 2.88 | 2.10 | 5.11 |
| Karl-Anthony Towns | 12 / 63 | 20.04 | 2.85 | 17.19 | 6.02 | 5.88 | 1.97 | 2.57 | 2.06 |
| Donovan Mitchell | 11 / 59 | 19.11 | 2.19 | 16.92 | 5.53 | 5.21 | 2.00 | 3.28 | 2.34 |

Source: `source_profiles.csv`, `season=2025`, `period=season`, `pid=1628973/1630178/1626157/1628378`; columns `top_games`, `ordinary_games`, `fp_gap`, `delta_*`. The five scoring columns shown are a subset; stocks, turnovers and bonuses explain the remaining gap. Minutes and per-minute allocations already sum to the whole gap and overlap these scoring categories.

Brunson's combined shooting increase divides into **7.72 points from attempt volume and 4.36 from conversion**. Maxey's divides into **8.00 and 2.16**. Their source patterns differ even though both have approximately 19–20 additional DK points in their biggest games. This is a description of realized games, not a prediction that a particular matchup will recreate them.

Independent checks used `raw_player_2025.parquet` directly, filtering `PLAYER-ID` and the shared frame's accepted `GAME-ID` set, and independently recomputed DK scores from `PTS`, `3P`, `TOT`, `A`, `ST`, `BL`, `TO` and bonus categories. Brunson: 74 games, raw p85 **50.55**, tail mean **58.545455**, ordinary mean **39.75**, minutes allocation **4.907707**, 3PT contribution **6.358586**. Maxey: 70 games, raw p85 **61.1625**, tail mean **66.340909**, ordinary mean **45.881356**, minutes allocation **7.507121**, assist contribution **5.105547**. Both raw/frame score comparisons have maximum absolute error **0**, and both calculations match the exported decomposition.

## What repeats

The primary repeatability quantity is the component's share of the player's tail-versus-ordinary FP gap. Spearman correlations compare those shares across common players in earlier and later periods. A second set subtracts the component's **ordinary-game share of FP**, checking whether apparent stability merely repeats ordinary scoring style. These are two distinct questions. No half-specific tail label or same-game scoring component is supplied as a pregame feature.

There are 96 declared metric/comparison rows: 24 source metrics × four comparisons. Of these, 72 are estimable; the 24 older-half comparisons have zero eligible pairs. BH adjustment covers all 72 available p-values in one family, including negative and uninteresting results. Thirty-six rows have positive rho and q≤0.05; these are not 36 independent edges because the measures overlap and some are exact complements. Reported confidence intervals use 2,000 paired-player bootstrap draws, seed 271828.

| Source share | 2025–26 H1→H2 rho, n=157 | 95% bootstrap interval | q | Year→year through March 10 rho, n=199 |
|---|---:|---|---:|---:|
| 3PT scoring | .636 | .523 to .729 | <.001 | .618 |
| Minutes allocation | .491 | .347 to .605 | <.001 | .438 |
| 2PT scoring | .415 | .270 to .538 | <.001 | .382 |
| Rebounds | .375 | .237 to .508 | <.001 | .564 |
| Assists | .253 | .099 to .401 | .004 | .453 |
| Shooting conversion allocation | .246 | .091 to .387 | .005 | .326 |
| Blocks | .194 | .024 to .350 | .032 | .373 |
| Free throws | .174 | .006 to .330 | .055 | .210 |
| Steals | .117 | −.045 to .275 | .207 | .103 |
| Shooting volume allocation | .113 | −.051 to .274 | .218 | .295 |

Source: `source_repeatability.csv → comparison, metric, n, rho, ci_low, ci_high, q`. These tests describe relative profile stability; they do not test the ability to identify the date of a future ceiling game. For same-single-team pairs in 2025–26 (145 players), 3PT rho is .679 and minutes rho is .477; the broad positive patterns do not require the 12 changing-team pairs. Team continuity still does not guarantee role continuity.

**The strongest objection survives:** much of the apparent ceiling-source stability is ordinary player style. After subtracting the ordinary scoring mix, 2025–26 H1→H2 correlations are **3PT .177 (q=.051), 2PT .136 (q=.140), rebounds .020 (q=.859), assists .061 (q=.538)**. The adjusted rebound and assist measures do recur in the larger equal-calendar year comparison (.280 and .215 respectively), so it would also be wrong to declare them universally absent. They are not consistently strong in both temporal comparisons.

Double-double, triple-double and turnover contrasts include some adjusted associations. Triple-double results are particularly sparse: only **16/157 early and 14/157 late** players have a nonzero source contrast; the strict year comparison has **one of 25** on each side. Their nominal correlations should not be read as broad individual-player reliability. `nonzero_early_n` and `nonzero_late_n` expose that support for every row.

Across the 197 primary eligible 2025–26 players, the equal-player median minutes allocation is **37.3%** of the ceiling gap, with the complementary per-minute allocation **62.7%**. The median shooting-volume allocation is **38.1%** and conversion allocation **15.9%**. These last two are medians of different within-player ratios and are not pieces of an additive median pie. Source: `source_summary.json → season.2025.source_share_distribution`.

## Validation and gap check

`python -m pytest nba/analytics/test_ceiling_sources_study.py -q`: **12 passed**. Known-bad cases prove rejection of a false DK score, missing/nonfinite input, makes exceeding attempts, duplicate player/game, negative box counts, subminute outcomes and pooled-season labels. Other tests cover the zero-attempt convention, all exact decompositions, future-period mutation, suppression of insufficient tails, constant-source correlation, and vectorized bootstrap agreement with an independent scalar Spearman calculation including tied ranks.

Existing layers deliberately excluded: daily tracking is unnecessary for exact 2PT/3PT/FT accounting and has separate coverage issues; aggregate Synergy lacks the game-time detail needed for this decomposition; market lines, opponent funnels and injury proxies concern predictors rather than scoring identity; roster membership does not establish historical role continuity; contest construction and salary/ownership data are outside this descriptive question. The parent study audits predictive layers and role changes separately. No NFL environment formula or ADP analogy is imported into NBA scoring.

## FINDINGS

**Data:** Exact scoring closure holds across 47,039 rows; 197 recent-season primary profiles and 157 common half-season profiles meet declared gates. Source profiles differ materially across players, and raw component shares often repeat. All counts, deltas and repeatability estimates are in the three `source_*.csv` outputs and `source_summary.json` cited above.

**Inference:** A useful player dossier can describe *how* prior ceilings were assembled. The ordinary-mix sensitivity refutes a strong claim that raw source persistence alone establishes a special repeatable ceiling mechanism. Steal-share and recent-season shot-volume-share persistence are weak in this sample.

**Assumptions/unresolved:** Strict sample p85 is a retrospective definition; small tails are noisy; paired-player bootstrap intervals do not account fully for shared team/game shocks; role changes and opportunity shifts can confound comparisons; the older source is incomplete after March 10; bonus-source correlations can be sparse. None of this is a calibrated future ceiling probability.

## CONFLICTS

The older top-15% artifact omitted Cup games, so its player counts and tail means are superseded for this study. No current result justifies turning realized shooting accuracy, actual minutes or eventual box-score components into pregame features. A claim that all 96 declared tests were powered would be false: only 72 have eligible data, and the full-season year comparison has just 25 players.

## DECISION POINTS

No production setting needs a decision to complete this research. If the owner later wants these profiles used in a forecast, the options are descriptive dossier fields only, or a separately specified prior-data source model tested on unseen dates. Recommendation: keep the current decomposition descriptive; evaluate any forecast extension only after role/context controls and a locked prospective test.
